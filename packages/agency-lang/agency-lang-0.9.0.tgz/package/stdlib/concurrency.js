import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { _withLock } from "agency-lang/stdlib-lib/concurrency.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/concurrency.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/concurrency.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/concurrency.agency");
}
__registerGlobalsInit("stdlib/concurrency.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/concurrency.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
async function __withLock_impl(name, timeoutMs = __UNSET, warnAfterMs = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/concurrency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["name"] = name;
  __stack.args["timeoutMs"] = timeoutMs === __UNSET ? null : timeoutMs;
  __stack.args["warnAfterMs"] = warnAfterMs === __UNSET ? null : warnAfterMs;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/concurrency.agency", scopeName: "withLock", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
    if ("timeoutMs" in __overrides) {
      timeoutMs = __overrides["timeoutMs"];
      __stack.args["timeoutMs"] = timeoutMs;
    }
    if ("warnAfterMs" in __overrides) {
      warnAfterMs = __overrides["warnAfterMs"];
      __stack.args["warnAfterMs"] = warnAfterMs;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "withLock",
            args: {
              name,
              timeoutMs,
              warnAfterMs,
              block
            },
            moduleId: "stdlib/concurrency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_withLock, {
          type: "positional",
          args: [__stack.args.name, __stack.args.timeoutMs, __stack.args.warnAfterMs, __stack.args.block]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "withLock");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function withLock threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "withLock"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "withLock",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "withLock",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const withLock = __AgencyFunction.create({
  name: "withLock",
  module: "stdlib/concurrency.agency",
  fn: __withLock_impl,
  params: [{
    name: "name",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "timeoutMs",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "warnAfterMs",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "withLock",
    description: `Run a block while holding a named per-run mutex. Branches of the same run
  that use the same lock name execute this block one at a time. Branches
  using different names continue concurrently. The lock is released
  automatically when the block returns, throws, or unwinds for an interrupt.

  @param name - Lock name; use stable names like "std::tty" for shared resources
  @param timeoutMs - Maximum time to wait before failing without acquiring the lock; null waits indefinitely
  @param warnAfterMs - Wait time before printing a diagnostic warning; defaults to 30s
  @param block - The work to run while holding the lock`,
    schema: z.object({ "name": z.string(), "timeoutMs": z.union([z.number(), z.null()]).describe("Default: null"), "warnAfterMs": z.union([z.number(), z.null()]).describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
async function __concurrencyPool_impl(size, items, block) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/concurrency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["size"] = size;
  __stack.args["items"] = items;
  __stack.args["block"] = block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/concurrency.agency", scopeName: "concurrencyPool", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("size" in __overrides) {
      size = __overrides["size"];
      __stack.args["size"] = size;
    }
    if ("items" in __overrides) {
      items = __overrides["items"];
      __stack.args["items"] = items;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "concurrencyPool",
            args: {
              size,
              items,
              block
            },
            moduleId: "stdlib/concurrency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.indexed = [];
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.index = 0;
      });
      await runner.loop(4, async () => __stack.args.items, async (item, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          await __callMethod(__stack.locals.indexed, "push", {
            type: "positional",
            args: [[item, __stack.locals.index]]
          });
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.index = __stack.locals.index + 1;
        });
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.chunks = [];
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.worker = 0;
      });
      await runner.whileLoop(7, async () => __stack.locals.worker < __stack.args.size, async (runner2) => {
        await runner2.step(0, async (runner3) => {
          await __callMethod(__stack.locals.chunks, "push", {
            type: "positional",
            args: [[]]
          });
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.worker = __stack.locals.worker + 1;
        });
      });
      await runner.step(8, async (runner2) => {
        __stack.locals.position = 0;
      });
      await runner.loop(9, async () => __stack.locals.indexed, async (pair, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          await __callMethod(__stack.locals.chunks[__stack.locals.position % __stack.args.size], "push", {
            type: "positional",
            args: [pair]
          });
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.position = __stack.locals.position + 1;
        });
      });
      await runner.step(10, async (runner2) => {
        __stack.locals.chunkResults = await runner2.fork(10, __stack.locals.chunks, async (__forkItem, __forkIndex, __forkBranchStack) => {
          const __bstack = __forkBranchStack.getNewState();
          const __self2 = __bstack.locals;
          const __bframe___block_0 = __bstack;
          const chunk = __forkItem;
          __bstack.args["chunk"] = __forkItem;
          const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/concurrency.agency", scopeName: "__block_0" });
          try {
            await runner3.step(0, async (runner4) => {
              __bstack.locals.chunkOut = [];
            });
            await runner3.loop(1, async () => __bstack.args.chunk, async (pair, _, runner4) => {
              await runner4.step(0, async (runner5) => {
                await __callMethod(__bstack.locals.chunkOut, "push", {
                  type: "positional",
                  args: [[__nn(pair[1]), await __call(__stack.args.block, {
                    type: "positional",
                    args: [__nn(pair[0])]
                  })]]
                });
              });
            });
            await runner3.step(2, async (runner4) => {
              runner4.halt(__bstack.locals.chunkOut);
              return;
            });
            return runner3.halted ? runner3.haltResult : void 0;
          } finally {
            __forkBranchStack.pop();
          }
        }, "all", getRuntimeContext().stack, false);
        if (hasInterrupts(__stack.locals.chunkResults)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.chunkResults);
          return;
        }
        if (isAborted(__stack.locals.chunkResults)) {
          runner2.halt(__stack.locals.chunkResults.carryThrough(__stack, "concurrencyPool"));
          return;
        }
      });
      await runner.step(11, async (runner2) => {
        __stack.locals.results = await __call(map, {
          type: "named",
          positionalArgs: [__stack.args.items],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/concurrency.agency", fn: async (_) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_1 = __bstack;
            __bstack.args["_"] = _;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/concurrency.agency", scopeName: "__block_1" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(null);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_1");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "_", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.results)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.results);
          return;
        }
        if (isAborted(__stack.locals.results)) {
          runner2.halt(__stack.locals.results.carryThrough(__stack, "concurrencyPool"));
          return;
        }
      });
      await runner.loop(12, async () => __stack.locals.chunkResults, async (chunkOut, _, runner2) => {
        await runner2.loop(0, async () => chunkOut, async (entry, _2, runner3) => {
          await runner3.step(0, async (runner4) => {
            __stack.locals.results[__nn(entry[0])] = __nn(entry[1]);
          });
        });
      });
      await runner.step(13, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.results);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "concurrencyPool");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function concurrencyPool threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "concurrencyPool"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "concurrencyPool",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "concurrencyPool",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const concurrencyPool = __AgencyFunction.create({
  name: "concurrencyPool",
  module: "stdlib/concurrency.agency",
  fn: __concurrencyPool_impl,
  params: [{
    name: "size",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "items",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "concurrencyPool",
    description: `Run a block in parallel across a bounded pool of workers.

  @param size - Number of concurrent workers to run
  @param items - The items to process
  @param block - The work to run in each worker`,
    schema: z.object({ "size": z.number(), "items": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/concurrency.agency:withLock": { "1": { "line": 48, "col": 2 } }, "stdlib/concurrency.agency:concurrencyPool": { "2": { "line": 70, "col": 2 }, "3": { "line": 71, "col": 2 }, "4": { "line": 72, "col": 2 }, "5": { "line": 76, "col": 2 }, "6": { "line": 77, "col": 2 }, "7": { "line": 78, "col": 2 }, "8": { "line": 82, "col": 2 }, "9": { "line": 83, "col": 2 }, "10": { "line": 87, "col": 2 }, "11": { "line": 94, "col": 2 }, "12": { "line": 95, "col": 2 }, "13": { "line": 100, "col": 2 }, "4.0": { "line": 73, "col": 4 }, "4.1": { "line": 74, "col": 4 }, "7.0": { "line": 79, "col": 4 }, "7.1": { "line": 80, "col": 4 }, "9.0": { "line": 84, "col": 4 }, "9.1": { "line": 85, "col": 4 }, "12.0.0": { "line": 97, "col": 6 }, "12.0": { "line": 96, "col": 4 } }, "stdlib/concurrency.agency:__block_0": { "10.0": { "line": 88, "col": 4 }, "10.1.0": { "line": 90, "col": 6 }, "10.1": { "line": 89, "col": 4 }, "10.2": { "line": 92, "col": 4 } }, "stdlib/concurrency.agency:__block_1": {} };
export {
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  concurrencyPool,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  reject,
  respondToInterrupts,
  rewindFrom,
  withLock
};
