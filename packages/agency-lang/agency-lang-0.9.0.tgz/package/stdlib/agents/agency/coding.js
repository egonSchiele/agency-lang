import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { compile } from "agency-lang/stdlib/agency.js";
import { agencyReviewAgent } from "agency-lang/stdlib/agents/agency/review.js";
import { renderFeedback, feedbackHasErrors } from "agency-lang/stdlib/agents/lib/feedback.js";
import { llmOptions, withContext } from "agency-lang/stdlib/agents/lib/shared.js";
import { agencyDocTools, agencyCodeTools, readOnlyFileTools } from "agency-lang/stdlib/agents/lib/toolkits.js";
import { fetch, fetchJSON, fetchMarkdown } from "agency-lang/stdlib/http.js";
import { revise, Critique } from "agency-lang/stdlib/strategy.js";
import { agentSkill } from "agency-lang/stdlib/skills.js";
import { systemMessage, threadIsNew } from "agency-lang/stdlib/thread.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  runPrompt,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  __registerCallbacksInit,
  success,
  failure,
  isFailure,
  stampFailureBoundary,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __threads,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/agents/agency/coding.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(compile);
__registerTool(agencyReviewAgent);
__registerTool(renderFeedback);
__registerTool(feedbackHasErrors);
__registerTool(llmOptions);
__registerTool(withContext);
__registerTool(agencyDocTools);
__registerTool(agencyCodeTools);
__registerTool(readOnlyFileTools);
__registerTool(fetch);
__registerTool(fetchJSON);
__registerTool(fetchMarkdown);
__registerTool(revise);
__registerTool(Critique);
__registerTool(agentSkill);
__registerTool(systemMessage);
__registerTool(threadIsNew);
let __staticInitPromise = null;
let systemPrompt = __UNINIT_STATIC;
let skills = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    systemPrompt = __deepFreeze(`You write code in the Agency language.
Agency syntax rules you MUST follow:
- Functions: def name(param: Type): ReturnType { ... }
- Nodes: node name() { ... } \u2014 export the entry node.
- if / while / for require parentheses AND curly braces: if (x > 5) { ... }
- The ONLY for loop is for-in over an array: for (item in items) { ... }
  There is NO C-style for (let i = 0; i < n; i++) loop. To count, use a
  while loop:
    let i = 1
    while (i <= 3) {
      print(i)
      i = i + 1
    }
- Declare variables with let or const before use.
- No Python-style colon blocks. Always { ... }.

Here are complete, correct Agency programs. Copy their structure: the imports, the \`node main\`, and the explicit \`return\` at the end.

EXAMPLE 1, compute and return a value:
node main(): number {
  let total = 0
  for (x in [1, 2, 3]) {
    total = total + x
  }
  return total
}

EXAMPLE 2, import a tool and define and call a helper:
import { bash } from "std::shell"
def greet(name: string): string {
  return "Hello, \${name}"
}
node main(): string {
  bash(command: "echo starting")
  return greet("world")
}

EXAMPLE 3, get structured output from the model by annotating the result type:
type Summary = { title: string; points: string[] }
node main(): Summary {
  const s: Summary = llm("Summarize the water cycle with a title and three bullet points.")
  return s
}

Commonly useful standard library modules:
- std::shell: bash, exec, ls, grep, glob (run commands, inspect files)
- std::http: fetch, fetchJSON (call web APIs)
- std::array: map, filter (transform lists)
- std::agency: runCode (run Agency code)

If you are unsure about syntax or a standard-library function, read the
relevant page with the docs tool before writing code. When a diagnostic code
(AG####) comes back, look it up in the diagnostics reference rather than
guessing at the fix.

Typecheck your draft before returning it, and fix what it reports. An
attempt you already know does not typecheck wastes a whole round.
Return only the complete program in the code field.`);
    skills = __deepFreeze(await __call(agentSkill, {
      type: "positional",
      args: [`agency/coding`]
    }));
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    systemPrompt,
    skills
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/agents/agency/coding.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/agents/agency/coding.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/agents/agency/coding.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/agents/agency/coding.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/agents/agency/coding.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const WriteFailure = z.object({ "source": z.string(), "problems": z.array(z.string()) });
const GeneratedCode = z.object({ "code": z.string() });
async function __buildTools_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/coding.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/coding.agency", scopeName: "buildTools", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildTools",
            args: {},
            moduleId: "stdlib/agents/agency/coding.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt([...await __call(agencyDocTools, {
          type: "positional",
          args: []
        }), ...await __call(agencyCodeTools, {
          type: "positional",
          args: []
        }), ...await __call(readOnlyFileTools, {
          type: "positional",
          args: []
        }), __readStatic(fetch, "fetch", ""), __readStatic(fetchJSON, "fetchJSON", ""), __readStatic(fetchMarkdown, "fetchMarkdown", ""), __readStatic(skills, "skills", "stdlib/agents/agency/coding.agency")]);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildTools");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildTools threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildTools"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildTools",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildTools",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildTools = __AgencyFunction.create({
  name: "buildTools",
  module: "stdlib/agents/agency/coding.agency",
  fn: __buildTools_impl,
  params: [],
  toolDefinition: {
    name: "buildTools",
    description: `Return the Agency writer's tools: the bundled documentation, the source
  inspectors it checks drafts with, read-only access to the project it is
  writing for, and fetches for a named external resource.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __syntaxHintFor_impl(errors) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/coding.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["errors"] = errors;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/coding.agency", scopeName: "syntaxHintFor", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("errors" in __overrides) {
      errors = __overrides["errors"];
      __stack.args["errors"] = errors;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "syntaxHintFor",
            args: {
              errors
            },
            moduleId: "stdlib/agents/agency/coding.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => /for loop condition/.test(__stack.args.errors),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(`Reminder: Agency has no C-style for loop. Count with a while loop, or iterate with for (x in items).`);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(``);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "syntaxHintFor");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function syntaxHintFor threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "syntaxHintFor"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "syntaxHintFor",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "syntaxHintFor",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const syntaxHintFor = __AgencyFunction.create({
  name: "syntaxHintFor",
  module: "stdlib/agents/agency/coding.agency",
  fn: __syntaxHintFor_impl,
  params: [{
    name: "errors",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "syntaxHintFor",
    description: `Return a specific syntax reminder to inject next to a diagnostic, or ""
  when no known pattern matches.

  @param errors - The rendered diagnostic text to match against`,
    schema: z.object({ "errors": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __withSyntaxHint_impl(findings) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/coding.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["findings"] = findings;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/coding.agency", scopeName: "withSyntaxHint", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("findings" in __overrides) {
      findings = __overrides["findings"];
      __stack.args["findings"] = findings;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "withSyntaxHint",
            args: {
              findings
            },
            moduleId: "stdlib/agents/agency/coding.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.hint = await __call(syntaxHintFor, {
          type: "positional",
          args: [__stack.args.findings]
        });
        if (hasInterrupts(__stack.locals.hint)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.hint);
          return;
        }
        if (isAborted(__stack.locals.hint)) {
          runner2.halt(__stack.locals.hint.carryThrough(__stack, "withSyntaxHint"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => __eq(__stack.locals.hint, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.__ifbranch_3 = __stack.args.findings;
            });
            await runner2.step(1, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__ifbranch_3);
              return;
            });
          }
        }
      ], async (runner2) => {
        await runner2.step(2, async (runner3) => {
          __stack.locals.__ifbranch_2 = `${__stack.locals.hint}

${__stack.args.findings}`;
        });
        await runner2.step(3, async (runner3) => {
          runner3.exitMatch(1, __stack.locals.__ifbranch_2);
          return;
        });
      }, { matchId: 1 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "withSyntaxHint");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function withSyntaxHint threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "withSyntaxHint"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "withSyntaxHint",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "withSyntaxHint",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const withSyntaxHint = __AgencyFunction.create({
  name: "withSyntaxHint",
  module: "stdlib/agents/agency/coding.agency",
  fn: __withSyntaxHint_impl,
  params: [{
    name: "findings",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "withSyntaxHint",
    description: "No description provided.",
    schema: z.object({ "findings": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __hasMainNode_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/coding.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/coding.agency", scopeName: "hasMainNode", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "hasMainNode",
            args: {
              source
            },
            moduleId: "stdlib/agents/agency/coding.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(/node\s+main\s*\(/.test(__stack.args.source));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "hasMainNode");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function hasMainNode threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "hasMainNode"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "hasMainNode",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "hasMainNode",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const hasMainNode = __AgencyFunction.create({
  name: "hasMainNode",
  module: "stdlib/agents/agency/coding.agency",
  fn: __hasMainNode_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "hasMainNode",
    description: "No description provided.",
    schema: z.object({ "source": z.string() })
  },
  exported: false
}, __toolRegistry);
const WriteOutcome = z.object({ "valid": z.boolean(), "source": z.string(), "problems": z.array(z.string()) });
async function __outcomeToResult_impl(outcome) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/coding.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["outcome"] = outcome;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/coding.agency", scopeName: "outcomeToResult", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("outcome" in __overrides) {
      outcome = __overrides["outcome"];
      __stack.args["outcome"] = outcome;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "outcomeToResult",
            args: {
              outcome
            },
            moduleId: "stdlib/agents/agency/coding.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.outcome.valid,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await success(__stack.args.outcome.source));
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(failure({
          "source": __stack.args.outcome.source,
          "problems": __stack.args.outcome.problems
        }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "outcomeToResult", args: __stack.args }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "outcomeToResult");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function outcomeToResult threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "outcomeToResult"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "outcomeToResult",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "outcomeToResult",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const outcomeToResult = __AgencyFunction.create({
  name: "outcomeToResult",
  module: "stdlib/agents/agency/coding.agency",
  fn: __outcomeToResult_impl,
  params: [{
    name: "outcome",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "outcomeToResult",
    description: "No description provided.",
    schema: z.object({ "outcome": WriteOutcome })
  },
  exported: false
}, __toolRegistry);
async function __checkSource_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/coding.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/coding.agency", scopeName: "checkSource", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "checkSource",
            args: {
              source
            },
            moduleId: "stdlib/agents/agency/coding.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.reviewed = await __call(agencyReviewAgent, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            source: __stack.args.source
          }
        });
        if (hasInterrupts(__stack.locals.reviewed)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.reviewed);
          return;
        }
        if (isAborted(__stack.locals.reviewed)) {
          runner2.halt(__stack.locals.reviewed.carryThrough(__stack, "checkSource"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await __call(feedbackHasErrors, {
            type: "positional",
            args: [__stack.locals.reviewed]
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.findings = await __call(renderFeedback, {
                type: "positional",
                args: [__stack.locals.reviewed]
              });
              if (hasInterrupts(__stack.locals.findings)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.findings);
                return;
              }
              if (isAborted(__stack.locals.findings)) {
                runner3.halt(__stack.locals.findings.carryThrough(__stack, "checkSource"));
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                "accepted": false,
                "feedback": `That code has problems:
${await __call(withSyntaxHint, {
                  type: "positional",
                  args: [__stack.locals.findings]
                })}
Return a corrected complete program.`
              });
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.compiled = await __call(compile, {
          type: "positional",
          args: [__stack.args.source]
        });
        if (hasInterrupts(__stack.locals.compiled)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.compiled);
          return;
        }
        if (isAborted(__stack.locals.compiled)) {
          runner2.halt(__stack.locals.compiled.carryThrough(__stack, "checkSource"));
          return;
        }
      });
      await runner.ifElse(4, [
        {
          condition: async () => await isFailure(__stack.locals.compiled),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.compileErr = __stack.locals.compiled.error;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                "accepted": false,
                "feedback": `That code failed to compile:
${await __call(withSyntaxHint, {
                  type: "positional",
                  args: [`${__stack.locals.compileErr}`]
                })}
Return a corrected complete program.`
              });
              return;
            });
          }
        }
      ]);
      await runner.ifElse(5, [
        {
          condition: async () => !await __call(hasMainNode, {
            type: "positional",
            args: [__stack.args.source]
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                "accepted": false,
                "feedback": `The program compiles but has no \`node main\`. Every program MUST have a node named \`main\` as its entry point. Add one and return the complete program.`
              });
              return;
            });
          }
        }
      ]);
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "accepted": true,
          "feedback": ``
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "checkSource");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function checkSource threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "checkSource"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "checkSource",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "checkSource",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const checkSource = __AgencyFunction.create({
  name: "checkSource",
  module: "stdlib/agents/agency/coding.agency",
  fn: __checkSource_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "checkSource",
    description: "No description provided.",
    schema: z.object({ "source": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __outcomeFor_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/coding.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/coding.agency", scopeName: "outcomeFor", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "outcomeFor",
            args: {
              source
            },
            moduleId: "stdlib/agents/agency/coding.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.critique = await __call(checkSource, {
          type: "positional",
          args: [__stack.args.source]
        });
        if (hasInterrupts(__stack.locals.critique)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.critique);
          return;
        }
        if (isAborted(__stack.locals.critique)) {
          runner2.halt(__stack.locals.critique.carryThrough(__stack, "outcomeFor"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => __stack.locals.critique.accepted,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                "valid": true,
                "source": __stack.args.source,
                "problems": []
              });
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "valid": false,
          "source": __stack.args.source,
          "problems": [__stack.locals.critique.feedback]
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "outcomeFor");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function outcomeFor threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "outcomeFor"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "outcomeFor",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "outcomeFor",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const outcomeFor = __AgencyFunction.create({
  name: "outcomeFor",
  module: "stdlib/agents/agency/coding.agency",
  fn: __outcomeFor_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "outcomeFor",
    description: "No description provided.",
    schema: z.object({ "source": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __critiqueOf_impl(outcome) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/coding.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["outcome"] = outcome;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/coding.agency", scopeName: "critiqueOf", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("outcome" in __overrides) {
      outcome = __overrides["outcome"];
      __stack.args["outcome"] = outcome;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "critiqueOf",
            args: {
              outcome
            },
            moduleId: "stdlib/agents/agency/coding.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.outcome.valid,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                "accepted": true,
                "feedback": ``
              });
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "accepted": false,
          "feedback": __nn(__stack.args.outcome.problems[0])
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "critiqueOf");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function critiqueOf threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "critiqueOf"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "critiqueOf",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "critiqueOf",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const critiqueOf = __AgencyFunction.create({
  name: "critiqueOf",
  module: "stdlib/agents/agency/coding.agency",
  fn: __critiqueOf_impl,
  params: [{
    name: "outcome",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "critiqueOf",
    description: "No description provided.",
    schema: z.object({ "outcome": WriteOutcome })
  },
  exported: false
}, __toolRegistry);
async function __generateLoop_impl(task, context, maxAttempts, model, provider, extraTools) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/coding.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["context"] = context;
  __stack.args["maxAttempts"] = maxAttempts;
  __stack.args["model"] = model;
  __stack.args["provider"] = provider;
  __stack.args["extraTools"] = extraTools;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/coding.agency", scopeName: "generateLoop", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("maxAttempts" in __overrides) {
      maxAttempts = __overrides["maxAttempts"];
      __stack.args["maxAttempts"] = maxAttempts;
    }
    if ("model" in __overrides) {
      model = __overrides["model"];
      __stack.args["model"] = model;
    }
    if ("provider" in __overrides) {
      provider = __overrides["provider"];
      __stack.args["provider"] = provider;
    }
    if ("extraTools" in __overrides) {
      extraTools = __overrides["extraTools"];
      __stack.args["extraTools"] = extraTools;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "generateLoop",
            args: {
              task,
              context,
              maxAttempts,
              model,
              provider,
              extraTools
            },
            moduleId: "stdlib/agents/agency/coding.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => await __call(threadIsNew, {
            type: "positional",
            args: []
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(systemMessage, {
                type: "positional",
                args: [__readStatic(systemPrompt, "systemPrompt", "stdlib/agents/agency/coding.agency")]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "generateLoop"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __stack.locals.opening = `Write an Agency program for this task:
<task>
${await __call(withContext, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            task: __stack.args.task,
            context: __stack.args.context
          }
        })}
</task>`;
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(revise, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            maxAttempts: __stack.args.maxAttempts,
            check: critiqueOf
          },
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/agents/agency/coding.agency", fn: async (critique) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["critique"] = critique;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/agency/coding.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
              });
              await runner3.step(1, async (runner4) => {
                __bstack.locals.prompt = __bstack.args.critique;
              });
              await runner3.ifElse(2, [
                {
                  condition: async () => __eq(__bstack.args.critique, ``),
                  body: async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      __bstack.locals.prompt = __stack.locals.opening;
                    });
                  }
                }
              ]);
              await runner3.step(3, async (runner4) => {
                __self2.__removedTools = __self2.__removedTools || [];
                __bstack.locals.generated = await runPrompt({
                  prompt: __bstack.locals.prompt,
                  messages: __threads().getOrCreateActive(),
                  responseFormat: z.object({
                    response: GeneratedCode
                  }),
                  clientConfig: await __call(llmOptions, {
                    type: "named",
                    positionalArgs: [],
                    namedArgs: {
                      model: __stack.args.model,
                      provider: __stack.args.provider,
                      tools: await __callMethod(await await __call(buildTools, {
                        type: "positional",
                        args: []
                      }), "concat", {
                        type: "positional",
                        args: [__stack.args.extraTools]
                      })
                    }
                  }),
                  draftSchema: WriteOutcome,
                  maxToolCallRounds: 10,
                  removedTools: __self2.__removedTools,
                  destructiveSink: __self2,
                  checkpointInfo: runner4.getCheckpointInfo()
                });
                if (hasInterrupts(__bstack.locals.generated)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__bstack.locals.generated);
                  return;
                }
              });
              await runner3.step(4, async (runner4) => {
                __bstack.locals.outcome = await __call(outcomeFor, {
                  type: "named",
                  positionalArgs: [],
                  namedArgs: {
                    source: __bstack.locals.generated.code
                  }
                });
                if (hasInterrupts(__bstack.locals.outcome)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__bstack.locals.outcome);
                  return;
                }
                if (isAborted(__bstack.locals.outcome)) {
                  runner4.halt(__bstack.locals.outcome.carryThrough(__bstack, "__block_0"));
                  return;
                }
              });
              await runner3.step(5, async (runner4) => {
                const __funcResult = await __call(saveDraft, {
                  type: "positional",
                  args: [__bstack.locals.outcome]
                });
                if (hasInterrupts(__funcResult)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__funcResult);
                  return;
                }
                if (isAborted(__funcResult)) {
                  runner4.halt(__funcResult.carryThrough(__bstack, "__block_0"));
                  return;
                }
              });
              await runner3.step(6, async (runner4) => {
                runner4.halt(__bstack.locals.outcome);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_0");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "critique", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "generateLoop");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function generateLoop threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "generateLoop"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "generateLoop",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "generateLoop",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const generateLoop = __AgencyFunction.create({
  name: "generateLoop",
  module: "stdlib/agents/agency/coding.agency",
  fn: __generateLoop_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxAttempts",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "model",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "provider",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "extraTools",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "generateLoop",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "context": z.string(), "maxAttempts": z.number(), "model": z.string(), "provider": z.string(), "extraTools": z.array(z.any()) })
  },
  exported: false
}, __toolRegistry);
async function __agencyCodingAgent_impl(task, context = __UNSET, maxAttempts = __UNSET, maxCost = __UNSET, maxTime = __UNSET, model = __UNSET, provider = __UNSET, session = __UNSET, extraTools = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/coding.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["context"] = context === __UNSET ? `` : context;
  __stack.args["maxAttempts"] = maxAttempts === __UNSET ? 3 : maxAttempts;
  __stack.args["maxCost"] = maxCost === __UNSET ? 20 : maxCost;
  __stack.args["maxTime"] = maxTime === __UNSET ? 9e5 : maxTime;
  __stack.args["model"] = model === __UNSET ? `` : model;
  __stack.args["provider"] = provider === __UNSET ? `` : provider;
  __stack.args["session"] = session === __UNSET ? `` : session;
  __stack.args["extraTools"] = extraTools === __UNSET ? [] : extraTools;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/coding.agency", scopeName: "agencyCodingAgent", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("maxAttempts" in __overrides) {
      maxAttempts = __overrides["maxAttempts"];
      __stack.args["maxAttempts"] = maxAttempts;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
    if ("maxTime" in __overrides) {
      maxTime = __overrides["maxTime"];
      __stack.args["maxTime"] = maxTime;
    }
    if ("model" in __overrides) {
      model = __overrides["model"];
      __stack.args["model"] = model;
    }
    if ("provider" in __overrides) {
      provider = __overrides["provider"];
      __stack.args["provider"] = provider;
    }
    if ("session" in __overrides) {
      session = __overrides["session"];
      __stack.args["session"] = session;
    }
    if ("extraTools" in __overrides) {
      extraTools = __overrides["extraTools"];
      __stack.args["extraTools"] = extraTools;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "agencyCodingAgent",
            args: {
              task,
              context,
              maxAttempts,
              maxCost,
              maxTime,
              model,
              provider,
              session,
              extraTools
            },
            moduleId: "stdlib/agents/agency/coding.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.captured = await __call(_guard, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            cost: __stack.args.maxCost,
            time: __stack.args.maxTime
          },
          blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/agents/agency/coding.agency", fn: async () => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_1 = __bstack;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/agency/coding.agency", scopeName: "__block_1" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.outcome = {
                  "valid": false,
                  "source": ``,
                  "problems": [`generation never ran`]
                };
              });
              await runner3.thread(1, "create", async () => ({ label: `agencyCodingAgent`, session: __stack.args.session }), async (runner4) => {
                await runner4.step(0, async (runner5) => {
                  __bstack.locals.outcome = await __call(generateLoop, {
                    type: "named",
                    positionalArgs: [],
                    namedArgs: {
                      task: __stack.args.task,
                      context: __stack.args.context,
                      maxAttempts: __stack.args.maxAttempts,
                      model: __stack.args.model,
                      provider: __stack.args.provider,
                      extraTools: __stack.args.extraTools
                    }
                  });
                  if (hasInterrupts(__bstack.locals.outcome)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__bstack.locals.outcome);
                    return;
                  }
                  if (isAborted(__bstack.locals.outcome)) {
                    runner5.halt(__bstack.locals.outcome.carryThrough(__bstack, "__block_1"));
                    return;
                  }
                });
              });
              await runner3.step(2, async (runner4) => {
                runner4.halt(__bstack.locals.outcome);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_1");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.captured)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.captured);
          return;
        }
        if (isAborted(__stack.locals.captured)) {
          runner2.halt(__stack.locals.captured.carryThrough(__stack, "agencyCodingAgent"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.captured),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure({
                "source": ``,
                "problems": [`agencyCodingAgent stopped before generating: ${__stack.locals.captured.error}`]
              }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "agencyCodingAgent", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(outcomeToResult, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            outcome: __stack.locals.captured.value
          }
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "agencyCodingAgent");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function agencyCodingAgent threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "agencyCodingAgent"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "agencyCodingAgent",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "agencyCodingAgent",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const agencyCodingAgent = __AgencyFunction.create({
  name: "agencyCodingAgent",
  module: "stdlib/agents/agency/coding.agency",
  fn: __agencyCodingAgent_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxAttempts",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxTime",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "model",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "provider",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "session",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "extraTools",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "agencyCodingAgent",
    description: `Write an Agency program for the task. Iterates until the source parses,
  typechecks, compiles, and has a node main, or attempts run out. On failure
  returns the last attempted source with the problems found in it.

  @param task - What the program should do
  @param context - Extra material folded into the prompt, or ""
  @param maxAttempts - Generation attempts before giving up
  @param maxCost - Hard spend cap
  @param maxTime - Hard wall-clock cap
  @param model - Model override, or "" for the ambient model
  @param provider - Provider for the model override
  @param session - Session name to share a thread across calls, or "" for isolated
  @param extraTools - Extra tools to offer the LLM, appended to the built-in set`,
    schema: z.object({ "task": z.string(), "context": z.string().nullable().describe("Default: "), "maxAttempts": z.number().nullable().describe("Default: 3"), "maxCost": z.number().nullable().describe("Default: $20.00"), "maxTime": z.number().nullable().describe("Default: 15m"), "model": z.string().nullable().describe("Default: "), "provider": z.string().nullable().describe("Default: "), "session": z.string().nullable().describe("Default: "), "extraTools": z.array(z.any()).nullable().describe("Default: []") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/agents/agency/coding.agency:buildTools": { "1": { "line": 110, "col": 2 } }, "stdlib/agents/agency/coding.agency:syntaxHintFor": { "1": { "line": 128, "col": 2 }, "2": { "line": 131, "col": 2 }, "1.0": { "line": 129, "col": 4 } }, "stdlib/agents/agency/coding.agency:withSyntaxHint": { "1": { "line": 138, "col": 2 }, "2": { "line": 139, "col": 9 }, "3": { "line": 139, "col": 2 }, "2.0": { "line": 139, "col": 28 }, "2.1": { "line": 139, "col": 28 } }, "stdlib/agents/agency/coding.agency:hasMainNode": { "1": { "line": 145, "col": 2 } }, "stdlib/agents/agency/coding.agency:outcomeToResult": { "1": { "line": 160, "col": 2 }, "2": { "line": 163, "col": 2 }, "1.0": { "line": 161, "col": 4 } }, "stdlib/agents/agency/coding.agency:checkSource": { "1": { "line": 170, "col": 2 }, "2": { "line": 171, "col": 2 }, "3": { "line": 178, "col": 2 }, "4": { "line": 179, "col": 2 }, "5": { "line": 185, "col": 2 }, "6": { "line": 191, "col": 2 }, "2.0": { "line": 172, "col": 4 }, "2.1": { "line": 173, "col": 4 }, "4.0": { "line": 179, "col": 2 }, "4.1": { "line": 180, "col": 4 }, "5.0": { "line": 186, "col": 4 } }, "stdlib/agents/agency/coding.agency:outcomeFor": { "1": { "line": 198, "col": 2 }, "2": { "line": 199, "col": 2 }, "3": { "line": 202, "col": 2 }, "2.0": { "line": 200, "col": 4 } }, "stdlib/agents/agency/coding.agency:critiqueOf": { "1": { "line": 206, "col": 2 }, "2": { "line": 209, "col": 2 }, "1.0": { "line": 207, "col": 4 } }, "stdlib/agents/agency/coding.agency:generateLoop": { "1": { "line": 220, "col": 2 }, "2": { "line": 223, "col": 2 }, "3": { "line": 224, "col": 2 }, "1.0": { "line": 221, "col": 4 } }, "stdlib/agents/agency/coding.agency:__block_0": { "3.1": { "line": 230, "col": 4 }, "3.2.0": { "line": 232, "col": 6 }, "3.2": { "line": 231, "col": 4 }, "3.3": { "line": 234, "col": 4 }, "3.4": { "line": 242, "col": 4 }, "3.5": { "line": 243, "col": 4 }, "3.6": { "line": 244, "col": 4 } }, "stdlib/agents/agency/coding.agency:agencyCodingAgent": { "1": { "line": 274, "col": 2 }, "2": { "line": 293, "col": 2 }, "4": { "line": 303, "col": 2 }, "2.1": { "line": 295, "col": 4 } }, "stdlib/agents/agency/coding.agency:__block_1": { "1.0": { "line": 275, "col": 4 }, "1.1.0": { "line": 277, "col": 6 }, "1.1": { "line": 276, "col": 4 }, "1.2": { "line": 286, "col": 4 } } };
export {
  WriteFailure,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  agencyCodingAgent,
  approve,
  buildTools,
  checkSource,
  critiqueOf,
  stdin_default as default,
  generateLoop,
  hasInterrupts,
  hasMainNode,
  interrupt,
  isDebugger,
  isInterrupt,
  outcomeFor,
  outcomeToResult,
  reject,
  respondToInterrupts,
  rewindFrom,
  syntaxHintFor,
  withSyntaxHint
};
