import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { fetchJSON } from "agency-lang/stdlib/http.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  success,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  __call,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/data/finance/dbnomics.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(fetchJSON);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/data/finance/dbnomics.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/data/finance/dbnomics.agency");
  __ctx.globals.set("stdlib/data/finance/dbnomics.agency", "DBNOMICS_BASE", `https://api.db.nomics.world/v22/`);
  __ctx.globals.set("stdlib/data/finance/dbnomics.agency", "DBNOMICS_DOMAINS", [`api.db.nomics.world`]);
}
__registerGlobalsInit("stdlib/data/finance/dbnomics.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/data/finance/dbnomics.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const DbnomicsObservation = z.object({ "period": z.string(), "value": z.union([z.number(), z.null()]).optional().default(null) });
const DbnomicsSeries = z.object({ "providerCode": z.string(), "datasetCode": z.string(), "seriesCode": z.string(), "seriesName": z.string(), "frequency": z.string(), "observations": z.array(DbnomicsObservation) });
async function __buildDbnomicsPath_impl(provider, dataset, series) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/dbnomics.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["provider"] = provider;
  __stack.args["dataset"] = dataset;
  __stack.args["series"] = series;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/dbnomics.agency", scopeName: "buildDbnomicsPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("provider" in __overrides) {
      provider = __overrides["provider"];
      __stack.args["provider"] = provider;
    }
    if ("dataset" in __overrides) {
      dataset = __overrides["dataset"];
      __stack.args["dataset"] = dataset;
    }
    if ("series" in __overrides) {
      series = __overrides["series"];
      __stack.args["series"] = series;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildDbnomicsPath",
            args: {
              provider,
              dataset,
              series
            },
            moduleId: "stdlib/data/finance/dbnomics.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.p = await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.provider]
        });
        if (hasInterrupts(__stack.locals.p)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.p);
          return;
        }
        if (isAborted(__stack.locals.p)) {
          runner2.halt(__stack.locals.p.carryThrough(__stack, "buildDbnomicsPath"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.d = await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.dataset]
        });
        if (hasInterrupts(__stack.locals.d)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.d);
          return;
        }
        if (isAborted(__stack.locals.d)) {
          runner2.halt(__stack.locals.d.carryThrough(__stack, "buildDbnomicsPath"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.s = await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.series]
        });
        if (hasInterrupts(__stack.locals.s)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.s);
          return;
        }
        if (isAborted(__stack.locals.s)) {
          runner2.halt(__stack.locals.s.carryThrough(__stack, "buildDbnomicsPath"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`series/${__stack.locals.p}/${__stack.locals.d}/${__stack.locals.s}?observations=1`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildDbnomicsPath");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildDbnomicsPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildDbnomicsPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildDbnomicsPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildDbnomicsPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildDbnomicsPath = __AgencyFunction.create({
  name: "buildDbnomicsPath",
  module: "stdlib/data/finance/dbnomics.agency",
  fn: __buildDbnomicsPath_impl,
  params: [{
    name: "provider",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dataset",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "series",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildDbnomicsPath",
    description: "No description provided.",
    schema: z.object({ "provider": z.string(), "dataset": z.string(), "series": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __parseDbnomics_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/dbnomics.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/dbnomics.agency", scopeName: "parseDbnomics", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseDbnomics",
            args: {
              raw
            },
            moduleId: "stdlib/data/finance/dbnomics.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.series = __stack.locals.r.series ?? {};
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.docs = __stack.locals.series.docs ?? [];
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.doc = __nn(__stack.locals.docs[0]) ?? {};
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.periods = __stack.locals.doc.period ?? [];
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.values = __stack.locals.doc.value ?? [];
      });
      await runner.step(7, async (runner2) => {
        __stack.locals.observations = await __call(map, {
          type: "named",
          positionalArgs: [await __call(range, {
            type: "positional",
            args: [__stack.locals.periods.length]
          })],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/data/finance/dbnomics.agency", fn: async (i) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["i"] = i;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/finance/dbnomics.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt({
                  "period": __nn(__stack.locals.periods[__bstack.args.i]) ?? ``,
                  "value": __nn(__stack.locals.values[__bstack.args.i]) ?? null
                });
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_0");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "i", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.observations)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.observations);
          return;
        }
        if (isAborted(__stack.locals.observations)) {
          runner2.halt(__stack.locals.observations.carryThrough(__stack, "parseDbnomics"));
          return;
        }
      });
      await runner.step(8, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "providerCode": __stack.locals.doc.provider_code ?? ``,
          "datasetCode": __stack.locals.doc.dataset_code ?? ``,
          "seriesCode": __stack.locals.doc.series_code ?? ``,
          "seriesName": __stack.locals.doc.series_name ?? ``,
          "frequency": __nn(__stack.locals.doc[`@frequency`]) ?? ``,
          "observations": __stack.locals.observations
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseDbnomics");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseDbnomics threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseDbnomics"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseDbnomics",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseDbnomics",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseDbnomics = __AgencyFunction.create({
  name: "parseDbnomics",
  module: "stdlib/data/finance/dbnomics.agency",
  fn: __parseDbnomics_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseDbnomics",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __dbnomicsFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/dbnomics.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/dbnomics.agency", scopeName: "dbnomicsFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "dbnomicsFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/finance/dbnomics.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_3 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_3),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_3.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.b = __stack.locals.body ?? {};
            });
            await runner2.step(2, async (runner3) => {
              __stack.locals.series = __stack.locals.b.series ?? {};
            });
            await runner2.step(3, async (runner3) => {
              __stack.locals.docs = __stack.locals.series.docs ?? [];
            });
            await runner2.ifElse(4, [
              {
                condition: async () => __eq(__stack.locals.docs.length, 0),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    runner4.exitMatch(1, failure(`DBnomics returned no series (check the provider/dataset/series codes)`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "dbnomicsFinalize", args: __stack.args }));
                    return;
                  });
                }
              }
            ]);
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(1, await success(await __call(parseDbnomics, {
                type: "positional",
                args: [__stack.locals.body]
              })));
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_3),
          body: async (runner2) => {
            await runner2.step(6, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_3.error;
            });
            await runner2.step(7, async (runner3) => {
              __stack.locals.__armval_2 = failure(`DBnomics request failed: ${__stack.locals.err}`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "dbnomicsFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_2)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_2);
                return;
              }
              if (isAborted(__stack.locals.__armval_2)) {
                runner3.halt(__stack.locals.__armval_2.carryThrough(__stack, "dbnomicsFinalize"));
                return;
              }
            });
            await runner2.step(8, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_2);
              return;
            });
          }
        }
      ], void 0, { matchId: 1 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "dbnomicsFinalize");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function dbnomicsFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "dbnomicsFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "dbnomicsFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "dbnomicsFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const dbnomicsFinalize = __AgencyFunction.create({
  name: "dbnomicsFinalize",
  module: "stdlib/data/finance/dbnomics.agency",
  fn: __dbnomicsFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "dbnomicsFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __dbnomicsSeries_impl(provider, dataset, series) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/dbnomics.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["provider"] = provider;
  __stack.args["dataset"] = dataset;
  __stack.args["series"] = series;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/dbnomics.agency", scopeName: "dbnomicsSeries", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("provider" in __overrides) {
      provider = __overrides["provider"];
      __stack.args["provider"] = provider;
    }
    if ("dataset" in __overrides) {
      dataset = __overrides["dataset"];
      __stack.args["dataset"] = dataset;
    }
    if ("series" in __overrides) {
      series = __overrides["series"];
      __stack.args["series"] = series;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "dbnomicsSeries",
            args: {
              provider,
              dataset,
              series
            },
            moduleId: "stdlib/data/finance/dbnomics.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::dbnomics", `Fetch this DBnomics series?`, {
            "provider": __stack.args.provider,
            "dataset": __stack.args.dataset,
            "series": __stack.args.series
          }, "std::data/finance/dbnomics", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/finance/dbnomics.agency", scopeName: "dbnomicsSeries", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.path = await __call(buildDbnomicsPath, {
          type: "positional",
          args: [__stack.args.provider, __stack.args.dataset, __stack.args.series]
        });
        if (hasInterrupts(__stack.locals.path)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.path);
          return;
        }
        if (isAborted(__stack.locals.path)) {
          runner2.halt(__stack.locals.path.carryThrough(__stack, "dbnomicsSeries"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.result = await __call(fetchJSON, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            baseUrl: __globals().get("stdlib/data/finance/dbnomics.agency", "DBNOMICS_BASE"),
            path: __stack.locals.path,
            allowedDomains: __globals().get("stdlib/data/finance/dbnomics.agency", "DBNOMICS_DOMAINS")
          }
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "dbnomicsSeries"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(dbnomicsFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "dbnomicsSeries");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function dbnomicsSeries threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "dbnomicsSeries"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "dbnomicsSeries",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "dbnomicsSeries",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const dbnomicsSeries = __AgencyFunction.create({
  name: "dbnomicsSeries",
  module: "stdlib/data/finance/dbnomics.agency",
  fn: __dbnomicsSeries_impl,
  params: [{
    name: "provider",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dataset",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "series",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "dbnomicsSeries",
    description: `Fetch a macroeconomic time-series from DBnomics by its provider/dataset/series codes
  (e.g. provider "BLS", dataset "cu", series "CUUR0000SA0" for U.S. CPI). Returns the series
  name, frequency, and a list of { period, value } observations. Use for non-U.S. or
  cross-country economic data. No API key required.

  @param provider - DBnomics provider code, e.g. "Eurostat", "IMF", "BLS"
  @param dataset - Dataset code within the provider, e.g. "cu"
  @param series - Series code within the dataset, e.g. "CUUR0000SA0"`,
    schema: z.object({ "provider": z.string(), "dataset": z.string(), "series": z.string() })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/data/finance/dbnomics.agency:buildDbnomicsPath": { "1": { "line": 51, "col": 2 }, "2": { "line": 52, "col": 2 }, "3": { "line": 53, "col": 2 }, "4": { "line": 54, "col": 2 } }, "stdlib/data/finance/dbnomics.agency:parseDbnomics": { "1": { "line": 59, "col": 2 }, "2": { "line": 60, "col": 2 }, "3": { "line": 61, "col": 2 }, "4": { "line": 62, "col": 2 }, "5": { "line": 63, "col": 2 }, "6": { "line": 64, "col": 2 }, "7": { "line": 65, "col": 2 }, "8": { "line": 68, "col": 2 } }, "stdlib/data/finance/dbnomics.agency:__block_0": { "7.0": { "line": 66, "col": 4 } }, "stdlib/data/finance/dbnomics.agency:dbnomicsFinalize": { "1": { "line": 80, "col": 9 }, "2": { "line": 80, "col": 9 }, "3": { "line": 80, "col": 2 }, "2.0": { "line": 80, "col": 9 }, "2.1": { "line": 82, "col": 6 }, "2.2": { "line": 83, "col": 6 }, "2.3": { "line": 84, "col": 6 }, "2.4.0": { "line": 86, "col": 8 }, "2.4": { "line": 85, "col": 6 }, "2.5": { "line": 88, "col": 6 }, "2.6": { "line": 80, "col": 9 }, "2.7": { "line": 90, "col": 20 }, "2.8": { "line": 90, "col": 20 } }, "stdlib/data/finance/dbnomics.agency:dbnomicsSeries": { "1": { "line": 105, "col": 2 }, "2": { "line": 110, "col": 2 }, "3": { "line": 112, "col": 2 }, "4": { "line": 113, "col": 2 } } };
export {
  DbnomicsObservation,
  DbnomicsSeries,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  buildDbnomicsPath,
  dbnomicsFinalize,
  dbnomicsSeries,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  parseDbnomics,
  reject,
  respondToInterrupts,
  rewindFrom
};
