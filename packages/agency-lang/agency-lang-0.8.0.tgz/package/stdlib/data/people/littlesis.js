import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { fetchJSON } from "agency-lang/stdlib/http.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  success,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/data/people/littlesis.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(fetchJSON);
let __staticInitPromise = null;
let LITTLESIS_BASE = __UNINIT_STATIC;
let LITTLESIS_DOMAINS = __UNINIT_STATIC;
let CATEGORY_NAMES = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    LITTLESIS_BASE = __deepFreeze(`https://littlesis.org/api`);
    LITTLESIS_DOMAINS = __deepFreeze([`littlesis.org`]);
    CATEGORY_NAMES = __deepFreeze([``, `position`, `education`, `membership`, `family`, `donation`, `transaction`, `lobbying`, `social`, `professional`, `ownership`, `hierarchy`, `generic`]);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    LITTLESIS_BASE,
    LITTLESIS_DOMAINS,
    CATEGORY_NAMES
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/data/people/littlesis.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/data/people/littlesis.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/data/people/littlesis.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/data/people/littlesis.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const Entity = z.object({ "id": z.number(), "name": z.string(), "type": z.string(), "blurb": z.string(), "types": z.array(z.string()), "aliases": z.array(z.string()), "website": z.string(), "url": z.string(), "relationshipId": z.union([z.number(), z.null()]).optional().default(null), "relationshipCategory": z.string() });
const Relationship = z.object({ "id": z.number(), "category": z.string(), "categoryId": z.number(), "entity1Id": z.number(), "entity2Id": z.number(), "description1": z.string(), "description2": z.string(), "amount": z.union([z.number(), z.null()]).optional().default(null), "startDate": z.string(), "endDate": z.string(), "isCurrent": z.union([z.boolean(), z.null()]).optional().default(null) });
const CategoryFilter = z.union([z.object({ "type": z.literal("all") }), z.object({ "type": z.literal("category"), "id": z.number() })]);
async function __categoryIdToName_impl(id) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["id"] = id;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "categoryIdToName", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("id" in __overrides) {
      id = __overrides["id"];
      __stack.args["id"] = id;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "categoryIdToName",
            args: {
              id
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.id >= 1 && __stack.args.id < __readStatic(CATEGORY_NAMES, "CATEGORY_NAMES", "stdlib/data/people/littlesis.agency").length,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__nn(__readStatic(CATEGORY_NAMES, "CATEGORY_NAMES", "stdlib/data/people/littlesis.agency")[__stack.args.id]));
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(``);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function categoryIdToName threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "categoryIdToName"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "categoryIdToName",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "categoryIdToName",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const categoryIdToName = __AgencyFunction.create({
  name: "categoryIdToName",
  module: "stdlib/data/people/littlesis.agency",
  fn: __categoryIdToName_impl,
  params: [{
    name: "id",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "categoryIdToName",
    description: "No description provided.",
    schema: z.object({ "id": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __categoryNamesList_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "categoryNamesList", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "categoryNamesList",
            args: {},
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(await __callMethod(__readStatic(CATEGORY_NAMES, "CATEGORY_NAMES", "stdlib/data/people/littlesis.agency"), "slice", {
          type: "positional",
          args: [1]
        }), "join", {
          type: "positional",
          args: [`, `]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function categoryNamesList threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "categoryNamesList"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "categoryNamesList",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "categoryNamesList",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const categoryNamesList = __AgencyFunction.create({
  name: "categoryNamesList",
  module: "stdlib/data/people/littlesis.agency",
  fn: __categoryNamesList_impl,
  params: [],
  toolDefinition: {
    name: "categoryNamesList",
    description: "No description provided.",
    schema: z.object({})
  },
  exported: false
}, __toolRegistry);
async function __parseCategoryFilter_impl(name) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["name"] = name;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "parseCategoryFilter", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseCategoryFilter",
            args: {
              name
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.name, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await success({
                "type": `all`
              }));
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __stack.locals.idx = await __callMethod(__readStatic(CATEGORY_NAMES, "CATEGORY_NAMES", "stdlib/data/people/littlesis.agency"), "indexOf", {
          type: "positional",
          args: [__stack.args.name]
        });
      });
      await runner.ifElse(3, [
        {
          condition: async () => __stack.locals.idx < 1,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(`unknown category '${__stack.args.name}'; valid: ${await __call(categoryNamesList, {
                type: "positional",
                args: []
              })}`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "parseCategoryFilter", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await success({
          "type": `category`,
          "id": __stack.locals.idx
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseCategoryFilter threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseCategoryFilter"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseCategoryFilter",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseCategoryFilter",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseCategoryFilter = __AgencyFunction.create({
  name: "parseCategoryFilter",
  module: "stdlib/data/people/littlesis.agency",
  fn: __parseCategoryFilter_impl,
  params: [{
    name: "name",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "parseCategoryFilter",
    description: "No description provided.",
    schema: z.object({ "name": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildSearchPath_impl(name, page) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["name"] = name;
  __stack.args["page"] = page;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "buildSearchPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
    if ("page" in __overrides) {
      page = __overrides["page"];
      __stack.args["page"] = page;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildSearchPath",
            args: {
              name,
              page
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.q = await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.name]
        });
        if (hasInterrupts(__stack.locals.q)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.q);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => __stack.args.page > 1,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(`/entities/search?q=${__stack.locals.q}&page=${__stack.args.page}`);
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/entities/search?q=${__stack.locals.q}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildSearchPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildSearchPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildSearchPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildSearchPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildSearchPath = __AgencyFunction.create({
  name: "buildSearchPath",
  module: "stdlib/data/people/littlesis.agency",
  fn: __buildSearchPath_impl,
  params: [{
    name: "name",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "page",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildSearchPath",
    description: "No description provided.",
    schema: z.object({ "name": z.string(), "page": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __buildEntityPath_impl(id) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["id"] = id;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "buildEntityPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("id" in __overrides) {
      id = __overrides["id"];
      __stack.args["id"] = id;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildEntityPath",
            args: {
              id
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/entities/${__stack.args.id}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildEntityPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildEntityPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildEntityPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildEntityPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildEntityPath = __AgencyFunction.create({
  name: "buildEntityPath",
  module: "stdlib/data/people/littlesis.agency",
  fn: __buildEntityPath_impl,
  params: [{
    name: "id",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildEntityPath",
    description: "No description provided.",
    schema: z.object({ "id": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __buildRelationshipsPath_impl(id, filter2, sort) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["id"] = id;
  __stack.args["filter"] = filter2;
  __stack.args["sort"] = sort;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "buildRelationshipsPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("id" in __overrides) {
      id = __overrides["id"];
      __stack.args["id"] = id;
    }
    if ("filter" in __overrides) {
      filter2 = __overrides["filter"];
      __stack.args["filter"] = filter2;
    }
    if ("sort" in __overrides) {
      sort = __overrides["sort"];
      __stack.args["sort"] = sort;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildRelationshipsPath",
            args: {
              id,
              filter: filter2,
              sort
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.base = `/entities/${__stack.args.id}/relationships`;
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.params = [];
      });
      await runner.ifElse(3, [
        {
          condition: async () => __eq(__stack.args.filter.type, `category`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.catId = __stack.args.filter.id;
            });
            await runner2.step(1, async (runner3) => {
              await __callMethod(__stack.locals.params, "push", {
                type: "positional",
                args: [`category_id=${__stack.locals.catId}`]
              });
            });
          }
        }
      ]);
      await runner.ifElse(4, [
        {
          condition: async () => !__eq(__stack.args.sort, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              await __callMethod(__stack.locals.params, "push", {
                type: "positional",
                args: [`sort=${await __call(encodeURIComponent, {
                  type: "positional",
                  args: [__stack.args.sort]
                })}`]
              });
            });
          }
        }
      ]);
      await runner.ifElse(5, [
        {
          condition: async () => __eq(__stack.locals.params.length, 0),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.locals.base);
              return;
            });
          }
        }
      ]);
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`${__stack.locals.base}?${await __callMethod(__stack.locals.params, "join", {
          type: "positional",
          args: [`&`]
        })}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildRelationshipsPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildRelationshipsPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildRelationshipsPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildRelationshipsPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildRelationshipsPath = __AgencyFunction.create({
  name: "buildRelationshipsPath",
  module: "stdlib/data/people/littlesis.agency",
  fn: __buildRelationshipsPath_impl,
  params: [{
    name: "id",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filter",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "sort",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildRelationshipsPath",
    description: "No description provided.",
    schema: z.object({ "id": z.number(), "filter": CategoryFilter, "sort": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildConnectionsPath_impl(id, filter2) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["id"] = id;
  __stack.args["filter"] = filter2;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "buildConnectionsPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("id" in __overrides) {
      id = __overrides["id"];
      __stack.args["id"] = id;
    }
    if ("filter" in __overrides) {
      filter2 = __overrides["filter"];
      __stack.args["filter"] = filter2;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildConnectionsPath",
            args: {
              id,
              filter: filter2
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.filter.type, `category`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.catId = __stack.args.filter.id;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(`/entities/${__stack.args.id}/connections?category_id=${__stack.locals.catId}`);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/entities/${__stack.args.id}/connections`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildConnectionsPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildConnectionsPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildConnectionsPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildConnectionsPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildConnectionsPath = __AgencyFunction.create({
  name: "buildConnectionsPath",
  module: "stdlib/data/people/littlesis.agency",
  fn: __buildConnectionsPath_impl,
  params: [{
    name: "id",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filter",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildConnectionsPath",
    description: "No description provided.",
    schema: z.object({ "id": z.number(), "filter": CategoryFilter })
  },
  exported: false
}, __toolRegistry);
async function __parseEntity_impl(node) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["node"] = node;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "parseEntity", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("node" in __overrides) {
      node = __overrides["node"];
      __stack.args["node"] = node;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseEntity",
            args: {
              node
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.safeNode = __stack.args.node ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.attrs = __stack.locals.safeNode.attributes ?? {};
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.links = __stack.locals.safeNode.links ?? {};
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.relCatId = __stack.locals.attrs.relationship_category_id ?? __stack.locals.safeNode.relationship_category_id ?? 0;
      });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "id": __stack.locals.attrs.id ?? 0,
          "name": __stack.locals.attrs.name ?? ``,
          "type": __stack.locals.attrs.primary_ext ?? ``,
          "blurb": __stack.locals.attrs.blurb ?? ``,
          "types": __stack.locals.attrs.types ?? [],
          "aliases": __stack.locals.attrs.aliases ?? [],
          "website": __stack.locals.attrs.website ?? ``,
          "url": __stack.locals.links.self ?? ``,
          "relationshipId": __stack.locals.attrs.relationship_id ?? __stack.locals.safeNode.relationship_id ?? null,
          "relationshipCategory": await __call(categoryIdToName, {
            type: "positional",
            args: [__stack.locals.relCatId]
          })
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseEntity threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseEntity"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseEntity",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseEntity",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseEntity = __AgencyFunction.create({
  name: "parseEntity",
  module: "stdlib/data/people/littlesis.agency",
  fn: __parseEntity_impl,
  params: [{
    name: "node",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseEntity",
    description: "No description provided.",
    schema: z.object({ "node": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __parseEntities_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "parseEntities", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseEntities",
            args: {
              raw
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.data = __stack.locals.r.data ?? [];
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(map, {
          type: "named",
          positionalArgs: [__stack.locals.data],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/data/people/littlesis.agency", fn: async (node) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["node"] = node;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(await __call(parseEntity, {
                  type: "positional",
                  args: [__bstack.args.node]
                }));
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "node", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseEntities threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseEntities"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseEntities",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseEntities",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseEntities = __AgencyFunction.create({
  name: "parseEntities",
  module: "stdlib/data/people/littlesis.agency",
  fn: __parseEntities_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseEntities",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __parseRelationships_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "parseRelationships", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseRelationships",
            args: {
              raw
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.data = __stack.locals.r.data ?? [];
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(map, {
          type: "named",
          positionalArgs: [__stack.locals.data],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/data/people/littlesis.agency", fn: async (node) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_1 = __bstack;
            __bstack.args["node"] = node;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "__block_1" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.safeNode = __bstack.args.node ?? {};
              });
              await runner3.step(1, async (runner4) => {
                __bstack.locals.attrs = __bstack.locals.safeNode.attributes ?? {};
              });
              await runner3.step(2, async (runner4) => {
                __bstack.locals.catId = __bstack.locals.attrs.category_id ?? 0;
              });
              await runner3.step(3, async (runner4) => {
                runner4.halt({
                  "id": __bstack.locals.attrs.id ?? 0,
                  "category": await __call(categoryIdToName, {
                    type: "positional",
                    args: [__bstack.locals.catId]
                  }),
                  "categoryId": __bstack.locals.catId,
                  "entity1Id": __bstack.locals.attrs.entity1_id ?? 0,
                  "entity2Id": __bstack.locals.attrs.entity2_id ?? 0,
                  "description1": __bstack.locals.attrs.description1 ?? ``,
                  "description2": __bstack.locals.attrs.description2 ?? ``,
                  "amount": __bstack.locals.attrs.amount ?? null,
                  "startDate": __bstack.locals.attrs.start_date ?? ``,
                  "endDate": __bstack.locals.attrs.end_date ?? ``,
                  "isCurrent": __bstack.locals.attrs.is_current ?? null
                });
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "node", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseRelationships threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseRelationships"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseRelationships",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseRelationships",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseRelationships = __AgencyFunction.create({
  name: "parseRelationships",
  module: "stdlib/data/people/littlesis.agency",
  fn: __parseRelationships_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseRelationships",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __littlesisError_impl(err) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["err"] = err;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "littlesisError", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("err" in __overrides) {
      err = __overrides["err"];
      __stack.args["err"] = err;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "littlesisError",
            args: {
              err
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`LittleSis request failed (the API may be rate-limited; HTTP 503 = Rate Limit Exceeded): ${__stack.args.err}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function littlesisError threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "littlesisError"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "littlesisError",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "littlesisError",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const littlesisError = __AgencyFunction.create({
  name: "littlesisError",
  module: "stdlib/data/people/littlesis.agency",
  fn: __littlesisError_impl,
  params: [{
    name: "err",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "littlesisError",
    description: "No description provided.",
    schema: z.object({ "err": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __littlesisFetch_impl(path2) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["path"] = path2;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "littlesisFetch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("path" in __overrides) {
      path2 = __overrides["path"];
      __stack.args["path"] = path2;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "littlesisFetch",
            args: {
              path: path2
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.handle(1, async (data) => {
        if (__eq(data.effect, `std::http::fetchJSON`)) {
          return await approve();
        }
      }, async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __functionCompleted = true;
          runner3.halt(await __call(fetchJSON, {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              baseUrl: __readStatic(LITTLESIS_BASE, "LITTLESIS_BASE", "stdlib/data/people/littlesis.agency"),
              path: __stack.args.path,
              allowedDomains: __readStatic(LITTLESIS_DOMAINS, "LITTLESIS_DOMAINS", "stdlib/data/people/littlesis.agency")
            }
          }));
          return;
        });
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function littlesisFetch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "littlesisFetch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "littlesisFetch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "littlesisFetch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const littlesisFetch = __AgencyFunction.create({
  name: "littlesisFetch",
  module: "stdlib/data/people/littlesis.agency",
  fn: __littlesisFetch_impl,
  params: [{
    name: "path",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "littlesisFetch",
    description: "No description provided.",
    schema: z.object({ "path": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __entityListFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "entityListFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "entityListFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_4 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_4),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_4.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_2 = await success(await __call(parseEntities, {
                type: "positional",
                args: [__stack.locals.body]
              }));
              if (hasInterrupts(__stack.locals.__armval_2)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_2);
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_2);
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_4),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_4.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_3 = failure(await __call(littlesisError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "entityListFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_3)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_3);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_3);
              return;
            });
          }
        }
      ], void 0, { matchId: 1 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function entityListFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "entityListFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "entityListFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "entityListFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const entityListFinalize = __AgencyFunction.create({
  name: "entityListFinalize",
  module: "stdlib/data/people/littlesis.agency",
  fn: __entityListFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "entityListFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __entityFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "entityFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "entityFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_7 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_7),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_7.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.bodyObj = __stack.locals.body ?? {};
            });
            await runner2.ifElse(2, [
              {
                condition: async () => __eq(__stack.locals.bodyObj.data ?? null, null),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    runner4.exitMatch(5, failure(`LittleSis returned no entity`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "entityFinalize", args: __stack.args }));
                    return;
                  });
                }
              }
            ]);
            await runner2.step(3, async (runner3) => {
              runner3.exitMatch(5, await success(await __call(parseEntity, {
                type: "positional",
                args: [__stack.locals.bodyObj.data]
              })));
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_7),
          body: async (runner2) => {
            await runner2.step(4, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_7.error;
            });
            await runner2.step(5, async (runner3) => {
              __stack.locals.__armval_6 = failure(await __call(littlesisError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "entityFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_6)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_6);
                return;
              }
            });
            await runner2.step(6, async (runner3) => {
              runner3.exitMatch(5, __stack.locals.__armval_6);
              return;
            });
          }
        }
      ], void 0, { matchId: 5 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_5));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function entityFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "entityFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "entityFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "entityFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const entityFinalize = __AgencyFunction.create({
  name: "entityFinalize",
  module: "stdlib/data/people/littlesis.agency",
  fn: __entityFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "entityFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __relationshipsFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "relationshipsFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "relationshipsFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_11 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_11),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_11.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_9 = await success(await __call(parseRelationships, {
                type: "positional",
                args: [__stack.locals.body]
              }));
              if (hasInterrupts(__stack.locals.__armval_9)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_9);
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(8, __stack.locals.__armval_9);
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_11),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_11.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_10 = failure(await __call(littlesisError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "relationshipsFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_10)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_10);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(8, __stack.locals.__armval_10);
              return;
            });
          }
        }
      ], void 0, { matchId: 8 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_8));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function relationshipsFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "relationshipsFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "relationshipsFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "relationshipsFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const relationshipsFinalize = __AgencyFunction.create({
  name: "relationshipsFinalize",
  module: "stdlib/data/people/littlesis.agency",
  fn: __relationshipsFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "relationshipsFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __littlesisSearch_impl(name, page = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["name"] = name;
  __stack.args["page"] = page === __UNSET ? 1 : page;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "littlesisSearch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
    if ("page" in __overrides) {
      page = __overrides["page"];
      __stack.args["page"] = page;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "littlesisSearch",
            args: {
              name,
              page
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::littlesis", `Search LittleSis for this name?`, {
            "op": `search`,
            "query": __stack.args.name
          }, "std::data/people/littlesis", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/people/littlesis.agency", scopeName: "littlesisSearch", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(littlesisFetch, {
          type: "positional",
          args: [await __call(buildSearchPath, {
            type: "positional",
            args: [__stack.args.name, __stack.args.page]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(entityListFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function littlesisSearch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "littlesisSearch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "littlesisSearch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "littlesisSearch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const littlesisSearch = __AgencyFunction.create({
  name: "littlesisSearch",
  module: "stdlib/data/people/littlesis.agency",
  fn: __littlesisSearch_impl,
  params: [{
    name: "name",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "page",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "littlesisSearch",
    description: `Search LittleSis for people and organizations by name. Returns matching entities (id, name,
  type "Person"/"Org", blurb, aliases, website, url). Use the returned id with the other
  littlesis functions. Empty result set returns an empty list.

  @param name - The person or organization name to search for
  @param page - Result page, 10 per page (default 1)`,
    schema: z.object({ "name": z.string(), "page": z.number().nullable().describe("Default: 1") })
  },
  exported: true
}, __toolRegistry);
async function __littlesisEntity_impl(id) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["id"] = id;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "littlesisEntity", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("id" in __overrides) {
      id = __overrides["id"];
      __stack.args["id"] = id;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "littlesisEntity",
            args: {
              id
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::littlesis", `Fetch this LittleSis entity?`, {
            "op": `entity`,
            "query": `${__stack.args.id}`
          }, "std::data/people/littlesis", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/people/littlesis.agency", scopeName: "littlesisEntity", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(littlesisFetch, {
          type: "positional",
          args: [await __call(buildEntityPath, {
            type: "positional",
            args: [__stack.args.id]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(entityFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function littlesisEntity threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "littlesisEntity"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "littlesisEntity",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "littlesisEntity",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const littlesisEntity = __AgencyFunction.create({
  name: "littlesisEntity",
  module: "stdlib/data/people/littlesis.agency",
  fn: __littlesisEntity_impl,
  params: [{
    name: "id",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "littlesisEntity",
    description: `Fetch one LittleSis entity by its numeric id (from littlesisSearch). Returns the full profile
  (name, type, blurb, aliases, website, url). Unknown id returns a failure.

  @param id - The LittleSis entity id`,
    schema: z.object({ "id": z.number() })
  },
  exported: true
}, __toolRegistry);
async function __littlesisRelationships_impl(id, category = __UNSET, sort = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["id"] = id;
  __stack.args["category"] = category === __UNSET ? `` : category;
  __stack.args["sort"] = sort === __UNSET ? `` : sort;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "littlesisRelationships", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("id" in __overrides) {
      id = __overrides["id"];
      __stack.args["id"] = id;
    }
    if ("category" in __overrides) {
      category = __overrides["category"];
      __stack.args["category"] = category;
    }
    if ("sort" in __overrides) {
      sort = __overrides["sort"];
      __stack.args["sort"] = sort;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "littlesisRelationships",
            args: {
              id,
              category,
              sort
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.filterResult = await __call(parseCategoryFilter, {
          type: "positional",
          args: [__stack.args.category]
        });
        if (hasInterrupts(__stack.locals.filterResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.filterResult);
          return;
        }
      });
      await runner.ifElse(3, [
        {
          condition: async () => await isFailure(__stack.locals.filterResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.msg = __stack.locals.filterResult.error;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(__stack.locals.msg, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "littlesisRelationships", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __stack.locals.filter = __stack.locals.filterResult.value;
      });
      await runner.step(5, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_5);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::littlesis", `Fetch relationships for this LittleSis entity?`, {
            "op": `relationships`,
            "query": `${__stack.args.id}`
          }, "std::data/people/littlesis", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_5 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/people/littlesis.agency", scopeName: "littlesisRelationships", stepPath: "5" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.result = await __call(littlesisFetch, {
          type: "positional",
          args: [await __call(buildRelationshipsPath, {
            type: "positional",
            args: [__stack.args.id, __stack.locals.filter, __stack.args.sort]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.step(7, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(relationshipsFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function littlesisRelationships threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "littlesisRelationships"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "littlesisRelationships",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "littlesisRelationships",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const littlesisRelationships = __AgencyFunction.create({
  name: "littlesisRelationships",
  module: "stdlib/data/people/littlesis.agency",
  fn: __littlesisRelationships_impl,
  params: [{
    name: "id",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "category",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "sort",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "littlesisRelationships",
    description: `List an entity's relationships (typed edges) by its id. Each edge carries the two entity IDs,
  role labels (description1/description2), amount, dates, and category. Filter with a friendly
  category name. Edges carry entity IDs, not names \u2014 use littlesisConnections for neighbor names.

  @param id - The LittleSis entity id
  @param category - Optional category filter: position, education, membership, family, donation, transaction, lobbying, social, professional, ownership, hierarchy, generic (empty = all)
  @param sort - Optional sort: "amount", "oldest", or "recent" (empty = default)`,
    schema: z.object({ "id": z.number(), "category": z.string().nullable().describe("Default: "), "sort": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __littlesisConnections_impl(id, category = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/people/littlesis.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["id"] = id;
  __stack.args["category"] = category === __UNSET ? `` : category;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/people/littlesis.agency", scopeName: "littlesisConnections", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("id" in __overrides) {
      id = __overrides["id"];
      __stack.args["id"] = id;
    }
    if ("category" in __overrides) {
      category = __overrides["category"];
      __stack.args["category"] = category;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "littlesisConnections",
            args: {
              id,
              category
            },
            moduleId: "stdlib/data/people/littlesis.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.filterResult = await __call(parseCategoryFilter, {
          type: "positional",
          args: [__stack.args.category]
        });
        if (hasInterrupts(__stack.locals.filterResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.filterResult);
          return;
        }
      });
      await runner.ifElse(3, [
        {
          condition: async () => await isFailure(__stack.locals.filterResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.msg = __stack.locals.filterResult.error;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(__stack.locals.msg, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "littlesisConnections", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __stack.locals.filter = __stack.locals.filterResult.value;
      });
      await runner.step(5, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_5);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::littlesis", `Fetch connections for this LittleSis entity?`, {
            "op": `connections`,
            "query": `${__stack.args.id}`
          }, "std::data/people/littlesis", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_5 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/people/littlesis.agency", scopeName: "littlesisConnections", stepPath: "5" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.result = await __call(littlesisFetch, {
          type: "positional",
          args: [await __call(buildConnectionsPath, {
            type: "positional",
            args: [__stack.args.id, __stack.locals.filter]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.step(7, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(entityListFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function littlesisConnections threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "littlesisConnections"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "littlesisConnections",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "littlesisConnections",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const littlesisConnections = __AgencyFunction.create({
  name: "littlesisConnections",
  module: "stdlib/data/people/littlesis.agency",
  fn: __littlesisConnections_impl,
  params: [{
    name: "id",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "category",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "littlesisConnections",
    description: `List the entities connected to an entity (neighbors, by name), optionally filtered by a
  friendly category name. Lighter than littlesisRelationships and name-bearing \u2014 the preferred
  first hop for "who is X tied to". Each result also carries the linking relationshipId/category.

  @param id - The LittleSis entity id
  @param category - Optional category filter: position, education, membership, family, donation, transaction, lobbying, social, professional, ownership, hierarchy, generic (empty = all)`,
    schema: z.object({ "id": z.number(), "category": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/data/people/littlesis.agency:categoryIdToName": { "1": { "line": 83, "col": 2 }, "2": { "line": 86, "col": 2 }, "1.0": { "line": 84, "col": 4 } }, "stdlib/data/people/littlesis.agency:categoryNamesList": { "1": { "line": 92, "col": 2 } }, "stdlib/data/people/littlesis.agency:parseCategoryFilter": { "1": { "line": 98, "col": 2 }, "2": { "line": 101, "col": 2 }, "3": { "line": 102, "col": 2 }, "4": { "line": 105, "col": 2 }, "1.0": { "line": 99, "col": 4 }, "3.0": { "line": 103, "col": 4 } }, "stdlib/data/people/littlesis.agency:buildSearchPath": { "1": { "line": 110, "col": 2 }, "2": { "line": 111, "col": 2 }, "3": { "line": 114, "col": 2 }, "2.0": { "line": 112, "col": 4 } }, "stdlib/data/people/littlesis.agency:buildEntityPath": { "1": { "line": 119, "col": 2 } }, "stdlib/data/people/littlesis.agency:buildRelationshipsPath": { "1": { "line": 125, "col": 2 }, "2": { "line": 126, "col": 2 }, "3": { "line": 127, "col": 2 }, "4": { "line": 130, "col": 2 }, "5": { "line": 133, "col": 2 }, "6": { "line": 136, "col": 2 }, "3.0": { "line": 127, "col": 2 }, "3.1": { "line": 128, "col": 4 }, "4.0": { "line": 131, "col": 4 }, "5.0": { "line": 134, "col": 4 } }, "stdlib/data/people/littlesis.agency:buildConnectionsPath": { "1": { "line": 141, "col": 2 }, "2": { "line": 144, "col": 2 }, "1.0": { "line": 141, "col": 2 }, "1.1": { "line": 142, "col": 4 } }, "stdlib/data/people/littlesis.agency:parseEntity": { "1": { "line": 150, "col": 2 }, "2": { "line": 151, "col": 2 }, "3": { "line": 152, "col": 2 }, "4": { "line": 153, "col": 2 }, "5": { "line": 154, "col": 2 } }, "stdlib/data/people/littlesis.agency:parseEntities": { "1": { "line": 170, "col": 2 }, "2": { "line": 171, "col": 2 }, "3": { "line": 172, "col": 2 } }, "stdlib/data/people/littlesis.agency:__block_0": { "3.0": { "line": 173, "col": 4 } }, "stdlib/data/people/littlesis.agency:parseRelationships": { "1": { "line": 179, "col": 2 }, "2": { "line": 180, "col": 2 }, "3": { "line": 181, "col": 2 } }, "stdlib/data/people/littlesis.agency:__block_1": { "3.0": { "line": 182, "col": 4 }, "3.1": { "line": 183, "col": 4 }, "3.2": { "line": 184, "col": 4 }, "3.3": { "line": 185, "col": 4 } }, "stdlib/data/people/littlesis.agency:littlesisError": { "1": { "line": 203, "col": 2 } }, "stdlib/data/people/littlesis.agency:littlesisFetch": { "1": { "line": 211, "col": 2 }, "1.0": { "line": 212, "col": 4 } }, "stdlib/data/people/littlesis.agency:entityListFinalize": { "1": { "line": 223, "col": 9 }, "2": { "line": 223, "col": 9 }, "3": { "line": 223, "col": 2 }, "2.0": { "line": 223, "col": 9 }, "2.1": { "line": 224, "col": 21 }, "2.2": { "line": 224, "col": 21 }, "2.3": { "line": 223, "col": 9 }, "2.4": { "line": 225, "col": 20 }, "2.5": { "line": 225, "col": 20 } }, "stdlib/data/people/littlesis.agency:entityFinalize": { "1": { "line": 231, "col": 9 }, "2": { "line": 231, "col": 9 }, "3": { "line": 231, "col": 2 }, "2.0": { "line": 231, "col": 9 }, "2.1": { "line": 233, "col": 6 }, "2.2.0": { "line": 235, "col": 8 }, "2.2": { "line": 234, "col": 6 }, "2.3": { "line": 237, "col": 6 }, "2.4": { "line": 231, "col": 9 }, "2.5": { "line": 239, "col": 20 }, "2.6": { "line": 239, "col": 20 } }, "stdlib/data/people/littlesis.agency:relationshipsFinalize": { "1": { "line": 245, "col": 9 }, "2": { "line": 245, "col": 9 }, "3": { "line": 245, "col": 2 }, "2.0": { "line": 245, "col": 9 }, "2.1": { "line": 246, "col": 21 }, "2.2": { "line": 246, "col": 21 }, "2.3": { "line": 245, "col": 9 }, "2.4": { "line": 247, "col": 20 }, "2.5": { "line": 247, "col": 20 } }, "stdlib/data/people/littlesis.agency:littlesisSearch": { "1": { "line": 260, "col": 2 }, "2": { "line": 263, "col": 2 }, "3": { "line": 264, "col": 2 } }, "stdlib/data/people/littlesis.agency:littlesisEntity": { "1": { "line": 274, "col": 2 }, "2": { "line": 275, "col": 2 }, "3": { "line": 276, "col": 2 } }, "stdlib/data/people/littlesis.agency:littlesisRelationships": { "2": { "line": 293, "col": 2 }, "3": { "line": 294, "col": 2 }, "4": { "line": 297, "col": 2 }, "5": { "line": 298, "col": 2 }, "6": { "line": 299, "col": 2 }, "7": { "line": 300, "col": 2 }, "3.0": { "line": 294, "col": 2 }, "3.1": { "line": 295, "col": 4 } }, "stdlib/data/people/littlesis.agency:littlesisConnections": { "2": { "line": 313, "col": 2 }, "3": { "line": 314, "col": 2 }, "4": { "line": 317, "col": 2 }, "5": { "line": 318, "col": 2 }, "6": { "line": 319, "col": 2 }, "7": { "line": 320, "col": 2 }, "3.0": { "line": 314, "col": 2 }, "3.1": { "line": 315, "col": 4 } } };
export {
  Entity,
  Relationship,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  buildConnectionsPath,
  buildEntityPath,
  buildRelationshipsPath,
  buildSearchPath,
  categoryIdToName,
  categoryNamesList,
  stdin_default as default,
  entityFinalize,
  entityListFinalize,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  littlesisConnections,
  littlesisEntity,
  littlesisError,
  littlesisFetch,
  littlesisRelationships,
  littlesisSearch,
  parseCategoryFilter,
  parseEntities,
  parseEntity,
  parseRelationships,
  reject,
  relationshipsFinalize,
  respondToInterrupts,
  rewindFrom
};
