import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { writeAgency, runCode, feedbackHasErrors, renderFeedback, Feedback, WriteFailure } from "agency-lang/stdlib/agency.js";
import { guard } from "agency-lang/stdlib/thread.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  runPrompt,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  success,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __threads,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/agents/agency.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(writeAgency);
__registerTool(runCode);
__registerTool(feedbackHasErrors);
__registerTool(renderFeedback);
__registerTool(Feedback);
__registerTool(WriteFailure);
__registerTool(guard);
let __staticInitPromise = null;
let judgeResultPrompt = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    judgeResultPrompt = __deepFreeze(`Does this program's result satisfy the task? For each finding, return a Feedback item: set error=true when it fails the task (name the specific problem), error=false for a satisfied point.`);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    judgeResultPrompt
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/agents/agency.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/agents/agency.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/agents/agency.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/agents/agency.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const AttemptOutcome = z.object({ "done": z.boolean(), "feedback": z.string() });
async function __stopOutcome_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency.agency", scopeName: "stopOutcome", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "stopOutcome",
            args: {},
            moduleId: "stdlib/agents/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "done": true,
          "feedback": ``
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function stopOutcome threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "stopOutcome"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "stopOutcome",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "stopOutcome",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const stopOutcome = __AgencyFunction.create({
  name: "stopOutcome",
  module: "stdlib/agents/agency.agency",
  fn: __stopOutcome_impl,
  params: [],
  toolDefinition: {
    name: "stopOutcome",
    description: "No description provided.",
    schema: z.object({})
  },
  exported: false
}, __toolRegistry);
async function __failedToRun_impl(err) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["err"] = err;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency.agency", scopeName: "failedToRun", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("err" in __overrides) {
      err = __overrides["err"];
      __stack.args["err"] = err;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "failedToRun",
            args: {
              err
            },
            moduleId: "stdlib/agents/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "done": false,
          "feedback": `The program failed to run: ${__stack.args.err}`
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function failedToRun threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "failedToRun"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "failedToRun",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "failedToRun",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const failedToRun = __AgencyFunction.create({
  name: "failedToRun",
  module: "stdlib/agents/agency.agency",
  fn: __failedToRun_impl,
  params: [{
    name: "err",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "failedToRun",
    description: "No description provided.",
    schema: z.object({ "err": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __outcomeFromJudge_impl(task, data) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["data"] = data;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency.agency", scopeName: "outcomeFromJudge", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("data" in __overrides) {
      data = __overrides["data"];
      __stack.args["data"] = data;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "outcomeFromJudge",
            args: {
              task,
              data
            },
            moduleId: "stdlib/agents/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __self.__removedTools = __self.__removedTools || [];
        __stack.locals.items = await runPrompt({
          prompt: `${__readStatic(judgeResultPrompt, "judgeResultPrompt", "stdlib/agents/agency.agency")}

Task: ${__stack.args.task}

Result: ${__stack.args.data}`,
          messages: __threads().getOrCreateActive(),
          responseFormat: z.object({
            response: z.array(Feedback)
          }),
          clientConfig: {},
          maxToolCallRounds: 10,
          removedTools: __self.__removedTools,
          destructiveSink: __self,
          checkpointInfo: runner2.getCheckpointInfo()
        });
        if (hasInterrupts(__stack.locals.items)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.items);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.fb = await success(__stack.locals.items);
        if (hasInterrupts(__stack.locals.fb)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.fb);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.failed = await __call(feedbackHasErrors, {
          type: "positional",
          args: [__stack.locals.fb]
        });
        if (hasInterrupts(__stack.locals.failed)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.failed);
          return;
        }
      });
      await runner.ifElse(4, [
        {
          condition: async () => __stack.locals.failed,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.__ifbranch_3 = await __call(renderFeedback, {
                type: "positional",
                args: [__stack.locals.fb]
              });
              if (hasInterrupts(__stack.locals.__ifbranch_3)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__ifbranch_3);
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__ifbranch_3);
              return;
            });
          }
        }
      ], async (runner2) => {
        await runner2.step(2, async (runner3) => {
          __stack.locals.__ifbranch_2 = ``;
        });
        await runner2.step(3, async (runner3) => {
          runner3.exitMatch(1, __stack.locals.__ifbranch_2);
          return;
        });
      }, { matchId: 1 });
      await runner.step(5, async (runner2) => {
        __stack.locals.detail = __nn(__stack.locals.__matchval_1);
      });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "done": !__stack.locals.failed,
          "feedback": __stack.locals.detail
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function outcomeFromJudge threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "outcomeFromJudge"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "outcomeFromJudge",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "outcomeFromJudge",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const outcomeFromJudge = __AgencyFunction.create({
  name: "outcomeFromJudge",
  module: "stdlib/agents/agency.agency",
  fn: __outcomeFromJudge_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "data",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "outcomeFromJudge",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "data": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __judgeRun_impl(task, src) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["src"] = src;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency.agency", scopeName: "judgeRun", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("src" in __overrides) {
      src = __overrides["src"];
      __stack.args["src"] = src;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "judgeRun",
            args: {
              task,
              src
            },
            moduleId: "stdlib/agents/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.ran = await __call(runCode, {
          type: "positional",
          args: [__stack.args.src]
        });
        if (hasInterrupts(__stack.locals.ran)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.ran);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.__scrutinee_7 = __stack.locals.ran;
      });
      await runner.ifElse(3, [
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_7),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_7.error;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_5 = await __call(failedToRun, {
                type: "positional",
                args: [__stack.locals.err]
              });
              if (hasInterrupts(__stack.locals.__armval_5)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_5);
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(4, __stack.locals.__armval_5);
              return;
            });
          }
        },
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_7),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.data = __stack.locals.__scrutinee_7.value;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_6 = await __call(outcomeFromJudge, {
                type: "positional",
                args: [__stack.args.task, __stack.locals.data]
              });
              if (hasInterrupts(__stack.locals.__armval_6)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_6);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(4, __stack.locals.__armval_6);
              return;
            });
          }
        }
      ], void 0, { matchId: 4 });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_4));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function judgeRun threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "judgeRun"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "judgeRun",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "judgeRun",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const judgeRun = __AgencyFunction.create({
  name: "judgeRun",
  module: "stdlib/agents/agency.agency",
  fn: __judgeRun_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "src",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "judgeRun",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "src": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __judgeState_impl(task, result) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["result"] = result;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency.agency", scopeName: "judgeState", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("result" in __overrides) {
      result = __overrides["result"];
      __stack.args["result"] = result;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "judgeState",
            args: {
              task,
              result
            },
            moduleId: "stdlib/agents/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_11 = __stack.args.result;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_11),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals._ = __stack.locals.__scrutinee_11.error;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_9 = await __call(stopOutcome, {
                type: "positional",
                args: []
              });
              if (hasInterrupts(__stack.locals.__armval_9)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_9);
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(8, __stack.locals.__armval_9);
              return;
            });
          }
        },
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_11),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.src = __stack.locals.__scrutinee_11.value;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_10 = await __call(judgeRun, {
                type: "positional",
                args: [__stack.args.task, __stack.locals.src]
              });
              if (hasInterrupts(__stack.locals.__armval_10)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_10);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(8, __stack.locals.__armval_10);
              return;
            });
          }
        }
      ], void 0, { matchId: 8 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_8));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function judgeState threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "judgeState"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "judgeState",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "judgeState",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const judgeState = __AgencyFunction.create({
  name: "judgeState",
  module: "stdlib/agents/agency.agency",
  fn: __judgeState_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "result",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "judgeState",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "result": z.union([z.object({ __type: z.literal("resultType"), success: z.literal(true), value: z.string() }), z.object({ __type: z.literal("resultType"), success: z.literal(false), error: z.any() })]) })
  },
  exported: false
}, __toolRegistry);
async function __agencyCodingAgent_impl(task, context = __UNSET, maxAttempts = __UNSET, maxCost = __UNSET, maxTime = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["context"] = context === __UNSET ? `` : context;
  __stack.args["maxAttempts"] = maxAttempts === __UNSET ? 3 : maxAttempts;
  __stack.args["maxCost"] = maxCost === __UNSET ? 50 : maxCost;
  __stack.args["maxTime"] = maxTime === __UNSET ? 18e5 : maxTime;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency.agency", scopeName: "agencyCodingAgent", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("maxAttempts" in __overrides) {
      maxAttempts = __overrides["maxAttempts"];
      __stack.args["maxAttempts"] = maxAttempts;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
    if ("maxTime" in __overrides) {
      maxTime = __overrides["maxTime"];
      __stack.args["maxTime"] = maxTime;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "agencyCodingAgent",
            args: {
              task,
              context,
              maxAttempts,
              maxCost,
              maxTime
            },
            moduleId: "stdlib/agents/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.captured = await __call(guard, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            cost: __stack.args.maxCost,
            time: __stack.args.maxTime
          },
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/agents/agency.agency", fn: async () => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/agency.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.result = await __call(writeAgency, {
                  type: "positional",
                  args: [__stack.args.task, __stack.args.context]
                });
                if (hasInterrupts(__bstack.locals.result)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__bstack.locals.result);
                  return;
                }
              });
              await runner3.step(1, async (runner4) => {
                __bstack.locals.attemptsLeft = __stack.args.maxAttempts - 1;
              });
              await runner3.step(2, async (runner4) => {
                __bstack.locals.done = false;
              });
              await runner3.whileLoop(3, async () => !__bstack.locals.done, async (runner4) => {
                await runner4.step(0, async (runner5) => {
                  __bstack.locals.outcome = await __call(judgeState, {
                    type: "positional",
                    args: [__stack.args.task, __bstack.locals.result]
                  });
                  if (hasInterrupts(__bstack.locals.outcome)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__bstack.locals.outcome);
                    return;
                  }
                });
                await runner4.ifElse(1, [
                  {
                    condition: async () => __bstack.locals.outcome.done,
                    body: async (runner5) => {
                      await runner5.step(0, async (runner6) => {
                        __bstack.locals.done = true;
                      });
                    }
                  },
                  {
                    condition: async () => __bstack.locals.attemptsLeft <= 0,
                    body: async (runner5) => {
                      await runner5.step(1, async (runner6) => {
                        __bstack.locals.done = true;
                      });
                    }
                  }
                ], async (runner5) => {
                  await runner5.step(2, async (runner6) => {
                    __bstack.locals.extra = `${__stack.args.context}

A prior attempt had these problems; fix them:
${__bstack.locals.outcome.feedback}`;
                  });
                  await runner5.step(3, async (runner6) => {
                    __bstack.locals.next = await __call(writeAgency, {
                      type: "positional",
                      args: [__stack.args.task, __bstack.locals.extra]
                    });
                    if (hasInterrupts(__bstack.locals.next)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner6.halt(__bstack.locals.next);
                      return;
                    }
                  });
                  await runner5.step(4, async (runner6) => {
                    __bstack.locals.result = __bstack.locals.next;
                  });
                  await runner5.step(5, async (runner6) => {
                    __bstack.locals.attemptsLeft = __bstack.locals.attemptsLeft - 1;
                  });
                });
              });
              await runner3.step(4, async (runner4) => {
                runner4.halt(__bstack.locals.result);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.captured)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.captured);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.__scrutinee_15 = __stack.locals.captured;
      });
      await runner.ifElse(3, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_15),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.r = __stack.locals.__scrutinee_15.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_13 = __stack.locals.r;
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_13);
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_15),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.e = __stack.locals.__scrutinee_15.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_14 = failure({
                "source": `budget exceeded: ${__stack.locals.e.type}`,
                "errors": []
              }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "agencyCodingAgent", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_14)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_14);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_14);
              return;
            });
          }
        }
      ], void 0, { matchId: 12 });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_12));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function agencyCodingAgent threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "agencyCodingAgent"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "agencyCodingAgent",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "agencyCodingAgent",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const agencyCodingAgent = __AgencyFunction.create({
  name: "agencyCodingAgent",
  module: "stdlib/agents/agency.agency",
  fn: __agencyCodingAgent_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxAttempts",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxTime",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "agencyCodingAgent",
    description: `Writes an Agency program for the task, runs it, and judges its result against
  the task. On success returns source that compiles, typechecks, and passed the
  result check. If the result check keeps failing within maxAttempts (or the
  cost/time budget trips), returns the last attempt as a best effort.

  @param task - What the generated program should do.
  @param context - Optional extra material.
  @param maxAttempts - Max generation attempts before giving up (default 3).
  @param maxCost - Hard spend cap for the whole run (default $50).
  @param maxTime - Hard wall-clock cap for the whole run (default 30 minutes).`,
    schema: z.object({ "task": z.string(), "context": z.string().nullable().describe("Default: "), "maxAttempts": z.number().nullable().describe("Default: 3"), "maxCost": z.number().nullable().describe("Default: $50.00"), "maxTime": z.number().nullable().describe("Default: 30m") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/agents/agency.agency:stopOutcome": { "1": { "line": 17, "col": 2 } }, "stdlib/agents/agency.agency:failedToRun": { "1": { "line": 21, "col": 2 } }, "stdlib/agents/agency.agency:outcomeFromJudge": { "1": { "line": 28, "col": 2 }, "2": { "line": 29, "col": 2 }, "3": { "line": 30, "col": 2 }, "4": { "line": 31, "col": 17 }, "5": { "line": 31, "col": 2 }, "6": { "line": 32, "col": 2 }, "4.0": { "line": 31, "col": 32 }, "4.1": { "line": 31, "col": 32 } }, "stdlib/agents/agency.agency:judgeRun": { "1": { "line": 36, "col": 2 }, "2": { "line": 37, "col": 9 }, "3": { "line": 37, "col": 9 }, "4": { "line": 37, "col": 2 }, "3.0": { "line": 37, "col": 9 }, "3.1": { "line": 38, "col": 20 }, "3.2": { "line": 38, "col": 20 }, "3.3": { "line": 37, "col": 9 }, "3.4": { "line": 39, "col": 21 }, "3.5": { "line": 39, "col": 21 } }, "stdlib/agents/agency.agency:judgeState": { "1": { "line": 46, "col": 9 }, "2": { "line": 46, "col": 9 }, "3": { "line": 46, "col": 2 }, "2.0": { "line": 46, "col": 9 }, "2.1": { "line": 47, "col": 18 }, "2.2": { "line": 47, "col": 18 }, "2.3": { "line": 46, "col": 9 }, "2.4": { "line": 48, "col": 20 }, "2.5": { "line": 48, "col": 20 } }, "stdlib/agents/agency.agency:agencyCodingAgent": { "1": { "line": 65, "col": 2 }, "2": { "line": 84, "col": 9 }, "3": { "line": 84, "col": 9 }, "4": { "line": 84, "col": 2 }, "3.0": { "line": 84, "col": 9 }, "3.1": { "line": 85, "col": 18 }, "3.2": { "line": 85, "col": 18 }, "3.3": { "line": 84, "col": 9 }, "3.4": { "line": 86, "col": 18 }, "3.5": { "line": 86, "col": 18 } }, "stdlib/agents/agency.agency:__block_0": { "1.0": { "line": 66, "col": 4 }, "1.1": { "line": 67, "col": 4 }, "1.2": { "line": 68, "col": 4 }, "1.3.0": { "line": 70, "col": 6 }, "1.3.1.0": { "line": 72, "col": 8 }, "1.3.1.1": { "line": 74, "col": 8 }, "1.3.1.2": { "line": 76, "col": 8 }, "1.3.1.3": { "line": 77, "col": 8 }, "1.3.1.4": { "line": 78, "col": 8 }, "1.3.1.5": { "line": 79, "col": 8 }, "1.3.1": { "line": 71, "col": 6 }, "1.3": { "line": 69, "col": 4 }, "1.4": { "line": 82, "col": 4 } } };
export {
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  agencyCodingAgent,
  approve,
  stdin_default as default,
  failedToRun,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  judgeRun,
  judgeState,
  outcomeFromJudge,
  reject,
  respondToInterrupts,
  rewindFrom,
  stopOutcome
};
