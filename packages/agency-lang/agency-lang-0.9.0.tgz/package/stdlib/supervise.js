import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  __call,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/supervise.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/supervise.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/supervise.agency");
  __ctx.globals.set("stdlib/supervise.agency", "_instanceCounter", 0);
}
__registerGlobalsInit("stdlib/supervise.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/supervise.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const SuperviseDecision = z.object({ "action": z.union([z.literal("continue"), z.literal("redirect"), z.literal("stop")]), "message": z.string() });
async function __supervise_impl(every2, maxTime, check, block) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/supervise.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["every"] = every2;
  __stack.args["maxTime"] = maxTime;
  __stack.args["check"] = check;
  __stack.args["block"] = block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/supervise.agency", scopeName: "supervise", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("every" in __overrides) {
      every2 = __overrides["every"];
      __stack.args["every"] = every2;
    }
    if ("maxTime" in __overrides) {
      maxTime = __overrides["maxTime"];
      __stack.args["maxTime"] = maxTime;
    }
    if ("check" in __overrides) {
      check = __overrides["check"];
      __stack.args["check"] = check;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "supervise",
            args: {
              every: every2,
              maxTime,
              check,
              block
            },
            moduleId: "stdlib/supervise.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.maxTime < __stack.args.every,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(`supervise: maxTime is less than the check interval, so no checkpoint would ever be reached`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "supervise", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __globals().set("stdlib/supervise.agency", "_instanceCounter", __globals().get("stdlib/supervise.agency", "_instanceCounter") + 1);
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.instanceLabel = `std::supervise#${__globals().get("stdlib/supervise.agency", "_instanceCounter")}`;
      });
      await runner.handle(4, async (intr) => {
        if (!__eq(intr.effect, `std::guard`) || !__eq(intr.data.label, __stack.locals.instanceLabel)) {
          return await __call(pass, {
            type: "positional",
            args: []
          });
        }
        __stack.locals.spent = intr.data.spent;
        if (__stack.locals.spent >= __stack.args.maxTime) {
          return await reject(`supervise: maxTime reached`);
        }
        __stack.locals.decision = await __call(__stack.args.check, {
          type: "positional",
          args: [__stack.locals.spent, intr.data.draftValue ?? null]
        });
        if (hasInterrupts(__stack.locals.decision)) {
          throw new Error("Cannot throw an interrupt inside a handler body");
        }
        if (isAborted(__stack.locals.decision)) {
          throw __stack.locals.decision.toError();
        }
        __stack.locals.overshoot = __stack.locals.spent - intr.data.limit;
        __stack.locals.nextInterval = __stack.args.every;
        if (__stack.args.maxTime - __stack.locals.spent < __stack.args.every) {
          __stack.locals.nextInterval = __stack.args.maxTime - __stack.locals.spent;
        }
        __stack.locals.grant = __stack.locals.overshoot + __stack.locals.nextInterval;
        __stack.locals.__matchval_1 = await (async () => {
          if (__stack.locals.decision.action === `continue`) {
            __stack.locals.__armval_2 = await approve({
              "maxTime": __stack.locals.grant
            });
            if (hasInterrupts(__stack.locals.__armval_2)) {
              throw new Error("Cannot throw an interrupt inside a handler body");
            }
            if (isAborted(__stack.locals.__armval_2)) {
              throw __stack.locals.__armval_2.toError();
            }
            return __stack.locals.__armval_2;
          } else if (__stack.locals.decision.action === `redirect`) {
            __stack.locals.__armval_3 = await approve({
              "maxTime": __stack.locals.grant,
              "message": __stack.locals.decision.message
            });
            if (hasInterrupts(__stack.locals.__armval_3)) {
              throw new Error("Cannot throw an interrupt inside a handler body");
            }
            if (isAborted(__stack.locals.__armval_3)) {
              throw __stack.locals.__armval_3.toError();
            }
            return __stack.locals.__armval_3;
          } else if (__stack.locals.decision.action === `stop`) {
            __stack.locals.__armval_4 = await reject(__stack.locals.decision.message);
            if (hasInterrupts(__stack.locals.__armval_4)) {
              throw new Error("Cannot throw an interrupt inside a handler body");
            }
            if (isAborted(__stack.locals.__armval_4)) {
              throw __stack.locals.__armval_4.toError();
            }
            return __stack.locals.__armval_4;
          }
        })();
        return __nn(__stack.locals.__matchval_1);
      }, async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.captured = await __call(_guard, {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              time: __stack.args.every,
              label: __stack.locals.instanceLabel
            },
            blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/supervise.agency", fn: async () => {
              const __bsetup = setupFunction();
              const __bstack = __bsetup.stack;
              const __self2 = __bstack.locals;
              const __bframe___block_0 = __bstack;
              const runner4 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/supervise.agency", scopeName: "__block_0" });
              try {
                await runner4.step(0, async (runner5) => {
                  runner5.halt(await __call(__stack.args.block, {
                    type: "positional",
                    args: []
                  }));
                  return;
                });
                return runner4.halted ? runner4.haltResult : void 0;
              } catch (__blockError) {
                if (__blockError instanceof AgencyAbort) {
                  return AbortedResult.fromError(__blockError, __bstack, "__block_0");
                }
                throw __blockError;
              } finally {
                __bsetup.stateStack.pop();
              }
            }, params: [], toolDefinition: null }, __toolRegistry)
          });
          if (hasInterrupts(__stack.locals.captured)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.captured);
            return;
          }
          if (isAborted(__stack.locals.captured)) {
            runner3.halt(__stack.locals.captured.carryThrough(__stack, "supervise"));
            return;
          }
        });
        await runner2.step(1, async (runner3) => {
          __functionCompleted = true;
          runner3.halt(__stack.locals.captured);
          return;
        });
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "supervise");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function supervise threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "supervise"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "supervise",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "supervise",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const supervise = __AgencyFunction.create({
  name: "supervise",
  module: "stdlib/supervise.agency",
  fn: __supervise_impl,
  params: [{
    name: "every",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxTime",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "check",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "supervise",
    description: `Run a block, pausing it every interval to check progress and steer it.

  @param every - How often to pause and check
  @param maxTime - Total time budget across all intervals
  @param check - Called at each pause with elapsed time and the block's most
    recent saveDraft value (null when none has been saved), and decides
    whether to continue, redirect, or stop. The draft is the block's own
    account of its progress: a draft that has not changed between checks is
    strong evidence the block is stalled.
  @param block - The long-running work. Known limitation: do not call
    supervise() in parallel fork branches \u2014 sibling instances can mint
    colliding guard labels (the instance counter is branch-isolated
    while the handler chain is shared) and answer each other's trips.`,
    schema: z.object({ "every": z.number(), "maxTime": z.number() })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/supervise.agency:supervise": { "1": { "line": 66, "col": 2 }, "2": { "line": 69, "col": 2 }, "3": { "line": 70, "col": 2 }, "4": { "line": 71, "col": 2 }, "1.0": { "line": 67, "col": 4 }, "4.0": { "line": 72, "col": 4 }, "4.1": { "line": 75, "col": 4 } }, "stdlib/supervise.agency:__block_0": { "4.0.0": { "line": 73, "col": 6 } } };
export {
  SuperviseDecision,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  reject,
  respondToInterrupts,
  rewindFrom,
  supervise
};
