import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { bash, ls, glob, grep } from "agency-lang/stdlib/shell.js";
import { edit } from "agency-lang/stdlib/fs.js";
import { systemMessage, guard } from "agency-lang/stdlib/thread.js";
import { verify, feedbackHasErrors, renderFeedback } from "agency-lang/stdlib/agency.js";
import { withContext, unwrapGuard } from "agency-lang/stdlib/agents/shared.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  runPrompt,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  failure,
  isFailure,
  stampFailureBoundary,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __threads,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/agents/coding.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(bash);
__registerTool(ls);
__registerTool(glob);
__registerTool(grep);
__registerTool(edit);
__registerTool(systemMessage);
__registerTool(guard);
__registerTool(verify);
__registerTool(feedbackHasErrors);
__registerTool(renderFeedback);
__registerTool(withContext);
__registerTool(unwrapGuard);
let __staticInitPromise = null;
let codingTools = __UNINIT_STATIC;
let codingSysPrompt = __UNINIT_STATIC;
let finalizeReminder = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    codingTools = __deepFreeze([await __callMethod(__readStatic(read, "read", ""), "partial", {
      type: "named",
      positionalArgs: [],
      namedArgs: {
        useAgentCwd: true
      }
    }), await __callMethod(__readStatic(write, "write", ""), "partial", {
      type: "named",
      positionalArgs: [],
      namedArgs: {
        useAgentCwd: true
      }
    }), await __callMethod(__readStatic(edit, "edit", ""), "partial", {
      type: "named",
      positionalArgs: [],
      namedArgs: {
        useAgentCwd: true
      }
    }), await __callMethod(__readStatic(ls, "ls", ""), "partial", {
      type: "named",
      positionalArgs: [],
      namedArgs: {
        useAgentCwd: true
      }
    }), await __callMethod(__readStatic(glob, "glob", ""), "partial", {
      type: "named",
      positionalArgs: [],
      namedArgs: {
        useAgentCwd: true
      }
    }), await __callMethod(__readStatic(grep, "grep", ""), "partial", {
      type: "named",
      positionalArgs: [],
      namedArgs: {
        useAgentCwd: true
      }
    }), await __callMethod(__readStatic(bash, "bash", ""), "partial", {
      type: "named",
      positionalArgs: [],
      namedArgs: {
        useAgentCwd: true
      }
    })]);
    codingSysPrompt = __deepFreeze(`You are an expert software engineer. Solve the task by writing and running real code with your tools.

- The deliverable is a working artifact backed by real tool output, not a description. Actually run and exercise what you build.
- Match the output contract exactly: the requested filename, path, format, and fields. Follow the task's stated whitespace and trailing-newline requirement precisely, whether it asks for one or forbids one. A near-miss fails.
- When an exact check decides success (a numeric tolerance, an exact match, or a hidden test), do not stop at the first solution that passes your own check. Write down the judgment calls you made to reach it. If a choice could have gone another way and still fit the task, it is an assumption, not a fact, and your answer may only be correct under your reading of it. Re-check that it still passes under the other readings, and prefer a solution that holds under all of them.
- NEVER fabricate output you did not actually produce.`);
    finalizeReminder = __deepFreeze(`Before finishing, re-read the task's exact output requirements (filename, format, fields, whitespace, trailing newline) and confirm the artifact on disk matches them exactly.`);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    codingTools,
    codingSysPrompt,
    finalizeReminder
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/agents/coding.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/agents/coding.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/agents/coding.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/agents/coding.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
async function __codingAgent_impl(task, context = __UNSET, criteria = __UNSET, maxAttempts = __UNSET, maxCost = __UNSET, maxTime = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/coding.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["context"] = context === __UNSET ? `` : context;
  __stack.args["criteria"] = criteria === __UNSET ? [] : criteria;
  __stack.args["maxAttempts"] = maxAttempts === __UNSET ? 3 : maxAttempts;
  __stack.args["maxCost"] = maxCost === __UNSET ? 50 : maxCost;
  __stack.args["maxTime"] = maxTime === __UNSET ? 18e5 : maxTime;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/coding.agency", scopeName: "codingAgent", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("criteria" in __overrides) {
      criteria = __overrides["criteria"];
      __stack.args["criteria"] = criteria;
    }
    if ("maxAttempts" in __overrides) {
      maxAttempts = __overrides["maxAttempts"];
      __stack.args["maxAttempts"] = maxAttempts;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
    if ("maxTime" in __overrides) {
      maxTime = __overrides["maxTime"];
      __stack.args["maxTime"] = maxTime;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "codingAgent",
            args: {
              task,
              context,
              criteria,
              maxAttempts,
              maxCost,
              maxTime
            },
            moduleId: "stdlib/agents/coding.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.captured = await __call(guard, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            cost: __stack.args.maxCost,
            time: __stack.args.maxTime
          },
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/agents/coding.agency", fn: async () => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/coding.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.reply = ``;
              });
              await runner3.step(1, async (runner4) => {
                __bstack.locals.msg = await __call(withContext, {
                  type: "positional",
                  args: [__stack.args.task, __stack.args.context]
                });
                if (hasInterrupts(__bstack.locals.msg)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__bstack.locals.msg);
                  return;
                }
              });
              await runner3.thread(2, "create", async () => ({ label: `codingAgent` }), async (runner4) => {
                await runner4.step(0, async (runner5) => {
                  const __funcResult = await __call(systemMessage, {
                    type: "positional",
                    args: [__readStatic(codingSysPrompt, "codingSysPrompt", "stdlib/agents/coding.agency")]
                  });
                  if (hasInterrupts(__funcResult)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__funcResult);
                    return;
                  }
                });
                await runner4.step(1, async (runner5) => {
                  __bstack.locals.done = false;
                });
                await runner4.step(2, async (runner5) => {
                  __bstack.locals.attemptsLeft = __stack.args.maxAttempts;
                });
                await runner4.whileLoop(3, async () => !__bstack.locals.done && __bstack.locals.attemptsLeft > 0, async (runner5) => {
                  await runner5.step(0, async (runner6) => {
                    __self2.__removedTools = __self2.__removedTools || [];
                    __bstack.locals.reply = await runPrompt({
                      prompt: `${__bstack.locals.msg}

${__readStatic(finalizeReminder, "finalizeReminder", "stdlib/agents/coding.agency")}`,
                      messages: __threads().getOrCreateActive(),
                      clientConfig: {
                        "tools": __readStatic(codingTools, "codingTools", "stdlib/agents/coding.agency")
                      },
                      maxToolCallRounds: 10,
                      removedTools: __self2.__removedTools,
                      destructiveSink: __self2,
                      checkpointInfo: runner6.getCheckpointInfo()
                    });
                    if (hasInterrupts(__bstack.locals.reply)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner6.halt(__bstack.locals.reply);
                      return;
                    }
                  });
                  await runner5.step(1, async (runner6) => {
                    __bstack.locals.fb = await __call(verify, {
                      type: "positional",
                      args: [__stack.args.task, __stack.args.criteria]
                    });
                    if (hasInterrupts(__bstack.locals.fb)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner6.halt(__bstack.locals.fb);
                      return;
                    }
                  });
                  await runner5.ifElse(2, [
                    {
                      condition: async () => await __call(feedbackHasErrors, {
                        type: "positional",
                        args: [__bstack.locals.fb]
                      }),
                      body: async (runner6) => {
                        await runner6.step(0, async (runner7) => {
                          __bstack.locals.msg = `Not done yet. A strict review found:

${await __call(renderFeedback, {
                            type: "positional",
                            args: [__bstack.locals.fb]
                          })}

Fix each problem exactly.`;
                        });
                        await runner6.step(1, async (runner7) => {
                          __bstack.locals.attemptsLeft = __bstack.locals.attemptsLeft - 1;
                        });
                      }
                    }
                  ], async (runner6) => {
                    await runner6.step(2, async (runner7) => {
                      __bstack.locals.done = true;
                    });
                  });
                });
              });
              await runner3.step(3, async (runner4) => {
                runner4.halt(__bstack.locals.reply);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.captured)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.captured);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(unwrapGuard, {
          type: "positional",
          args: [__stack.locals.captured, `Coding`]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function codingAgent threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "codingAgent"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "codingAgent",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "codingAgent",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const codingAgent = __AgencyFunction.create({
  name: "codingAgent",
  module: "stdlib/agents/coding.agency",
  fn: __codingAgent_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "criteria",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxAttempts",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxTime",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "codingAgent",
    description: `General-purpose coding agent. Writes and runs code to complete a task and
  verifies the result against the task's success criteria. Returns a short
  summary; the real output is filesystem side effects.

  @param task - What to build or fix.
  @param context - Optional extra material (data, examples, constraints).
  @param criteria - Optional authoritative acceptance criteria (e.g. an expert
    checklist) passed through to \`verify\` so the strict review checks those
    exact items, not just its own re-derivation.
  @param maxAttempts - Max verify-and-fix attempts before returning (default 3).
  @param maxCost - Hard spend cap for the whole run (default $50).
  @param maxTime - Hard wall-clock cap for the whole run (default 30 minutes).`,
    schema: z.object({ "task": z.string(), "context": z.string().nullable().describe("Default: "), "criteria": z.array(z.string()).nullable().describe("Default: []"), "maxAttempts": z.number().nullable().describe("Default: 3"), "maxCost": z.number().nullable().describe("Default: $50.00"), "maxTime": z.number().nullable().describe("Default: 30m") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/agents/coding.agency:codingAgent": { "1": { "line": 45, "col": 2 }, "2": { "line": 65, "col": 2 } }, "stdlib/agents/coding.agency:__block_0": { "1.0": { "line": 46, "col": 4 }, "1.1": { "line": 47, "col": 4 }, "1.2.0": { "line": 49, "col": 6 }, "1.2.1": { "line": 50, "col": 6 }, "1.2.2": { "line": 51, "col": 6 }, "1.2.3.0": { "line": 53, "col": 8 }, "1.2.3.1": { "line": 54, "col": 8 }, "1.2.3.2.0": { "line": 56, "col": 10 }, "1.2.3.2.1": { "line": 57, "col": 10 }, "1.2.3.2.2": { "line": 59, "col": 10 }, "1.2.3.2": { "line": 55, "col": 8 }, "1.2.3": { "line": 52, "col": 6 }, "1.2": { "line": 48, "col": 4 }, "1.3": { "line": 63, "col": 4 } } };
export {
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  codingAgent,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  reject,
  respondToInterrupts,
  rewindFrom
};
