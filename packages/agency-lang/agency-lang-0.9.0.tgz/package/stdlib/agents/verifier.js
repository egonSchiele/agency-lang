import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { failOpenFeedback, Feedback } from "agency-lang/stdlib/agents/lib/feedback.js";
import { llmOptions } from "agency-lang/stdlib/agents/lib/shared.js";
import { readOnlyFileTools, shellTools } from "agency-lang/stdlib/agents/lib/toolkits.js";
import { concurrencyPool } from "agency-lang/stdlib/concurrency.js";
import { agentSkill } from "agency-lang/stdlib/skills.js";
import { systemMessage, threadIsNew } from "agency-lang/stdlib/thread.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  runPrompt,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __eq,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __threads,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/agents/verifier.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(failOpenFeedback);
__registerTool(Feedback);
__registerTool(llmOptions);
__registerTool(readOnlyFileTools);
__registerTool(shellTools);
__registerTool(concurrencyPool);
__registerTool(agentSkill);
__registerTool(systemMessage);
__registerTool(threadIsNew);
let __staticInitPromise = null;
let POOL_SIZE = __UNINIT_STATIC;
let skills = __UNINIT_STATIC;
let systemPrompt = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    POOL_SIZE = __deepFreeze(4);
    skills = __deepFreeze(await __call(agentSkill, {
      type: "positional",
      args: [`verifier`]
    }));
    systemPrompt = __deepFreeze(`You verify whether a coding task was completed correctly. You do NOT fix anything. Inspect, COMPUTE, and report.

The grading tests are hidden and NOT in this environment, so you must reconstruct and ACTUALLY RUN every check the task states \u2014 never eyeball the artifact.

Method:
1. Enumerate EVERY explicit success criterion in the task. Two kinds: the output contract (exact file path and name, format, JSON keys, field types, units, signed-vs-unsigned, the stated whitespace / trailing-newline requirement) AND every quantitative rule (lengths, ranges, counts, thresholds, temperatures, GC content, percentages, etc.).
2. For EACH criterion, use the \`exec\` tool to COMPUTE the artifact's actual value and compare it to the requirement. If the task names a specific tool or command to compute a value (e.g. a CLI with exact flags), install if needed and run THAT tool \u2014 it is the ground truth; do not approximate it with your own estimate.
3. A criterion you did NOT computationally verify is itself a gap \u2014 report it as one. A near-miss on any numeric constraint is an error: report the actual computed value vs. the requirement (e.g. "Tm difference 6.5\xB0C, limit 5\xB0C").

Never say the artifact "appears" or "should" satisfy something. Run it, measure it, and report a concrete pass/fail per criterion with the numbers.`);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    POOL_SIZE,
    skills,
    systemPrompt
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/agents/verifier.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/agents/verifier.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/agents/verifier.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/agents/verifier.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/agents/verifier.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
async function __buildTools_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/verifier.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/verifier.agency", scopeName: "buildTools", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildTools",
            args: {},
            moduleId: "stdlib/agents/verifier.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt([...await __call(readOnlyFileTools, {
          type: "positional",
          args: []
        }), ...await __call(shellTools, {
          type: "positional",
          args: []
        }), await __callMethod(__readStatic(readBinary, "readBinary", ""), "partial", {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            useAgentCwd: true
          }
        }), __readStatic(skills, "skills", "stdlib/agents/verifier.agency")]);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildTools");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildTools threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildTools"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildTools",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildTools",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildTools = __AgencyFunction.create({
  name: "buildTools",
  module: "stdlib/agents/verifier.agency",
  fn: __buildTools_impl,
  params: [],
  toolDefinition: {
    name: "buildTools",
    description: `Return the verifier's tools. It measures with shell pipelines and reads
  bytes, because a criterion checked by eye is a criterion not checked. It
  has no write tools: a verifier that can fix things is no longer a verifier.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __verifierAgent_impl(task, criteria = __UNSET, context = __UNSET, maxCost = __UNSET, maxTime = __UNSET, model = __UNSET, provider = __UNSET, session = __UNSET, extraTools = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/verifier.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["criteria"] = criteria === __UNSET ? [] : criteria;
  __stack.args["context"] = context === __UNSET ? `` : context;
  __stack.args["maxCost"] = maxCost === __UNSET ? 20 : maxCost;
  __stack.args["maxTime"] = maxTime === __UNSET ? 9e5 : maxTime;
  __stack.args["model"] = model === __UNSET ? `` : model;
  __stack.args["provider"] = provider === __UNSET ? `` : provider;
  __stack.args["session"] = session === __UNSET ? `` : session;
  __stack.args["extraTools"] = extraTools === __UNSET ? [] : extraTools;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/verifier.agency", scopeName: "verifierAgent", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("criteria" in __overrides) {
      criteria = __overrides["criteria"];
      __stack.args["criteria"] = criteria;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
    if ("maxTime" in __overrides) {
      maxTime = __overrides["maxTime"];
      __stack.args["maxTime"] = maxTime;
    }
    if ("model" in __overrides) {
      model = __overrides["model"];
      __stack.args["model"] = model;
    }
    if ("provider" in __overrides) {
      provider = __overrides["provider"];
      __stack.args["provider"] = provider;
    }
    if ("session" in __overrides) {
      session = __overrides["session"];
      __stack.args["session"] = session;
    }
    if ("extraTools" in __overrides) {
      extraTools = __overrides["extraTools"];
      __stack.args["extraTools"] = extraTools;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "verifierAgent",
            args: {
              task,
              criteria,
              context,
              maxCost,
              maxTime,
              model,
              provider,
              session,
              extraTools
            },
            moduleId: "stdlib/agents/verifier.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.captured = await __call(_guard, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            cost: __stack.args.maxCost,
            time: __stack.args.maxTime
          },
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/agents/verifier.agency", fn: async () => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/verifier.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.results = [];
              });
              await runner3.thread(1, "create", async () => ({ label: `verifierAgent`, session: __stack.args.session }), async (runner4) => {
                await runner4.ifElse(0, [
                  {
                    condition: async () => await __call(threadIsNew, {
                      type: "positional",
                      args: []
                    }),
                    body: async (runner5) => {
                      await runner5.step(0, async (runner6) => {
                        const __funcResult = await __call(systemMessage, {
                          type: "positional",
                          args: [__readStatic(systemPrompt, "systemPrompt", "stdlib/agents/verifier.agency")]
                        });
                        if (hasInterrupts(__funcResult)) {
                          await getRuntimeContext().ctx.pendingPromises.awaitAll();
                          runner6.halt(__funcResult);
                          return;
                        }
                        if (isAborted(__funcResult)) {
                          runner6.halt(__funcResult.carryThrough(__bstack, "__block_0"));
                          return;
                        }
                      });
                    }
                  }
                ]);
                await runner4.step(1, async (runner5) => {
                  __bstack.locals.criteriaString = await __call(criteriaAsString, {
                    type: "positional",
                    args: [__stack.args.criteria]
                  });
                  if (hasInterrupts(__bstack.locals.criteriaString)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__bstack.locals.criteriaString);
                    return;
                  }
                  if (isAborted(__bstack.locals.criteriaString)) {
                    runner5.halt(__bstack.locals.criteriaString.carryThrough(__bstack, "__block_0"));
                    return;
                  }
                });
                await runner4.step(2, async (runner5) => {
                });
                await runner4.step(3, async (runner5) => {
                  __bstack.locals.generateCriteriaPrompt = `
    Given this task, come up with measurable criteria for success.
    <task>${__stack.args.task}</task>
    `;
                });
                await runner4.step(4, async (runner5) => {
                  __self2.__removedTools = __self2.__removedTools || [];
                  __bstack.locals.generatedCriteria = await runPrompt({
                    prompt: __bstack.locals.generateCriteriaPrompt,
                    messages: __threads().getOrCreateActive(),
                    responseFormat: z.object({
                      response: z.array(z.string())
                    }),
                    clientConfig: await __call(llmOptions, {
                      type: "named",
                      positionalArgs: [],
                      namedArgs: {
                        model: __stack.args.model,
                        provider: __stack.args.provider,
                        tools: __stack.args.extraTools
                      }
                    }),
                    draftSchema: z.union([z.object({ __type: z.literal("resultType"), success: z.literal(true), value: z.array(Feedback) }), z.object({ __type: z.literal("resultType"), success: z.literal(false), error: z.any() })]),
                    maxToolCallRounds: 10,
                    removedTools: __self2.__removedTools,
                    destructiveSink: __self2,
                    checkpointInfo: runner5.getCheckpointInfo()
                  });
                  if (hasInterrupts(__bstack.locals.generatedCriteria)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__bstack.locals.generatedCriteria);
                    return;
                  }
                });
                await runner4.step(5, async (runner5) => {
                  __bstack.locals.allCriteria = [...__stack.args.criteria, ...__bstack.locals.generatedCriteria];
                });
                await runner4.step(6, async (runner5) => {
                  __bstack.locals.prompt = `
      Given this task:
      <task>${__stack.args.task}</task>

      Judge it against this criterion:
      <criterion>${await __call(criteriaAsString, {
                    type: "positional",
                    args: [__bstack.locals.allCriteria]
                  })}</criterion>

      Verify, don't assume. Use your tools to see what code has been produced, and compare it to the criterion.
      Report a concrete pass/fail. If the criterion involves a number, compute that number.
      A criterion you did not actually compute counts as a failure.
      `;
                });
                await runner4.step(7, async (runner5) => {
                  __self2.__removedTools = __self2.__removedTools || [];
                  __bstack.locals.items = await runPrompt({
                    prompt: __bstack.locals.prompt,
                    messages: __threads().getOrCreateActive(),
                    responseFormat: z.object({
                      response: z.array(Feedback)
                    }),
                    clientConfig: await __call(llmOptions, {
                      type: "named",
                      positionalArgs: [],
                      namedArgs: {
                        model: __stack.args.model,
                        provider: __stack.args.provider,
                        tools: await __callMethod(await await __call(buildTools, {
                          type: "positional",
                          args: []
                        }), "concat", {
                          type: "positional",
                          args: [__stack.args.extraTools]
                        })
                      }
                    }),
                    draftSchema: z.union([z.object({ __type: z.literal("resultType"), success: z.literal(true), value: z.array(Feedback) }), z.object({ __type: z.literal("resultType"), success: z.literal(false), error: z.any() })]),
                    maxToolCallRounds: 10,
                    removedTools: __self2.__removedTools,
                    destructiveSink: __self2,
                    checkpointInfo: runner5.getCheckpointInfo()
                  });
                  if (hasInterrupts(__bstack.locals.items)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__bstack.locals.items);
                    return;
                  }
                });
                await runner4.step(8, async (runner5) => {
                  runner5.halt(__bstack.locals.items);
                  return;
                });
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_0");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.captured)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.captured);
          return;
        }
        if (isAborted(__stack.locals.captured)) {
          runner2.halt(__stack.locals.captured.carryThrough(__stack, "verifierAgent"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(failOpenFeedback, {
          type: "positional",
          args: [__stack.locals.captured]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "verifierAgent");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function verifierAgent threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "verifierAgent"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "verifierAgent",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "verifierAgent",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const verifierAgent = __AgencyFunction.create({
  name: "verifierAgent",
  module: "stdlib/agents/verifier.agency",
  fn: __verifierAgent_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "criteria",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxTime",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "model",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "provider",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "session",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "extraTools",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "verifierAgent",
    description: `Verify work on disk against a task: derive measurable success criteria,
  compute each one with tools, and return one pass/fail finding per
  criterion.

  @param task - The task the work must satisfy
  @param criteria - Known acceptance criteria to check, extended with derived ones
  @param context - Extra material for the judgment, or ""
  @param maxCost - Hard spend cap
  @param maxTime - Hard wall-clock cap
  @param model - Model override, or "" for the ambient model
  @param provider - Provider for the model override
  @param session - Session name to share a thread across calls, or "" for isolated
  @param extraTools - Extra tools to offer the LLM, appended to the built-in set`,
    schema: z.object({ "task": z.string(), "criteria": z.array(z.string()).nullable().describe("Default: []"), "context": z.string().nullable().describe("Default: "), "maxCost": z.number().nullable().describe("Default: $20.00"), "maxTime": z.number().nullable().describe("Default: 15m"), "model": z.string().nullable().describe("Default: "), "provider": z.string().nullable().describe("Default: "), "session": z.string().nullable().describe("Default: "), "extraTools": z.array(z.any()).nullable().describe("Default: []") })
  },
  exported: true
}, __toolRegistry);
async function __criteriaAsString_impl(criteria) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/verifier.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["criteria"] = criteria;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/verifier.agency", scopeName: "criteriaAsString", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("criteria" in __overrides) {
      criteria = __overrides["criteria"];
      __stack.args["criteria"] = criteria;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "criteriaAsString",
            args: {
              criteria
            },
            moduleId: "stdlib/agents/verifier.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.criteria.length, 0),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(``);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(await await __call(map, {
          type: "named",
          positionalArgs: [__stack.args.criteria],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/agents/verifier.agency", fn: async (criterion) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_1 = __bstack;
            __bstack.args["criterion"] = criterion;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/verifier.agency", scopeName: "__block_1" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(`- ${__bstack.args.criterion}`);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_1");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "criterion", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }), "join", {
          type: "positional",
          args: [`
`]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "criteriaAsString");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function criteriaAsString threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "criteriaAsString"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "criteriaAsString",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "criteriaAsString",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const criteriaAsString = __AgencyFunction.create({
  name: "criteriaAsString",
  module: "stdlib/agents/verifier.agency",
  fn: __criteriaAsString_impl,
  params: [{
    name: "criteria",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "criteriaAsString",
    description: "No description provided.",
    schema: z.object({ "criteria": z.array(z.string()) })
  },
  exported: false
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/agents/verifier.agency:buildTools": { "1": { "line": 24, "col": 2 } }, "stdlib/agents/verifier.agency:verifierAgent": { "1": { "line": 69, "col": 2 }, "2": { "line": 122, "col": 2 } }, "stdlib/agents/verifier.agency:__block_0": { "1.0": { "line": 70, "col": 4 }, "1.1.0.0": { "line": 73, "col": 8 }, "1.1.0": { "line": 72, "col": 6 }, "1.1.1": { "line": 75, "col": 6 }, "1.1.3": { "line": 86, "col": 6 }, "1.1.4": { "line": 91, "col": 6 }, "1.1.5": { "line": 96, "col": 6 }, "1.1.6": { "line": 98, "col": 6 }, "1.1.7": { "line": 110, "col": 6 }, "1.1.8": { "line": 118, "col": 6 }, "1.1": { "line": 71, "col": 4 } }, "stdlib/agents/verifier.agency:criteriaAsString": { "1": { "line": 126, "col": 2 }, "2": { "line": 129, "col": 2 }, "1.0": { "line": 127, "col": 4 } }, "stdlib/agents/verifier.agency:__block_1": {} };
export {
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  buildTools,
  criteriaAsString,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  reject,
  respondToInterrupts,
  rewindFrom,
  verifierAgent
};
