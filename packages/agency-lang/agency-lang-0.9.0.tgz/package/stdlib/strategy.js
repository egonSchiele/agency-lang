import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { _mostCommon } from "agency-lang/stdlib-lib/builtins.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isFailure,
  stampFailureBoundary,
  AgencyFunction as __AgencyFunction,
  __call,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/strategy.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/strategy.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/strategy.agency");
}
__registerGlobalsInit("stdlib/strategy.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/strategy.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
async function __mostCommon_impl(items) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/strategy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["items"] = items;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/strategy.agency", scopeName: "mostCommon", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("items" in __overrides) {
      items = __overrides["items"];
      __stack.args["items"] = items;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "mostCommon",
            args: {
              items
            },
            moduleId: "stdlib/strategy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_mostCommon, {
          type: "positional",
          args: [__stack.args.items]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "mostCommon");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function mostCommon threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "mostCommon"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "mostCommon",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "mostCommon",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const mostCommon = __AgencyFunction.create({
  name: "mostCommon",
  module: "stdlib/strategy.agency",
  fn: __mostCommon_impl,
  params: [{
    name: "items",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "mostCommon",
    description: "No description provided.",
    schema: z.object({ "items": z.array(z.any()) })
  },
  exported: false
}, __toolRegistry);
async function __sample_impl(n, block) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/strategy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["n"] = n;
  __stack.args["block"] = block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/strategy.agency", scopeName: "sample", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("n" in __overrides) {
      n = __overrides["n"];
      __stack.args["n"] = n;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "sample",
            args: {
              n,
              block
            },
            moduleId: "stdlib/strategy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await runner2.fork(1, await __call(range, {
          type: "positional",
          args: [__stack.args.n]
        }), async (__forkItem, __forkIndex, __forkBranchStack) => {
          const __bstack = __forkBranchStack.getNewState();
          const __self2 = __bstack.locals;
          const __bframe___block_0 = __bstack;
          const _ = __forkItem;
          __bstack.args["_"] = __forkItem;
          const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/strategy.agency", scopeName: "__block_0" });
          try {
            await runner3.step(0, async (runner4) => {
              runner4.halt(await __call(__stack.args.block, {
                type: "positional",
                args: []
              }));
              return;
            });
            return runner3.halted ? runner3.haltResult : void 0;
          } finally {
            __forkBranchStack.pop();
          }
        }, "all", getRuntimeContext().stack, false));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "sample");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function sample threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "sample"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "sample",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "sample",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const sample = __AgencyFunction.create({
  name: "sample",
  module: "stdlib/strategy.agency",
  fn: __sample_impl,
  params: [{
    name: "n",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "sample",
    description: `Run a block n times in parallel. Returns an array of all results.

  @param n - Number of times to run
  @param block - The block to execute`,
    schema: z.object({ "n": z.number() })
  },
  exported: true
}, __toolRegistry);
async function __consensus_impl(n, block) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/strategy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["n"] = n;
  __stack.args["block"] = block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/strategy.agency", scopeName: "consensus", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("n" in __overrides) {
      n = __overrides["n"];
      __stack.args["n"] = n;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "consensus",
            args: {
              n,
              block
            },
            moduleId: "stdlib/strategy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.results = await __call(sample, {
          type: "positional",
          args: [__stack.args.n, __stack.args.block]
        });
        if (hasInterrupts(__stack.locals.results)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.results);
          return;
        }
        if (isAborted(__stack.locals.results)) {
          runner2.halt(__stack.locals.results.carryThrough(__stack, "consensus"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(mostCommon, {
          type: "positional",
          args: [__stack.locals.results]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "consensus");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function consensus threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "consensus"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "consensus",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "consensus",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const consensus = __AgencyFunction.create({
  name: "consensus",
  module: "stdlib/strategy.agency",
  fn: __consensus_impl,
  params: [{
    name: "n",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "consensus",
    description: `Run a block n times in parallel and return the most common result (majority vote).

  @param n - Number of times to run
  @param block - The block to execute`,
    schema: z.object({ "n": z.number() })
  },
  exported: true
}, __toolRegistry);
async function __retry_impl(n, test, block) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/strategy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["n"] = n;
  __stack.args["test"] = test;
  __stack.args["block"] = block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/strategy.agency", scopeName: "retry", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("n" in __overrides) {
      n = __overrides["n"];
      __stack.args["n"] = n;
    }
    if ("test" in __overrides) {
      test = __overrides["test"];
      __stack.args["test"] = test;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "retry",
            args: {
              n,
              test,
              block
            },
            moduleId: "stdlib/strategy.agency"
          }
        });
      });
      await runner.loop(1, async () => Array.from({ length: __stack.args.n - 0 }, (_, __i) => __i + 0), async (i, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.result = await __call(__stack.args.block, {
            type: "positional",
            args: []
          });
          if (hasInterrupts(__stack.locals.result)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.result);
            return;
          }
          if (isAborted(__stack.locals.result)) {
            runner3.halt(__stack.locals.result.carryThrough(__stack, "retry"));
            return;
          }
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.passed = await __call(__stack.args.test, {
            type: "positional",
            args: [__stack.locals.result]
          });
          if (hasInterrupts(__stack.locals.passed)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.passed);
            return;
          }
          if (isAborted(__stack.locals.passed)) {
            runner3.halt(__stack.locals.passed.carryThrough(__stack, "retry"));
            return;
          }
        });
        await runner2.ifElse(2, [
          {
            condition: async () => __stack.locals.passed,
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(__stack.locals.result);
                return;
              });
            }
          }
        ]);
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(null);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "retry");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function retry threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "retry"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "retry",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "retry",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const retry = __AgencyFunction.create({
  name: "retry",
  module: "stdlib/strategy.agency",
  fn: __retry_impl,
  params: [{
    name: "n",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "test",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "retry",
    description: `Run a block up to n times. Returns the first result that passes the test function. Returns null if all attempts fail.

  @param n - Maximum number of attempts
  @param test - The function that returns true when the result is acceptable
  @param block - The block to execute`,
    schema: z.object({ "n": z.number() })
  },
  exported: true
}, __toolRegistry);
async function __retryWithFeedback_impl(n, test, block) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/strategy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["n"] = n;
  __stack.args["test"] = test;
  __stack.args["block"] = block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/strategy.agency", scopeName: "retryWithFeedback", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("n" in __overrides) {
      n = __overrides["n"];
      __stack.args["n"] = n;
    }
    if ("test" in __overrides) {
      test = __overrides["test"];
      __stack.args["test"] = test;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "retryWithFeedback",
            args: {
              n,
              test,
              block
            },
            moduleId: "stdlib/strategy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.prev = null;
      });
      await runner.loop(2, async () => Array.from({ length: __stack.args.n - 0 }, (_, __i) => __i + 0), async (i, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.result = await __call(__stack.args.block, {
            type: "positional",
            args: [__stack.locals.prev, i + 1]
          });
          if (hasInterrupts(__stack.locals.result)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.result);
            return;
          }
          if (isAborted(__stack.locals.result)) {
            runner3.halt(__stack.locals.result.carryThrough(__stack, "retryWithFeedback"));
            return;
          }
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.passed = await __call(__stack.args.test, {
            type: "positional",
            args: [__stack.locals.result]
          });
          if (hasInterrupts(__stack.locals.passed)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.passed);
            return;
          }
          if (isAborted(__stack.locals.passed)) {
            runner3.halt(__stack.locals.passed.carryThrough(__stack, "retryWithFeedback"));
            return;
          }
        });
        await runner2.ifElse(2, [
          {
            condition: async () => __stack.locals.passed,
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(__stack.locals.result);
                return;
              });
            }
          }
        ]);
        await runner2.step(3, async (runner3) => {
          __stack.locals.prev = __stack.locals.result;
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.prev);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "retryWithFeedback");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function retryWithFeedback threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "retryWithFeedback"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "retryWithFeedback",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "retryWithFeedback",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const retryWithFeedback = __AgencyFunction.create({
  name: "retryWithFeedback",
  module: "stdlib/strategy.agency",
  fn: __retryWithFeedback_impl,
  params: [{
    name: "n",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "test",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "retryWithFeedback",
    description: `Run a block up to n times. Each attempt receives the previous result and the attempt number (starting from 1). Returns the first result that passes the test, or the last result if all fail.

  @param n - Maximum number of attempts
  @param test - The function that returns true when the result is acceptable
  @param block - The block receiving (previousResult, attemptNumber)`,
    schema: z.object({ "n": z.number() })
  },
  exported: true
}, __toolRegistry);
const Critique = z.object({ "accepted": z.boolean(), "feedback": z.string() });
async function __revise_impl(maxAttempts, check, block) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/strategy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["maxAttempts"] = maxAttempts;
  __stack.args["check"] = check;
  __stack.args["block"] = block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/strategy.agency", scopeName: "revise", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("maxAttempts" in __overrides) {
      maxAttempts = __overrides["maxAttempts"];
      __stack.args["maxAttempts"] = maxAttempts;
    }
    if ("check" in __overrides) {
      check = __overrides["check"];
      __stack.args["check"] = check;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "revise",
            args: {
              maxAttempts,
              check,
              block
            },
            moduleId: "stdlib/strategy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.result = null;
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.feedback = ``;
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.attempt = 0;
      });
      await runner.whileLoop(4, async () => __stack.locals.attempt < __stack.args.maxAttempts, async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.attempt = __stack.locals.attempt + 1;
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.result = await __call(__stack.args.block, {
            type: "positional",
            args: [__stack.locals.feedback]
          });
          if (hasInterrupts(__stack.locals.result)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.result);
            return;
          }
          if (isAborted(__stack.locals.result)) {
            runner3.halt(__stack.locals.result.carryThrough(__stack, "revise"));
            return;
          }
        });
        await runner2.step(2, async (runner3) => {
          __stack.locals.critique = await __call(__stack.args.check, {
            type: "positional",
            args: [__stack.locals.result]
          });
          if (hasInterrupts(__stack.locals.critique)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.critique);
            return;
          }
          if (isAborted(__stack.locals.critique)) {
            runner3.halt(__stack.locals.critique.carryThrough(__stack, "revise"));
            return;
          }
        });
        await runner2.ifElse(3, [
          {
            condition: async () => __stack.locals.critique.accepted,
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(__stack.locals.result);
                return;
              });
            }
          }
        ]);
        await runner2.step(4, async (runner3) => {
          __stack.locals.feedback = __stack.locals.critique.feedback;
        });
      });
      await runner.step(5, async (runner2) => {
      });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "revise");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function revise threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "revise"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "revise",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "revise",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const revise = __AgencyFunction.create({
  name: "revise",
  module: "stdlib/strategy.agency",
  fn: __revise_impl,
  params: [{
    name: "maxAttempts",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "check",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "revise",
    description: `Run a block until its result is accepted, up to maxAttempts times. Each
  rejected attempt passes its critique to the next one, which receives it as
  its argument (an empty string on the first attempt). Returns the first
  accepted result, or the last result when every attempt is rejected.

  @param maxAttempts - Maximum number of attempts
  @param check - Judges a result and returns the critique to address next
  @param block - The work, receiving the previous critique`,
    schema: z.object({ "maxAttempts": z.number() })
  },
  exported: true
}, __toolRegistry);
async function __firstValid_impl(variants, test, block) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/strategy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["variants"] = variants;
  __stack.args["test"] = test;
  __stack.args["block"] = block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/strategy.agency", scopeName: "firstValid", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("variants" in __overrides) {
      variants = __overrides["variants"];
      __stack.args["variants"] = variants;
    }
    if ("test" in __overrides) {
      test = __overrides["test"];
      __stack.args["test"] = test;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "firstValid",
            args: {
              variants,
              test,
              block
            },
            moduleId: "stdlib/strategy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.results = await runner2.fork(1, __stack.args.variants, async (__forkItem, __forkIndex, __forkBranchStack) => {
          const __bstack = __forkBranchStack.getNewState();
          const __self2 = __bstack.locals;
          const __bframe___block_1 = __bstack;
          const v = __forkItem;
          __bstack.args["v"] = __forkItem;
          const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/strategy.agency", scopeName: "__block_1" });
          try {
            await runner3.step(0, async (runner4) => {
              runner4.halt(await __call(__stack.args.block, {
                type: "positional",
                args: [__bstack.args.v]
              }));
              return;
            });
            return runner3.halted ? runner3.haltResult : void 0;
          } finally {
            __forkBranchStack.pop();
          }
        }, "all", getRuntimeContext().stack, false);
        if (hasInterrupts(__stack.locals.results)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.results);
          return;
        }
        if (isAborted(__stack.locals.results)) {
          runner2.halt(__stack.locals.results.carryThrough(__stack, "firstValid"));
          return;
        }
      });
      await runner.loop(2, async () => __stack.locals.results, async (r, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.passed = await __call(__stack.args.test, {
            type: "positional",
            args: [r]
          });
          if (hasInterrupts(__stack.locals.passed)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.passed);
            return;
          }
          if (isAborted(__stack.locals.passed)) {
            runner3.halt(__stack.locals.passed.carryThrough(__stack, "firstValid"));
            return;
          }
        });
        await runner2.ifElse(1, [
          {
            condition: async () => __stack.locals.passed,
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(r);
                return;
              });
            }
          }
        ]);
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(null);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "firstValid");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function firstValid threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "firstValid"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "firstValid",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "firstValid",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const firstValid = __AgencyFunction.create({
  name: "firstValid",
  module: "stdlib/strategy.agency",
  fn: __firstValid_impl,
  params: [{
    name: "variants",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "test",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "firstValid",
    description: `Run a block for each variant in parallel, then return the first result that passes the test. Returns null if none pass.

  @param variants - Array of variants to try
  @param test - The function that returns true for valid results
  @param block - The block receiving each variant`,
    schema: z.object({ "variants": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/strategy.agency:mostCommon": { "1": { "line": 24, "col": 2 } }, "stdlib/strategy.agency:sample": { "1": { "line": 34, "col": 2 } }, "stdlib/strategy.agency:__block_0": { "1.0": { "line": 35, "col": 4 } }, "stdlib/strategy.agency:consensus": { "1": { "line": 46, "col": 2 }, "2": { "line": 47, "col": 2 } }, "stdlib/strategy.agency:retry": { "1": { "line": 58, "col": 2 }, "2": { "line": 65, "col": 2 }, "1.0": { "line": 59, "col": 4 }, "1.1": { "line": 60, "col": 4 }, "1.2.0": { "line": 62, "col": 6 }, "1.2": { "line": 61, "col": 4 } }, "stdlib/strategy.agency:retryWithFeedback": { "1": { "line": 80, "col": 2 }, "2": { "line": 81, "col": 2 }, "3": { "line": 89, "col": 2 }, "2.0": { "line": 82, "col": 4 }, "2.1": { "line": 83, "col": 4 }, "2.2.0": { "line": 85, "col": 6 }, "2.2": { "line": 84, "col": 4 }, "2.3": { "line": 87, "col": 4 } }, "stdlib/strategy.agency:revise": { "1": { "line": 115, "col": 2 }, "2": { "line": 116, "col": 2 }, "3": { "line": 117, "col": 2 }, "4": { "line": 118, "col": 2 }, "6": { "line": 129, "col": 2 }, "4.0": { "line": 119, "col": 4 }, "4.1": { "line": 120, "col": 4 }, "4.2": { "line": 121, "col": 4 }, "4.3.0": { "line": 123, "col": 6 }, "4.3": { "line": 122, "col": 4 }, "4.4": { "line": 125, "col": 4 } }, "stdlib/strategy.agency:firstValid": { "1": { "line": 144, "col": 2 }, "2": { "line": 147, "col": 2 }, "3": { "line": 153, "col": 2 }, "2.0": { "line": 148, "col": 4 }, "2.1.0": { "line": 150, "col": 6 }, "2.1": { "line": 149, "col": 4 } }, "stdlib/strategy.agency:__block_1": { "1.0": { "line": 145, "col": 4 } } };
export {
  Critique,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  consensus,
  stdin_default as default,
  firstValid,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  mostCommon,
  reject,
  respondToInterrupts,
  retry,
  retryWithFeedback,
  revise,
  rewindFrom,
  sample
};
