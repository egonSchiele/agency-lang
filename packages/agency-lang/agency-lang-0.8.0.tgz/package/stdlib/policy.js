import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { withLock } from "agency-lang/stdlib/concurrency.js";
import { keys } from "agency-lang/stdlib/object.js";
import { dirname, basename } from "agency-lang/stdlib/path.js";
import { exists } from "agency-lang/stdlib/shell.js";
import { highlight, diff } from "agency-lang/stdlib/syntax.js";
import { chooseOption, ChoiceItem } from "agency-lang/stdlib/ui.js";
import { render, text } from "agency-lang/stdlib/ui/layout.js";
import { table } from "agency-lang/stdlib/ui/table.js";
import { _checkPolicy, _validatePolicy, _writePolicyFile, _builtinPolicy, _builtinPolicyNames, _BUILTIN_POLICIES, _minimalAutoApprovePolicy, _recommendedAutoApprovePolicy, _withWritesPolicy, _approveAllPolicy } from "agency-lang/stdlib-lib/policy.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { color, nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __registerStaticInit,
  __registerGlobalsInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __tryCall,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/policy.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(withLock);
__registerTool(keys);
__registerTool(dirname);
__registerTool(basename);
__registerTool(exists);
__registerTool(highlight);
__registerTool(diff);
__registerTool(chooseOption);
__registerTool(ChoiceItem);
__registerTool(render);
__registerTool(text);
__registerTool(table);
let __staticInitPromise = null;
let minimalAutoApprovePolicy = __UNINIT_STATIC;
let recommendedAutoApprovePolicy = __UNINIT_STATIC;
let approveAllPolicy = __UNINIT_STATIC;
let BUILTIN_POLICIES = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    minimalAutoApprovePolicy = __deepFreeze(_minimalAutoApprovePolicy);
    recommendedAutoApprovePolicy = __deepFreeze(_recommendedAutoApprovePolicy);
    approveAllPolicy = __deepFreeze(_approveAllPolicy);
    BUILTIN_POLICIES = __deepFreeze(_BUILTIN_POLICIES);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    minimalAutoApprovePolicy,
    recommendedAutoApprovePolicy,
    approveAllPolicy,
    BUILTIN_POLICIES
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/policy.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/policy.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/policy.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
  __ctx.globals.set("stdlib/policy.agency", "globalCliPolicyOpts", {
    "file": ``,
    "fields": {}
  });
  __ctx.globals.set("stdlib/policy.agency", "_policy", null);
  __ctx.globals.set("stdlib/policy.agency", "_policyLoaded", false);
  __ctx.globals.set("stdlib/policy.agency", "_pendingSave", false);
  __ctx.globals.set("stdlib/policy.agency", "_internalIo", false);
}
__registerGlobalsInit("stdlib/policy.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const InterruptDataKey = z.string();
const InterruptDataVal = z.string();
const InterruptEffect = z.string();
const PolicyRule = z.object({ "match": z.union([z.record(z.string(), z.string()), z.null()]).optional().default(null), "action": z.union([z.literal("approve"), z.literal("reject"), z.literal("propagate")]) });
const Policy = z.record(z.string(), z.array(PolicyRule));
async function __withWritesPolicy_impl(baseDir) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["baseDir"] = baseDir;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "withWritesPolicy", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("baseDir" in __overrides) {
      baseDir = __overrides["baseDir"];
      __stack.args["baseDir"] = baseDir;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "withWritesPolicy",
            args: {
              baseDir
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_withWritesPolicy, {
          type: "positional",
          args: [__stack.args.baseDir]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function withWritesPolicy threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "withWritesPolicy"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "withWritesPolicy",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "withWritesPolicy",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const withWritesPolicy = __AgencyFunction.create({
  name: "withWritesPolicy",
  module: "stdlib/policy.agency",
  fn: __withWritesPolicy_impl,
  params: [{
    name: "baseDir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "withWritesPolicy",
    description: "No description provided.",
    schema: z.object({ "baseDir": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __builtinPolicy_impl(name, baseDir) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["name"] = name;
  __stack.args["baseDir"] = baseDir;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "builtinPolicy", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
    if ("baseDir" in __overrides) {
      baseDir = __overrides["baseDir"];
      __stack.args["baseDir"] = baseDir;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "builtinPolicy",
            args: {
              name,
              baseDir
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_builtinPolicy, {
          type: "positional",
          args: [__stack.args.name, __stack.args.baseDir]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function builtinPolicy threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "builtinPolicy"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "builtinPolicy",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "builtinPolicy",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const builtinPolicy = __AgencyFunction.create({
  name: "builtinPolicy",
  module: "stdlib/policy.agency",
  fn: __builtinPolicy_impl,
  params: [{
    name: "name",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "baseDir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "builtinPolicy",
    description: "No description provided.",
    schema: z.object({ "name": z.string(), "baseDir": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __builtinPolicyNames_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "builtinPolicyNames", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "builtinPolicyNames",
            args: {},
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_builtinPolicyNames, {
          type: "positional",
          args: []
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function builtinPolicyNames threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "builtinPolicyNames"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "builtinPolicyNames",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "builtinPolicyNames",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const builtinPolicyNames = __AgencyFunction.create({
  name: "builtinPolicyNames",
  module: "stdlib/policy.agency",
  fn: __builtinPolicyNames_impl,
  params: [],
  toolDefinition: {
    name: "builtinPolicyNames",
    description: "No description provided.",
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
const Decision = z.union([z.literal("approve"), z.literal("reject"), z.literal("approve-always"), z.literal("approve-always-here"), z.literal("reject-always")]);
const ScopedField = z.object({ "field": z.string(), "matchSubpaths": z.boolean() });
const ScopedRuleFields = z.record(z.string(), z.array(ScopedField));
const CliPolicyOpts = z.object({ "file": z.string(), "fields": ScopedRuleFields });
async function __checkPolicy_impl(policy, interrupt2) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["policy"] = policy;
  __stack.args["interrupt"] = interrupt2;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "checkPolicy", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("policy" in __overrides) {
      policy = __overrides["policy"];
      __stack.args["policy"] = policy;
    }
    if ("interrupt" in __overrides) {
      interrupt2 = __overrides["interrupt"];
      __stack.args["interrupt"] = interrupt2;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "checkPolicy",
            args: {
              policy,
              interrupt: interrupt2
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_checkPolicy, {
          type: "positional",
          args: [__stack.args.policy, __stack.args.interrupt]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function checkPolicy threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "checkPolicy"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "checkPolicy",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "checkPolicy",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const checkPolicy = __AgencyFunction.create({
  name: "checkPolicy",
  module: "stdlib/policy.agency",
  fn: __checkPolicy_impl,
  params: [{
    name: "policy",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "interrupt",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "checkPolicy",
    description: `Evaluate a policy against an interrupt. Returns approve(), reject(), or propagate() based on the first matching rule.

  @param policy - Ordered rules keyed by interrupt effect; each rule has optional glob-pattern match fields and an action.
  @param interrupt - The interrupt to evaluate.`,
    schema: z.object({ "policy": z.record(z.string(), z.any()), "interrupt": z.record(z.string(), z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __validatePolicy_impl(policy) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["policy"] = policy;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "validatePolicy", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("policy" in __overrides) {
      policy = __overrides["policy"];
      __stack.args["policy"] = policy;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "validatePolicy",
            args: {
              policy
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_validatePolicy, {
          type: "positional",
          args: [__stack.args.policy]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function validatePolicy threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "validatePolicy"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "validatePolicy",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "validatePolicy",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const validatePolicy = __AgencyFunction.create({
  name: "validatePolicy",
  module: "stdlib/policy.agency",
  fn: __validatePolicy_impl,
  params: [{
    name: "policy",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "validatePolicy",
    description: `Validate that a policy object is well-formed. Returns { success: true } if valid, or { success: false, error } describing the problem.

  @param policy - The policy object to validate.`,
    schema: z.object({ "policy": z.record(z.string(), z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __buildScopedMatch_impl(intr, fields) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["intr"] = intr;
  __stack.args["fields"] = fields;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "buildScopedMatch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("intr" in __overrides) {
      intr = __overrides["intr"];
      __stack.args["intr"] = intr;
    }
    if ("fields" in __overrides) {
      fields = __overrides["fields"];
      __stack.args["fields"] = fields;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildScopedMatch",
            args: {
              intr,
              fields
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.specs = [];
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__nn(__stack.args.fields[__stack.args.intr.effect]), void 0),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.specs = __nn(__stack.args.fields[__stack.args.intr.effect]);
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.match = {};
      });
      await runner.loop(4, async () => __stack.locals.specs, async (spec, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.value = __nn(__stack.args.intr.data[spec.field]);
        });
        await runner2.ifElse(1, [
          {
            condition: async () => __eq(__stack.locals.value, null),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                runner4.continueLoop();
                return;
              });
            }
          }
        ]);
        await runner2.ifElse(2, [
          {
            condition: async () => spec.matchSubpaths,
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.match[spec.field] = `{${__stack.locals.value},${__stack.locals.value}/**}`;
              });
            }
          }
        ], async (runner3) => {
          await runner3.step(1, async (runner4) => {
            __stack.locals.match[spec.field] = __stack.locals.value;
          });
        });
      });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.match);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildScopedMatch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildScopedMatch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildScopedMatch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildScopedMatch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildScopedMatch = __AgencyFunction.create({
  name: "buildScopedMatch",
  module: "stdlib/policy.agency",
  fn: __buildScopedMatch_impl,
  params: [{
    name: "intr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fields",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildScopedMatch",
    description: `Build a match object for an interrupt, pinned to the configured fields. Returns {} when the effect has no configured fields.

  @param intr - The interrupt whose data fields to pin.
  @param fields - Per-effect config naming which data fields to pin.`,
    schema: z.object({ "intr": z.record(z.string(), z.any()), "fields": ScopedRuleFields })
  },
  exported: true
}, __toolRegistry);
async function __recordRule_impl(policy, effect, action) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["policy"] = policy;
  __stack.args["effect"] = effect;
  __stack.args["action"] = action;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "recordRule", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("policy" in __overrides) {
      policy = __overrides["policy"];
      __stack.args["policy"] = policy;
    }
    if ("effect" in __overrides) {
      effect = __overrides["effect"];
      __stack.args["effect"] = effect;
    }
    if ("action" in __overrides) {
      action = __overrides["action"];
      __stack.args["action"] = action;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "recordRule",
            args: {
              policy,
              effect,
              action
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.existing = __nn(__stack.args.policy[__stack.args.effect]) || [];
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.next = {
          ...__stack.args.policy,
          [__stack.args.effect]: [...__stack.locals.existing, {
            "action": __stack.args.action
          }]
        };
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.next);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function recordRule threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "recordRule"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "recordRule",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "recordRule",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const recordRule = __AgencyFunction.create({
  name: "recordRule",
  module: "stdlib/policy.agency",
  fn: __recordRule_impl,
  params: [{
    name: "policy",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "effect",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "action",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "recordRule",
    description: `Return a new policy with a catch-all rule for an effect appended. A single bare rule covers every future interrupt of that effect.

  @param policy - The policy to extend (not mutated).
  @param effect - The interrupt effect the rule applies to.
  @param action - Whether to approve or reject matching interrupts.`,
    schema: z.object({ "policy": Policy, "effect": InterruptEffect, "action": z.union([z.literal("approve"), z.literal("reject")]) })
  },
  exported: true
}, __toolRegistry);
async function __recordScopedRule_impl(policy, intr, fields) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["policy"] = policy;
  __stack.args["intr"] = intr;
  __stack.args["fields"] = fields;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "recordScopedRule", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("policy" in __overrides) {
      policy = __overrides["policy"];
      __stack.args["policy"] = policy;
    }
    if ("intr" in __overrides) {
      intr = __overrides["intr"];
      __stack.args["intr"] = intr;
    }
    if ("fields" in __overrides) {
      fields = __overrides["fields"];
      __stack.args["fields"] = fields;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "recordScopedRule",
            args: {
              policy,
              intr,
              fields
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.match = await __call(buildScopedMatch, {
          type: "positional",
          args: [__stack.args.intr, __stack.args.fields]
        });
        if (hasInterrupts(__stack.locals.match)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.match);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.existing = __nn(__stack.args.policy[__stack.args.intr.effect]) || [];
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.next = {
          ...__stack.args.policy,
          [__stack.args.intr.effect]: [{
            "match": __stack.locals.match,
            "action": `approve`
          }, ...__stack.locals.existing]
        };
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.next);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function recordScopedRule threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "recordScopedRule"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "recordScopedRule",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "recordScopedRule",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const recordScopedRule = __AgencyFunction.create({
  name: "recordScopedRule",
  module: "stdlib/policy.agency",
  fn: __recordScopedRule_impl,
  params: [{
    name: "policy",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "intr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fields",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "recordScopedRule",
    description: `Return a new policy with a scoped approve rule prepended for the interrupt's effect. The rule pins the configured fields, so it approves only future interrupts matching this one's field values.

  @param policy - The policy to extend (not mutated).
  @param intr - The interrupt whose field values to pin.
  @param fields - Per-effect config naming which data fields to pin.`,
    schema: z.object({ "policy": Policy, "intr": z.record(z.string(), z.any()), "fields": ScopedRuleFields })
  },
  exported: true
}, __toolRegistry);
const ParsePolicyFailureStatus = z.union([z.literal("doesnt-exist"), z.literal("read-error"), z.literal("malformed-json"), z.literal("policy-not-valid")]);
const ParsePolicyFailure = z.object({ "status": ParsePolicyFailureStatus, "error": z.union([z.string(), z.null()]).optional().default(null) });
async function __parsePolicyFile_impl(path2) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["path"] = path2;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "parsePolicyFile", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("path" in __overrides) {
      path2 = __overrides["path"];
      __stack.args["path"] = path2;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parsePolicyFile",
            args: {
              path: path2
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(dirname, {
          type: "positional",
          args: [__stack.args.path]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.name = await __call(basename, {
          type: "positional",
          args: [__stack.args.path]
        });
        if (hasInterrupts(__stack.locals.name)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.name);
          return;
        }
      });
      await runner.ifElse(3, [
        {
          condition: async () => !await __call(exists, {
            type: "positional",
            args: [__stack.locals.name, __stack.locals.dir]
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure({
                "status": `doesnt-exist`
              }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "parsePolicyFile", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.handle(4, async (__data) => approve(), async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.readResult = await __call(read, {
            type: "positional",
            args: [__stack.locals.name, __stack.locals.dir]
          });
          if (hasInterrupts(__stack.locals.readResult)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.readResult);
            return;
          }
        });
      });
      await runner.ifElse(5, [
        {
          condition: async () => await isFailure(__stack.locals.readResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure({
                "status": `read-error`,
                "error": __stack.locals.readResult.error
              }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "parsePolicyFile", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(6, async (runner2) => {
        __stack.locals.parsed = await __tryCall(async () => await __callMethod(JSON, "parse", {
          type: "positional",
          args: [__stack.locals.readResult.value]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "parsePolicyFile",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.parsed)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.parsed);
          return;
        }
      });
      await runner.ifElse(7, [
        {
          condition: async () => await isFailure(__stack.locals.parsed),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure({
                "status": `malformed-json`
              }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "parsePolicyFile", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(8, async (runner2) => {
        __stack.locals.valid = await __call(validatePolicy, {
          type: "positional",
          args: [__stack.locals.parsed.value]
        });
        if (hasInterrupts(__stack.locals.valid)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.valid);
          return;
        }
      });
      await runner.ifElse(9, [
        {
          condition: async () => !__stack.locals.valid.success,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure({
                "status": `policy-not-valid`,
                "error": __stack.locals.valid.error
              }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "parsePolicyFile", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(10, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.parsed);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parsePolicyFile threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parsePolicyFile"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parsePolicyFile",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parsePolicyFile",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parsePolicyFile = __AgencyFunction.create({
  name: "parsePolicyFile",
  module: "stdlib/policy.agency",
  fn: __parsePolicyFile_impl,
  params: [{
    name: "path",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "parsePolicyFile",
    description: `Read + parse + validate a policy file from disk. Returns {} on any
  failure (missing, unreadable, malformed JSON, invalid schema) with a
  warning to the user.

  @param path - The policy file path`,
    schema: z.object({ "path": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __setPolicy_impl(path2, policy) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["path"] = path2;
  __stack.args["policy"] = policy;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "setPolicy", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("path" in __overrides) {
      path2 = __overrides["path"];
      __stack.args["path"] = path2;
    }
    if ("policy" in __overrides) {
      policy = __overrides["policy"];
      __stack.args["policy"] = policy;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "setPolicy",
            args: {
              path: path2,
              policy
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __globals().set("stdlib/policy.agency", "_policy", __stack.args.policy);
      });
      await runner.step(2, async (runner2) => {
        __globals().set("stdlib/policy.agency", "_policyLoaded", true);
      });
      await runner.handle(3, async (__data) => approve(), async (runner2) => {
        await runner2.step(0, async (runner3) => {
          const __funcResult = await __call(writePolicyFile, {
            type: "positional",
            args: [__stack.args.path, __stack.args.policy, []]
          });
          if (hasInterrupts(__funcResult)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__funcResult);
            return;
          }
        });
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function setPolicy threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "setPolicy"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "setPolicy",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "setPolicy",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const setPolicy = __AgencyFunction.create({
  name: "setPolicy",
  module: "stdlib/policy.agency",
  fn: __setPolicy_impl,
  params: [{
    name: "path",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "policy",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "setPolicy",
    description: "No description provided.",
    schema: z.object({ "path": z.string(), "policy": Policy })
  },
  exported: true
}, __toolRegistry);
async function __writePolicyFile_impl(path2, policy, allowedPaths = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["path"] = path2;
  __stack.args["policy"] = policy;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "writePolicyFile", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("path" in __overrides) {
      path2 = __overrides["path"];
      __stack.args["path"] = path2;
    }
    if ("policy" in __overrides) {
      policy = __overrides["policy"];
      __stack.args["policy"] = policy;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "writePolicyFile",
            args: {
              path: path2,
              policy,
              allowedPaths
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_writePolicyFile, {
          type: "positional",
          args: [__stack.args.path, __stack.args.policy, __stack.args.allowedPaths]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "writePolicyFile",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function writePolicyFile threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "writePolicyFile"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "writePolicyFile",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "writePolicyFile",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const writePolicyFile = __AgencyFunction.create({
  name: "writePolicyFile",
  module: "stdlib/policy.agency",
  fn: __writePolicyFile_impl,
  params: [{
    name: "path",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "policy",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "writePolicyFile",
    description: `Validate and write a policy to a JSON file. Throws if the policy is invalid.

  @param path - The destination file path.
  @param policy - The policy to write.
  @param allowedPaths - Restrict writes to these path prefixes; empty allows any path.`,
    schema: z.object({ "path": z.string(), "policy": Policy, "allowedPaths": z.array(z.string()).nullable().describe("Default: []") })
  },
  exported: true
}, __toolRegistry);
async function __maybeLoadPolicy_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "maybeLoadPolicy", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "maybeLoadPolicy",
            args: {},
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => !__globals().get("stdlib/policy.agency", "_policyLoaded"),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_policyLoaded", true);
            });
            await runner2.step(1, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_internalIo", true);
            });
            await runner2.handle(2, async (__data) => approve(), async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.loaded = await __call(parsePolicyFile, {
                  type: "positional",
                  args: [__globals().get("stdlib/policy.agency", "globalCliPolicyOpts").file]
                });
                if (hasInterrupts(__stack.locals.loaded)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__stack.locals.loaded);
                  return;
                }
              });
            });
            await runner2.step(3, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_internalIo", false);
            });
            await runner2.ifElse(4, [
              {
                condition: async () => await isFailure(__stack.locals.loaded),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __globals().set("stdlib/policy.agency", "_policy", {});
                  });
                }
              }
            ], async (runner3) => {
              await runner3.step(1, async (runner4) => {
                __globals().set("stdlib/policy.agency", "_policy", __stack.locals.loaded.value);
              });
            });
          }
        }
      ]);
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function maybeLoadPolicy threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "maybeLoadPolicy"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "maybeLoadPolicy",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "maybeLoadPolicy",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const maybeLoadPolicy = __AgencyFunction.create({
  name: "maybeLoadPolicy",
  module: "stdlib/policy.agency",
  fn: __maybeLoadPolicy_impl,
  params: [],
  toolDefinition: {
    name: "maybeLoadPolicy",
    description: "No description provided.",
    schema: z.object({})
  },
  exported: false
}, __toolRegistry);
async function __maybeFlush_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "maybeFlush", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "maybeFlush",
            args: {},
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __globals().get("stdlib/policy.agency", "_pendingSave"),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
            });
            await runner2.step(1, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_pendingSave", false);
            });
            await runner2.ifElse(2, [
              {
                condition: async () => !__eq(__globals().get("stdlib/policy.agency", "_policy"), null),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __globals().set("stdlib/policy.agency", "_internalIo", true);
                  });
                  await runner3.handle(1, async (__data) => approve(), async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      const __funcResult = await __call(writePolicyFile, {
                        type: "positional",
                        args: [__globals().get("stdlib/policy.agency", "globalCliPolicyOpts").file, __globals().get("stdlib/policy.agency", "_policy"), []]
                      });
                      if (hasInterrupts(__funcResult)) {
                        await getRuntimeContext().ctx.pendingPromises.awaitAll();
                        runner5.halt(__funcResult);
                        return;
                      }
                    });
                  });
                  await runner3.step(2, async (runner4) => {
                    __globals().set("stdlib/policy.agency", "_internalIo", false);
                  });
                }
              }
            ]);
          }
        }
      ]);
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function maybeFlush threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "maybeFlush"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "maybeFlush",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "maybeFlush",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const maybeFlush = __AgencyFunction.create({
  name: "maybeFlush",
  module: "stdlib/policy.agency",
  fn: __maybeFlush_impl,
  params: [],
  toolDefinition: {
    name: "maybeFlush",
    description: "No description provided.",
    schema: z.object({})
  },
  exported: false
}, __toolRegistry);
async function __flushPolicy_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "flushPolicy", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "flushPolicy",
            args: {},
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __globals().get("stdlib/policy.agency", "_pendingSave"),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_pendingSave", false);
            });
            await runner2.ifElse(1, [
              {
                condition: async () => !__eq(__globals().get("stdlib/policy.agency", "_policy"), null),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __globals().set("stdlib/policy.agency", "_internalIo", true);
                  });
                  await runner3.handle(1, async (__data) => approve(), async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      const __funcResult = await __call(writePolicyFile, {
                        type: "positional",
                        args: [__globals().get("stdlib/policy.agency", "globalCliPolicyOpts").file, __globals().get("stdlib/policy.agency", "_policy"), []]
                      });
                      if (hasInterrupts(__funcResult)) {
                        await getRuntimeContext().ctx.pendingPromises.awaitAll();
                        runner5.halt(__funcResult);
                        return;
                      }
                    });
                  });
                  await runner3.step(2, async (runner4) => {
                    __globals().set("stdlib/policy.agency", "_internalIo", false);
                  });
                }
              }
            ]);
          }
        }
      ]);
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function flushPolicy threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "flushPolicy"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "flushPolicy",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "flushPolicy",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const flushPolicy = __AgencyFunction.create({
  name: "flushPolicy",
  module: "stdlib/policy.agency",
  fn: __flushPolicy_impl,
  params: [],
  toolDefinition: {
    name: "flushPolicy",
    description: "No description provided.",
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __describeScopedMatch_impl(intr) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["intr"] = intr;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "describeScopedMatch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("intr" in __overrides) {
      intr = __overrides["intr"];
      __stack.args["intr"] = intr;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "describeScopedMatch",
            args: {
              intr
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.match = await __call(buildScopedMatch, {
          type: "positional",
          args: [__stack.args.intr, __globals().get("stdlib/policy.agency", "globalCliPolicyOpts").fields]
        });
        if (hasInterrupts(__stack.locals.match)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.match);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.ks = await __call(keys, {
          type: "positional",
          args: [__stack.locals.match]
        });
        if (hasInterrupts(__stack.locals.ks)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.ks);
          return;
        }
      });
      await runner.ifElse(3, [
        {
          condition: async () => __eq(__stack.locals.ks.length, 0),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(`(no scoped fields)`);
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __stack.locals.parts = [];
      });
      await runner.loop(5, async () => __stack.locals.ks, async (k, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          await __callMethod(__stack.locals.parts, "push", {
            type: "positional",
            args: [`${k}=${__nn(__stack.locals.match[k])}`]
          });
        });
      });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(__stack.locals.parts, "join", {
          type: "positional",
          args: [`, `]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function describeScopedMatch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "describeScopedMatch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "describeScopedMatch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "describeScopedMatch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const describeScopedMatch = __AgencyFunction.create({
  name: "describeScopedMatch",
  module: "stdlib/policy.agency",
  fn: __describeScopedMatch_impl,
  params: [{
    name: "intr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "describeScopedMatch",
    description: "No description provided.",
    schema: z.object({ "intr": z.any() })
  },
  exported: false
}, __toolRegistry);
const AskUserResult = z.object({ "action": Decision, "reason": z.union([z.string(), z.null()]).optional().default(null) });
async function __renderEditDiff_impl(payload) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["payload"] = payload;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "renderEditDiff", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("payload" in __overrides) {
      payload = __overrides["payload"];
      __stack.args["payload"] = payload;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "renderEditDiff",
            args: {
              payload
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.lines = [];
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.locals.lines, "push", {
          type: "positional",
          args: [await __callMethod(color, "yellow", {
            type: "positional",
            args: [`\u23FA Edit: ${__stack.args.payload.filename}`]
          })]
        });
      });
      await runner.step(3, async (runner2) => {
        await __callMethod(__stack.locals.lines, "push", {
          type: "positional",
          args: [await __call(diff, {
            type: "named",
            positionalArgs: [__stack.args.payload.before || ``, __stack.args.payload.after || ``],
            namedArgs: {
              language: `auto`,
              color: true,
              lineNumbers: true,
              context: 3,
              ignoreWhitespace: true
            }
          })]
        });
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(__stack.locals.lines, "join", {
          type: "positional",
          args: [`
`]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function renderEditDiff threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "renderEditDiff"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "renderEditDiff",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "renderEditDiff",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const renderEditDiff = __AgencyFunction.create({
  name: "renderEditDiff",
  module: "stdlib/policy.agency",
  fn: __renderEditDiff_impl,
  params: [{
    name: "payload",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "renderEditDiff",
    description: "No description provided.",
    schema: z.object({ "payload": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __prettyPrintInterruptData_impl(data, effect = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["data"] = data;
  __stack.args["effect"] = effect === __UNSET ? `` : effect;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "prettyPrintInterruptData", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("data" in __overrides) {
      data = __overrides["data"];
      __stack.args["data"] = data;
    }
    if ("effect" in __overrides) {
      effect = __overrides["effect"];
      __stack.args["effect"] = effect;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "prettyPrintInterruptData",
            args: {
              data,
              effect
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.ifElse(2, [
        {
          condition: async () => __eq(__stack.args.data, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(``);
              return;
            });
          }
        }
      ]);
      await runner.ifElse(3, [
        {
          condition: async () => __eq(typeof __stack.args.data, `string`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.args.data);
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
      });
      await runner.ifElse(5, [
        {
          condition: async () => __eq(__stack.args.effect, `std::edit`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.meta = await __call(renderObjAsTable, {
                type: "named",
                positionalArgs: [__stack.args.data],
                namedArgs: {
                  excludeKeys: [`before`, `after`, `filename`, `edits`]
                }
              });
              if (hasInterrupts(__stack.locals.meta)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.meta);
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.editDiff = await __call(renderEditDiff, {
                type: "positional",
                args: [__stack.args.data]
              });
              if (hasInterrupts(__stack.locals.editDiff)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.editDiff);
                return;
              }
            });
            await runner2.ifElse(2, [
              {
                condition: async () => __eq(__stack.locals.meta, ``),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __functionCompleted = true;
                    runner4.halt(__stack.locals.editDiff);
                    return;
                  });
                }
              }
            ]);
            await runner2.step(3, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(`${__stack.locals.meta}

${__stack.locals.editDiff}`);
              return;
            });
          }
        }
      ]);
      await runner.step(6, async (runner2) => {
      });
      await runner.ifElse(7, [
        {
          condition: async () => await __callMethod(Array, "isArray", {
            type: "positional",
            args: [__stack.args.data]
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.i = 0;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.paramTable = await __call(table, {
                type: "named",
                positionalArgs: [],
                namedArgs: {},
                blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/policy.agency", fn: async (t) => {
                  const __bsetup = setupFunction();
                  const __bstack = __bsetup.stack;
                  const __self2 = __bstack.locals;
                  const __bframe___block_0 = __bstack;
                  __bstack.args["t"] = t;
                  const runner4 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/policy.agency", scopeName: "__block_0" });
                  try {
                    await runner4.loop(0, async () => __stack.args.data, async (item, _, runner5) => {
                      await runner5.step(0, async (runner6) => {
                        await __callMethod(__bstack.args.t, "row", {
                          type: "positional",
                          args: [await __call(text, {
                            type: "named",
                            positionalArgs: [`${__stack.locals.i}`],
                            namedArgs: {
                              bold: true
                            }
                          }), await __call(text, {
                            type: "positional",
                            args: [await __call(prettyPrintInterruptData, {
                              type: "positional",
                              args: [item]
                            })]
                          })]
                        });
                      });
                      await runner5.step(1, async (runner6) => {
                        __stack.locals.i = __stack.locals.i + 1;
                      });
                    });
                    return runner4.halted ? runner4.haltResult : void 0;
                  } finally {
                    __bsetup.stateStack.pop();
                  }
                }, params: [{ name: "t", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
              });
              if (hasInterrupts(__stack.locals.paramTable)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.paramTable);
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await __call(render, {
                type: "positional",
                args: [__stack.locals.paramTable]
              }));
              return;
            });
          }
        }
      ]);
      await runner.ifElse(8, [
        {
          condition: async () => __eq(typeof __stack.args.data, `object`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await __call(renderObjAsTable, {
                type: "positional",
                args: [__stack.args.data]
              }));
              return;
            });
          }
        }
      ]);
      await runner.step(9, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(JSON, "stringify", {
          type: "positional",
          args: [__stack.args.data]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function prettyPrintInterruptData threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "prettyPrintInterruptData"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "prettyPrintInterruptData",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "prettyPrintInterruptData",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const prettyPrintInterruptData = __AgencyFunction.create({
  name: "prettyPrintInterruptData",
  module: "stdlib/policy.agency",
  fn: __prettyPrintInterruptData_impl,
  params: [{
    name: "data",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "effect",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "prettyPrintInterruptData",
    description: "No description provided.",
    schema: z.object({ "data": z.any(), "effect": z.string().nullable().describe("Default: ") })
  },
  exported: false
}, __toolRegistry);
async function __renderObjAsTable_impl(obj, excludeKeys = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["obj"] = obj;
  __stack.args["excludeKeys"] = excludeKeys === __UNSET ? null : excludeKeys;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "renderObjAsTable", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("obj" in __overrides) {
      obj = __overrides["obj"];
      __stack.args["obj"] = obj;
    }
    if ("excludeKeys" in __overrides) {
      excludeKeys = __overrides["excludeKeys"];
      __stack.args["excludeKeys"] = excludeKeys;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "renderObjAsTable",
            args: {
              obj,
              excludeKeys
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.skip = __stack.args.excludeKeys || [];
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.rows = 0;
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.paramTable = await __call(table, {
          type: "named",
          positionalArgs: [],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/policy.agency", fn: async (t) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_1 = __bstack;
            __bstack.args["t"] = t;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/policy.agency", scopeName: "__block_1" });
            try {
              await runner3.loop(0, async () => __stack.args.obj, async (key, _, runner4) => {
                await runner4.ifElse(0, [
                  {
                    condition: async () => await __callMethod(__stack.locals.skip, "includes", {
                      type: "positional",
                      args: [key]
                    }),
                    body: async (runner5) => {
                      await runner5.step(0, async (runner6) => {
                        runner6.continueLoop();
                        return;
                      });
                    }
                  }
                ]);
                await runner4.step(1, async (runner5) => {
                  await __callMethod(__bstack.args.t, "row", {
                    type: "positional",
                    args: [await __call(text, {
                      type: "named",
                      positionalArgs: [key],
                      namedArgs: {
                        bold: true
                      }
                    }), await __call(text, {
                      type: "positional",
                      args: [await __call(prettyPrintInterruptData, {
                        type: "positional",
                        args: [__nn(__stack.args.obj[key])]
                      })]
                    })]
                  });
                });
                await runner4.step(2, async (runner5) => {
                  __stack.locals.rows = __stack.locals.rows + 1;
                });
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "t", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.paramTable)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.paramTable);
          return;
        }
      });
      await runner.ifElse(4, [
        {
          condition: async () => __eq(__stack.locals.rows, 0),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(``);
              return;
            });
          }
        }
      ]);
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(render, {
          type: "positional",
          args: [__stack.locals.paramTable]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function renderObjAsTable threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "renderObjAsTable"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "renderObjAsTable",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "renderObjAsTable",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const renderObjAsTable = __AgencyFunction.create({
  name: "renderObjAsTable",
  module: "stdlib/policy.agency",
  fn: __renderObjAsTable_impl,
  params: [{
    name: "obj",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "excludeKeys",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "renderObjAsTable",
    description: "No description provided.",
    schema: z.object({ "obj": z.record(z.string(), z.any()), "excludeKeys": z.array(z.string()).nullable().describe("Default: null") })
  },
  exported: false
}, __toolRegistry);
async function __askUser_impl(intr) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["intr"] = intr;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "askUser", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("intr" in __overrides) {
      intr = __overrides["intr"];
      __stack.args["intr"] = intr;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "askUser",
            args: {
              intr
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.effectFields = [];
      });
      await runner.ifElse(3, [
        {
          condition: async () => !__eq(__nn(__globals().get("stdlib/policy.agency", "globalCliPolicyOpts").fields[__stack.args.intr.effect]), void 0),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.effectFields = __nn(__globals().get("stdlib/policy.agency", "globalCliPolicyOpts").fields[__stack.args.intr.effect]);
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __stack.locals.scopedAvailable = __stack.locals.effectFields.length > 0;
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.title = __stack.args.intr.message;
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.body = await __call(prettyPrintInterruptData, {
          type: "positional",
          args: [__stack.args.intr.data, __stack.args.intr.effect]
        });
        if (hasInterrupts(__stack.locals.body)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.body);
          return;
        }
      });
      await runner.step(7, async (runner2) => {
        __stack.locals.items = [{
          "key": `a`,
          "label": `approve once`
        }, {
          "key": `r`,
          "label": `reject once`
        }, {
          "key": `aa`,
          "label": `approve always (every future ${__stack.args.intr.effect})`
        }];
      });
      await runner.ifElse(8, [
        {
          condition: async () => __stack.locals.scopedAvailable,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              await __callMethod(__stack.locals.items, "push", {
                type: "positional",
                args: [{
                  "key": `ap`,
                  "label": `approve always here (${await __call(describeScopedMatch, {
                    type: "positional",
                    args: [__stack.args.intr]
                  })})`
                }]
              });
            });
          }
        }
      ]);
      await runner.step(9, async (runner2) => {
        await __callMethod(__stack.locals.items, "push", {
          type: "positional",
          args: [{
            "key": `rr`,
            "label": `reject always`
          }]
        });
      });
      await runner.step(10, async (runner2) => {
        __stack.locals.answer = await __call(withLock, {
          type: "named",
          positionalArgs: [`std::tty`],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_2", module: "stdlib/policy.agency", fn: async () => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_2 = __bstack;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/policy.agency", scopeName: "__block_2" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(await __call(chooseOption, {
                  type: "named",
                  positionalArgs: [__stack.locals.title, __stack.locals.body, __stack.locals.items],
                  namedArgs: {
                    allowFreeText: true,
                    allowCancel: true
                  }
                }));
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.answer)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.answer);
          return;
        }
      });
      await runner.ifElse(11, [
        {
          condition: async () => __stack.locals.answer === `a`,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.__armval_2 = {
                "action": `approve`,
                "reason": null
              };
            });
            await runner2.step(1, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_2);
              return;
            });
          }
        },
        {
          condition: async () => __stack.locals.answer === `r`,
          body: async (runner2) => {
            await runner2.step(2, async (runner3) => {
              __stack.locals.__armval_3 = {
                "action": `reject`,
                "reason": null
              };
            });
            await runner2.step(3, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_3);
              return;
            });
          }
        },
        {
          condition: async () => __stack.locals.answer === `aa`,
          body: async (runner2) => {
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_4 = {
                "action": `approve-always`,
                "reason": null
              };
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_4);
              return;
            });
          }
        },
        {
          condition: async () => __stack.locals.answer === `ap`,
          body: async (runner2) => {
            await runner2.step(6, async (runner3) => {
              __stack.locals.__armval_5 = {
                "action": `approve-always-here`,
                "reason": null
              };
            });
            await runner2.step(7, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_5);
              return;
            });
          }
        },
        {
          condition: async () => __stack.locals.answer === `rr`,
          body: async (runner2) => {
            await runner2.step(8, async (runner3) => {
              __stack.locals.__armval_6 = {
                "action": `reject-always`,
                "reason": null
              };
            });
            await runner2.step(9, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_6);
              return;
            });
          }
        }
      ], async (runner2) => {
        await runner2.step(10, async (runner3) => {
          __stack.locals.__armval_7 = {
            "action": `reject`,
            "reason": __stack.locals.answer
          };
        });
        await runner2.step(11, async (runner3) => {
          runner3.exitMatch(1, __stack.locals.__armval_7);
          return;
        });
      }, { matchId: 1 });
      await runner.step(12, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function askUser threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "askUser"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "askUser",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "askUser",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const askUser = __AgencyFunction.create({
  name: "askUser",
  module: "stdlib/policy.agency",
  fn: __askUser_impl,
  params: [{
    name: "intr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "askUser",
    description: "No description provided.",
    schema: z.object({ "intr": z.any() })
  },
  exported: false
}, __toolRegistry);
async function ___handler_impl(intr) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["intr"] = intr;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "_handler", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("intr" in __overrides) {
      intr = __overrides["intr"];
      __stack.args["intr"] = intr;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_handler",
            args: {
              intr
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.ifElse(2, [
        {
          condition: async () => __globals().get("stdlib/policy.agency", "_internalIo"),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await approve());
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        const __funcResult = await __call(maybeLoadPolicy, {
          type: "positional",
          args: []
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        const __funcResult = await __call(maybeFlush, {
          type: "positional",
          args: []
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
      });
      await runner.ifElse(5, [
        {
          condition: async () => __eq(__globals().get("stdlib/policy.agency", "_policy"), null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(print, {
                type: "positional",
                args: [`Error: no policy loaded. Rejecting by default. Load a policy with parsePolicyFile and set it using setPolicy before installing the handler.`]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await reject());
              return;
            });
          }
        }
      ]);
      await runner.step(6, async (runner2) => {
        __stack.locals.decision = await __call(checkPolicy, {
          type: "positional",
          args: [__globals().get("stdlib/policy.agency", "_policy"), __stack.args.intr]
        });
        if (hasInterrupts(__stack.locals.decision)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.decision);
          return;
        }
      });
      await runner.ifElse(7, [
        {
          condition: async () => __eq(__stack.locals.decision.type, `approve`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
            });
            await runner2.ifElse(1, [
              {
                condition: async () => __eq(__stack.args.intr.effect, `std::edit`),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    const __funcResult = await __call(print, {
                      type: "positional",
                      args: [await __call(renderEditDiff, {
                        type: "positional",
                        args: [__stack.args.intr.data]
                      })]
                    });
                    if (hasInterrupts(__funcResult)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner4.halt(__funcResult);
                      return;
                    }
                  });
                }
              }
            ]);
            await runner2.step(2, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await approve());
              return;
            });
          }
        }
      ]);
      await runner.ifElse(8, [
        {
          condition: async () => __eq(__stack.locals.decision.type, `reject`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await reject());
              return;
            });
          }
        }
      ]);
      await runner.step(9, async (runner2) => {
        __stack.locals.answer = await __call(askUser, {
          type: "positional",
          args: [__stack.args.intr]
        });
        if (hasInterrupts(__stack.locals.answer)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.answer);
          return;
        }
      });
      await runner.ifElse(10, [
        {
          condition: async () => __eq(__stack.locals.answer.action, `approve-always`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_policy", await __call(recordRule, {
                type: "positional",
                args: [__globals().get("stdlib/policy.agency", "_policy"), __stack.args.intr.effect, `approve`]
              }));
              if (hasInterrupts(__globals().get("stdlib/policy.agency", "_policy"))) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__globals().get("stdlib/policy.agency", "_policy"));
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_pendingSave", true);
            });
            await runner2.step(2, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await approve());
              return;
            });
          }
        }
      ]);
      await runner.ifElse(11, [
        {
          condition: async () => __eq(__stack.locals.answer.action, `approve-always-here`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_policy", await __call(recordScopedRule, {
                type: "positional",
                args: [__globals().get("stdlib/policy.agency", "_policy"), __stack.args.intr, __globals().get("stdlib/policy.agency", "globalCliPolicyOpts").fields]
              }));
              if (hasInterrupts(__globals().get("stdlib/policy.agency", "_policy"))) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__globals().get("stdlib/policy.agency", "_policy"));
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_pendingSave", true);
            });
            await runner2.step(2, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await approve());
              return;
            });
          }
        }
      ]);
      await runner.ifElse(12, [
        {
          condition: async () => __eq(__stack.locals.answer.action, `reject-always`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_policy", await __call(recordRule, {
                type: "positional",
                args: [__globals().get("stdlib/policy.agency", "_policy"), __stack.args.intr.effect, `reject`]
              }));
              if (hasInterrupts(__globals().get("stdlib/policy.agency", "_policy"))) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__globals().get("stdlib/policy.agency", "_policy"));
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_pendingSave", true);
            });
            await runner2.step(2, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await reject());
              return;
            });
          }
        }
      ]);
      await runner.ifElse(13, [
        {
          condition: async () => __eq(__stack.locals.answer.action, `approve`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await approve());
              return;
            });
          }
        }
      ]);
      await runner.step(14, async (runner2) => {
      });
      await runner.ifElse(15, [
        {
          condition: async () => !__eq(__stack.locals.answer.reason, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await reject(__stack.locals.answer.reason));
              return;
            });
          }
        }
      ]);
      await runner.step(16, async (runner2) => {
      });
      await runner.step(17, async (runner2) => {
        __stack.locals.reason = await __call(input, {
          type: "positional",
          args: [`What should the agent do instead? (press enter to skip) `]
        });
        if (hasInterrupts(__stack.locals.reason)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.reason);
          return;
        }
      });
      await runner.ifElse(18, [
        {
          condition: async () => __eq(__stack.locals.reason, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await reject());
              return;
            });
          }
        }
      ]);
      await runner.step(19, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await reject(__stack.locals.reason));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _handler threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_handler"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_handler",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_handler",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _handler = __AgencyFunction.create({
  name: "_handler",
  module: "stdlib/policy.agency",
  fn: ___handler_impl,
  params: [{
    name: "intr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "_handler",
    description: "No description provided.",
    schema: z.object({ "intr": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __cliPolicyHandler_impl(file, fields, policy = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/policy.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["file"] = file;
  __stack.args["fields"] = fields;
  __stack.args["policy"] = policy === __UNSET ? null : policy;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/policy.agency", scopeName: "cliPolicyHandler", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("file" in __overrides) {
      file = __overrides["file"];
      __stack.args["file"] = file;
    }
    if ("fields" in __overrides) {
      fields = __overrides["fields"];
      __stack.args["fields"] = fields;
    }
    if ("policy" in __overrides) {
      policy = __overrides["policy"];
      __stack.args["policy"] = policy;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "cliPolicyHandler",
            args: {
              file,
              fields,
              policy
            },
            moduleId: "stdlib/policy.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __globals().set("stdlib/policy.agency", "globalCliPolicyOpts", {
          "file": __stack.args.file,
          "fields": __stack.args.fields
        });
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.policy, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
            });
            await runner2.step(1, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_policy", __stack.args.policy);
            });
            await runner2.step(2, async (runner3) => {
              __globals().set("stdlib/policy.agency", "_policyLoaded", true);
            });
          }
        }
      ], async (runner2) => {
        await runner2.step(3, async (runner3) => {
          __globals().set("stdlib/policy.agency", "_policy", null);
        });
        await runner2.step(4, async (runner3) => {
          __globals().set("stdlib/policy.agency", "_policyLoaded", false);
        });
      });
      await runner.step(3, async (runner2) => {
        __globals().set("stdlib/policy.agency", "_pendingSave", false);
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(_handler);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function cliPolicyHandler threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "cliPolicyHandler"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "cliPolicyHandler",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "cliPolicyHandler",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const cliPolicyHandler = __AgencyFunction.create({
  name: "cliPolicyHandler",
  module: "stdlib/policy.agency",
  fn: __cliPolicyHandler_impl,
  params: [{
    name: "file",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fields",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "policy",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "cliPolicyHandler",
    description: `CLI sugar for an interactive policy handler. Loads and saves the policy file, prompts the user on new interrupts, records "always" decisions, and returns approve/reject. Install on the outermost \`handle\`. Call exactly once per program \u2014 internal state is module-level.

  @param file - Path to the on-disk policy file.
  @param fields - Per-effect config controlling the "approve-always-here" prompt option.
  @param policy - Optional in-memory policy to use directly instead of loading \`file\` on startup.`,
    schema: z.object({ "file": z.string(), "fields": ScopedRuleFields, "policy": z.union([Policy, z.null()]).describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/policy.agency:withWritesPolicy": { "1": { "line": 107, "col": 2 } }, "stdlib/policy.agency:builtinPolicy": { "1": { "line": 111, "col": 2 } }, "stdlib/policy.agency:builtinPolicyNames": { "1": { "line": 115, "col": 2 } }, "stdlib/policy.agency:checkPolicy": { "1": { "line": 214, "col": 2 } }, "stdlib/policy.agency:validatePolicy": { "1": { "line": 232, "col": 2 } }, "stdlib/policy.agency:buildScopedMatch": { "1": { "line": 271, "col": 2 }, "2": { "line": 272, "col": 2 }, "3": { "line": 275, "col": 2 }, "4": { "line": 276, "col": 2 }, "5": { "line": 287, "col": 2 }, "2.0": { "line": 273, "col": 4 }, "4.0": { "line": 277, "col": 4 }, "4.1": { "line": 278, "col": 4 }, "4.2.0": { "line": 282, "col": 6 }, "4.2.1": { "line": 284, "col": 6 }, "4.2": { "line": 281, "col": 4 } }, "stdlib/policy.agency:recordRule": { "1": { "line": 323, "col": 2 }, "2": { "line": 324, "col": 2 }, "3": { "line": 330, "col": 2 } }, "stdlib/policy.agency:recordScopedRule": { "1": { "line": 360, "col": 2 }, "2": { "line": 361, "col": 2 }, "3": { "line": 362, "col": 2 }, "4": { "line": 369, "col": 2 } }, "stdlib/policy.agency:parsePolicyFile": { "1": { "line": 402, "col": 2 }, "2": { "line": 403, "col": 2 }, "3": { "line": 404, "col": 2 }, "4": { "line": 409, "col": 2 }, "5": { "line": 410, "col": 2 }, "6": { "line": 416, "col": 2 }, "7": { "line": 417, "col": 2 }, "8": { "line": 422, "col": 2 }, "9": { "line": 423, "col": 2 }, "10": { "line": 429, "col": 2 }, "3.0": { "line": 405, "col": 4 }, "4.0": { "line": 409, "col": 2 }, "5.0": { "line": 411, "col": 4 }, "7.0": { "line": 418, "col": 4 }, "9.0": { "line": 424, "col": 4 } }, "stdlib/policy.agency:setPolicy": { "1": { "line": 440, "col": 2 }, "2": { "line": 441, "col": 2 }, "3": { "line": 442, "col": 2 } }, "stdlib/policy.agency:writePolicyFile": { "1": { "line": 467, "col": 2 } }, "stdlib/policy.agency:maybeLoadPolicy": { "1": { "line": 476, "col": 2 }, "1.0": { "line": 477, "col": 4 }, "1.1": { "line": 478, "col": 4 }, "1.2.0": { "line": 479, "col": 4 }, "1.2": { "line": 479, "col": 4 }, "1.3": { "line": 480, "col": 4 }, "1.4.0": { "line": 482, "col": 6 }, "1.4.1": { "line": 484, "col": 6 }, "1.4": { "line": 481, "col": 4 } }, "stdlib/policy.agency:maybeFlush": { "1": { "line": 495, "col": 2 }, "1.1": { "line": 497, "col": 4 }, "1.2.0": { "line": 502, "col": 6 }, "1.2.1": { "line": 503, "col": 6 }, "1.2.2": { "line": 504, "col": 6 }, "1.2": { "line": 501, "col": 4 } }, "stdlib/policy.agency:flushPolicy": { "1": { "line": 521, "col": 2 }, "1.0": { "line": 522, "col": 4 }, "1.1.0": { "line": 524, "col": 6 }, "1.1.1": { "line": 525, "col": 6 }, "1.1.2": { "line": 526, "col": 6 }, "1.1": { "line": 523, "col": 4 } }, "stdlib/policy.agency:describeScopedMatch": { "1": { "line": 535, "col": 2 }, "2": { "line": 536, "col": 2 }, "3": { "line": 537, "col": 2 }, "4": { "line": 540, "col": 2 }, "5": { "line": 541, "col": 2 }, "6": { "line": 544, "col": 2 }, "3.0": { "line": 538, "col": 4 }, "5.0": { "line": 542, "col": 4 } }, "stdlib/policy.agency:renderEditDiff": { "1": { "line": 564, "col": 2 }, "2": { "line": 565, "col": 2 }, "3": { "line": 566, "col": 2 }, "4": { "line": 577, "col": 2 } }, "stdlib/policy.agency:prettyPrintInterruptData": { "2": { "line": 588, "col": 2 }, "3": { "line": 592, "col": 2 }, "5": { "line": 600, "col": 2 }, "7": { "line": 617, "col": 2 }, "8": { "line": 627, "col": 2 }, "9": { "line": 630, "col": 2 }, "2.0": { "line": 589, "col": 4 }, "3.0": { "line": 593, "col": 4 }, "5.0": { "line": 601, "col": 4 }, "5.1": { "line": 605, "col": 4 }, "5.2.0": { "line": 607, "col": 6 }, "5.2": { "line": 606, "col": 4 }, "5.3": { "line": 609, "col": 4 }, "7.0": { "line": 618, "col": 4 }, "7.1": { "line": 619, "col": 4 }, "7.2": { "line": 625, "col": 4 }, "8.0": { "line": 628, "col": 4 } }, "stdlib/policy.agency:__block_0": { "7.1.0.0": { "line": 621, "col": 8 }, "7.1.0.1": { "line": 622, "col": 8 }, "7.1.0": { "line": 620, "col": 6 } }, "stdlib/policy.agency:renderObjAsTable": { "1": { "line": 640, "col": 2 }, "2": { "line": 641, "col": 2 }, "3": { "line": 642, "col": 2 }, "4": { "line": 651, "col": 2 }, "5": { "line": 654, "col": 2 }, "4.0": { "line": 652, "col": 4 } }, "stdlib/policy.agency:__block_1": { "3.0.0": { "line": 644, "col": 6 }, "3.0.1": { "line": 647, "col": 6 }, "3.0.2": { "line": 648, "col": 6 }, "3.0": { "line": 643, "col": 4 } }, "stdlib/policy.agency:askUser": { "2": { "line": 669, "col": 2 }, "3": { "line": 670, "col": 2 }, "4": { "line": 673, "col": 2 }, "5": { "line": 675, "col": 2 }, "6": { "line": 676, "col": 2 }, "7": { "line": 678, "col": 2 }, "8": { "line": 692, "col": 2 }, "9": { "line": 700, "col": 2 }, "10": { "line": 709, "col": 2 }, "11": { "line": 712, "col": 9 }, "12": { "line": 712, "col": 2 }, "3.0": { "line": 671, "col": 4 }, "8.0": { "line": 693, "col": 4 } }, "stdlib/policy.agency:__block_2": { "10.0": { "line": 710, "col": 4 } }, "stdlib/policy.agency:_handler": { "2": { "line": 753, "col": 2 }, "3": { "line": 756, "col": 2 }, "4": { "line": 757, "col": 2 }, "5": { "line": 759, "col": 2 }, "6": { "line": 766, "col": 2 }, "7": { "line": 767, "col": 2 }, "8": { "line": 776, "col": 2 }, "9": { "line": 780, "col": 2 }, "10": { "line": 781, "col": 2 }, "11": { "line": 786, "col": 2 }, "12": { "line": 791, "col": 2 }, "13": { "line": 796, "col": 2 }, "15": { "line": 803, "col": 2 }, "17": { "line": 810, "col": 2 }, "18": { "line": 811, "col": 2 }, "19": { "line": 814, "col": 2 }, "2.0": { "line": 754, "col": 4 }, "5.0": { "line": 760, "col": 4 }, "5.1": { "line": 763, "col": 4 }, "7.1.0": { "line": 772, "col": 6 }, "7.1": { "line": 771, "col": 4 }, "7.2": { "line": 774, "col": 4 }, "8.0": { "line": 777, "col": 4 }, "10.0": { "line": 782, "col": 4 }, "10.1": { "line": 783, "col": 4 }, "10.2": { "line": 784, "col": 4 }, "11.0": { "line": 787, "col": 4 }, "11.1": { "line": 788, "col": 4 }, "11.2": { "line": 789, "col": 4 }, "12.0": { "line": 792, "col": 4 }, "12.1": { "line": 793, "col": 4 }, "12.2": { "line": 794, "col": 4 }, "13.0": { "line": 797, "col": 4 }, "15.0": { "line": 804, "col": 4 }, "18.0": { "line": 812, "col": 4 } }, "stdlib/policy.agency:cliPolicyHandler": { "1": { "line": 887, "col": 2 }, "2": { "line": 891, "col": 2 }, "3": { "line": 900, "col": 2 }, "4": { "line": 901, "col": 2 }, "2.1": { "line": 894, "col": 4 }, "2.2": { "line": 895, "col": 4 }, "2.3": { "line": 897, "col": 4 }, "2.4": { "line": 898, "col": 4 } } };
export {
  BUILTIN_POLICIES,
  Decision,
  InterruptDataKey,
  InterruptDataVal,
  InterruptEffect,
  ParsePolicyFailure,
  ParsePolicyFailureStatus,
  Policy,
  PolicyRule,
  ScopedField,
  ScopedRuleFields,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  _handler,
  approve,
  approveAllPolicy,
  askUser,
  buildScopedMatch,
  builtinPolicy,
  builtinPolicyNames,
  checkPolicy,
  cliPolicyHandler,
  stdin_default as default,
  describeScopedMatch,
  flushPolicy,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  maybeFlush,
  maybeLoadPolicy,
  minimalAutoApprovePolicy,
  parsePolicyFile,
  prettyPrintInterruptData,
  recommendedAutoApprovePolicy,
  recordRule,
  recordScopedRule,
  reject,
  renderEditDiff,
  renderObjAsTable,
  respondToInterrupts,
  rewindFrom,
  setPolicy,
  validatePolicy,
  withWritesPolicy,
  writePolicyFile
};
