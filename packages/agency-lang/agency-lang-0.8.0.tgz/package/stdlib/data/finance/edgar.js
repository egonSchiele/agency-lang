import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { fetchJSON } from "agency-lang/stdlib/http.js";
import { env } from "agency-lang/stdlib/system.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  __registerGlobalsInit,
  success,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __catchResult,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/data/finance/edgar.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(fetchJSON);
__registerTool(env);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/data/finance/edgar.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/data/finance/edgar.agency");
  __ctx.globals.set("stdlib/data/finance/edgar.agency", "CIK_WIDTH", 10);
  __ctx.globals.set("stdlib/data/finance/edgar.agency", "secUserAgent", await __call(env, {
    type: "positional",
    args: [`SEC_USER_AGENT`]
  }) ?? `agency-lang admin@agency-lang.com`);
  __ctx.globals.set("stdlib/data/finance/edgar.agency", "SEC_HEADERS", {
    "User-Agent": __globals().get("stdlib/data/finance/edgar.agency", "secUserAgent")
  });
  __ctx.globals.set("stdlib/data/finance/edgar.agency", "SEC_TICKER_BASE", `https://www.sec.gov/`);
  __ctx.globals.set("stdlib/data/finance/edgar.agency", "SEC_TICKER_DOMAINS", [`www.sec.gov`]);
  __ctx.globals.set("stdlib/data/finance/edgar.agency", "SEC_DATA_BASE", `https://data.sec.gov/`);
  __ctx.globals.set("stdlib/data/finance/edgar.agency", "SEC_DATA_DOMAINS", [`data.sec.gov`]);
}
__registerGlobalsInit("stdlib/data/finance/edgar.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const Filing = z.object({ "form": z.string(), "filingDate": z.string(), "reportDate": z.string(), "accessionNumber": z.string(), "primaryDocument": z.string(), "description": z.string(), "url": z.string() });
async function __buildSubmissionsPath_impl(cik10) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/edgar.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cik10"] = cik10;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/edgar.agency", scopeName: "buildSubmissionsPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cik10" in __overrides) {
      cik10 = __overrides["cik10"];
      __stack.args["cik10"] = cik10;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildSubmissionsPath",
            args: {
              cik10
            },
            moduleId: "stdlib/data/finance/edgar.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`submissions/CIK${__stack.args.cik10}.json`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildSubmissionsPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildSubmissionsPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildSubmissionsPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildSubmissionsPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildSubmissionsPath = __AgencyFunction.create({
  name: "buildSubmissionsPath",
  module: "stdlib/data/finance/edgar.agency",
  fn: __buildSubmissionsPath_impl,
  params: [{
    name: "cik10",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildSubmissionsPath",
    description: "No description provided.",
    schema: z.object({ "cik10": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildArchiveUrl_impl(cikNoPad, accessionNumber, primaryDocument) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/edgar.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cikNoPad"] = cikNoPad;
  __stack.args["accessionNumber"] = accessionNumber;
  __stack.args["primaryDocument"] = primaryDocument;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/edgar.agency", scopeName: "buildArchiveUrl", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cikNoPad" in __overrides) {
      cikNoPad = __overrides["cikNoPad"];
      __stack.args["cikNoPad"] = cikNoPad;
    }
    if ("accessionNumber" in __overrides) {
      accessionNumber = __overrides["accessionNumber"];
      __stack.args["accessionNumber"] = accessionNumber;
    }
    if ("primaryDocument" in __overrides) {
      primaryDocument = __overrides["primaryDocument"];
      __stack.args["primaryDocument"] = primaryDocument;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildArchiveUrl",
            args: {
              cikNoPad,
              accessionNumber,
              primaryDocument
            },
            moduleId: "stdlib/data/finance/edgar.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.accessionNoDashes = await __callMethod(__stack.args.accessionNumber, "replaceAll", {
          type: "positional",
          args: [`-`, ``]
        });
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`https://www.sec.gov/Archives/edgar/data/${__stack.args.cikNoPad}/${__stack.locals.accessionNoDashes}/${__stack.args.primaryDocument}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildArchiveUrl threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildArchiveUrl"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildArchiveUrl",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildArchiveUrl",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildArchiveUrl = __AgencyFunction.create({
  name: "buildArchiveUrl",
  module: "stdlib/data/finance/edgar.agency",
  fn: __buildArchiveUrl_impl,
  params: [{
    name: "cikNoPad",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "accessionNumber",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "primaryDocument",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildArchiveUrl",
    description: "No description provided.",
    schema: z.object({ "cikNoPad": z.string(), "accessionNumber": z.string(), "primaryDocument": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __parseTickerMap_impl(raw, ticker) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/edgar.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __stack.args["ticker"] = ticker;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/edgar.agency", scopeName: "parseTickerMap", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
    if ("ticker" in __overrides) {
      ticker = __overrides["ticker"];
      __stack.args["ticker"] = ticker;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseTickerMap",
            args: {
              raw,
              ticker
            },
            moduleId: "stdlib/data/finance/edgar.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.rows = await __callMethod(Object, "values", {
          type: "positional",
          args: [__stack.args.raw ?? {}]
        });
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.want = await __callMethod(__stack.args.ticker, "toUpperCase", {
          type: "positional",
          args: []
        });
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.row = await __call(find, {
          type: "named",
          positionalArgs: [__stack.locals.rows],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/data/finance/edgar.agency", fn: async (r) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["r"] = r;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/finance/edgar.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(__eq(await __callMethod(__bstack.args.r.ticker ?? ``, "toUpperCase", {
                  type: "positional",
                  args: []
                }), __stack.locals.want));
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "r", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.row)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.row);
          return;
        }
      });
      await runner.ifElse(4, [
        {
          condition: async () => __eq(__stack.locals.row, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(``);
              return;
            });
          }
        }
      ]);
      await runner.step(5, async (runner2) => {
        __stack.locals.cikStr = `${__stack.locals.row.cik_str}`;
      });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(__stack.locals.cikStr, "padStart", {
          type: "positional",
          args: [__globals().get("stdlib/data/finance/edgar.agency", "CIK_WIDTH"), `0`]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseTickerMap threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseTickerMap"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseTickerMap",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseTickerMap",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseTickerMap = __AgencyFunction.create({
  name: "parseTickerMap",
  module: "stdlib/data/finance/edgar.agency",
  fn: __parseTickerMap_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "ticker",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "parseTickerMap",
    description: "No description provided.",
    schema: z.object({ "raw": z.any(), "ticker": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __parseSubmissions_impl(cik10, raw, formType, limit) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/edgar.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cik10"] = cik10;
  __stack.args["raw"] = raw;
  __stack.args["formType"] = formType;
  __stack.args["limit"] = limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/edgar.agency", scopeName: "parseSubmissions", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cik10" in __overrides) {
      cik10 = __overrides["cik10"];
      __stack.args["cik10"] = cik10;
    }
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
    if ("formType" in __overrides) {
      formType = __overrides["formType"];
      __stack.args["formType"] = formType;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseSubmissions",
            args: {
              cik10,
              raw,
              formType,
              limit
            },
            moduleId: "stdlib/data/finance/edgar.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.filings = __stack.locals.r.filings ?? {};
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.recent = __stack.locals.filings.recent ?? {};
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.forms = __stack.locals.recent.form ?? [];
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.accessions = __stack.locals.recent.accessionNumber ?? [];
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.filingDates = __stack.locals.recent.filingDate ?? [];
      });
      await runner.step(7, async (runner2) => {
        __stack.locals.reportDates = __stack.locals.recent.reportDate ?? [];
      });
      await runner.step(8, async (runner2) => {
        __stack.locals.primaryDocs = __stack.locals.recent.primaryDocument ?? [];
      });
      await runner.step(9, async (runner2) => {
        __stack.locals.descriptions = __stack.locals.recent.primaryDocDescription ?? [];
      });
      await runner.step(10, async (runner2) => {
        __stack.locals.cikNoPad = `${await __call(Number, {
          type: "positional",
          args: [__stack.args.cik10]
        })}`;
      });
      await runner.step(11, async (runner2) => {
        __stack.locals.rows = await __call(map, {
          type: "named",
          positionalArgs: [await __call(range, {
            type: "positional",
            args: [__stack.locals.forms.length]
          })],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/data/finance/edgar.agency", fn: async (i) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_1 = __bstack;
            __bstack.args["i"] = i;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/finance/edgar.agency", scopeName: "__block_1" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt({
                  "form": __nn(__stack.locals.forms[__bstack.args.i]) ?? ``,
                  "filingDate": __nn(__stack.locals.filingDates[__bstack.args.i]) ?? ``,
                  "reportDate": __nn(__stack.locals.reportDates[__bstack.args.i]) ?? ``,
                  "accessionNumber": __nn(__stack.locals.accessions[__bstack.args.i]) ?? ``,
                  "primaryDocument": __nn(__stack.locals.primaryDocs[__bstack.args.i]) ?? ``,
                  "description": __nn(__stack.locals.descriptions[__bstack.args.i]) ?? ``,
                  "url": await __call(buildArchiveUrl, {
                    type: "positional",
                    args: [__stack.locals.cikNoPad, __nn(__stack.locals.accessions[__bstack.args.i]) ?? ``, __nn(__stack.locals.primaryDocs[__bstack.args.i]) ?? ``]
                  })
                });
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "i", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.rows)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.rows);
          return;
        }
      });
      await runner.step(12, async (runner2) => {
        __stack.locals.filtered = await __call(filter, {
          type: "named",
          positionalArgs: [__stack.locals.rows],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_2", module: "stdlib/data/finance/edgar.agency", fn: async (f) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_2 = __bstack;
            __bstack.args["f"] = f;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/finance/edgar.agency", scopeName: "__block_2" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(__eq(__stack.args.formType, ``) || __eq(__bstack.args.f.form, __stack.args.formType));
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "f", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.filtered)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.filtered);
          return;
        }
      });
      await runner.ifElse(13, [
        {
          condition: async () => __stack.args.limit > 0,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await __callMethod(__stack.locals.filtered, "slice", {
                type: "positional",
                args: [0, __stack.args.limit]
              }));
              return;
            });
          }
        }
      ]);
      await runner.step(14, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.filtered);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseSubmissions threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseSubmissions"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseSubmissions",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseSubmissions",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseSubmissions = __AgencyFunction.create({
  name: "parseSubmissions",
  module: "stdlib/data/finance/edgar.agency",
  fn: __parseSubmissions_impl,
  params: [{
    name: "cik10",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "formType",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "parseSubmissions",
    description: "No description provided.",
    schema: z.object({ "cik10": z.string(), "raw": z.any(), "formType": z.string(), "limit": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __edgarSubmissionsFinalize_impl(cik10, formType, limit, fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/edgar.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cik10"] = cik10;
  __stack.args["formType"] = formType;
  __stack.args["limit"] = limit;
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/edgar.agency", scopeName: "edgarSubmissionsFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cik10" in __overrides) {
      cik10 = __overrides["cik10"];
      __stack.args["cik10"] = cik10;
    }
    if ("formType" in __overrides) {
      formType = __overrides["formType"];
      __stack.args["formType"] = formType;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "edgarSubmissionsFinalize",
            args: {
              cik10,
              formType,
              limit,
              fetchResult
            },
            moduleId: "stdlib/data/finance/edgar.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_3 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_3),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_3.value;
            });
            await runner2.ifElse(1, [
              {
                condition: async () => __eq(__stack.locals.body.filings ?? null, null),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    runner4.exitMatch(1, failure(`EDGAR returned no filings for CIK ${__stack.args.cik10}`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "edgarSubmissionsFinalize", args: __stack.args }));
                    return;
                  });
                }
              }
            ]);
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(1, await success(await __call(parseSubmissions, {
                type: "positional",
                args: [__stack.args.cik10, __stack.locals.body, __stack.args.formType, __stack.args.limit]
              })));
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_3),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_3.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_2 = failure(`EDGAR submissions request failed: ${__stack.locals.err}`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "edgarSubmissionsFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_2)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_2);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_2);
              return;
            });
          }
        }
      ], void 0, { matchId: 1 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function edgarSubmissionsFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "edgarSubmissionsFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "edgarSubmissionsFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "edgarSubmissionsFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const edgarSubmissionsFinalize = __AgencyFunction.create({
  name: "edgarSubmissionsFinalize",
  module: "stdlib/data/finance/edgar.agency",
  fn: __edgarSubmissionsFinalize_impl,
  params: [{
    name: "cik10",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "formType",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "edgarSubmissionsFinalize",
    description: "No description provided.",
    schema: z.object({ "cik10": z.string(), "formType": z.string(), "limit": z.number(), "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __edgarFilingsByCik_impl(cik, formType = __UNSET, limit = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/edgar.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cik"] = cik;
  __stack.args["formType"] = formType === __UNSET ? `` : formType;
  __stack.args["limit"] = limit === __UNSET ? 20 : limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/edgar.agency", scopeName: "edgarFilingsByCik", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cik" in __overrides) {
      cik = __overrides["cik"];
      __stack.args["cik"] = cik;
    }
    if ("formType" in __overrides) {
      formType = __overrides["formType"];
      __stack.args["formType"] = formType;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "edgarFilingsByCik",
            args: {
              cik,
              formType,
              limit
            },
            moduleId: "stdlib/data/finance/edgar.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.cik10 = await __callMethod(__stack.args.cik, "padStart", {
          type: "positional",
          args: [__globals().get("stdlib/data/finance/edgar.agency", "CIK_WIDTH"), `0`]
        });
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::edgar", `Fetch SEC filings for this company?`, {
            "company": __stack.args.cik
          }, "std::data/finance/edgar", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/finance/edgar.agency", scopeName: "edgarFilingsByCik", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.path = await __call(buildSubmissionsPath, {
          type: "positional",
          args: [__stack.locals.cik10]
        });
        if (hasInterrupts(__stack.locals.path)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.path);
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.result = await __call(fetchJSON, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            baseUrl: __globals().get("stdlib/data/finance/edgar.agency", "SEC_DATA_BASE"),
            path: __stack.locals.path,
            headers: __globals().get("stdlib/data/finance/edgar.agency", "SEC_HEADERS"),
            allowedDomains: __globals().get("stdlib/data/finance/edgar.agency", "SEC_DATA_DOMAINS")
          }
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(edgarSubmissionsFinalize, {
          type: "positional",
          args: [__stack.locals.cik10, __stack.args.formType, __stack.args.limit, __stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function edgarFilingsByCik threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "edgarFilingsByCik"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "edgarFilingsByCik",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "edgarFilingsByCik",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const edgarFilingsByCik = __AgencyFunction.create({
  name: "edgarFilingsByCik",
  module: "stdlib/data/finance/edgar.agency",
  fn: __edgarFilingsByCik_impl,
  params: [{
    name: "cik",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "formType",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "edgarFilingsByCik",
    description: `List recent SEC filings for a company by its CIK (Central Index Key). Returns filings with
  form type, filing/report dates, and a direct URL to each primary document. Optionally filter
  by form type (e.g. "10-K", "10-Q", "8-K").

  @param cik - The company CIK, with or without leading zeros
  @param formType - Optional filing form to filter by, e.g. "10-K" (empty for all forms)
  @param limit - Maximum filings to return (default 20)`,
    schema: z.object({ "cik": z.string(), "formType": z.string().nullable().describe("Default: "), "limit": z.number().nullable().describe("Default: 20") })
  },
  exported: true
}, __toolRegistry);
async function __edgarFilings_impl(ticker, formType = __UNSET, limit = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/edgar.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["ticker"] = ticker;
  __stack.args["formType"] = formType === __UNSET ? `` : formType;
  __stack.args["limit"] = limit === __UNSET ? 20 : limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/edgar.agency", scopeName: "edgarFilings", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("ticker" in __overrides) {
      ticker = __overrides["ticker"];
      __stack.args["ticker"] = ticker;
    }
    if ("formType" in __overrides) {
      formType = __overrides["formType"];
      __stack.args["formType"] = formType;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "edgarFilings",
            args: {
              ticker,
              formType,
              limit
            },
            moduleId: "stdlib/data/finance/edgar.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::edgar", `Fetch SEC filings for this company?`, {
            "company": __stack.args.ticker
          }, "std::data/finance/edgar", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/finance/edgar.agency", scopeName: "edgarFilings", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.tickersResult = await __call(fetchJSON, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            baseUrl: __globals().get("stdlib/data/finance/edgar.agency", "SEC_TICKER_BASE"),
            path: `files/company_tickers.json`,
            headers: __globals().get("stdlib/data/finance/edgar.agency", "SEC_HEADERS"),
            allowedDomains: __globals().get("stdlib/data/finance/edgar.agency", "SEC_TICKER_DOMAINS")
          }
        });
        if (hasInterrupts(__stack.locals.tickersResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.tickersResult);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.tickerMap = await __catchResult(__stack.locals.tickersResult, async () => {
          return {};
        });
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.cik10 = await __call(parseTickerMap, {
          type: "positional",
          args: [__stack.locals.tickerMap, __stack.args.ticker]
        });
        if (hasInterrupts(__stack.locals.cik10)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.cik10);
          return;
        }
      });
      await runner.ifElse(5, [
        {
          condition: async () => __eq(__stack.locals.cik10, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(`EDGAR: no company found for ticker '${__stack.args.ticker}' (or the ticker lookup failed)`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "edgarFilings", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(6, async (runner2) => {
        __stack.locals.subResult = await __call(fetchJSON, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            baseUrl: __globals().get("stdlib/data/finance/edgar.agency", "SEC_DATA_BASE"),
            path: await __call(buildSubmissionsPath, {
              type: "positional",
              args: [__stack.locals.cik10]
            }),
            headers: __globals().get("stdlib/data/finance/edgar.agency", "SEC_HEADERS"),
            allowedDomains: __globals().get("stdlib/data/finance/edgar.agency", "SEC_DATA_DOMAINS")
          }
        });
        if (hasInterrupts(__stack.locals.subResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.subResult);
          return;
        }
      });
      await runner.step(7, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(edgarSubmissionsFinalize, {
          type: "positional",
          args: [__stack.locals.cik10, __stack.args.formType, __stack.args.limit, __stack.locals.subResult]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function edgarFilings threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "edgarFilings"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "edgarFilings",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "edgarFilings",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const edgarFilings = __AgencyFunction.create({
  name: "edgarFilings",
  module: "stdlib/data/finance/edgar.agency",
  fn: __edgarFilings_impl,
  params: [{
    name: "ticker",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "formType",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "edgarFilings",
    description: `List recent SEC filings for a U.S.-listed company by its ticker symbol (e.g. "AAPL").
  Resolves the ticker to a CIK, then returns filings with form type, filing/report dates, and
  a direct URL to each primary document. Optionally filter by form type (e.g. "10-K", "8-K").
  This downloads the SEC ticker->CIK map on each call; if you already know the CIK, prefer
  edgarFilingsByCik to skip that fetch.

  @param ticker - The company's stock ticker, e.g. "AAPL"
  @param formType - Optional filing form to filter by, e.g. "10-K" (empty for all forms)
  @param limit - Maximum filings to return (default 20)`,
    schema: z.object({ "ticker": z.string(), "formType": z.string().nullable().describe("Default: "), "limit": z.number().nullable().describe("Default: 20") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/data/finance/edgar.agency:buildSubmissionsPath": { "1": { "line": 61, "col": 2 } }, "stdlib/data/finance/edgar.agency:buildArchiveUrl": { "1": { "line": 66, "col": 2 }, "2": { "line": 67, "col": 2 } }, "stdlib/data/finance/edgar.agency:parseTickerMap": { "1": { "line": 72, "col": 2 }, "2": { "line": 73, "col": 2 }, "3": { "line": 74, "col": 2 }, "4": { "line": 77, "col": 2 }, "5": { "line": 80, "col": 2 }, "6": { "line": 81, "col": 2 }, "4.0": { "line": 78, "col": 4 } }, "stdlib/data/finance/edgar.agency:__block_0": { "3.0": { "line": 75, "col": 4 } }, "stdlib/data/finance/edgar.agency:parseSubmissions": { "1": { "line": 86, "col": 2 }, "2": { "line": 87, "col": 2 }, "3": { "line": 88, "col": 2 }, "4": { "line": 89, "col": 2 }, "5": { "line": 90, "col": 2 }, "6": { "line": 91, "col": 2 }, "7": { "line": 92, "col": 2 }, "8": { "line": 93, "col": 2 }, "9": { "line": 94, "col": 2 }, "10": { "line": 96, "col": 2 }, "11": { "line": 97, "col": 2 }, "12": { "line": 108, "col": 2 }, "13": { "line": 111, "col": 2 }, "14": { "line": 114, "col": 2 }, "13.0": { "line": 112, "col": 4 } }, "stdlib/data/finance/edgar.agency:__block_1": { "11.0": { "line": 98, "col": 4 } }, "stdlib/data/finance/edgar.agency:__block_2": { "12.0": { "line": 109, "col": 4 } }, "stdlib/data/finance/edgar.agency:edgarSubmissionsFinalize": { "1": { "line": 119, "col": 9 }, "2": { "line": 119, "col": 9 }, "3": { "line": 119, "col": 2 }, "2.0": { "line": 119, "col": 9 }, "2.1.0": { "line": 122, "col": 8 }, "2.1": { "line": 121, "col": 6 }, "2.2": { "line": 124, "col": 6 }, "2.3": { "line": 119, "col": 9 }, "2.4": { "line": 126, "col": 20 }, "2.5": { "line": 126, "col": 20 } }, "stdlib/data/finance/edgar.agency:edgarFilingsByCik": { "1": { "line": 140, "col": 2 }, "2": { "line": 141, "col": 2 }, "3": { "line": 142, "col": 2 }, "4": { "line": 144, "col": 2 }, "5": { "line": 145, "col": 2 } }, "stdlib/data/finance/edgar.agency:edgarFilings": { "1": { "line": 160, "col": 2 }, "2": { "line": 163, "col": 2 }, "3": { "line": 164, "col": 2 }, "4": { "line": 165, "col": 2 }, "5": { "line": 166, "col": 2 }, "6": { "line": 169, "col": 2 }, "7": { "line": 170, "col": 2 }, "5.0": { "line": 167, "col": 4 } } };
export {
  Filing,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  buildArchiveUrl,
  buildSubmissionsPath,
  stdin_default as default,
  edgarFilings,
  edgarFilingsByCik,
  edgarSubmissionsFinalize,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  parseSubmissions,
  parseTickerMap,
  reject,
  respondToInterrupts,
  rewindFrom
};
