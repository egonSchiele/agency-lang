import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { fetchJSON } from "agency-lang/stdlib/http.js";
import { keys } from "agency-lang/stdlib/object.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  success,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/data/tech/yc.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(fetchJSON);
__registerTool(keys);
let __staticInitPromise = null;
let YC_BASE = __UNINIT_STATIC;
let YC_DOMAINS = __UNINIT_STATIC;
let YC_LISTS = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    YC_BASE = __deepFreeze(`https://yc-oss.github.io/api`);
    YC_DOMAINS = __deepFreeze([`yc-oss.github.io`]);
    YC_LISTS = __deepFreeze([`top`, `all`, `hiring`, `nonprofit`, `women-founded`, `black-founded`, `hispanic-latino-founded`]);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    YC_BASE,
    YC_DOMAINS,
    YC_LISTS
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/data/tech/yc.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/data/tech/yc.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/data/tech/yc.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/data/tech/yc.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const Company = z.object({ "id": z.number(), "name": z.string(), "slug": z.string(), "website": z.string(), "oneLiner": z.string(), "longDescription": z.string(), "batch": z.string(), "status": z.string(), "stage": z.string(), "teamSize": z.number(), "industry": z.string(), "subindustry": z.string(), "tags": z.array(z.string()), "regions": z.array(z.string()), "allLocations": z.string(), "launchedAt": z.number(), "topCompany": z.boolean(), "isHiring": z.boolean(), "nonprofit": z.boolean(), "url": z.string() });
const YcMeta = z.object({ "lastUpdated": z.string(), "batches": z.array(z.string()), "industries": z.array(z.string()), "tags": z.array(z.string()) });
async function __slugify_impl(s) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["s"] = s;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "slugify", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("s" in __overrides) {
      s = __overrides["s"];
      __stack.args["s"] = s;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "slugify",
            args: {
              s
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(await __callMethod(await __callMethod(await __callMethod(__stack.args.s, "toLowerCase", {
          type: "positional",
          args: []
        }), "trim", {
          type: "positional",
          args: []
        }), "replaceAll", {
          type: "positional",
          args: [` `, `-`]
        }), "replaceAll", {
          type: "positional",
          args: [`_`, `-`]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function slugify threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "slugify"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "slugify",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "slugify",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const slugify = __AgencyFunction.create({
  name: "slugify",
  module: "stdlib/data/tech/yc.agency",
  fn: __slugify_impl,
  params: [{
    name: "s",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "slugify",
    description: "No description provided.",
    schema: z.object({ "s": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __ycListsList_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycListsList", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "ycListsList",
            args: {},
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(__readStatic(YC_LISTS, "YC_LISTS", "stdlib/data/tech/yc.agency"), "join", {
          type: "positional",
          args: [`, `]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function ycListsList threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "ycListsList"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "ycListsList",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "ycListsList",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const ycListsList = __AgencyFunction.create({
  name: "ycListsList",
  module: "stdlib/data/tech/yc.agency",
  fn: __ycListsList_impl,
  params: [],
  toolDefinition: {
    name: "ycListsList",
    description: "No description provided.",
    schema: z.object({})
  },
  exported: false
}, __toolRegistry);
async function __parseListName_impl(list) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["list"] = list;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "parseListName", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("list" in __overrides) {
      list = __overrides["list"];
      __stack.args["list"] = list;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseListName",
            args: {
              list
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.slug = await __call(slugify, {
          type: "positional",
          args: [__stack.args.list]
        });
        if (hasInterrupts(__stack.locals.slug)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.slug);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await __callMethod(__readStatic(YC_LISTS, "YC_LISTS", "stdlib/data/tech/yc.agency"), "indexOf", {
            type: "positional",
            args: [__stack.locals.slug]
          }) < 0,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(`unknown list '${__stack.args.list}'; valid: ${await __call(ycListsList, {
                type: "positional",
                args: []
              })}`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "parseListName", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await success(__stack.locals.slug));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseListName threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseListName"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseListName",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseListName",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseListName = __AgencyFunction.create({
  name: "parseListName",
  module: "stdlib/data/tech/yc.agency",
  fn: __parseListName_impl,
  params: [{
    name: "list",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "parseListName",
    description: "No description provided.",
    schema: z.object({ "list": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildBatchPath_impl(slug) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["slug"] = slug;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "buildBatchPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("slug" in __overrides) {
      slug = __overrides["slug"];
      __stack.args["slug"] = slug;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildBatchPath",
            args: {
              slug
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/batches/${__stack.args.slug}.json`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildBatchPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildBatchPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildBatchPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildBatchPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildBatchPath = __AgencyFunction.create({
  name: "buildBatchPath",
  module: "stdlib/data/tech/yc.agency",
  fn: __buildBatchPath_impl,
  params: [{
    name: "slug",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildBatchPath",
    description: "No description provided.",
    schema: z.object({ "slug": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildIndustryPath_impl(slug) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["slug"] = slug;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "buildIndustryPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("slug" in __overrides) {
      slug = __overrides["slug"];
      __stack.args["slug"] = slug;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildIndustryPath",
            args: {
              slug
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/industries/${__stack.args.slug}.json`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildIndustryPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildIndustryPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildIndustryPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildIndustryPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildIndustryPath = __AgencyFunction.create({
  name: "buildIndustryPath",
  module: "stdlib/data/tech/yc.agency",
  fn: __buildIndustryPath_impl,
  params: [{
    name: "slug",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildIndustryPath",
    description: "No description provided.",
    schema: z.object({ "slug": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildTagPath_impl(slug) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["slug"] = slug;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "buildTagPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("slug" in __overrides) {
      slug = __overrides["slug"];
      __stack.args["slug"] = slug;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildTagPath",
            args: {
              slug
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/tags/${__stack.args.slug}.json`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildTagPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildTagPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildTagPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildTagPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildTagPath = __AgencyFunction.create({
  name: "buildTagPath",
  module: "stdlib/data/tech/yc.agency",
  fn: __buildTagPath_impl,
  params: [{
    name: "slug",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildTagPath",
    description: "No description provided.",
    schema: z.object({ "slug": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildListPath_impl(name) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["name"] = name;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "buildListPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildListPath",
            args: {
              name
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/companies/${__stack.args.name}.json`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildListPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildListPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildListPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildListPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildListPath = __AgencyFunction.create({
  name: "buildListPath",
  module: "stdlib/data/tech/yc.agency",
  fn: __buildListPath_impl,
  params: [{
    name: "name",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildListPath",
    description: "No description provided.",
    schema: z.object({ "name": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildMetaPath_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "buildMetaPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildMetaPath",
            args: {},
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/meta.json`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildMetaPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildMetaPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildMetaPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildMetaPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildMetaPath = __AgencyFunction.create({
  name: "buildMetaPath",
  module: "stdlib/data/tech/yc.agency",
  fn: __buildMetaPath_impl,
  params: [],
  toolDefinition: {
    name: "buildMetaPath",
    description: "No description provided.",
    schema: z.object({})
  },
  exported: false
}, __toolRegistry);
async function __parseCompanies_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "parseCompanies", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseCompanies",
            args: {
              raw
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.arr = __stack.args.raw ?? [];
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(map, {
          type: "named",
          positionalArgs: [__stack.locals.arr],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/data/tech/yc.agency", fn: async (c) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["c"] = c;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.co = __bstack.args.c ?? {};
              });
              await runner3.step(1, async (runner4) => {
                runner4.halt({
                  "id": __bstack.locals.co.id ?? 0,
                  "name": __bstack.locals.co.name ?? ``,
                  "slug": __bstack.locals.co.slug ?? ``,
                  "website": __bstack.locals.co.website ?? ``,
                  "oneLiner": __bstack.locals.co.one_liner ?? ``,
                  "longDescription": __bstack.locals.co.long_description ?? ``,
                  "batch": __bstack.locals.co.batch ?? ``,
                  "status": __bstack.locals.co.status ?? ``,
                  "stage": __bstack.locals.co.stage ?? ``,
                  "teamSize": __bstack.locals.co.team_size ?? 0,
                  "industry": __bstack.locals.co.industry ?? ``,
                  "subindustry": __bstack.locals.co.subindustry ?? ``,
                  "tags": __bstack.locals.co.tags ?? [],
                  "regions": __bstack.locals.co.regions ?? [],
                  "allLocations": __bstack.locals.co.all_locations ?? ``,
                  "launchedAt": __bstack.locals.co.launched_at ?? 0,
                  "topCompany": __bstack.locals.co.top_company ?? false,
                  "isHiring": __bstack.locals.co.isHiring ?? false,
                  "nonprofit": __bstack.locals.co.nonprofit ?? false,
                  "url": __bstack.locals.co.url ?? ``
                });
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "c", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseCompanies threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseCompanies"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseCompanies",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseCompanies",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseCompanies = __AgencyFunction.create({
  name: "parseCompanies",
  module: "stdlib/data/tech/yc.agency",
  fn: __parseCompanies_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseCompanies",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __parseMeta_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "parseMeta", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseMeta",
            args: {
              raw
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "lastUpdated": __stack.locals.r.last_updated ?? ``,
          "batches": await __call(keys, {
            type: "positional",
            args: [__stack.locals.r.batches ?? {}]
          }),
          "industries": await __call(keys, {
            type: "positional",
            args: [__stack.locals.r.industries ?? {}]
          }),
          "tags": await __call(keys, {
            type: "positional",
            args: [__stack.locals.r.tags ?? {}]
          })
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseMeta threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseMeta"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseMeta",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseMeta",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseMeta = __AgencyFunction.create({
  name: "parseMeta",
  module: "stdlib/data/tech/yc.agency",
  fn: __parseMeta_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseMeta",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __ycError_impl(err) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["err"] = err;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycError", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("err" in __overrides) {
      err = __overrides["err"];
      __stack.args["err"] = err;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "ycError",
            args: {
              err
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`YC request failed (the data is static JSON on GitHub Pages; an unknown batch/industry/tag slug 404s): ${__stack.args.err.message ?? __stack.args.err}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function ycError threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "ycError"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "ycError",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "ycError",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const ycError = __AgencyFunction.create({
  name: "ycError",
  module: "stdlib/data/tech/yc.agency",
  fn: __ycError_impl,
  params: [{
    name: "err",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "ycError",
    description: "No description provided.",
    schema: z.object({ "err": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __companiesFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "companiesFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "companiesFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_4 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_4),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_4.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_2 = await success(await __call(parseCompanies, {
                type: "positional",
                args: [__stack.locals.body]
              }));
              if (hasInterrupts(__stack.locals.__armval_2)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_2);
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_2);
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_4),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_4.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_3 = failure(await __call(ycError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "companiesFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_3)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_3);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_3);
              return;
            });
          }
        }
      ], void 0, { matchId: 1 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function companiesFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "companiesFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "companiesFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "companiesFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const companiesFinalize = __AgencyFunction.create({
  name: "companiesFinalize",
  module: "stdlib/data/tech/yc.agency",
  fn: __companiesFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "companiesFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __metaFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "metaFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "metaFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_8 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_8),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_8.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_6 = await success(await __call(parseMeta, {
                type: "positional",
                args: [__stack.locals.body]
              }));
              if (hasInterrupts(__stack.locals.__armval_6)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_6);
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(5, __stack.locals.__armval_6);
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_8),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_8.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_7 = failure(await __call(ycError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "metaFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_7)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_7);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(5, __stack.locals.__armval_7);
              return;
            });
          }
        }
      ], void 0, { matchId: 5 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_5));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function metaFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "metaFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "metaFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "metaFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const metaFinalize = __AgencyFunction.create({
  name: "metaFinalize",
  module: "stdlib/data/tech/yc.agency",
  fn: __metaFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "metaFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __ycFetch_impl(path2) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["path"] = path2;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycFetch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("path" in __overrides) {
      path2 = __overrides["path"];
      __stack.args["path"] = path2;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "ycFetch",
            args: {
              path: path2
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.handle(1, async (data) => {
        if (__eq(data.effect, `std::http::fetchJSON`)) {
          return await approve();
        }
      }, async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __functionCompleted = true;
          runner3.halt(await __call(fetchJSON, {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              baseUrl: __readStatic(YC_BASE, "YC_BASE", "stdlib/data/tech/yc.agency"),
              path: __stack.args.path,
              allowedDomains: __readStatic(YC_DOMAINS, "YC_DOMAINS", "stdlib/data/tech/yc.agency")
            }
          }));
          return;
        });
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function ycFetch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "ycFetch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "ycFetch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "ycFetch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const ycFetch = __AgencyFunction.create({
  name: "ycFetch",
  module: "stdlib/data/tech/yc.agency",
  fn: __ycFetch_impl,
  params: [{
    name: "path",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "ycFetch",
    description: "No description provided.",
    schema: z.object({ "path": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __ycBatch_impl(batch) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["batch"] = batch;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycBatch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("batch" in __overrides) {
      batch = __overrides["batch"];
      __stack.args["batch"] = batch;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "ycBatch",
            args: {
              batch
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::yc", `Fetch YC companies for this batch?`, {
            "op": `batch`,
            "query": __stack.args.batch
          }, "std::data/tech/yc", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycBatch", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(ycFetch, {
          type: "positional",
          args: [await __call(buildBatchPath, {
            type: "positional",
            args: [await __call(slugify, {
              type: "positional",
              args: [__stack.args.batch]
            })]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(companiesFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function ycBatch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "ycBatch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "ycBatch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "ycBatch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const ycBatch = __AgencyFunction.create({
  name: "ycBatch",
  module: "stdlib/data/tech/yc.agency",
  fn: __ycBatch_impl,
  params: [{
    name: "batch",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "ycBatch",
    description: `Fetch the YC companies in a batch. Returns each company's id, name, one-liner, batch, status,
  stage, team size, industry, tags, and URL. An unknown batch returns a failure.

  @param batch - The YC batch, e.g. "Winter 2025" or "winter-2025"`,
    schema: z.object({ "batch": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __ycIndustry_impl(industry) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["industry"] = industry;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycIndustry", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("industry" in __overrides) {
      industry = __overrides["industry"];
      __stack.args["industry"] = industry;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "ycIndustry",
            args: {
              industry
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::yc", `Fetch YC companies for this industry?`, {
            "op": `industry`,
            "query": __stack.args.industry
          }, "std::data/tech/yc", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycIndustry", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(ycFetch, {
          type: "positional",
          args: [await __call(buildIndustryPath, {
            type: "positional",
            args: [await __call(slugify, {
              type: "positional",
              args: [__stack.args.industry]
            })]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(companiesFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function ycIndustry threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "ycIndustry"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "ycIndustry",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "ycIndustry",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const ycIndustry = __AgencyFunction.create({
  name: "ycIndustry",
  module: "stdlib/data/tech/yc.agency",
  fn: __ycIndustry_impl,
  params: [{
    name: "industry",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "ycIndustry",
    description: `Fetch the YC companies in an industry. Returns each company's profile. An unknown industry
  returns a failure.

  @param industry - The industry, e.g. "fintech" or "Healthcare"`,
    schema: z.object({ "industry": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __ycTag_impl(tag) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["tag"] = tag;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycTag", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("tag" in __overrides) {
      tag = __overrides["tag"];
      __stack.args["tag"] = tag;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "ycTag",
            args: {
              tag
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::yc", `Fetch YC companies for this tag?`, {
            "op": `tag`,
            "query": __stack.args.tag
          }, "std::data/tech/yc", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycTag", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(ycFetch, {
          type: "positional",
          args: [await __call(buildTagPath, {
            type: "positional",
            args: [await __call(slugify, {
              type: "positional",
              args: [__stack.args.tag]
            })]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(companiesFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function ycTag threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "ycTag"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "ycTag",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "ycTag",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const ycTag = __AgencyFunction.create({
  name: "ycTag",
  module: "stdlib/data/tech/yc.agency",
  fn: __ycTag_impl,
  params: [{
    name: "tag",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "ycTag",
    description: `Fetch the YC companies with a tag. Returns each company's profile. An unknown tag returns a
  failure.

  @param tag - The tag, e.g. "ai" or "SaaS"`,
    schema: z.object({ "tag": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __ycList_impl(list = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["list"] = list === __UNSET ? `top` : list;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycList", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("list" in __overrides) {
      list = __overrides["list"];
      __stack.args["list"] = list;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "ycList",
            args: {
              list
            },
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.nameResult = await __call(parseListName, {
          type: "positional",
          args: [__stack.args.list]
        });
        if (hasInterrupts(__stack.locals.nameResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.nameResult);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.nameResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.msg = __stack.locals.nameResult.error;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(__stack.locals.msg, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "ycList", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.name = __stack.locals.nameResult.value;
      });
      await runner.step(4, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_4);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::yc", `Fetch this YC company list?`, {
            "op": `list`,
            "query": __stack.args.list
          }, "std::data/tech/yc", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_4 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycList", stepPath: "4" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.result = await __call(ycFetch, {
          type: "positional",
          args: [await __call(buildListPath, {
            type: "positional",
            args: [__stack.locals.name]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(companiesFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function ycList threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "ycList"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "ycList",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "ycList",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const ycList = __AgencyFunction.create({
  name: "ycList",
  module: "stdlib/data/tech/yc.agency",
  fn: __ycList_impl,
  params: [{
    name: "list",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "ycList",
    description: `Fetch a curated YC company list: "top", "all", "hiring", "nonprofit", "women-founded",
  "black-founded", or "hispanic-latino-founded". "all" is large (~6 MB); prefer a batch, industry,
  or tag slice when you can.

  @param list - The curated list name`,
    schema: z.object({ "list": z.string().nullable().describe("Default: top") })
  },
  exported: true
}, __toolRegistry);
async function __ycMeta_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/yc.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycMeta", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "ycMeta",
            args: {},
            moduleId: "stdlib/data/tech/yc.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::yc", `Fetch the YC directory metadata?`, {
            "op": `meta`,
            "query": ``
          }, "std::data/tech/yc", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/tech/yc.agency", scopeName: "ycMeta", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(ycFetch, {
          type: "positional",
          args: [await __call(buildMetaPath, {
            type: "positional",
            args: []
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(metaFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function ycMeta threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "ycMeta"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "ycMeta",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "ycMeta",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const ycMeta = __AgencyFunction.create({
  name: "ycMeta",
  module: "stdlib/data/tech/yc.agency",
  fn: __ycMeta_impl,
  params: [],
  toolDefinition: {
    name: "ycMeta",
    description: `Fetch the YC directory metadata: the available batch, industry, and tag slugs plus the
  last-updated timestamp. Use it to discover the newest batch slug before calling ycBatch.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/data/tech/yc.agency:slugify": { "1": { "line": 71, "col": 2 } }, "stdlib/data/tech/yc.agency:ycListsList": { "1": { "line": 76, "col": 2 } }, "stdlib/data/tech/yc.agency:parseListName": { "1": { "line": 81, "col": 2 }, "2": { "line": 82, "col": 2 }, "3": { "line": 85, "col": 2 }, "2.0": { "line": 83, "col": 4 } }, "stdlib/data/tech/yc.agency:buildBatchPath": { "1": { "line": 90, "col": 2 } }, "stdlib/data/tech/yc.agency:buildIndustryPath": { "1": { "line": 95, "col": 2 } }, "stdlib/data/tech/yc.agency:buildTagPath": { "1": { "line": 100, "col": 2 } }, "stdlib/data/tech/yc.agency:buildListPath": { "1": { "line": 105, "col": 2 } }, "stdlib/data/tech/yc.agency:buildMetaPath": { "1": { "line": 110, "col": 2 } }, "stdlib/data/tech/yc.agency:parseCompanies": { "1": { "line": 115, "col": 2 }, "2": { "line": 116, "col": 2 } }, "stdlib/data/tech/yc.agency:__block_0": { "2.0": { "line": 117, "col": 4 }, "2.1": { "line": 118, "col": 4 } }, "stdlib/data/tech/yc.agency:parseMeta": { "1": { "line": 146, "col": 2 }, "2": { "line": 147, "col": 2 } }, "stdlib/data/tech/yc.agency:ycError": { "1": { "line": 157, "col": 2 } }, "stdlib/data/tech/yc.agency:companiesFinalize": { "1": { "line": 162, "col": 9 }, "2": { "line": 162, "col": 9 }, "3": { "line": 162, "col": 2 }, "2.0": { "line": 162, "col": 9 }, "2.1": { "line": 163, "col": 21 }, "2.2": { "line": 163, "col": 21 }, "2.3": { "line": 162, "col": 9 }, "2.4": { "line": 164, "col": 20 }, "2.5": { "line": 164, "col": 20 } }, "stdlib/data/tech/yc.agency:metaFinalize": { "1": { "line": 170, "col": 9 }, "2": { "line": 170, "col": 9 }, "3": { "line": 170, "col": 2 }, "2.0": { "line": 170, "col": 9 }, "2.1": { "line": 171, "col": 21 }, "2.2": { "line": 171, "col": 21 }, "2.3": { "line": 170, "col": 9 }, "2.4": { "line": 172, "col": 20 }, "2.5": { "line": 172, "col": 20 } }, "stdlib/data/tech/yc.agency:ycFetch": { "1": { "line": 181, "col": 2 }, "1.0": { "line": 182, "col": 4 } }, "stdlib/data/tech/yc.agency:ycBatch": { "1": { "line": 197, "col": 2 }, "2": { "line": 198, "col": 2 }, "3": { "line": 199, "col": 2 } }, "stdlib/data/tech/yc.agency:ycIndustry": { "1": { "line": 209, "col": 2 }, "2": { "line": 210, "col": 2 }, "3": { "line": 211, "col": 2 } }, "stdlib/data/tech/yc.agency:ycTag": { "1": { "line": 221, "col": 2 }, "2": { "line": 222, "col": 2 }, "3": { "line": 223, "col": 2 } }, "stdlib/data/tech/yc.agency:ycList": { "1": { "line": 234, "col": 2 }, "2": { "line": 235, "col": 2 }, "3": { "line": 238, "col": 2 }, "4": { "line": 239, "col": 2 }, "5": { "line": 240, "col": 2 }, "6": { "line": 241, "col": 2 }, "2.0": { "line": 235, "col": 2 }, "2.1": { "line": 236, "col": 4 } }, "stdlib/data/tech/yc.agency:ycMeta": { "1": { "line": 249, "col": 2 }, "2": { "line": 250, "col": 2 }, "3": { "line": 251, "col": 2 } } };
export {
  Company,
  YcMeta,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  buildBatchPath,
  buildIndustryPath,
  buildListPath,
  buildMetaPath,
  buildTagPath,
  companiesFinalize,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  metaFinalize,
  parseCompanies,
  parseListName,
  parseMeta,
  reject,
  respondToInterrupts,
  rewindFrom,
  slugify,
  ycBatch,
  ycError,
  ycFetch,
  ycIndustry,
  ycList,
  ycListsList,
  ycMeta,
  ycTag
};
