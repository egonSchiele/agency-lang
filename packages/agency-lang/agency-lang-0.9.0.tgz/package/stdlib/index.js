import { _callback } from "agency-lang/stdlib-lib/agency.js";
import { _print, _read, _write, _writeBinary, _readBinary, _range, _input, _sleep, _pairsOf as _pairsOfImpl } from "agency-lang/stdlib-lib/builtins.js";
import { _resolve } from "agency-lang/stdlib-lib/path.js";
import { syntaxHighlight as _syntaxHighlight } from "agency-lang/stdlib-lib/syntax.js";
import { _saveDraft, _pushGuard, _runGuarded, _popGuard } from "agency-lang/stdlib-lib/thread.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __tryCall,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/index.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/index.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/index.agency");
  __ctx.globals.set("stdlib/index.agency", "_agentCwd", ``);
}
__registerGlobalsInit("stdlib/index.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/index.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const WriteMode = z.union([z.literal("overwrite"), z.literal("append"), z.literal("create-only")]);
async function __print_impl(messages) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["messages"] = messages;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "print", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("messages" in __overrides) {
      messages = __overrides["messages"];
      __stack.args["messages"] = messages;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "print",
            args: {
              messages
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __funcResult = await __call(_print, {
          type: "positional",
          args: [...__stack.args.messages]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "print"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`Message printed.`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "print");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function print threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "print"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "print",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "print",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const print = __AgencyFunction.create({
  name: "print",
  module: "stdlib/index.agency",
  fn: __print_impl,
  params: [{
    name: "messages",
    hasDefault: false,
    defaultValue: void 0,
    variadic: true,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "print",
    description: `Print a message to the console.

  @param messages - The values to print`,
    schema: z.object({ "messages": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __setAgentCwd_impl(dir) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "setAgentCwd", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "setAgentCwd",
            args: {
              dir
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __globals().set("stdlib/index.agency", "_agentCwd", __stack.args.dir);
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "setAgentCwd");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function setAgentCwd threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "setAgentCwd"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "setAgentCwd",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "setAgentCwd",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const setAgentCwd = __AgencyFunction.create({
  name: "setAgentCwd",
  module: "stdlib/index.agency",
  fn: __setAgentCwd_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "setAgentCwd",
    description: `Set the working directory that path-taking tools resolve relative paths against.

  @param dir - The absolute directory to use as the agent working directory`,
    schema: z.object({ "dir": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __getAgentCwd_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "getAgentCwd", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getAgentCwd",
            args: {},
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__globals().get("stdlib/index.agency", "_agentCwd"));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "getAgentCwd");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getAgentCwd threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getAgentCwd"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getAgentCwd",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getAgentCwd",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getAgentCwd = __AgencyFunction.create({
  name: "getAgentCwd",
  module: "stdlib/index.agency",
  fn: __getAgentCwd_impl,
  params: [],
  toolDefinition: {
    name: "getAgentCwd",
    description: `Return the agent working directory, or an empty string if none is set.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __applyAgentCwd_impl(dir) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "applyAgentCwd", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "applyAgentCwd",
            args: {
              dir
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.base = await __call(getAgentCwd, {
          type: "positional",
          args: []
        });
        if (hasInterrupts(__stack.locals.base)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.base);
          return;
        }
        if (isAborted(__stack.locals.base)) {
          runner2.halt(__stack.locals.base.carryThrough(__stack, "applyAgentCwd"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => __eq(__stack.locals.base, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.args.dir);
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_resolve, {
          type: "positional",
          args: [[__stack.locals.base, __stack.args.dir]]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "applyAgentCwd");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function applyAgentCwd threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "applyAgentCwd"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "applyAgentCwd",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "applyAgentCwd",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const applyAgentCwd = __AgencyFunction.create({
  name: "applyAgentCwd",
  module: "stdlib/index.agency",
  fn: __applyAgentCwd_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "applyAgentCwd",
    description: "No description provided.",
    schema: z.object({ "dir": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __printJSON_impl(obj, highlight = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["obj"] = obj;
  __stack.args["highlight"] = highlight === __UNSET ? false : highlight;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "printJSON", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("obj" in __overrides) {
      obj = __overrides["obj"];
      __stack.args["obj"] = obj;
    }
    if ("highlight" in __overrides) {
      highlight = __overrides["highlight"];
      __stack.args["highlight"] = highlight;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "printJSON",
            args: {
              obj,
              highlight
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.highlight,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(_print, {
                type: "positional",
                args: [await __call(_syntaxHighlight, {
                  type: "positional",
                  args: [await __callMethod(JSON, "stringify", {
                    type: "positional",
                    args: [__stack.args.obj, null, 2]
                  }), `json`]
                })]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "printJSON"));
                return;
              }
            });
          }
        }
      ], async (runner2) => {
        await runner2.step(1, async (runner3) => {
          const __funcResult = await __call(_print, {
            type: "positional",
            args: [await __callMethod(JSON, "stringify", {
              type: "positional",
              args: [__stack.args.obj, null, 2]
            })]
          });
          if (hasInterrupts(__funcResult)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__funcResult);
            return;
          }
          if (isAborted(__funcResult)) {
            runner3.halt(__funcResult.carryThrough(__stack, "printJSON"));
            return;
          }
        });
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`JSON printed.`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "printJSON");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function printJSON threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "printJSON"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "printJSON",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "printJSON",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const printJSON = __AgencyFunction.create({
  name: "printJSON",
  module: "stdlib/index.agency",
  fn: __printJSON_impl,
  params: [{
    name: "obj",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "highlight",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "printJSON",
    description: `Print an object as formatted JSON to the console.

  @param obj - The object to print
  @param highlight - Whether to syntax-highlight the output`,
    schema: z.object({ "obj": z.any(), "highlight": z.boolean().nullable().describe("Default: false") })
  },
  exported: true
}, __toolRegistry);
async function __input_impl(prompt) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["prompt"] = prompt;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "input", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("prompt" in __overrides) {
      prompt = __overrides["prompt"];
      __stack.args["prompt"] = prompt;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "input",
            args: {
              prompt
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_input, {
          type: "positional",
          args: [__stack.args.prompt]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "input");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function input threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "input"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "input",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "input",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const input = __AgencyFunction.create({
  name: "input",
  module: "stdlib/index.agency",
  fn: __input_impl,
  params: [{
    name: "prompt",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "input",
    description: `Prompt the user for input and return their response.

  @param prompt - The message to show the user`,
    schema: z.object({ "prompt": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __sleep_impl(ms) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["ms"] = ms;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "sleep", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("ms" in __overrides) {
      ms = __overrides["ms"];
      __stack.args["ms"] = ms;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "sleep",
            args: {
              ms
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __funcResult = await __call(_sleep, {
          type: "positional",
          args: [__stack.args.ms]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "sleep"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "sleep");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function sleep threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "sleep"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "sleep",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "sleep",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const sleep = __AgencyFunction.create({
  name: "sleep",
  module: "stdlib/index.agency",
  fn: __sleep_impl,
  params: [{
    name: "ms",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "sleep",
    description: `Pause execution for the given duration in milliseconds.

  @param ms - The number of milliseconds to pause`,
    schema: z.object({ "ms": z.number() })
  },
  exported: true
}, __toolRegistry);
async function __saveDraft_impl(value) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["value"] = value;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "saveDraft", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("value" in __overrides) {
      value = __overrides["value"];
      __stack.args["value"] = value;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "saveDraft",
            args: {
              value
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __funcResult = await __call(_saveDraft, {
          type: "positional",
          args: [__stack.args.value]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "saveDraft"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "saveDraft");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function saveDraft threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "saveDraft"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "saveDraft",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "saveDraft",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const saveDraft = __AgencyFunction.create({
  name: "saveDraft",
  module: "stdlib/index.agency",
  fn: __saveDraft_impl,
  params: [{
    name: "value",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "saveDraft",
    description: `Record a best-so-far value for the current function or guarded block. If an
  enclosing \`guard(...)\` trips before this scope returns, the guard yields the
  last saved draft instead of a failure \u2014 an "anytime" result you can always
  fall back to. Call it repeatedly as your result improves; the last value
  wins. With no enclosing guard it is a harmless no-op. Calling it at module
  top level is an error: there is no enclosing scope to save a draft for.

  The value is type-checked against the enclosing scope's return type \u2014 a
  function/node body, or a \`guard\` block (whose return type is inferred from its
  \`return\`).

  @param value - The best-so-far value. Should match the enclosing scope's return type.`,
    schema: z.object({ "value": z.any() })
  },
  exported: true
}, __toolRegistry);
async function __read_impl(filename, dir = __UNSET, offset = __UNSET, limit = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["filename"] = filename;
  __stack.args["dir"] = dir === __UNSET ? `.` : dir;
  __stack.args["offset"] = offset === __UNSET ? 0 : offset;
  __stack.args["limit"] = limit === __UNSET ? 0 : limit;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "read", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("offset" in __overrides) {
      offset = __overrides["offset"];
      __stack.args["offset"] = offset;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "read",
            args: {
              filename,
              dir,
              offset,
              limit,
              useAgentCwd
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.dir = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dir]
              });
              if (hasInterrupts(__stack.args.dir)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dir);
                return;
              }
              if (isAborted(__stack.args.dir)) {
                runner3.halt(__stack.args.dir.carryThrough(__stack, "read"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::read", `Are you sure you want to read this file?`, {
            "dir": __stack.args.dir,
            "filename": __stack.args.filename,
            "offset": __stack.args.offset,
            "limit": __stack.args.limit
          }, "std::index", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/index.agency", scopeName: "read", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_read, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.filename, __stack.args.offset, __stack.args.limit]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "read",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "read");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function read threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "read"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "read",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "read",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const read = __AgencyFunction.create({
  name: "read",
  module: "stdlib/index.agency",
  fn: __read_impl,
  params: [{
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "offset",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "read",
    description: `Read the contents of a file and return it as a string.

  @param filename - The file to read
  @param dir - The directory to resolve the filename against (defaults to ".")
  @param offset - 1-indexed line to start at (0 means start of file)
  @param limit - Maximum number of lines to return (0 means read to end of file)
  @param useAgentCwd - Resolve relative paths against the agent working directory instead of dir`,
    schema: z.object({ "filename": z.string(), "dir": z.string().nullable().describe("Default: ."), "offset": z.number().nullable().describe("Default: 0"), "limit": z.number().nullable().describe("Default: 0"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __write_impl(filename, content, dir = __UNSET, mode = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["filename"] = filename;
  __stack.args["content"] = content;
  __stack.args["dir"] = dir === __UNSET ? `.` : dir;
  __stack.args["mode"] = mode === __UNSET ? `overwrite` : mode;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "write", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("content" in __overrides) {
      content = __overrides["content"];
      __stack.args["content"] = content;
    }
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("mode" in __overrides) {
      mode = __overrides["mode"];
      __stack.args["mode"] = mode;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "write",
            args: {
              filename,
              content,
              dir,
              mode,
              useAgentCwd
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.dir = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dir]
              });
              if (hasInterrupts(__stack.args.dir)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dir);
                return;
              }
              if (isAborted(__stack.args.dir)) {
                runner3.halt(__stack.args.dir.carryThrough(__stack, "write"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::write", `Are you sure you want to write to this file?`, {
            "dir": __stack.args.dir,
            "filename": __stack.args.filename,
            "content": __stack.args.content,
            "mode": __stack.args.mode
          }, "std::index", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/index.agency", scopeName: "write", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_write, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.filename, __stack.args.content, __stack.args.mode]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "write",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "write");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function write threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "write"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "write",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "write",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const write = __AgencyFunction.create({
  name: "write",
  module: "stdlib/index.agency",
  fn: __write_impl,
  params: [{
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "content",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "mode",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "write",
    description: `Write content to a file.

  @param filename - The file to write
  @param content - The content to write
  @param dir - The directory to resolve the filename against (defaults to ".")
  @param mode - How to handle an existing file
  @param useAgentCwd - Resolve relative paths against the agent working directory instead of dir`,
    schema: z.object({ "filename": z.string(), "content": z.string(), "dir": z.string().nullable().describe("Default: ."), "mode": WriteMode.nullable().describe("Default: overwrite"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __writeBinary_impl(filename, base64, dir = __UNSET, mode = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["filename"] = filename;
  __stack.args["base64"] = base64;
  __stack.args["dir"] = dir === __UNSET ? `.` : dir;
  __stack.args["mode"] = mode === __UNSET ? `overwrite` : mode;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "writeBinary", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("base64" in __overrides) {
      base64 = __overrides["base64"];
      __stack.args["base64"] = base64;
    }
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("mode" in __overrides) {
      mode = __overrides["mode"];
      __stack.args["mode"] = mode;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "writeBinary",
            args: {
              filename,
              base64,
              dir,
              mode,
              useAgentCwd
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.dir = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dir]
              });
              if (hasInterrupts(__stack.args.dir)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dir);
                return;
              }
              if (isAborted(__stack.args.dir)) {
                runner3.halt(__stack.args.dir.carryThrough(__stack, "writeBinary"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::writeBinary", `Are you sure you want to write this file?`, {
            "dir": __stack.args.dir,
            "filename": __stack.args.filename,
            "mode": __stack.args.mode
          }, "std::index", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/index.agency", scopeName: "writeBinary", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_writeBinary, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.filename, __stack.args.base64, __stack.args.mode]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "writeBinary",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "writeBinary");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function writeBinary threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "writeBinary"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "writeBinary",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "writeBinary",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const writeBinary = __AgencyFunction.create({
  name: "writeBinary",
  module: "stdlib/index.agency",
  fn: __writeBinary_impl,
  params: [{
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "base64",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "mode",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "writeBinary",
    description: `Write base64-encoded binary data to a file: images, audio, video, PDFs, or any
  binary. Decodes the base64 and writes raw bytes rather than UTF-8 text.

  @param filename - The file to write
  @param base64 - The binary content, base64-encoded
  @param dir - The directory to resolve the filename against (defaults to ".")
  @param mode - How to handle an existing file
  @param useAgentCwd - Resolve relative paths against the agent working directory instead of dir`,
    schema: z.object({ "filename": z.string(), "base64": z.string(), "dir": z.string().nullable().describe("Default: ."), "mode": WriteMode.nullable().describe("Default: overwrite"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __readBinary_impl(filename, dir = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["filename"] = filename;
  __stack.args["dir"] = dir === __UNSET ? `.` : dir;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "readBinary", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "readBinary",
            args: {
              filename,
              dir,
              useAgentCwd
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.dir = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dir]
              });
              if (hasInterrupts(__stack.args.dir)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dir);
                return;
              }
              if (isAborted(__stack.args.dir)) {
                runner3.halt(__stack.args.dir.carryThrough(__stack, "readBinary"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::readBinary", `Are you sure you want to read this file?`, {
            "dir": __stack.args.dir,
            "filename": __stack.args.filename
          }, "std::index", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/index.agency", scopeName: "readBinary", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_readBinary, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.filename]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "readBinary",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "readBinary");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function readBinary threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "readBinary"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "readBinary",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "readBinary",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const readBinary = __AgencyFunction.create({
  name: "readBinary",
  module: "stdlib/index.agency",
  fn: __readBinary_impl,
  params: [{
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "readBinary",
    description: `Read a file and return its contents as a Base64-encoded string. Works for any
  binary file: images, audio, video, PDFs.

  @param filename - The file to read
  @param dir - The directory to resolve the filename against (defaults to ".")
  @param useAgentCwd - Resolve relative paths against the agent working directory instead of dir`,
    schema: z.object({ "filename": z.string(), "dir": z.string().nullable().describe("Default: ."), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __range_impl(start, end = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["start"] = start;
  __stack.args["end"] = end === __UNSET ? -1 : end;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "range", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("start" in __overrides) {
      start = __overrides["start"];
      __stack.args["start"] = start;
    }
    if ("end" in __overrides) {
      end = __overrides["end"];
      __stack.args["end"] = end;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "range",
            args: {
              start,
              end
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.end, -1),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await __call(_range, {
                type: "positional",
                args: [__stack.args.start]
              }));
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_range, {
          type: "positional",
          args: [__stack.args.start, __stack.args.end]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "range");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function range threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "range"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "range",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "range",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const range = __AgencyFunction.create({
  name: "range",
  module: "stdlib/index.agency",
  fn: __range_impl,
  params: [{
    name: "start",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "end",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "range",
    description: `Generate an array of numbers. With one argument, counts from 0 to start-1;
  with two, from start to end-1.

  @param start - The count with one argument, or the starting number with two
  @param end - The exclusive end number (omit to count up from 0)`,
    schema: z.object({ "start": z.number(), "end": z.number().nullable().describe("Default: -1") })
  },
  exported: true
}, __toolRegistry);
async function __map_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "map", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "map",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.newArr = [];
      });
      await runner.loop(2, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          await __callMethod(__stack.locals.newArr, "push", {
            type: "positional",
            args: [await __call(__stack.args.func, {
              type: "positional",
              args: [item]
            })]
          });
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.newArr);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "map");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function map threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "map"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "map",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "map",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const map = __AgencyFunction.create({
  name: "map",
  module: "stdlib/index.agency",
  fn: __map_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "map",
    description: `Map a function over an array, returning a new array of results.

  @param arr - The array to map over
  @param func - The mapping function`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function ___pairsOf_impl(src) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["src"] = src;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "_pairsOf", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("src" in __overrides) {
      src = __overrides["src"];
      __stack.args["src"] = src;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_pairsOf",
            args: {
              src
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_pairsOfImpl, {
          type: "positional",
          args: [__stack.args.src]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_pairsOf");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _pairsOf threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_pairsOf"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_pairsOf",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_pairsOf",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _pairsOf = __AgencyFunction.create({
  name: "_pairsOf",
  module: "stdlib/index.agency",
  fn: ___pairsOf_impl,
  params: [{
    name: "src",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "_pairsOf",
    description: `Internal: the lowering target for two-binder list comprehensions - use
  a comprehension, not this function. Returns pairs in binder order,
  matching the \`for\` loop: arrays give [item, index], objects give
  [key, value], and anything else gives an empty array.

  @param src - An array, an object, or anything else`,
    schema: z.object({ "src": z.any() })
  },
  exported: true
}, __toolRegistry);
async function __mapWithIndex_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "mapWithIndex", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "mapWithIndex",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(map, {
          type: "named",
          positionalArgs: [await __call(_pairsOf, {
            type: "positional",
            args: [__stack.args.arr]
          })],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/index.agency", fn: async (pair) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["pair"] = pair;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/index.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(await __call(__stack.args.func, {
                  type: "positional",
                  args: [__nn(__bstack.args.pair[0]), __nn(__bstack.args.pair[1])]
                }));
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_0");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "pair", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "mapWithIndex");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function mapWithIndex threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "mapWithIndex"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "mapWithIndex",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "mapWithIndex",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const mapWithIndex = __AgencyFunction.create({
  name: "mapWithIndex",
  module: "stdlib/index.agency",
  fn: __mapWithIndex_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "mapWithIndex",
    description: `Apply a function to each item of an array along with its index, and
  return a new array of the results.

  @param arr - The array to map over
  @param func - Called with the item and its zero-based index`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __filter_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "filter", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "filter",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.result = [];
      });
      await runner.loop(2, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.ifElse(0, [
          {
            condition: async () => await __call(__stack.args.func, {
              type: "positional",
              args: [item]
            }),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                await __callMethod(__stack.locals.result, "push", {
                  type: "positional",
                  args: [item]
                });
              });
            }
          }
        ]);
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "filter");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function filter threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "filter"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "filter",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "filter",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const filter = __AgencyFunction.create({
  name: "filter",
  module: "stdlib/index.agency",
  fn: __filter_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "filter",
    description: `Return a new array containing only the elements for which the function returns true.

  @param arr - The array to filter
  @param func - The filter function`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __exclude_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "exclude", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "exclude",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.result = [];
      });
      await runner.loop(2, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.ifElse(0, [
          {
            condition: async () => __eq(await __call(__stack.args.func, {
              type: "positional",
              args: [item]
            }), false),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                await __callMethod(__stack.locals.result, "push", {
                  type: "positional",
                  args: [item]
                });
              });
            }
          }
        ]);
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "exclude");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function exclude threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "exclude"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "exclude",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "exclude",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const exclude = __AgencyFunction.create({
  name: "exclude",
  module: "stdlib/index.agency",
  fn: __exclude_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "exclude",
    description: `Return a new array excluding elements for which the function returns true.

  @param arr - The array to filter
  @param func - The exclusion predicate`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __find_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "find", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "find",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.loop(1, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.ifElse(0, [
          {
            condition: async () => await __call(__stack.args.func, {
              type: "positional",
              args: [item]
            }),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(item);
                return;
              });
            }
          }
        ]);
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(null);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "find");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function find threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "find"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "find",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "find",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const find = __AgencyFunction.create({
  name: "find",
  module: "stdlib/index.agency",
  fn: __find_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "find",
    description: `Return the first element for which the function returns true, or null if none match.

  @param arr - The array to search
  @param func - The predicate function`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __findIndex_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "findIndex", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "findIndex",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.loop(1, async () => __stack.args.arr, async (item, index, runner2) => {
        await runner2.ifElse(0, [
          {
            condition: async () => await __call(__stack.args.func, {
              type: "positional",
              args: [item]
            }),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(index);
                return;
              });
            }
          }
        ]);
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(-1);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "findIndex");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function findIndex threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "findIndex"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "findIndex",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "findIndex",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const findIndex = __AgencyFunction.create({
  name: "findIndex",
  module: "stdlib/index.agency",
  fn: __findIndex_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "findIndex",
    description: `Return the index of the first element for which the function returns true, or -1 if none match.

  @param arr - The array to search
  @param func - The predicate function`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __reduce_impl(arr, initial, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["initial"] = initial;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "reduce", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("initial" in __overrides) {
      initial = __overrides["initial"];
      __stack.args["initial"] = initial;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "reduce",
            args: {
              arr,
              initial,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.acc = __stack.args.initial;
      });
      await runner.loop(2, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.acc = await __call(__stack.args.func, {
            type: "positional",
            args: [__stack.locals.acc, item]
          });
          if (hasInterrupts(__stack.locals.acc)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.acc);
            return;
          }
          if (isAborted(__stack.locals.acc)) {
            runner3.halt(__stack.locals.acc.carryThrough(__stack, "reduce"));
            return;
          }
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.acc);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "reduce");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function reduce threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "reduce"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "reduce",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "reduce",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const reduce = __AgencyFunction.create({
  name: "reduce",
  module: "stdlib/index.agency",
  fn: __reduce_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "initial",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "reduce",
    description: `Reduce an array to a single value by applying a function to an accumulator and each element.

  @param arr - The array to reduce
  @param initial - The initial accumulator value
  @param func - The reducer function receiving (accumulator, element)`,
    schema: z.object({ "arr": z.array(z.any()), "initial": z.any() })
  },
  exported: true
}, __toolRegistry);
async function __flatMap_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "flatMap", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "flatMap",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.result = [];
      });
      await runner.loop(2, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.mapped = await __call(__stack.args.func, {
            type: "positional",
            args: [item]
          });
          if (hasInterrupts(__stack.locals.mapped)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.mapped);
            return;
          }
          if (isAborted(__stack.locals.mapped)) {
            runner3.halt(__stack.locals.mapped.carryThrough(__stack, "flatMap"));
            return;
          }
        });
        await runner2.loop(1, async () => __stack.locals.mapped, async (sub, _2, runner3) => {
          await runner3.step(0, async (runner4) => {
            await __callMethod(__stack.locals.result, "push", {
              type: "positional",
              args: [sub]
            });
          });
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "flatMap");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function flatMap threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "flatMap"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "flatMap",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "flatMap",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const flatMap = __AgencyFunction.create({
  name: "flatMap",
  module: "stdlib/index.agency",
  fn: __flatMap_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "flatMap",
    description: `Map a function over an array and flatten the results by one level.

  @param arr - The array to map over
  @param func - The mapping function`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __flatten_impl(arr) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "flatten", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "flatten",
            args: {
              arr
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.result = [];
      });
      await runner.loop(2, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.loop(0, async () => item, async (sub, _2, runner3) => {
          await runner3.step(0, async (runner4) => {
            await __callMethod(__stack.locals.result, "push", {
              type: "positional",
              args: [sub]
            });
          });
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "flatten");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function flatten threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "flatten"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "flatten",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "flatten",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const flatten = __AgencyFunction.create({
  name: "flatten",
  module: "stdlib/index.agency",
  fn: __flatten_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "flatten",
    description: `Flatten an array of arrays by one level.

  @param arr - The array to flatten`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __every_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "every", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "every",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.loop(1, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.ifElse(0, [
          {
            condition: async () => __eq(await __call(__stack.args.func, {
              type: "positional",
              args: [item]
            }), false),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(false);
                return;
              });
            }
          }
        ]);
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(true);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "every");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function every threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "every"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "every",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "every",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const every = __AgencyFunction.create({
  name: "every",
  module: "stdlib/index.agency",
  fn: __every_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "every",
    description: `Return true if the function returns true for every element in the array.

  @param arr - The array to test
  @param func - The predicate function`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __some_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "some", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "some",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.loop(1, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.ifElse(0, [
          {
            condition: async () => await __call(__stack.args.func, {
              type: "positional",
              args: [item]
            }),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(true);
                return;
              });
            }
          }
        ]);
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(false);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "some");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function some threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "some"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "some",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "some",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const some = __AgencyFunction.create({
  name: "some",
  module: "stdlib/index.agency",
  fn: __some_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "some",
    description: `Return true if the function returns true for at least one element in the array.

  @param arr - The array to test
  @param func - The predicate function`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __count_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "count", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "count",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.n = 0;
      });
      await runner.loop(2, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.ifElse(0, [
          {
            condition: async () => await __call(__stack.args.func, {
              type: "positional",
              args: [item]
            }),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.n = __stack.locals.n + 1;
              });
            }
          }
        ]);
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.n);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "count");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function count threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "count"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "count",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "count",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const count = __AgencyFunction.create({
  name: "count",
  module: "stdlib/index.agency",
  fn: __count_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "count",
    description: `Count the number of elements in the array for which the function returns true.

  @param arr - The array to count in
  @param func - The predicate function`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __sortBy_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "sortBy", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "sortBy",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.result = [];
      });
      await runner.loop(2, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          await __callMethod(__stack.locals.result, "push", {
            type: "positional",
            args: [item]
          });
        });
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.i = 0;
      });
      await runner.whileLoop(4, async () => __stack.locals.i < __stack.locals.result.length, async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.j = __stack.locals.i + 1;
        });
        await runner2.whileLoop(1, async () => __stack.locals.j < __stack.locals.result.length, async (runner3) => {
          await runner3.ifElse(0, [
            {
              condition: async () => await __call(__stack.args.func, {
                type: "positional",
                args: [__nn(__stack.locals.result[__stack.locals.j])]
              }) < await __call(__stack.args.func, {
                type: "positional",
                args: [__nn(__stack.locals.result[__stack.locals.i])]
              }),
              body: async (runner4) => {
                await runner4.step(0, async (runner5) => {
                  __stack.locals.temp = __nn(__stack.locals.result[__stack.locals.i]);
                });
                await runner4.step(1, async (runner5) => {
                  __stack.locals.result[__stack.locals.i] = __nn(__stack.locals.result[__stack.locals.j]);
                });
                await runner4.step(2, async (runner5) => {
                  __stack.locals.result[__stack.locals.j] = __stack.locals.temp;
                });
              }
            }
          ]);
          await runner3.step(1, async (runner4) => {
            __stack.locals.j = __stack.locals.j + 1;
          });
        });
        await runner2.step(2, async (runner3) => {
          __stack.locals.i = __stack.locals.i + 1;
        });
      });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "sortBy");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function sortBy threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "sortBy"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "sortBy",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "sortBy",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const sortBy = __AgencyFunction.create({
  name: "sortBy",
  module: "stdlib/index.agency",
  fn: __sortBy_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "sortBy",
    description: `Return a new array sorted by the values returned by the function, in ascending order.

  @param arr - The array to sort
  @param func - The sort-key function`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __unique_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "unique", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "unique",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.result = [];
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.seen = [];
      });
      await runner.loop(3, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.key = await __call(__stack.args.func, {
            type: "positional",
            args: [item]
          });
          if (hasInterrupts(__stack.locals.key)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.key);
            return;
          }
          if (isAborted(__stack.locals.key)) {
            runner3.halt(__stack.locals.key.carryThrough(__stack, "unique"));
            return;
          }
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.found = false;
        });
        await runner2.loop(2, async () => __stack.locals.seen, async (s, _2, runner3) => {
          await runner3.ifElse(0, [
            {
              condition: async () => __eq(s, __stack.locals.key),
              body: async (runner4) => {
                await runner4.step(0, async (runner5) => {
                  __stack.locals.found = true;
                });
              }
            }
          ]);
        });
        await runner2.ifElse(3, [
          {
            condition: async () => __eq(__stack.locals.found, false),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                await __callMethod(__stack.locals.result, "push", {
                  type: "positional",
                  args: [item]
                });
              });
              await runner3.step(1, async (runner4) => {
                await __callMethod(__stack.locals.seen, "push", {
                  type: "positional",
                  args: [__stack.locals.key]
                });
              });
            }
          }
        ]);
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "unique");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function unique threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "unique"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "unique",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "unique",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const unique = __AgencyFunction.create({
  name: "unique",
  module: "stdlib/index.agency",
  fn: __unique_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "unique",
    description: `Return a new array with duplicate elements removed, using the function to determine the identity of each element.

  @param arr - The array to deduplicate
  @param func - The identity-key function`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __groupBy_impl(arr, func) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["arr"] = arr;
  __stack.args["func"] = func;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "groupBy", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("arr" in __overrides) {
      arr = __overrides["arr"];
      __stack.args["arr"] = arr;
    }
    if ("func" in __overrides) {
      func = __overrides["func"];
      __stack.args["func"] = func;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "groupBy",
            args: {
              arr,
              func
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.groups = await __callMethod(Object, "create", {
          type: "positional",
          args: [null]
        });
      });
      await runner.loop(3, async () => __stack.args.arr, async (item, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.key = await __call(__stack.args.func, {
            type: "positional",
            args: [item]
          });
          if (hasInterrupts(__stack.locals.key)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.key);
            return;
          }
          if (isAborted(__stack.locals.key)) {
            runner3.halt(__stack.locals.key.carryThrough(__stack, "groupBy"));
            return;
          }
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.groups[__stack.locals.key] ??= [];
        });
        await runner2.step(2, async (runner3) => {
          await __callMethod(__stack.locals.groups[__stack.locals.key], "push", {
            type: "positional",
            args: [item]
          });
        });
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.groups);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "groupBy");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function groupBy threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "groupBy"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "groupBy",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "groupBy",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const groupBy = __AgencyFunction.create({
  name: "groupBy",
  module: "stdlib/index.agency",
  fn: __groupBy_impl,
  params: [{
    name: "arr",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "func",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "groupBy",
    description: `Group elements of an array by the value returned by the function. Returns an object where keys are group names and values are arrays of elements.

  @param arr - The array to group
  @param func - The group-key function`,
    schema: z.object({ "arr": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
async function __callback_impl(name, fn) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["name"] = name;
  __stack.args["fn"] = fn;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "callback", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
    if ("fn" in __overrides) {
      fn = __overrides["fn"];
      __stack.args["fn"] = fn;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "callback",
            args: {
              name,
              fn
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __funcResult = await __call(_callback, {
          type: "positional",
          args: [__stack.args.name, __stack.args.fn]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "callback"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "callback");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function callback threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "callback"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "callback",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "callback",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const callback = __AgencyFunction.create({
  name: "callback",
  module: "stdlib/index.agency",
  fn: __callback_impl,
  params: [{
    name: "name",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fn",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "callback",
    description: `Register a callback for a lifecycle event. A callback registered inside a
  function or node is removed when that returns. One registered at the top
  level stays active for the whole run.

  @param name - The callback hook name, e.g. "onNodeStart", "onFunctionStart", "onLLMCallEnd"
  @param fn - A function that receives the event data`,
    schema: z.object({ "name": z.string(), "fn": z.any() })
  },
  exported: true
}, __toolRegistry);
async function ___guard_impl(cost = __UNSET, time = __UNSET, label = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/index.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cost"] = cost === __UNSET ? null : cost;
  __stack.args["time"] = time === __UNSET ? null : time;
  __stack.args["label"] = label === __UNSET ? null : label;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/index.agency", scopeName: "_guard", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cost" in __overrides) {
      cost = __overrides["cost"];
      __stack.args["cost"] = cost;
    }
    if ("time" in __overrides) {
      time = __overrides["time"];
      __stack.args["time"] = time;
    }
    if ("label" in __overrides) {
      label = __overrides["label"];
      __stack.args["label"] = label;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_guard",
            args: {
              cost,
              time,
              label,
              block
            },
            moduleId: "stdlib/index.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.ids = await __call(_pushGuard, {
          type: "positional",
          args: [__stack.args.cost, __stack.args.time, __stack.args.label]
        });
        if (hasInterrupts(__stack.locals.ids)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.ids);
          return;
        }
        if (isAborted(__stack.locals.ids)) {
          runner2.halt(__stack.locals.ids.carryThrough(__stack, "_guard"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(_runGuarded, {
          type: "positional",
          args: [__stack.locals.ids, __stack.args.block]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "_guard"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        const __funcResult = await __call(_popGuard, {
          type: "positional",
          args: [__stack.locals.ids]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_guard"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_guard");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _guard threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_guard"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_guard",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_guard",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _guard = __AgencyFunction.create({
  name: "_guard",
  module: "stdlib/index.agency",
  fn: ___guard_impl,
  params: [{
    name: "cost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "time",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "label",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_guard",
    description: `Internal: the lowering target of the \`guard(...) { }\` construct \u2014 use
  the construct, not this function. Runs \`block\` under the given cost
  and/or time limits and returns a \`Result\` (see the guards guide).`,
    schema: z.object({ "cost": z.union([z.number(), z.null()]).describe("Default: null"), "time": z.union([z.number(), z.null()]).describe("Default: null"), "label": z.union([z.string(), z.null()]).describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/index.agency:print": { "1": { "line": 58, "col": 2 }, "2": { "line": 59, "col": 2 } }, "stdlib/index.agency:setAgentCwd": { "1": { "line": 87, "col": 2 } }, "stdlib/index.agency:getAgentCwd": { "1": { "line": 94, "col": 2 } }, "stdlib/index.agency:applyAgentCwd": { "1": { "line": 101, "col": 2 }, "2": { "line": 102, "col": 2 }, "3": { "line": 105, "col": 2 }, "2.0": { "line": 103, "col": 4 } }, "stdlib/index.agency:printJSON": { "1": { "line": 115, "col": 2 }, "2": { "line": 120, "col": 2 }, "1.0": { "line": 116, "col": 4 }, "1.1": { "line": 118, "col": 4 } }, "stdlib/index.agency:input": { "1": { "line": 131, "col": 2 } }, "stdlib/index.agency:sleep": { "1": { "line": 142, "col": 2 } }, "stdlib/index.agency:saveDraft": { "1": { "line": 160, "col": 2 } }, "stdlib/index.agency:read": { "1": { "line": 179, "col": 2 }, "2": { "line": 182, "col": 2 }, "3": { "line": 188, "col": 2 }, "1.0": { "line": 180, "col": 4 } }, "stdlib/index.agency:write": { "1": { "line": 207, "col": 2 }, "2": { "line": 210, "col": 2 }, "4": { "line": 217, "col": 4 }, "1.0": { "line": 208, "col": 4 } }, "stdlib/index.agency:writeBinary": { "1": { "line": 238, "col": 2 }, "2": { "line": 241, "col": 2 }, "4": { "line": 247, "col": 4 }, "1.0": { "line": 239, "col": 4 } }, "stdlib/index.agency:readBinary": { "1": { "line": 264, "col": 2 }, "2": { "line": 267, "col": 2 }, "3": { "line": 271, "col": 2 }, "1.0": { "line": 265, "col": 4 } }, "stdlib/index.agency:range": { "1": { "line": 282, "col": 2 }, "2": { "line": 285, "col": 2 }, "1.0": { "line": 283, "col": 4 } }, "stdlib/index.agency:map": { "1": { "line": 302, "col": 2 }, "2": { "line": 303, "col": 2 }, "3": { "line": 306, "col": 2 }, "2.0": { "line": 304, "col": 4 } }, "stdlib/index.agency:_pairsOf": { "1": { "line": 318, "col": 2 } }, "stdlib/index.agency:mapWithIndex": { "1": { "line": 329, "col": 2 } }, "stdlib/index.agency:__block_0": { "1.0": { "line": 329, "col": 38 } }, "stdlib/index.agency:filter": { "1": { "line": 339, "col": 2 }, "2": { "line": 340, "col": 2 }, "3": { "line": 345, "col": 2 }, "2.0.0": { "line": 342, "col": 6 }, "2.0": { "line": 341, "col": 4 } }, "stdlib/index.agency:exclude": { "1": { "line": 355, "col": 2 }, "2": { "line": 356, "col": 2 }, "3": { "line": 361, "col": 2 }, "2.0.0": { "line": 358, "col": 6 }, "2.0": { "line": 357, "col": 4 } }, "stdlib/index.agency:find": { "1": { "line": 371, "col": 2 }, "2": { "line": 376, "col": 2 }, "1.0.0": { "line": 373, "col": 6 }, "1.0": { "line": 372, "col": 4 } }, "stdlib/index.agency:findIndex": { "1": { "line": 386, "col": 2 }, "2": { "line": 391, "col": 2 }, "1.0.0": { "line": 388, "col": 6 }, "1.0": { "line": 387, "col": 4 } }, "stdlib/index.agency:reduce": { "1": { "line": 402, "col": 2 }, "2": { "line": 403, "col": 2 }, "3": { "line": 406, "col": 2 }, "2.0": { "line": 404, "col": 4 } }, "stdlib/index.agency:flatMap": { "1": { "line": 416, "col": 2 }, "2": { "line": 417, "col": 2 }, "3": { "line": 423, "col": 2 }, "2.0": { "line": 418, "col": 4 }, "2.1.0": { "line": 420, "col": 6 }, "2.1": { "line": 419, "col": 4 } }, "stdlib/index.agency:flatten": { "1": { "line": 432, "col": 2 }, "2": { "line": 433, "col": 2 }, "3": { "line": 438, "col": 2 }, "2.0.0": { "line": 435, "col": 6 }, "2.0": { "line": 434, "col": 4 } }, "stdlib/index.agency:every": { "1": { "line": 448, "col": 2 }, "2": { "line": 453, "col": 2 }, "1.0.0": { "line": 450, "col": 6 }, "1.0": { "line": 449, "col": 4 } }, "stdlib/index.agency:some": { "1": { "line": 463, "col": 2 }, "2": { "line": 468, "col": 2 }, "1.0.0": { "line": 465, "col": 6 }, "1.0": { "line": 464, "col": 4 } }, "stdlib/index.agency:count": { "1": { "line": 478, "col": 2 }, "2": { "line": 479, "col": 2 }, "3": { "line": 484, "col": 2 }, "2.0.0": { "line": 481, "col": 6 }, "2.0": { "line": 480, "col": 4 } }, "stdlib/index.agency:sortBy": { "1": { "line": 494, "col": 2 }, "2": { "line": 495, "col": 2 }, "3": { "line": 498, "col": 2 }, "4": { "line": 499, "col": 2 }, "5": { "line": 511, "col": 2 }, "2.0": { "line": 496, "col": 4 }, "4.0": { "line": 500, "col": 4 }, "4.1.0.0": { "line": 503, "col": 8 }, "4.1.0.1": { "line": 504, "col": 8 }, "4.1.0.2": { "line": 505, "col": 8 }, "4.1.0": { "line": 502, "col": 6 }, "4.1.1": { "line": 507, "col": 6 }, "4.1": { "line": 501, "col": 4 }, "4.2": { "line": 509, "col": 4 } }, "stdlib/index.agency:unique": { "1": { "line": 521, "col": 2 }, "2": { "line": 522, "col": 2 }, "3": { "line": 523, "col": 2 }, "4": { "line": 536, "col": 2 }, "3.0": { "line": 524, "col": 4 }, "3.1": { "line": 525, "col": 4 }, "3.2.0.0": { "line": 528, "col": 8 }, "3.2.0": { "line": 527, "col": 6 }, "3.2": { "line": 526, "col": 4 }, "3.3.0": { "line": 532, "col": 6 }, "3.3.1": { "line": 533, "col": 6 }, "3.3": { "line": 531, "col": 4 } }, "stdlib/index.agency:groupBy": { "2": { "line": 550, "col": 2 }, "3": { "line": 551, "col": 2 }, "4": { "line": 556, "col": 2 }, "3.0": { "line": 552, "col": 4 }, "3.2": { "line": 554, "col": 4 } }, "stdlib/index.agency:callback": { "1": { "line": 568, "col": 2 } }, "stdlib/index.agency:_guard": { "1": { "line": 605, "col": 2 }, "2": { "line": 606, "col": 2 }, "3": { "line": 607, "col": 2 }, "4": { "line": 608, "col": 2 } } };
export {
  WriteMode,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  _guard,
  _pairsOf,
  applyAgentCwd,
  approve,
  callback,
  count,
  stdin_default as default,
  every,
  exclude,
  filter,
  find,
  findIndex,
  flatMap,
  flatten,
  getAgentCwd,
  groupBy,
  hasInterrupts,
  input,
  interrupt,
  isDebugger,
  isInterrupt,
  map,
  mapWithIndex,
  print,
  printJSON,
  range,
  read,
  readBinary,
  reduce,
  reject,
  respondToInterrupts,
  rewindFrom,
  saveDraft,
  setAgentCwd,
  sleep,
  some,
  sortBy,
  unique,
  write,
  writeBinary
};
