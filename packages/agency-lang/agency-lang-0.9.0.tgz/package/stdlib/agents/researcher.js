import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { feedbackHasErrors, renderFeedback } from "agency-lang/stdlib/agents/lib/feedback.js";
import { hostedSearchTools, searchTools } from "agency-lang/stdlib/agents/lib/search.js";
import { llmOptions, withContext } from "agency-lang/stdlib/agents/lib/shared.js";
import { webTools } from "agency-lang/stdlib/agents/lib/toolkits.js";
import { reviewAgent } from "agency-lang/stdlib/agents/review.js";
import { agentSkill } from "agency-lang/stdlib/skills.js";
import { revise, Critique } from "agency-lang/stdlib/strategy.js";
import { systemMessage, threadIsNew } from "agency-lang/stdlib/thread.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  runPrompt,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __eq,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __threads,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/agents/researcher.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(feedbackHasErrors);
__registerTool(renderFeedback);
__registerTool(hostedSearchTools);
__registerTool(searchTools);
__registerTool(llmOptions);
__registerTool(withContext);
__registerTool(webTools);
__registerTool(reviewAgent);
__registerTool(agentSkill);
__registerTool(revise);
__registerTool(Critique);
__registerTool(systemMessage);
__registerTool(threadIsNew);
let __staticInitPromise = null;
let systemPrompt = __UNINIT_STATIC;
let skills = __UNINIT_STATIC;
let groundingInstruction = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    systemPrompt = __deepFreeze(`You are a research analyst. Answer the task using your source tools.

- Ground every factual claim in a source and cite it.
- If your tools cannot retrieve the needed information, say so plainly. NEVER fabricate sources or facts.`);
    skills = __deepFreeze(await __call(agentSkill, {
      type: "positional",
      args: [`researcher`]
    }));
    groundingInstruction = __deepFreeze(`Judge grounding: error=true if a claim is ungrounded or uncited or the task is not fully answered.`);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    systemPrompt,
    skills,
    groundingInstruction
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/agents/researcher.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/agents/researcher.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/agents/researcher.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/agents/researcher.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/agents/researcher.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
async function __buildTools_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/researcher.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/researcher.agency", scopeName: "buildTools", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildTools",
            args: {},
            moduleId: "stdlib/agents/researcher.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt([...await __call(webTools, {
          type: "positional",
          args: []
        }), await __callMethod(__readStatic(read, "read", ""), "partial", {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            useAgentCwd: true
          }
        }), ...await __call(searchTools, {
          type: "positional",
          args: []
        }), __readStatic(skills, "skills", "stdlib/agents/researcher.agency")]);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildTools");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildTools threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildTools"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildTools",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildTools",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildTools = __AgencyFunction.create({
  name: "buildTools",
  module: "stdlib/agents/researcher.agency",
  fn: __buildTools_impl,
  params: [],
  toolDefinition: {
    name: "buildTools",
    description: `Return the researcher's tools: the encyclopedia and fetch tools that need
  no key, a local file read for material the caller points at, and whichever
  search providers the environment has a key for.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __checkGrounding_impl(task, answer) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/researcher.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["answer"] = answer;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/researcher.agency", scopeName: "checkGrounding", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("answer" in __overrides) {
      answer = __overrides["answer"];
      __stack.args["answer"] = answer;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "checkGrounding",
            args: {
              task,
              answer
            },
            moduleId: "stdlib/agents/researcher.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.reviewed = await __call(reviewAgent, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            work: `${__stack.args.answer}`,
            task: __stack.args.task,
            context: __readStatic(groundingInstruction, "groundingInstruction", "stdlib/agents/researcher.agency"),
            maxCost: 1,
            maxTime: 12e4
          }
        });
        if (hasInterrupts(__stack.locals.reviewed)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.reviewed);
          return;
        }
        if (isAborted(__stack.locals.reviewed)) {
          runner2.halt(__stack.locals.reviewed.carryThrough(__stack, "checkGrounding"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => !await __call(feedbackHasErrors, {
            type: "positional",
            args: [__stack.locals.reviewed]
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                "accepted": true,
                "feedback": ``
              });
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "accepted": false,
          "feedback": `
Your answer has gaps:

${await __call(renderFeedback, {
            type: "positional",
            args: [__stack.locals.reviewed]
          })}

Retrieve more and fix them.
`
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "checkGrounding");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function checkGrounding threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "checkGrounding"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "checkGrounding",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "checkGrounding",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const checkGrounding = __AgencyFunction.create({
  name: "checkGrounding",
  module: "stdlib/agents/researcher.agency",
  fn: __checkGrounding_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "answer",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "checkGrounding",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "answer": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __researchLoop_impl(task, context, maxAttempts, model, provider, extraTools) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/researcher.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["context"] = context;
  __stack.args["maxAttempts"] = maxAttempts;
  __stack.args["model"] = model;
  __stack.args["provider"] = provider;
  __stack.args["extraTools"] = extraTools;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/researcher.agency", scopeName: "researchLoop", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("maxAttempts" in __overrides) {
      maxAttempts = __overrides["maxAttempts"];
      __stack.args["maxAttempts"] = maxAttempts;
    }
    if ("model" in __overrides) {
      model = __overrides["model"];
      __stack.args["model"] = model;
    }
    if ("provider" in __overrides) {
      provider = __overrides["provider"];
      __stack.args["provider"] = provider;
    }
    if ("extraTools" in __overrides) {
      extraTools = __overrides["extraTools"];
      __stack.args["extraTools"] = extraTools;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "researchLoop",
            args: {
              task,
              context,
              maxAttempts,
              model,
              provider,
              extraTools
            },
            moduleId: "stdlib/agents/researcher.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.researchTools = await __call(buildTools, {
          type: "positional",
          args: []
        });
        if (hasInterrupts(__stack.locals.researchTools)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.researchTools);
          return;
        }
        if (isAborted(__stack.locals.researchTools)) {
          runner2.halt(__stack.locals.researchTools.carryThrough(__stack, "researchLoop"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await __call(threadIsNew, {
            type: "positional",
            args: []
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(systemMessage, {
                type: "positional",
                args: [__readStatic(systemPrompt, "systemPrompt", "stdlib/agents/researcher.agency")]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "researchLoop"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.question = await __call(withContext, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            task: __stack.args.task,
            context: __stack.args.context
          }
        });
        if (hasInterrupts(__stack.locals.question)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.question);
          return;
        }
        if (isAborted(__stack.locals.question)) {
          runner2.halt(__stack.locals.question.carryThrough(__stack, "researchLoop"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(revise, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            maxAttempts: __stack.args.maxAttempts,
            check: await __callMethod(checkGrounding, "partial", {
              type: "named",
              positionalArgs: [],
              namedArgs: {
                task: __stack.args.task
              }
            })
          },
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/agents/researcher.agency", fn: async (critique) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["critique"] = critique;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/researcher.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.msg = __bstack.args.critique;
              });
              await runner3.ifElse(1, [
                {
                  condition: async () => __eq(__bstack.args.critique, ``),
                  body: async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      __bstack.locals.msg = __stack.locals.question;
                    });
                  }
                }
              ]);
              await runner3.step(2, async (runner4) => {
                __self2.__removedTools = __self2.__removedTools || [];
                __bstack.locals.answer = await runPrompt({
                  prompt: __bstack.locals.msg,
                  messages: __threads().getOrCreateActive(),
                  clientConfig: await __call(llmOptions, {
                    type: "named",
                    positionalArgs: [],
                    namedArgs: {
                      model: __stack.args.model,
                      provider: __stack.args.provider,
                      tools: await __callMethod(__stack.locals.researchTools, "concat", {
                        type: "positional",
                        args: [__stack.args.extraTools]
                      }),
                      hostedTools: await __call(hostedSearchTools, {
                        type: "positional",
                        args: [__stack.args.model]
                      })
                    }
                  }),
                  draftSchema: z.string(),
                  maxToolCallRounds: 10,
                  removedTools: __self2.__removedTools,
                  destructiveSink: __self2,
                  checkpointInfo: runner4.getCheckpointInfo()
                });
                if (hasInterrupts(__bstack.locals.answer)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__bstack.locals.answer);
                  return;
                }
              });
              await runner3.step(3, async (runner4) => {
                const __funcResult = await __call(saveDraft, {
                  type: "positional",
                  args: [__bstack.locals.answer]
                });
                if (hasInterrupts(__funcResult)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__funcResult);
                  return;
                }
                if (isAborted(__funcResult)) {
                  runner4.halt(__funcResult.carryThrough(__bstack, "__block_0"));
                  return;
                }
              });
              await runner3.step(4, async (runner4) => {
                runner4.halt(__bstack.locals.answer);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_0");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "critique", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "researchLoop");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function researchLoop threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "researchLoop"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "researchLoop",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "researchLoop",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const researchLoop = __AgencyFunction.create({
  name: "researchLoop",
  module: "stdlib/agents/researcher.agency",
  fn: __researchLoop_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxAttempts",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "model",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "provider",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "extraTools",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "researchLoop",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "context": z.string(), "maxAttempts": z.number(), "model": z.string(), "provider": z.string(), "extraTools": z.array(z.any()) })
  },
  exported: false
}, __toolRegistry);
async function __researcherAgent_impl(task, context = __UNSET, maxAttempts = __UNSET, maxCost = __UNSET, maxTime = __UNSET, model = __UNSET, provider = __UNSET, session = __UNSET, extraTools = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/researcher.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["context"] = context === __UNSET ? `` : context;
  __stack.args["maxAttempts"] = maxAttempts === __UNSET ? 2 : maxAttempts;
  __stack.args["maxCost"] = maxCost === __UNSET ? 50 : maxCost;
  __stack.args["maxTime"] = maxTime === __UNSET ? 18e5 : maxTime;
  __stack.args["model"] = model === __UNSET ? `` : model;
  __stack.args["provider"] = provider === __UNSET ? `` : provider;
  __stack.args["session"] = session === __UNSET ? `` : session;
  __stack.args["extraTools"] = extraTools === __UNSET ? [] : extraTools;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/researcher.agency", scopeName: "researcherAgent", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("maxAttempts" in __overrides) {
      maxAttempts = __overrides["maxAttempts"];
      __stack.args["maxAttempts"] = maxAttempts;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
    if ("maxTime" in __overrides) {
      maxTime = __overrides["maxTime"];
      __stack.args["maxTime"] = maxTime;
    }
    if ("model" in __overrides) {
      model = __overrides["model"];
      __stack.args["model"] = model;
    }
    if ("provider" in __overrides) {
      provider = __overrides["provider"];
      __stack.args["provider"] = provider;
    }
    if ("session" in __overrides) {
      session = __overrides["session"];
      __stack.args["session"] = session;
    }
    if ("extraTools" in __overrides) {
      extraTools = __overrides["extraTools"];
      __stack.args["extraTools"] = extraTools;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "researcherAgent",
            args: {
              task,
              context,
              maxAttempts,
              maxCost,
              maxTime,
              model,
              provider,
              session,
              extraTools
            },
            moduleId: "stdlib/agents/researcher.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_guard, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            cost: __stack.args.maxCost,
            time: __stack.args.maxTime
          },
          blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/agents/researcher.agency", fn: async () => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_1 = __bstack;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/researcher.agency", scopeName: "__block_1" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.answer = ``;
              });
              await runner3.thread(1, "create", async () => ({ label: `researcherAgent`, session: __stack.args.session }), async (runner4) => {
                await runner4.step(0, async (runner5) => {
                  __bstack.locals.answer = await __call(researchLoop, {
                    type: "named",
                    positionalArgs: [],
                    namedArgs: {
                      task: __stack.args.task,
                      context: __stack.args.context,
                      maxAttempts: __stack.args.maxAttempts,
                      model: __stack.args.model,
                      provider: __stack.args.provider,
                      extraTools: __stack.args.extraTools
                    }
                  });
                  if (hasInterrupts(__bstack.locals.answer)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__bstack.locals.answer);
                    return;
                  }
                  if (isAborted(__bstack.locals.answer)) {
                    runner5.halt(__bstack.locals.answer.carryThrough(__bstack, "__block_1"));
                    return;
                  }
                });
              });
              await runner3.step(2, async (runner4) => {
                runner4.halt(__bstack.locals.answer);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_1");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "researcherAgent");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function researcherAgent threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "researcherAgent"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "researcherAgent",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "researcherAgent",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const researcherAgent = __AgencyFunction.create({
  name: "researcherAgent",
  module: "stdlib/agents/researcher.agency",
  fn: __researcherAgent_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxAttempts",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxTime",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "model",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "provider",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "session",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "extraTools",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "researcherAgent",
    description: `Answer a research question from web and Wikipedia sources and return a
  cited answer, retrying while a review finds ungrounded claims.

  @param task - The research question
  @param context - Extra material folded into the prompt, or ""
  @param maxAttempts - Answer-and-fix attempts before returning
  @param maxCost - Hard spend cap
  @param maxTime - Hard wall-clock cap
  @param model - Model override, or "" for the ambient model
  @param provider - Provider for the model override
  @param session - Session name to share a thread across calls, or "" for isolated
  @param extraTools - Extra tools to offer the LLM, appended to the built-in set`,
    schema: z.object({ "task": z.string(), "context": z.string().nullable().describe("Default: "), "maxAttempts": z.number().nullable().describe("Default: 2"), "maxCost": z.number().nullable().describe("Default: $50.00"), "maxTime": z.number().nullable().describe("Default: 30m"), "model": z.string().nullable().describe("Default: "), "provider": z.string().nullable().describe("Default: "), "session": z.string().nullable().describe("Default: "), "extraTools": z.array(z.any()).nullable().describe("Default: []") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/agents/researcher.agency:buildTools": { "1": { "line": 30, "col": 2 } }, "stdlib/agents/researcher.agency:checkGrounding": { "1": { "line": 36, "col": 2 }, "2": { "line": 43, "col": 2 }, "3": { "line": 49, "col": 2 }, "2.0": { "line": 44, "col": 4 } }, "stdlib/agents/researcher.agency:researchLoop": { "1": { "line": 69, "col": 2 }, "2": { "line": 70, "col": 2 }, "3": { "line": 73, "col": 2 }, "4": { "line": 74, "col": 2 }, "2.0": { "line": 71, "col": 4 } }, "stdlib/agents/researcher.agency:__block_0": { "4.0": { "line": 76, "col": 4 }, "4.1.0": { "line": 78, "col": 6 }, "4.1": { "line": 77, "col": 4 }, "4.2": { "line": 81, "col": 4 }, "4.3": { "line": 90, "col": 4 }, "4.4": { "line": 91, "col": 4 } }, "stdlib/agents/researcher.agency:researcherAgent": { "1": { "line": 121, "col": 2 } }, "stdlib/agents/researcher.agency:__block_1": { "1.0": { "line": 122, "col": 4 }, "1.1.0": { "line": 124, "col": 6 }, "1.1": { "line": 123, "col": 4 }, "1.2": { "line": 133, "col": 4 } } };
export {
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  buildTools,
  checkGrounding,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  reject,
  researchLoop,
  researcherAgent,
  respondToInterrupts,
  rewindFrom
};
