import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { LayoutNode, Width } from "agency-lang/stdlib/ui/layout.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  __registerGlobalsInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __eq,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/ui/chart.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(LayoutNode);
__registerTool(Width);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/ui/chart.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/ui/chart.agency");
}
__registerGlobalsInit("stdlib/ui/chart.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const BarKey = z.object({ "name": z.string(), "color": z.union([z.string(), z.null()]).optional().default(null), "symbol": z.union([z.string(), z.null()]).optional().default(null) });
const Bar = z.object({ "label": z.string(), "values": z.array(z.number()) });
const BarMode = z.union([z.literal("stacked"), z.literal("grouped")]);
const ChartBuilder = z.object({ "key": z.any(), "bar": z.any() });
async function ___addKey_impl(state, name, color2 = __UNSET, symbol = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/chart.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["name"] = name;
  __stack.args["color"] = color2 === __UNSET ? `` : color2;
  __stack.args["symbol"] = symbol === __UNSET ? `` : symbol;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/chart.agency", scopeName: "_addKey", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
    if ("color" in __overrides) {
      color2 = __overrides["color"];
      __stack.args["color"] = color2;
    }
    if ("symbol" in __overrides) {
      symbol = __overrides["symbol"];
      __stack.args["symbol"] = symbol;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addKey",
            args: {
              state,
              name,
              color: color2,
              symbol
            },
            moduleId: "stdlib/ui/chart.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.k = {
          "name": __stack.args.name
        };
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.color, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.k.color = __stack.args.color;
            });
          }
        }
      ]);
      await runner.ifElse(3, [
        {
          condition: async () => !__eq(__stack.args.symbol, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.k.symbol = __stack.args.symbol;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        await __callMethod(__stack.args.state.keys, "push", {
          type: "positional",
          args: [__stack.locals.k]
        });
      });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(null);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addKey threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addKey"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addKey",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addKey",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addKey = __AgencyFunction.create({
  name: "_addKey",
  module: "stdlib/ui/chart.agency",
  fn: ___addKey_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "name",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "color",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "symbol",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addKey",
    description: "No description provided.",
    schema: z.object({ "state": z.any(), "name": z.string(), "color": z.string().nullable().describe("Default: "), "symbol": z.string().nullable().describe("Default: ") })
  },
  exported: false
}, __toolRegistry);
async function ___addBar_impl(state, label, values) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/chart.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["label"] = label;
  __stack.args["values"] = values;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/chart.agency", scopeName: "_addBar", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("label" in __overrides) {
      label = __overrides["label"];
      __stack.args["label"] = label;
    }
    if ("values" in __overrides) {
      values = __overrides["values"];
      __stack.args["values"] = values;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addBar",
            args: {
              state,
              label,
              values
            },
            moduleId: "stdlib/ui/chart.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        await __callMethod(__stack.args.state.data, "push", {
          type: "positional",
          args: [{
            "label": __stack.args.label,
            "values": __stack.args.values
          }]
        });
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(null);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addBar threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addBar"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addBar",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addBar",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addBar = __AgencyFunction.create({
  name: "_addBar",
  module: "stdlib/ui/chart.agency",
  fn: ___addBar_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "label",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "values",
    hasDefault: false,
    defaultValue: void 0,
    variadic: true,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addBar",
    description: "No description provided.",
    schema: z.object({ "state": z.any(), "label": z.string(), "values": z.array(z.number()) })
  },
  exported: false
}, __toolRegistry);
async function ___makeChartBuilder_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/chart.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/chart.agency", scopeName: "_makeChartBuilder", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_makeChartBuilder",
            args: {
              state
            },
            moduleId: "stdlib/ui/chart.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "key": await __callMethod(_addKey, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              state: __stack.args.state
            }
          }),
          "bar": await __callMethod(_addBar, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              state: __stack.args.state
            }
          })
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _makeChartBuilder threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_makeChartBuilder"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_makeChartBuilder",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_makeChartBuilder",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _makeChartBuilder = __AgencyFunction.create({
  name: "_makeChartBuilder",
  module: "stdlib/ui/chart.agency",
  fn: ___makeChartBuilder_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "_makeChartBuilder",
    description: "No description provided.",
    schema: z.object({ "state": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __barChart_impl(title = __UNSET, mode = __UNSET, keys = __UNSET, data = __UNSET, showValues = __UNSET, legend = __UNSET, max = __UNSET, barChar = __UNSET, width = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/chart.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["title"] = title === __UNSET ? `` : title;
  __stack.args["mode"] = mode === __UNSET ? `grouped` : mode;
  __stack.args["keys"] = keys === __UNSET ? null : keys;
  __stack.args["data"] = data === __UNSET ? null : data;
  __stack.args["showValues"] = showValues === __UNSET ? true : showValues;
  __stack.args["legend"] = legend === __UNSET ? true : legend;
  __stack.args["max"] = max === __UNSET ? 0 : max;
  __stack.args["barChar"] = barChar === __UNSET ? `\u2588` : barChar;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/chart.agency", scopeName: "barChart", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("title" in __overrides) {
      title = __overrides["title"];
      __stack.args["title"] = title;
    }
    if ("mode" in __overrides) {
      mode = __overrides["mode"];
      __stack.args["mode"] = mode;
    }
    if ("keys" in __overrides) {
      keys = __overrides["keys"];
      __stack.args["keys"] = keys;
    }
    if ("data" in __overrides) {
      data = __overrides["data"];
      __stack.args["data"] = data;
    }
    if ("showValues" in __overrides) {
      showValues = __overrides["showValues"];
      __stack.args["showValues"] = showValues;
    }
    if ("legend" in __overrides) {
      legend = __overrides["legend"];
      __stack.args["legend"] = legend;
    }
    if ("max" in __overrides) {
      max = __overrides["max"];
      __stack.args["max"] = max;
    }
    if ("barChar" in __overrides) {
      barChar = __overrides["barChar"];
      __stack.args["barChar"] = barChar;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "barChart",
            args: {
              title,
              mode,
              keys,
              data,
              showValues,
              legend,
              max,
              barChar,
              width,
              block
            },
            moduleId: "stdlib/ui/chart.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.keysArr = [];
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.keys, null),
          body: async (runner2) => {
            await runner2.loop(0, async () => __stack.args.keys, async (k, _, runner3) => {
              await runner3.step(0, async (runner4) => {
                await __callMethod(__stack.locals.keysArr, "push", {
                  type: "positional",
                  args: [k]
                });
              });
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.dataArr = [];
      });
      await runner.ifElse(4, [
        {
          condition: async () => !__eq(__stack.args.data, null),
          body: async (runner2) => {
            await runner2.loop(0, async () => __stack.args.data, async (d, _, runner3) => {
              await runner3.step(0, async (runner4) => {
                await __callMethod(__stack.locals.dataArr, "push", {
                  type: "positional",
                  args: [d]
                });
              });
            });
          }
        }
      ]);
      await runner.step(5, async (runner2) => {
        __stack.locals.state = {
          "keys": __stack.locals.keysArr,
          "data": __stack.locals.dataArr
        };
      });
      await runner.ifElse(6, [
        {
          condition: async () => !__eq(__stack.args.block, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(__stack.args.block, {
                type: "positional",
                args: [await __call(_makeChartBuilder, {
                  type: "positional",
                  args: [__stack.locals.state]
                })]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
            });
          }
        }
      ]);
      await runner.step(7, async (runner2) => {
        __stack.locals.attrs = {
          "title": __stack.args.title,
          "mode": __stack.args.mode,
          "keys": __stack.locals.state.keys,
          "data": __stack.locals.state.data,
          "showValues": __stack.args.showValues,
          "legend": __stack.args.legend,
          "max": __stack.args.max,
          "barChar": __stack.args.barChar
        };
      });
      await runner.ifElse(8, [
        {
          condition: async () => !__eq(__stack.args.width, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.attrs.width = __stack.args.width;
            });
          }
        }
      ]);
      await runner.step(9, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `barchart`,
          "attrs": __stack.locals.attrs,
          "children": []
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function barChart threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "barChart"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "barChart",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "barChart",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const barChart = __AgencyFunction.create({
  name: "barChart",
  module: "stdlib/ui/chart.agency",
  fn: __barChart_impl,
  params: [{
    name: "title",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "mode",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "keys",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "data",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "showValues",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "legend",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "max",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "barChar",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "barChart",
    description: `Build a horizontal bar chart as a layout node. Pass the data form:
  \`keys\` (one per series) and \`data\` (one entry per category, whose
  \`values\` array lines up with \`keys\` by index). Render the returned
  node to display it.

  @param title - Heading shown above the chart
  @param mode - "grouped" draws one bar per key; "stacked" stacks the keys into one bar
  @param keys - Series definitions. Each key may set a color (a color name like "blue" or a hex string like "#cc7a4a") and a fill symbol. Both auto-assign when omitted
  @param data - Categories to plot. Each has a \`label\` and a positional \`values\` array aligned to \`keys\`
  @param showValues - Show the numeric value beside each bar
  @param legend - Show a legend listing the named keys
  @param max - Fix the axis maximum to a positive number; values beyond it saturate at a full bar. 0 derives it from the data
  @param barChar - Default fill cell for the first / single series
  @param width - Chart width in cells, or "full" / "N%"`,
    schema: z.object({ "title": z.string().nullable().describe("Default: "), "mode": BarMode.nullable().describe("Default: grouped"), "keys": z.array(BarKey).nullable().describe("Default: null"), "data": z.array(Bar).nullable().describe("Default: null"), "showValues": z.boolean().nullable().describe("Default: true"), "legend": z.boolean().nullable().describe("Default: true"), "max": z.number().nullable().describe("Default: 0"), "barChar": z.string().nullable().describe("Default: \u2588"), "width": Width.nullable().describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/ui/chart.agency:_addKey": { "1": { "line": 61, "col": 2 }, "2": { "line": 62, "col": 2 }, "3": { "line": 65, "col": 2 }, "4": { "line": 68, "col": 2 }, "5": { "line": 69, "col": 2 }, "2.0": { "line": 63, "col": 4 }, "3.0": { "line": 66, "col": 4 } }, "stdlib/ui/chart.agency:_addBar": { "1": { "line": 73, "col": 2 }, "2": { "line": 74, "col": 2 } }, "stdlib/ui/chart.agency:_makeChartBuilder": { "1": { "line": 78, "col": 2 } }, "stdlib/ui/chart.agency:barChart": { "1": { "line": 112, "col": 2 }, "2": { "line": 113, "col": 2 }, "3": { "line": 118, "col": 2 }, "4": { "line": 119, "col": 2 }, "5": { "line": 124, "col": 2 }, "6": { "line": 128, "col": 2 }, "7": { "line": 131, "col": 2 }, "8": { "line": 141, "col": 2 }, "9": { "line": 144, "col": 2 }, "2.0.0": { "line": 115, "col": 6 }, "2.0": { "line": 114, "col": 4 }, "4.0.0": { "line": 121, "col": 6 }, "4.0": { "line": 120, "col": 4 }, "6.0": { "line": 129, "col": 4 }, "8.0": { "line": 142, "col": 4 } } };
export {
  Bar,
  BarKey,
  BarMode,
  ChartBuilder,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  _addBar,
  _addKey,
  _makeChartBuilder,
  approve,
  barChart,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  reject,
  respondToInterrupts,
  rewindFrom
};
