import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { _render } from "agency-lang/stdlib-lib/layout.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __eq,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/ui/layout.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/ui/layout.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/ui/layout.agency");
}
__registerGlobalsInit("stdlib/ui/layout.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/ui/layout.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const LayoutNode = z.object({ "type": z.string(), "attrs": z.any(), "children": z.array(z.any()) });
const LayoutBuilder = z.object({ "text": z.any(), "raw": z.any(), "space": z.any(), "hline": z.any(), "vline": z.any(), "row": z.any(), "column": z.any(), "box": z.any() });
const Alignment = z.union([z.literal("start"), z.literal("center"), z.literal("end")]);
const BorderStyle = z.union([z.literal("rounded"), z.literal("heavy"), z.literal("double"), z.literal("light")]);
const Width = z.union([z.number(), z.literal("full"), z.string()]);
async function __text_impl(content, fgColor = __UNSET, bgColor = __UNSET, bold = __UNSET, italic = __UNSET, dim = __UNSET, underline = __UNSET, align = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["content"] = content;
  __stack.args["fgColor"] = fgColor === __UNSET ? `` : fgColor;
  __stack.args["bgColor"] = bgColor === __UNSET ? `` : bgColor;
  __stack.args["bold"] = bold === __UNSET ? false : bold;
  __stack.args["italic"] = italic === __UNSET ? false : italic;
  __stack.args["dim"] = dim === __UNSET ? false : dim;
  __stack.args["underline"] = underline === __UNSET ? false : underline;
  __stack.args["align"] = align === __UNSET ? `start` : align;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "text", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("content" in __overrides) {
      content = __overrides["content"];
      __stack.args["content"] = content;
    }
    if ("fgColor" in __overrides) {
      fgColor = __overrides["fgColor"];
      __stack.args["fgColor"] = fgColor;
    }
    if ("bgColor" in __overrides) {
      bgColor = __overrides["bgColor"];
      __stack.args["bgColor"] = bgColor;
    }
    if ("bold" in __overrides) {
      bold = __overrides["bold"];
      __stack.args["bold"] = bold;
    }
    if ("italic" in __overrides) {
      italic = __overrides["italic"];
      __stack.args["italic"] = italic;
    }
    if ("dim" in __overrides) {
      dim = __overrides["dim"];
      __stack.args["dim"] = dim;
    }
    if ("underline" in __overrides) {
      underline = __overrides["underline"];
      __stack.args["underline"] = underline;
    }
    if ("align" in __overrides) {
      align = __overrides["align"];
      __stack.args["align"] = align;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "text",
            args: {
              content,
              fgColor,
              bgColor,
              bold,
              italic,
              dim,
              underline,
              align
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `text`,
          "attrs": {
            "content": __stack.args.content,
            "fgColor": __stack.args.fgColor,
            "bgColor": __stack.args.bgColor,
            "bold": __stack.args.bold,
            "italic": __stack.args.italic,
            "dim": __stack.args.dim,
            "underline": __stack.args.underline,
            "align": __stack.args.align
          },
          "children": []
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "text");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function text threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "text"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "text",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "text",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const text = __AgencyFunction.create({
  name: "text",
  module: "stdlib/ui/layout.agency",
  fn: __text_impl,
  params: [{
    name: "content",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fgColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bgColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bold",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "italic",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dim",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "underline",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "align",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "text",
    description: `A styled run of text. Newlines split it into multiple lines.

  @param content - The text to display
  @param fgColor - Foreground color, named ("red") or hex ("#cc7a4a")
  @param bgColor - Background color
  @param bold - Use bold weight
  @param italic - Use italic style
  @param dim - Use reduced intensity
  @param underline - Underline the text
  @param align - For multi-line text, how shorter lines align to the longest`,
    schema: z.object({ "content": z.string(), "fgColor": z.string().nullable().describe("Default: "), "bgColor": z.string().nullable().describe("Default: "), "bold": z.boolean().nullable().describe("Default: false"), "italic": z.boolean().nullable().describe("Default: false"), "dim": z.boolean().nullable().describe("Default: false"), "underline": z.boolean().nullable().describe("Default: false"), "align": Alignment.nullable().describe("Default: start") })
  },
  exported: true
}, __toolRegistry);
async function __raw_impl(content, align = __UNSET, wrap = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["content"] = content;
  __stack.args["align"] = align === __UNSET ? `start` : align;
  __stack.args["wrap"] = wrap === __UNSET ? true : wrap;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "raw", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("content" in __overrides) {
      content = __overrides["content"];
      __stack.args["content"] = content;
    }
    if ("align" in __overrides) {
      align = __overrides["align"];
      __stack.args["align"] = align;
    }
    if ("wrap" in __overrides) {
      wrap = __overrides["wrap"];
      __stack.args["wrap"] = wrap;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "raw",
            args: {
              content,
              align,
              wrap
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `raw`,
          "attrs": {
            "content": __stack.args.content,
            "align": __stack.args.align,
            "wrap": __stack.args.wrap
          },
          "children": []
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "raw");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function raw threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "raw"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "raw",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "raw",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const raw = __AgencyFunction.create({
  name: "raw",
  module: "stdlib/ui/layout.agency",
  fn: __raw_impl,
  params: [{
    name: "content",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "align",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "wrap",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "raw",
    description: `A pre-styled string (may carry its own ANSI or newlines). Wraps to the
  container width by default; pass wrap: false to render exactly as-is and
  never reflow (ASCII art, pre-rendered tables).

  @param content - Raw string content (may contain ANSI codes or newlines)
  @param align - For multi-line content, how shorter lines align to the longest
  @param wrap - Reflow to the container width (default true). false preserves the exact layout.`,
    schema: z.object({ "content": z.string(), "align": Alignment.nullable().describe("Default: start"), "wrap": z.boolean().nullable().describe("Default: true") })
  },
  exported: true
}, __toolRegistry);
async function __space_impl(count2 = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["count"] = count2 === __UNSET ? 1 : count2;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "space", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("count" in __overrides) {
      count2 = __overrides["count"];
      __stack.args["count"] = count2;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "space",
            args: {
              count: count2
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `space`,
          "attrs": {
            "count": __stack.args.count
          },
          "children": []
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "space");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function space threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "space"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "space",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "space",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const space = __AgencyFunction.create({
  name: "space",
  module: "stdlib/ui/layout.agency",
  fn: __space_impl,
  params: [{
    name: "count",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "space",
    description: `Blank space. Inside a row it adds columns; inside a column, rows.

  @param count - Number of cells of blank space`,
    schema: z.object({ "count": z.number().nullable().describe("Default: 1") })
  },
  exported: true
}, __toolRegistry);
async function __hline_impl(char = __UNSET, length = __UNSET, fgColor = __UNSET, bold = __UNSET, dim = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["char"] = char === __UNSET ? `\u2500` : char;
  __stack.args["length"] = length === __UNSET ? 0 : length;
  __stack.args["fgColor"] = fgColor === __UNSET ? `` : fgColor;
  __stack.args["bold"] = bold === __UNSET ? false : bold;
  __stack.args["dim"] = dim === __UNSET ? false : dim;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "hline", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("char" in __overrides) {
      char = __overrides["char"];
      __stack.args["char"] = char;
    }
    if ("length" in __overrides) {
      length = __overrides["length"];
      __stack.args["length"] = length;
    }
    if ("fgColor" in __overrides) {
      fgColor = __overrides["fgColor"];
      __stack.args["fgColor"] = fgColor;
    }
    if ("bold" in __overrides) {
      bold = __overrides["bold"];
      __stack.args["bold"] = bold;
    }
    if ("dim" in __overrides) {
      dim = __overrides["dim"];
      __stack.args["dim"] = dim;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "hline",
            args: {
              char,
              length,
              fgColor,
              bold,
              dim
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `hline`,
          "attrs": {
            "char": __stack.args.char,
            "length": __stack.args.length,
            "fgColor": __stack.args.fgColor,
            "bold": __stack.args.bold,
            "dim": __stack.args.dim
          },
          "children": []
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "hline");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function hline threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "hline"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "hline",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "hline",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const hline = __AgencyFunction.create({
  name: "hline",
  module: "stdlib/ui/layout.agency",
  fn: __hline_impl,
  params: [{
    name: "char",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "length",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fgColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bold",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dim",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "hline",
    description: `A horizontal rule. Inside a column, leave length at 0 to span the column's width.

  @param char - The character to repeat
  @param length - Explicit length (0 lets the parent size it)
  @param fgColor - Color of the line
  @param bold - Use bold weight
  @param dim - Use reduced intensity`,
    schema: z.object({ "char": z.string().nullable().describe("Default: \u2500"), "length": z.number().nullable().describe("Default: 0"), "fgColor": z.string().nullable().describe("Default: "), "bold": z.boolean().nullable().describe("Default: false"), "dim": z.boolean().nullable().describe("Default: false") })
  },
  exported: true
}, __toolRegistry);
async function __vline_impl(char = __UNSET, length = __UNSET, fgColor = __UNSET, bold = __UNSET, dim = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["char"] = char === __UNSET ? `\u2502` : char;
  __stack.args["length"] = length === __UNSET ? 0 : length;
  __stack.args["fgColor"] = fgColor === __UNSET ? `` : fgColor;
  __stack.args["bold"] = bold === __UNSET ? false : bold;
  __stack.args["dim"] = dim === __UNSET ? false : dim;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "vline", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("char" in __overrides) {
      char = __overrides["char"];
      __stack.args["char"] = char;
    }
    if ("length" in __overrides) {
      length = __overrides["length"];
      __stack.args["length"] = length;
    }
    if ("fgColor" in __overrides) {
      fgColor = __overrides["fgColor"];
      __stack.args["fgColor"] = fgColor;
    }
    if ("bold" in __overrides) {
      bold = __overrides["bold"];
      __stack.args["bold"] = bold;
    }
    if ("dim" in __overrides) {
      dim = __overrides["dim"];
      __stack.args["dim"] = dim;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "vline",
            args: {
              char,
              length,
              fgColor,
              bold,
              dim
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `vline`,
          "attrs": {
            "char": __stack.args.char,
            "length": __stack.args.length,
            "fgColor": __stack.args.fgColor,
            "bold": __stack.args.bold,
            "dim": __stack.args.dim
          },
          "children": []
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "vline");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function vline threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "vline"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "vline",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "vline",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const vline = __AgencyFunction.create({
  name: "vline",
  module: "stdlib/ui/layout.agency",
  fn: __vline_impl,
  params: [{
    name: "char",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "length",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fgColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bold",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dim",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "vline",
    description: `A vertical rule. Inside a row, leave length at 0 to span the row's height.

  @param char - The character to repeat
  @param length - Explicit length (0 lets the parent size it)
  @param fgColor - Color of the line
  @param bold - Use bold weight
  @param dim - Use reduced intensity`,
    schema: z.object({ "char": z.string().nullable().describe("Default: \u2502"), "length": z.number().nullable().describe("Default: 0"), "fgColor": z.string().nullable().describe("Default: "), "bold": z.boolean().nullable().describe("Default: false"), "dim": z.boolean().nullable().describe("Default: false") })
  },
  exported: true
}, __toolRegistry);
async function ___addText_impl(kids, content, fgColor = __UNSET, bgColor = __UNSET, bold = __UNSET, italic = __UNSET, dim = __UNSET, underline = __UNSET, align = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["content"] = content;
  __stack.args["fgColor"] = fgColor === __UNSET ? `` : fgColor;
  __stack.args["bgColor"] = bgColor === __UNSET ? `` : bgColor;
  __stack.args["bold"] = bold === __UNSET ? false : bold;
  __stack.args["italic"] = italic === __UNSET ? false : italic;
  __stack.args["dim"] = dim === __UNSET ? false : dim;
  __stack.args["underline"] = underline === __UNSET ? false : underline;
  __stack.args["align"] = align === __UNSET ? `start` : align;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "_addText", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("content" in __overrides) {
      content = __overrides["content"];
      __stack.args["content"] = content;
    }
    if ("fgColor" in __overrides) {
      fgColor = __overrides["fgColor"];
      __stack.args["fgColor"] = fgColor;
    }
    if ("bgColor" in __overrides) {
      bgColor = __overrides["bgColor"];
      __stack.args["bgColor"] = bgColor;
    }
    if ("bold" in __overrides) {
      bold = __overrides["bold"];
      __stack.args["bold"] = bold;
    }
    if ("italic" in __overrides) {
      italic = __overrides["italic"];
      __stack.args["italic"] = italic;
    }
    if ("dim" in __overrides) {
      dim = __overrides["dim"];
      __stack.args["dim"] = dim;
    }
    if ("underline" in __overrides) {
      underline = __overrides["underline"];
      __stack.args["underline"] = underline;
    }
    if ("align" in __overrides) {
      align = __overrides["align"];
      __stack.args["align"] = align;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addText",
            args: {
              kids,
              content,
              fgColor,
              bgColor,
              bold,
              italic,
              dim,
              underline,
              align
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.n = await __call(text, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            content: __stack.args.content,
            fgColor: __stack.args.fgColor,
            bgColor: __stack.args.bgColor,
            bold: __stack.args.bold,
            italic: __stack.args.italic,
            dim: __stack.args.dim,
            underline: __stack.args.underline,
            align: __stack.args.align
          }
        });
        if (hasInterrupts(__stack.locals.n)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.n);
          return;
        }
        if (isAborted(__stack.locals.n)) {
          runner2.halt(__stack.locals.n.carryThrough(__stack, "_addText"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.n]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.n);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addText");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addText threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addText"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addText",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addText",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addText = __AgencyFunction.create({
  name: "_addText",
  module: "stdlib/ui/layout.agency",
  fn: ___addText_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "content",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fgColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bgColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bold",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "italic",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dim",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "underline",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "align",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addText",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "content": z.string(), "fgColor": z.string().nullable().describe("Default: "), "bgColor": z.string().nullable().describe("Default: "), "bold": z.boolean().nullable().describe("Default: false"), "italic": z.boolean().nullable().describe("Default: false"), "dim": z.boolean().nullable().describe("Default: false"), "underline": z.boolean().nullable().describe("Default: false"), "align": Alignment.nullable().describe("Default: start") })
  },
  exported: false
}, __toolRegistry);
async function ___addRaw_impl(kids, content, align = __UNSET, wrap = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["content"] = content;
  __stack.args["align"] = align === __UNSET ? `start` : align;
  __stack.args["wrap"] = wrap === __UNSET ? true : wrap;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "_addRaw", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("content" in __overrides) {
      content = __overrides["content"];
      __stack.args["content"] = content;
    }
    if ("align" in __overrides) {
      align = __overrides["align"];
      __stack.args["align"] = align;
    }
    if ("wrap" in __overrides) {
      wrap = __overrides["wrap"];
      __stack.args["wrap"] = wrap;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addRaw",
            args: {
              kids,
              content,
              align,
              wrap
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.n = await __call(raw, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            content: __stack.args.content,
            align: __stack.args.align,
            wrap: __stack.args.wrap
          }
        });
        if (hasInterrupts(__stack.locals.n)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.n);
          return;
        }
        if (isAborted(__stack.locals.n)) {
          runner2.halt(__stack.locals.n.carryThrough(__stack, "_addRaw"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.n]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.n);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addRaw");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addRaw threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addRaw"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addRaw",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addRaw",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addRaw = __AgencyFunction.create({
  name: "_addRaw",
  module: "stdlib/ui/layout.agency",
  fn: ___addRaw_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "content",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "align",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "wrap",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addRaw",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "content": z.string(), "align": Alignment.nullable().describe("Default: start"), "wrap": z.boolean().nullable().describe("Default: true") })
  },
  exported: false
}, __toolRegistry);
async function ___addSpace_impl(kids, count2 = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["count"] = count2 === __UNSET ? 1 : count2;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "_addSpace", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("count" in __overrides) {
      count2 = __overrides["count"];
      __stack.args["count"] = count2;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addSpace",
            args: {
              kids,
              count: count2
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.n = await __call(space, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            count: __stack.args.count
          }
        });
        if (hasInterrupts(__stack.locals.n)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.n);
          return;
        }
        if (isAborted(__stack.locals.n)) {
          runner2.halt(__stack.locals.n.carryThrough(__stack, "_addSpace"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.n]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.n);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addSpace");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addSpace threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addSpace"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addSpace",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addSpace",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addSpace = __AgencyFunction.create({
  name: "_addSpace",
  module: "stdlib/ui/layout.agency",
  fn: ___addSpace_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "count",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addSpace",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "count": z.number().nullable().describe("Default: 1") })
  },
  exported: false
}, __toolRegistry);
async function ___addHline_impl(kids, char = __UNSET, length = __UNSET, fgColor = __UNSET, bold = __UNSET, dim = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["char"] = char === __UNSET ? `\u2500` : char;
  __stack.args["length"] = length === __UNSET ? 0 : length;
  __stack.args["fgColor"] = fgColor === __UNSET ? `` : fgColor;
  __stack.args["bold"] = bold === __UNSET ? false : bold;
  __stack.args["dim"] = dim === __UNSET ? false : dim;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "_addHline", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("char" in __overrides) {
      char = __overrides["char"];
      __stack.args["char"] = char;
    }
    if ("length" in __overrides) {
      length = __overrides["length"];
      __stack.args["length"] = length;
    }
    if ("fgColor" in __overrides) {
      fgColor = __overrides["fgColor"];
      __stack.args["fgColor"] = fgColor;
    }
    if ("bold" in __overrides) {
      bold = __overrides["bold"];
      __stack.args["bold"] = bold;
    }
    if ("dim" in __overrides) {
      dim = __overrides["dim"];
      __stack.args["dim"] = dim;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addHline",
            args: {
              kids,
              char,
              length,
              fgColor,
              bold,
              dim
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.n = await __call(hline, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            char: __stack.args.char,
            length: __stack.args.length,
            fgColor: __stack.args.fgColor,
            bold: __stack.args.bold,
            dim: __stack.args.dim
          }
        });
        if (hasInterrupts(__stack.locals.n)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.n);
          return;
        }
        if (isAborted(__stack.locals.n)) {
          runner2.halt(__stack.locals.n.carryThrough(__stack, "_addHline"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.n]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.n);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addHline");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addHline threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addHline"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addHline",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addHline",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addHline = __AgencyFunction.create({
  name: "_addHline",
  module: "stdlib/ui/layout.agency",
  fn: ___addHline_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "char",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "length",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fgColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bold",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dim",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addHline",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "char": z.string().nullable().describe("Default: \u2500"), "length": z.number().nullable().describe("Default: 0"), "fgColor": z.string().nullable().describe("Default: "), "bold": z.boolean().nullable().describe("Default: false"), "dim": z.boolean().nullable().describe("Default: false") })
  },
  exported: false
}, __toolRegistry);
async function ___addVline_impl(kids, char = __UNSET, length = __UNSET, fgColor = __UNSET, bold = __UNSET, dim = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["char"] = char === __UNSET ? `\u2502` : char;
  __stack.args["length"] = length === __UNSET ? 0 : length;
  __stack.args["fgColor"] = fgColor === __UNSET ? `` : fgColor;
  __stack.args["bold"] = bold === __UNSET ? false : bold;
  __stack.args["dim"] = dim === __UNSET ? false : dim;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "_addVline", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("char" in __overrides) {
      char = __overrides["char"];
      __stack.args["char"] = char;
    }
    if ("length" in __overrides) {
      length = __overrides["length"];
      __stack.args["length"] = length;
    }
    if ("fgColor" in __overrides) {
      fgColor = __overrides["fgColor"];
      __stack.args["fgColor"] = fgColor;
    }
    if ("bold" in __overrides) {
      bold = __overrides["bold"];
      __stack.args["bold"] = bold;
    }
    if ("dim" in __overrides) {
      dim = __overrides["dim"];
      __stack.args["dim"] = dim;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addVline",
            args: {
              kids,
              char,
              length,
              fgColor,
              bold,
              dim
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.n = await __call(vline, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            char: __stack.args.char,
            length: __stack.args.length,
            fgColor: __stack.args.fgColor,
            bold: __stack.args.bold,
            dim: __stack.args.dim
          }
        });
        if (hasInterrupts(__stack.locals.n)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.n);
          return;
        }
        if (isAborted(__stack.locals.n)) {
          runner2.halt(__stack.locals.n.carryThrough(__stack, "_addVline"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.n]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.n);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addVline");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addVline threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addVline"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addVline",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addVline",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addVline = __AgencyFunction.create({
  name: "_addVline",
  module: "stdlib/ui/layout.agency",
  fn: ___addVline_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "char",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "length",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fgColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bold",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dim",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addVline",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "char": z.string().nullable().describe("Default: \u2502"), "length": z.number().nullable().describe("Default: 0"), "fgColor": z.string().nullable().describe("Default: "), "bold": z.boolean().nullable().describe("Default: false"), "dim": z.boolean().nullable().describe("Default: false") })
  },
  exported: false
}, __toolRegistry);
async function ___addRow_impl(kids, gap = __UNSET, align = __UNSET, width = __UNSET, children = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["gap"] = gap === __UNSET ? 0 : gap;
  __stack.args["align"] = align === __UNSET ? `start` : align;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["children"] = children === __UNSET ? null : children;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "_addRow", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("gap" in __overrides) {
      gap = __overrides["gap"];
      __stack.args["gap"] = gap;
    }
    if ("align" in __overrides) {
      align = __overrides["align"];
      __stack.args["align"] = align;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("children" in __overrides) {
      children = __overrides["children"];
      __stack.args["children"] = children;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addRow",
            args: {
              kids,
              gap,
              align,
              width,
              children,
              block
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.n = await __call(row, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            gap: __stack.args.gap,
            align: __stack.args.align,
            width: __stack.args.width,
            children: __stack.args.children,
            block: __stack.args.block
          }
        });
        if (hasInterrupts(__stack.locals.n)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.n);
          return;
        }
        if (isAborted(__stack.locals.n)) {
          runner2.halt(__stack.locals.n.carryThrough(__stack, "_addRow"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.n]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.n);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addRow");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addRow threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addRow"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addRow",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addRow",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addRow = __AgencyFunction.create({
  name: "_addRow",
  module: "stdlib/ui/layout.agency",
  fn: ___addRow_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "gap",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "align",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "children",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addRow",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "gap": z.number().nullable().describe("Default: 0"), "align": Alignment.nullable().describe("Default: start"), "width": Width.nullable().describe("Default: null"), "children": z.array(LayoutNode).nullable().describe("Default: null") })
  },
  exported: false
}, __toolRegistry);
async function ___addColumn_impl(kids, gap = __UNSET, align = __UNSET, width = __UNSET, children = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["gap"] = gap === __UNSET ? 0 : gap;
  __stack.args["align"] = align === __UNSET ? `start` : align;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["children"] = children === __UNSET ? null : children;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "_addColumn", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("gap" in __overrides) {
      gap = __overrides["gap"];
      __stack.args["gap"] = gap;
    }
    if ("align" in __overrides) {
      align = __overrides["align"];
      __stack.args["align"] = align;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("children" in __overrides) {
      children = __overrides["children"];
      __stack.args["children"] = children;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addColumn",
            args: {
              kids,
              gap,
              align,
              width,
              children,
              block
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.n = await __call(column, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            gap: __stack.args.gap,
            align: __stack.args.align,
            width: __stack.args.width,
            children: __stack.args.children,
            block: __stack.args.block
          }
        });
        if (hasInterrupts(__stack.locals.n)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.n);
          return;
        }
        if (isAborted(__stack.locals.n)) {
          runner2.halt(__stack.locals.n.carryThrough(__stack, "_addColumn"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.n]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.n);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addColumn");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addColumn threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addColumn"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addColumn",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addColumn",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addColumn = __AgencyFunction.create({
  name: "_addColumn",
  module: "stdlib/ui/layout.agency",
  fn: ___addColumn_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "gap",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "align",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "children",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addColumn",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "gap": z.number().nullable().describe("Default: 0"), "align": Alignment.nullable().describe("Default: start"), "width": Width.nullable().describe("Default: null"), "children": z.array(LayoutNode).nullable().describe("Default: null") })
  },
  exported: false
}, __toolRegistry);
async function ___addBox_impl(kids, title = __UNSET, titleColor = __UNSET, borderStyle = __UNSET, borderColor = __UNSET, padding = __UNSET, width = __UNSET, children = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["title"] = title === __UNSET ? `` : title;
  __stack.args["titleColor"] = titleColor === __UNSET ? `` : titleColor;
  __stack.args["borderStyle"] = borderStyle === __UNSET ? `rounded` : borderStyle;
  __stack.args["borderColor"] = borderColor === __UNSET ? `` : borderColor;
  __stack.args["padding"] = padding === __UNSET ? 1 : padding;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["children"] = children === __UNSET ? null : children;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "_addBox", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("title" in __overrides) {
      title = __overrides["title"];
      __stack.args["title"] = title;
    }
    if ("titleColor" in __overrides) {
      titleColor = __overrides["titleColor"];
      __stack.args["titleColor"] = titleColor;
    }
    if ("borderStyle" in __overrides) {
      borderStyle = __overrides["borderStyle"];
      __stack.args["borderStyle"] = borderStyle;
    }
    if ("borderColor" in __overrides) {
      borderColor = __overrides["borderColor"];
      __stack.args["borderColor"] = borderColor;
    }
    if ("padding" in __overrides) {
      padding = __overrides["padding"];
      __stack.args["padding"] = padding;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("children" in __overrides) {
      children = __overrides["children"];
      __stack.args["children"] = children;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addBox",
            args: {
              kids,
              title,
              titleColor,
              borderStyle,
              borderColor,
              padding,
              width,
              children,
              block
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.n = await __call(box, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            title: __stack.args.title,
            titleColor: __stack.args.titleColor,
            borderStyle: __stack.args.borderStyle,
            borderColor: __stack.args.borderColor,
            padding: __stack.args.padding,
            width: __stack.args.width,
            children: __stack.args.children,
            block: __stack.args.block
          }
        });
        if (hasInterrupts(__stack.locals.n)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.n);
          return;
        }
        if (isAborted(__stack.locals.n)) {
          runner2.halt(__stack.locals.n.carryThrough(__stack, "_addBox"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.n]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.n);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addBox");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addBox threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addBox"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addBox",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addBox",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addBox = __AgencyFunction.create({
  name: "_addBox",
  module: "stdlib/ui/layout.agency",
  fn: ___addBox_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "title",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "titleColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderStyle",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "padding",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "children",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addBox",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "title": z.string().nullable().describe("Default: "), "titleColor": z.string().nullable().describe("Default: "), "borderStyle": BorderStyle.nullable().describe("Default: rounded"), "borderColor": z.string().nullable().describe("Default: "), "padding": z.number().nullable().describe("Default: 1"), "width": Width.nullable().describe("Default: null"), "children": z.array(LayoutNode).nullable().describe("Default: null") })
  },
  exported: false
}, __toolRegistry);
async function ___makeBuilder_impl(kids) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "_makeBuilder", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_makeBuilder",
            args: {
              kids
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "text": await __callMethod(_addText, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "raw": await __callMethod(_addRaw, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "space": await __callMethod(_addSpace, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "hline": await __callMethod(_addHline, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "vline": await __callMethod(_addVline, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "row": await __callMethod(_addRow, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "column": await __callMethod(_addColumn, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "box": await __callMethod(_addBox, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          })
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_makeBuilder");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _makeBuilder threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_makeBuilder"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_makeBuilder",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_makeBuilder",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _makeBuilder = __AgencyFunction.create({
  name: "_makeBuilder",
  module: "stdlib/ui/layout.agency",
  fn: ___makeBuilder_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_makeBuilder",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()) })
  },
  exported: false
}, __toolRegistry);
async function __row_impl(gap = __UNSET, align = __UNSET, width = __UNSET, children = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["gap"] = gap === __UNSET ? 0 : gap;
  __stack.args["align"] = align === __UNSET ? `start` : align;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["children"] = children === __UNSET ? null : children;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "row", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("gap" in __overrides) {
      gap = __overrides["gap"];
      __stack.args["gap"] = gap;
    }
    if ("align" in __overrides) {
      align = __overrides["align"];
      __stack.args["align"] = align;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("children" in __overrides) {
      children = __overrides["children"];
      __stack.args["children"] = children;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "row",
            args: {
              gap,
              align,
              width,
              children,
              block
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.kids = [];
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.children, null),
          body: async (runner2) => {
            await runner2.loop(0, async () => __stack.args.children, async (c, _, runner3) => {
              await runner3.step(0, async (runner4) => {
                await __callMethod(__stack.locals.kids, "push", {
                  type: "positional",
                  args: [c]
                });
              });
            });
          }
        }
      ]);
      await runner.ifElse(3, [
        {
          condition: async () => !__eq(__stack.args.block, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(__stack.args.block, {
                type: "positional",
                args: [await __call(_makeBuilder, {
                  type: "positional",
                  args: [__stack.locals.kids]
                })]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "row"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __stack.locals.attrs = {
          "gap": __stack.args.gap,
          "align": __stack.args.align
        };
      });
      await runner.ifElse(5, [
        {
          condition: async () => !__eq(__stack.args.width, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.attrs.width = __stack.args.width;
            });
          }
        }
      ]);
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `row`,
          "attrs": __stack.locals.attrs,
          "children": __stack.locals.kids
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "row");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function row threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "row"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "row",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "row",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const row = __AgencyFunction.create({
  name: "row",
  module: "stdlib/ui/layout.agency",
  fn: __row_impl,
  params: [{
    name: "gap",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "align",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "children",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "row",
    description: `A horizontal container. Children render left to right.

  @param gap - Cells of blank space between children
  @param align - Vertical alignment of shorter children
  @param width - Width as a column count, "X%" of the parent, or "full" for the whole terminal (root only)
  @param children - Pre-built child nodes
  @param block - Trailing builder block, appended after children`,
    schema: z.object({ "gap": z.number().nullable().describe("Default: 0"), "align": Alignment.nullable().describe("Default: start"), "width": Width.nullable().describe("Default: null"), "children": z.array(LayoutNode).nullable().describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
async function __column_impl(gap = __UNSET, align = __UNSET, width = __UNSET, children = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["gap"] = gap === __UNSET ? 0 : gap;
  __stack.args["align"] = align === __UNSET ? `start` : align;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["children"] = children === __UNSET ? null : children;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "column", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("gap" in __overrides) {
      gap = __overrides["gap"];
      __stack.args["gap"] = gap;
    }
    if ("align" in __overrides) {
      align = __overrides["align"];
      __stack.args["align"] = align;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("children" in __overrides) {
      children = __overrides["children"];
      __stack.args["children"] = children;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "column",
            args: {
              gap,
              align,
              width,
              children,
              block
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.kids = [];
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.children, null),
          body: async (runner2) => {
            await runner2.loop(0, async () => __stack.args.children, async (c, _, runner3) => {
              await runner3.step(0, async (runner4) => {
                await __callMethod(__stack.locals.kids, "push", {
                  type: "positional",
                  args: [c]
                });
              });
            });
          }
        }
      ]);
      await runner.ifElse(3, [
        {
          condition: async () => !__eq(__stack.args.block, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(__stack.args.block, {
                type: "positional",
                args: [await __call(_makeBuilder, {
                  type: "positional",
                  args: [__stack.locals.kids]
                })]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "column"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __stack.locals.attrs = {
          "gap": __stack.args.gap,
          "align": __stack.args.align
        };
      });
      await runner.ifElse(5, [
        {
          condition: async () => !__eq(__stack.args.width, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.attrs.width = __stack.args.width;
            });
          }
        }
      ]);
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `column`,
          "attrs": __stack.locals.attrs,
          "children": __stack.locals.kids
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "column");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function column threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "column"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "column",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "column",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const column = __AgencyFunction.create({
  name: "column",
  module: "stdlib/ui/layout.agency",
  fn: __column_impl,
  params: [{
    name: "gap",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "align",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "children",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "column",
    description: `A vertical container. Children render top to bottom.

  @param gap - Blank rows between children
  @param align - Horizontal alignment of narrower children
  @param width - Width as a column count, "X%" of the parent, or "full" for the whole terminal (root only)
  @param children - Pre-built child nodes
  @param block - Trailing builder block, appended after children`,
    schema: z.object({ "gap": z.number().nullable().describe("Default: 0"), "align": Alignment.nullable().describe("Default: start"), "width": Width.nullable().describe("Default: null"), "children": z.array(LayoutNode).nullable().describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
async function __box_impl(title = __UNSET, titleColor = __UNSET, borderStyle = __UNSET, borderColor = __UNSET, padding = __UNSET, width = __UNSET, children = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["title"] = title === __UNSET ? `` : title;
  __stack.args["titleColor"] = titleColor === __UNSET ? `` : titleColor;
  __stack.args["borderStyle"] = borderStyle === __UNSET ? `rounded` : borderStyle;
  __stack.args["borderColor"] = borderColor === __UNSET ? `` : borderColor;
  __stack.args["padding"] = padding === __UNSET ? 1 : padding;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["children"] = children === __UNSET ? null : children;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "box", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("title" in __overrides) {
      title = __overrides["title"];
      __stack.args["title"] = title;
    }
    if ("titleColor" in __overrides) {
      titleColor = __overrides["titleColor"];
      __stack.args["titleColor"] = titleColor;
    }
    if ("borderStyle" in __overrides) {
      borderStyle = __overrides["borderStyle"];
      __stack.args["borderStyle"] = borderStyle;
    }
    if ("borderColor" in __overrides) {
      borderColor = __overrides["borderColor"];
      __stack.args["borderColor"] = borderColor;
    }
    if ("padding" in __overrides) {
      padding = __overrides["padding"];
      __stack.args["padding"] = padding;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("children" in __overrides) {
      children = __overrides["children"];
      __stack.args["children"] = children;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "box",
            args: {
              title,
              titleColor,
              borderStyle,
              borderColor,
              padding,
              width,
              children,
              block
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.kids = [];
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.children, null),
          body: async (runner2) => {
            await runner2.loop(0, async () => __stack.args.children, async (c, _, runner3) => {
              await runner3.step(0, async (runner4) => {
                await __callMethod(__stack.locals.kids, "push", {
                  type: "positional",
                  args: [c]
                });
              });
            });
          }
        }
      ]);
      await runner.ifElse(3, [
        {
          condition: async () => !__eq(__stack.args.block, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(__stack.args.block, {
                type: "positional",
                args: [await __call(_makeBuilder, {
                  type: "positional",
                  args: [__stack.locals.kids]
                })]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "box"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __stack.locals.attrs = {
          "title": __stack.args.title,
          "titleColor": __stack.args.titleColor,
          "borderStyle": __stack.args.borderStyle,
          "borderColor": __stack.args.borderColor,
          "padding": __stack.args.padding
        };
      });
      await runner.ifElse(5, [
        {
          condition: async () => !__eq(__stack.args.width, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.attrs.width = __stack.args.width;
            });
          }
        }
      ]);
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `box`,
          "attrs": __stack.locals.attrs,
          "children": __stack.locals.kids
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "box");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function box threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "box"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "box",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "box",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const box = __AgencyFunction.create({
  name: "box",
  module: "stdlib/ui/layout.agency",
  fn: __box_impl,
  params: [{
    name: "title",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "titleColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderStyle",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "padding",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "children",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "box",
    description: `A bordered panel. Multiple children stack vertically inside it.

  @param title - Text shown in the top border (empty for none)
  @param titleColor - Color of the title text
  @param borderStyle - The border character style
  @param borderColor - Color of the border
  @param padding - Cells of padding between the border and content
  @param width - Width as a column count, "X%" of the parent, or "full" for the whole terminal (root only)
  @param children - Pre-built child nodes
  @param block - Trailing builder block, appended after children`,
    schema: z.object({ "title": z.string().nullable().describe("Default: "), "titleColor": z.string().nullable().describe("Default: "), "borderStyle": BorderStyle.nullable().describe("Default: rounded"), "borderColor": z.string().nullable().describe("Default: "), "padding": z.number().nullable().describe("Default: 1"), "width": Width.nullable().describe("Default: null"), "children": z.array(LayoutNode).nullable().describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
async function __render_impl(node, color2 = __UNSET, cols = __UNSET, rows = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/layout.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["node"] = node;
  __stack.args["color"] = color2 === __UNSET ? `auto` : color2;
  __stack.args["cols"] = cols === __UNSET ? 0 : cols;
  __stack.args["rows"] = rows === __UNSET ? 0 : rows;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/layout.agency", scopeName: "render", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("node" in __overrides) {
      node = __overrides["node"];
      __stack.args["node"] = node;
    }
    if ("color" in __overrides) {
      color2 = __overrides["color"];
      __stack.args["color"] = color2;
    }
    if ("cols" in __overrides) {
      cols = __overrides["cols"];
      __stack.args["cols"] = cols;
    }
    if ("rows" in __overrides) {
      rows = __overrides["rows"];
      __stack.args["rows"] = rows;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "render",
            args: {
              node,
              color: color2,
              cols,
              rows
            },
            moduleId: "stdlib/ui/layout.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_render, {
          type: "positional",
          args: [__stack.args.node, __stack.args.color, __stack.args.cols, __stack.args.rows]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "render");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function render threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "render"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "render",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "render",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const render = __AgencyFunction.create({
  name: "render",
  module: "stdlib/ui/layout.agency",
  fn: __render_impl,
  params: [{
    name: "node",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "color",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cols",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "rows",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "render",
    description: `Render a layout tree to a styled, multi-line string ready to print.

  @param node - The root layout node
  @param color - "auto" emits colors only to a terminal; true always; false strips styling
  @param cols - Width override in columns (0 auto-detects)
  @param rows - Height override in rows (0 uses the default)`,
    schema: z.object({ "node": LayoutNode, "color": z.union([z.literal("auto"), z.boolean()]).nullable().describe("Default: auto"), "cols": z.number().nullable().describe("Default: 0"), "rows": z.number().nullable().describe("Default: 0") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/ui/layout.agency:text": { "1": { "line": 86, "col": 2 } }, "stdlib/ui/layout.agency:raw": { "1": { "line": 115, "col": 2 } }, "stdlib/ui/layout.agency:space": { "1": { "line": 132, "col": 2 } }, "stdlib/ui/layout.agency:hline": { "1": { "line": 157, "col": 2 } }, "stdlib/ui/layout.agency:vline": { "1": { "line": 186, "col": 2 } }, "stdlib/ui/layout.agency:_addText": { "1": { "line": 216, "col": 2 }, "2": { "line": 226, "col": 2 }, "3": { "line": 227, "col": 2 } }, "stdlib/ui/layout.agency:_addRaw": { "1": { "line": 236, "col": 2 }, "2": { "line": 237, "col": 2 }, "3": { "line": 238, "col": 2 } }, "stdlib/ui/layout.agency:_addSpace": { "1": { "line": 242, "col": 2 }, "2": { "line": 243, "col": 2 }, "3": { "line": 244, "col": 2 } }, "stdlib/ui/layout.agency:_addHline": { "1": { "line": 255, "col": 2 }, "2": { "line": 256, "col": 2 }, "3": { "line": 257, "col": 2 } }, "stdlib/ui/layout.agency:_addVline": { "1": { "line": 268, "col": 2 }, "2": { "line": 269, "col": 2 }, "3": { "line": 270, "col": 2 } }, "stdlib/ui/layout.agency:_addRow": { "1": { "line": 281, "col": 2 }, "2": { "line": 282, "col": 2 }, "3": { "line": 283, "col": 2 } }, "stdlib/ui/layout.agency:_addColumn": { "1": { "line": 294, "col": 2 }, "2": { "line": 295, "col": 2 }, "3": { "line": 296, "col": 2 } }, "stdlib/ui/layout.agency:_addBox": { "1": { "line": 310, "col": 2 }, "2": { "line": 320, "col": 2 }, "3": { "line": 321, "col": 2 } }, "stdlib/ui/layout.agency:_makeBuilder": { "1": { "line": 325, "col": 2 } }, "stdlib/ui/layout.agency:row": { "1": { "line": 359, "col": 2 }, "2": { "line": 360, "col": 2 }, "3": { "line": 365, "col": 2 }, "4": { "line": 368, "col": 2 }, "5": { "line": 372, "col": 2 }, "6": { "line": 375, "col": 2 }, "2.0.0": { "line": 362, "col": 6 }, "2.0": { "line": 361, "col": 4 }, "3.0": { "line": 366, "col": 4 }, "5.0": { "line": 373, "col": 4 } }, "stdlib/ui/layout.agency:column": { "1": { "line": 398, "col": 2 }, "2": { "line": 399, "col": 2 }, "3": { "line": 404, "col": 2 }, "4": { "line": 407, "col": 2 }, "5": { "line": 411, "col": 2 }, "6": { "line": 414, "col": 2 }, "2.0.0": { "line": 401, "col": 6 }, "2.0": { "line": 400, "col": 4 }, "3.0": { "line": 405, "col": 4 }, "5.0": { "line": 412, "col": 4 } }, "stdlib/ui/layout.agency:box": { "1": { "line": 443, "col": 2 }, "2": { "line": 444, "col": 2 }, "3": { "line": 449, "col": 2 }, "4": { "line": 452, "col": 2 }, "5": { "line": 459, "col": 2 }, "6": { "line": 462, "col": 2 }, "2.0.0": { "line": 446, "col": 6 }, "2.0": { "line": 445, "col": 4 }, "3.0": { "line": 450, "col": 4 }, "5.0": { "line": 460, "col": 4 } }, "stdlib/ui/layout.agency:render": { "1": { "line": 483, "col": 2 } } };
export {
  Alignment,
  BorderStyle,
  LayoutBuilder,
  LayoutNode,
  Width,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  _addBox,
  _addColumn,
  _addHline,
  _addRaw,
  _addRow,
  _addSpace,
  _addText,
  _addVline,
  _makeBuilder,
  approve,
  box,
  column,
  stdin_default as default,
  hasInterrupts,
  hline,
  interrupt,
  isDebugger,
  isInterrupt,
  raw,
  reject,
  render,
  respondToInterrupts,
  rewindFrom,
  row,
  space,
  text,
  vline
};
