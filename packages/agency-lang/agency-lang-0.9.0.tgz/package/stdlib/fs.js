import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { _multiedit, _previewEdit, _applyPatch, _mkdir, _copy, _move, _remove } from "agency-lang/stdlib-lib/fs.js";
import { bash, glob, ls, grep } from "agency-lang/stdlib/shell.js";
import { applyAgentCwd } from "agency-lang/stdlib/index.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __tryCall,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/fs.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(bash);
__registerTool(glob);
__registerTool(ls);
__registerTool(grep);
__registerTool(applyAgentCwd);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/fs.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/fs.agency");
}
__registerGlobalsInit("stdlib/fs.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/fs.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const Edit = z.object({ "oldText": z.string(), "newText": z.string(), "replaceAll": z.boolean() });
const EditResult = z.object({ "replacements": z.number(), "path": z.string(), "edits": z.number() });
async function __edit_impl(filename, edits, dir = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/fs.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["filename"] = filename;
  __stack.args["edits"] = edits;
  __stack.args["dir"] = dir === __UNSET ? `.` : dir;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/fs.agency", scopeName: "edit", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("edits" in __overrides) {
      edits = __overrides["edits"];
      __stack.args["edits"] = edits;
    }
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "edit",
            args: {
              filename,
              edits,
              dir,
              useAgentCwd
            },
            moduleId: "stdlib/fs.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.dir = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dir]
              });
              if (hasInterrupts(__stack.args.dir)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dir);
                return;
              }
              if (isAborted(__stack.args.dir)) {
                runner3.halt(__stack.args.dir.carryThrough(__stack, "edit"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __stack.locals.preview = await __call(_previewEdit, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.filename, __stack.args.edits]
        });
        if (hasInterrupts(__stack.locals.preview)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.preview);
          return;
        }
        if (isAborted(__stack.locals.preview)) {
          runner2.halt(__stack.locals.preview.carryThrough(__stack, "edit"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_3);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::edit", `Are you sure you want to apply these edits?`, {
            "dir": __stack.args.dir,
            "filename": __stack.args.filename,
            "edits": __stack.args.edits,
            "before": __stack.locals.preview.before,
            "after": __stack.locals.preview.after
          }, "std::fs", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_3 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/fs.agency", scopeName: "edit", stepPath: "3" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(4, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_multiedit, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.filename, __stack.args.edits]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "edit",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "edit");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function edit threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "edit"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "edit",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "edit",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const edit = __AgencyFunction.create({
  name: "edit",
  module: "stdlib/fs.agency",
  fn: __edit_impl,
  params: [{
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "edits",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "edit",
    description: `Edit a single file by applying one or more text replacements atomically. Each edit's oldText must match a unique, non-overlapping region of the file as it stands when that edit runs (after earlier edits in the same call). If any edit fails, nothing is written.

  Prefer one call with multiple edits over many separate calls. Keep each oldText as small as possible while still matching uniquely. Do not pad with unchanged context to bridge distant changes; split them into separate edits instead.

  @param filename - The file to edit
  @param edits - Text replacements to apply in order; each has oldText, newText, and replaceAll (replace every occurrence when true)
  @param dir - The directory to resolve the filename against
  @param useAgentCwd - When true, resolve a relative path against the agent working directory if one is set`,
    schema: z.object({ "filename": z.string(), "edits": z.array(Edit), "dir": z.string().nullable().describe("Default: ."), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
const PatchResult = z.object({ "applied": z.number(), "files": z.array(z.string()) });
async function __applyPatch_impl(patch, allowedPaths = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/fs.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["patch"] = patch;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/fs.agency", scopeName: "applyPatch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("patch" in __overrides) {
      patch = __overrides["patch"];
      __stack.args["patch"] = patch;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "applyPatch",
            args: {
              patch,
              allowedPaths
            },
            moduleId: "stdlib/fs.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::applyPatch", `Are you sure you want to apply this patch?`, {
            "patch": __stack.args.patch
          }, "std::fs", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/fs.agency", scopeName: "applyPatch", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_applyPatch, {
          type: "positional",
          args: [__stack.args.patch, __stack.args.allowedPaths]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "applyPatch",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "applyPatch");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function applyPatch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "applyPatch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "applyPatch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "applyPatch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const applyPatch = __AgencyFunction.create({
  name: "applyPatch",
  module: "stdlib/fs.agency",
  fn: __applyPatch_impl,
  params: [{
    name: "patch",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "applyPatch",
    description: `Apply a unified diff to the working tree. Supports file creation (--- /dev/null), line additions, deletions, and context. Fails on a malformed diff or on a context-line mismatch against the current file contents.

  @param patch - The unified diff to apply
  @param allowedPaths - Only allow patches that touch files under these prefixes`,
    schema: z.object({ "patch": z.string(), "allowedPaths": z.array(z.string()).nullable().describe("Default: []") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __mkdir_impl(dir, allowedPaths = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/fs.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/fs.agency", scopeName: "mkdir", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "mkdir",
            args: {
              dir,
              allowedPaths,
              useAgentCwd
            },
            moduleId: "stdlib/fs.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.dir = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dir]
              });
              if (hasInterrupts(__stack.args.dir)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dir);
                return;
              }
              if (isAborted(__stack.args.dir)) {
                runner3.halt(__stack.args.dir.carryThrough(__stack, "mkdir"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::mkdir", `Are you sure you want to create this directory?`, {
            "dir": __stack.args.dir
          }, "std::fs", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/fs.agency", scopeName: "mkdir", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_mkdir, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.allowedPaths]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "mkdir",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "mkdir");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function mkdir threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "mkdir"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "mkdir",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "mkdir",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const mkdir = __AgencyFunction.create({
  name: "mkdir",
  module: "stdlib/fs.agency",
  fn: __mkdir_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "mkdir",
    description: `Create a directory, including any missing parent directories. Idempotent: succeeds if the directory already exists. Fails if a non-directory entry already occupies the path, or on permission errors.

  @param dir - The directory to create
  @param allowedPaths - Only allow paths starting with these prefixes
  @param useAgentCwd - When true, resolve a relative dir against the agent working directory if one is set`,
    schema: z.object({ "dir": z.string(), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __copy_impl(src, dest, allowedPaths = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/fs.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["src"] = src;
  __stack.args["dest"] = dest;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/fs.agency", scopeName: "copy", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("src" in __overrides) {
      src = __overrides["src"];
      __stack.args["src"] = src;
    }
    if ("dest" in __overrides) {
      dest = __overrides["dest"];
      __stack.args["dest"] = dest;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "copy",
            args: {
              src,
              dest,
              allowedPaths,
              useAgentCwd
            },
            moduleId: "stdlib/fs.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.src = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.src]
              });
              if (hasInterrupts(__stack.args.src)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.src);
                return;
              }
              if (isAborted(__stack.args.src)) {
                runner3.halt(__stack.args.src.carryThrough(__stack, "copy"));
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              __stack.args.dest = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dest]
              });
              if (hasInterrupts(__stack.args.dest)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dest);
                return;
              }
              if (isAborted(__stack.args.dest)) {
                runner3.halt(__stack.args.dest.carryThrough(__stack, "copy"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::copy", `Are you sure you want to copy this file or directory?`, {
            "src": __stack.args.src,
            "dest": __stack.args.dest
          }, "std::fs", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/fs.agency", scopeName: "copy", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_copy, {
          type: "positional",
          args: [__stack.args.src, __stack.args.dest, __stack.args.allowedPaths]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "copy",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "copy");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function copy threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "copy"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "copy",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "copy",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const copy = __AgencyFunction.create({
  name: "copy",
  module: "stdlib/fs.agency",
  fn: __copy_impl,
  params: [{
    name: "src",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dest",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "copy",
    description: `Copy a file or directory. Directories are copied recursively. Fails if src does not exist or dest cannot be written.

  @param src - The source path
  @param dest - The destination path
  @param allowedPaths - Only allow paths starting with these prefixes
  @param useAgentCwd - When true, resolve relative src/dest against the agent working directory if one is set`,
    schema: z.object({ "src": z.string(), "dest": z.string(), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __move_impl(src, dest, allowedPaths = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/fs.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["src"] = src;
  __stack.args["dest"] = dest;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/fs.agency", scopeName: "move", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("src" in __overrides) {
      src = __overrides["src"];
      __stack.args["src"] = src;
    }
    if ("dest" in __overrides) {
      dest = __overrides["dest"];
      __stack.args["dest"] = dest;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "move",
            args: {
              src,
              dest,
              allowedPaths,
              useAgentCwd
            },
            moduleId: "stdlib/fs.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.src = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.src]
              });
              if (hasInterrupts(__stack.args.src)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.src);
                return;
              }
              if (isAborted(__stack.args.src)) {
                runner3.halt(__stack.args.src.carryThrough(__stack, "move"));
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              __stack.args.dest = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dest]
              });
              if (hasInterrupts(__stack.args.dest)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dest);
                return;
              }
              if (isAborted(__stack.args.dest)) {
                runner3.halt(__stack.args.dest.carryThrough(__stack, "move"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::move", `Are you sure you want to move this file or directory?`, {
            "src": __stack.args.src,
            "dest": __stack.args.dest
          }, "std::fs", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/fs.agency", scopeName: "move", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_move, {
          type: "positional",
          args: [__stack.args.src, __stack.args.dest, __stack.args.allowedPaths]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "move",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "move");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function move threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "move"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "move",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "move",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const move = __AgencyFunction.create({
  name: "move",
  module: "stdlib/fs.agency",
  fn: __move_impl,
  params: [{
    name: "src",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dest",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "move",
    description: `Move or rename a file or directory. Falls back to copy+remove if src and dest are on different filesystems. Fails if src does not exist.

  @param src - The source path
  @param dest - The destination path
  @param allowedPaths - Only allow paths starting with these prefixes
  @param useAgentCwd - When true, resolve relative src/dest against the agent working directory if one is set`,
    schema: z.object({ "src": z.string(), "dest": z.string(), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __remove_impl(target, allowedPaths = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/fs.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["target"] = target;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/fs.agency", scopeName: "remove", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("target" in __overrides) {
      target = __overrides["target"];
      __stack.args["target"] = target;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "remove",
            args: {
              target,
              allowedPaths,
              useAgentCwd
            },
            moduleId: "stdlib/fs.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.target = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.target]
              });
              if (hasInterrupts(__stack.args.target)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.target);
                return;
              }
              if (isAborted(__stack.args.target)) {
                runner3.halt(__stack.args.target.carryThrough(__stack, "remove"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::remove", `Are you sure you want to delete this file or directory? This cannot be undone.`, {
            "target": __stack.args.target
          }, "std::fs", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/fs.agency", scopeName: "remove", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_remove, {
          type: "positional",
          args: [__stack.args.target, __stack.args.allowedPaths]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "remove",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "remove");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function remove threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "remove"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "remove",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "remove",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const remove = __AgencyFunction.create({
  name: "remove",
  module: "stdlib/fs.agency",
  fn: __remove_impl,
  params: [{
    name: "target",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "remove",
    description: `Delete a file or directory. Directories are removed recursively. Does not fail if the target does not exist.

  @param target - The path to delete
  @param allowedPaths - Only allow paths starting with these prefixes
  @param useAgentCwd - When true, resolve a relative target against the agent working directory if one is set`,
    schema: z.object({ "target": z.string(), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/fs.agency:edit": { "1": { "line": 58, "col": 2 }, "2": { "line": 61, "col": 2 }, "3": { "line": 62, "col": 2 }, "5": { "line": 71, "col": 4 }, "1.0": { "line": 59, "col": 4 } }, "stdlib/fs.agency:applyPatch": { "1": { "line": 87, "col": 2 }, "3": { "line": 92, "col": 4 } }, "stdlib/fs.agency:mkdir": { "1": { "line": 104, "col": 2 }, "2": { "line": 107, "col": 2 }, "4": { "line": 112, "col": 4 }, "1.0": { "line": 105, "col": 4 } }, "stdlib/fs.agency:copy": { "1": { "line": 125, "col": 2 }, "2": { "line": 129, "col": 2 }, "4": { "line": 135, "col": 4 }, "1.0": { "line": 126, "col": 4 }, "1.1": { "line": 127, "col": 4 } }, "stdlib/fs.agency:move": { "1": { "line": 148, "col": 2 }, "2": { "line": 152, "col": 2 }, "4": { "line": 158, "col": 4 }, "1.0": { "line": 149, "col": 4 }, "1.1": { "line": 150, "col": 4 } }, "stdlib/fs.agency:remove": { "1": { "line": 170, "col": 2 }, "2": { "line": 173, "col": 2 }, "4": { "line": 178, "col": 4 }, "1.0": { "line": 171, "col": 4 } } };
export {
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  applyPatch,
  approve,
  copy,
  stdin_default as default,
  edit,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  mkdir,
  move,
  reject,
  remove,
  respondToInterrupts,
  rewindFrom
};
