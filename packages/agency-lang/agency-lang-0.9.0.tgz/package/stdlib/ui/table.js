import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { LayoutNode, Width, Alignment, BorderStyle } from "agency-lang/stdlib/ui/layout.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __eq,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/ui/table.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(LayoutNode);
__registerTool(Width);
__registerTool(Alignment);
__registerTool(BorderStyle);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/ui/table.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/ui/table.agency");
}
__registerGlobalsInit("stdlib/ui/table.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/ui/table.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const Cell = z.union([z.string(), LayoutNode]);
const CellRow = z.array(Cell);
const ColumnSpec = z.object({ "align": z.union([Alignment, z.null()]).optional().default(null), "minWidth": z.union([z.number(), z.null()]).optional().default(null), "width": z.union([Width, z.null()]).optional().default(null), "fgColor": z.union([z.string(), z.null()]).optional().default(null) });
const TableBuilder = z.object({ "columns": z.any(), "caption": z.any(), "header": z.any(), "row": z.any(), "footer": z.any() });
async function ___setTableColumns_impl(state, specs) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/table.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["specs"] = specs;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/table.agency", scopeName: "_setTableColumns", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("specs" in __overrides) {
      specs = __overrides["specs"];
      __stack.args["specs"] = specs;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_setTableColumns",
            args: {
              state,
              specs
            },
            moduleId: "stdlib/ui/table.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.args.state.columns = __stack.args.specs;
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(null);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_setTableColumns");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _setTableColumns threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_setTableColumns"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_setTableColumns",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_setTableColumns",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _setTableColumns = __AgencyFunction.create({
  name: "_setTableColumns",
  module: "stdlib/ui/table.agency",
  fn: ___setTableColumns_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "specs",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_setTableColumns",
    description: "No description provided.",
    schema: z.object({ "state": z.any(), "specs": z.array(ColumnSpec) })
  },
  exported: false
}, __toolRegistry);
async function ___setTableCaption_impl(state, text) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/table.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["text"] = text;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/table.agency", scopeName: "_setTableCaption", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("text" in __overrides) {
      text = __overrides["text"];
      __stack.args["text"] = text;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_setTableCaption",
            args: {
              state,
              text
            },
            moduleId: "stdlib/ui/table.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.args.state.caption = __stack.args.text;
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(null);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_setTableCaption");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _setTableCaption threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_setTableCaption"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_setTableCaption",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_setTableCaption",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _setTableCaption = __AgencyFunction.create({
  name: "_setTableCaption",
  module: "stdlib/ui/table.agency",
  fn: ___setTableCaption_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "text",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_setTableCaption",
    description: "No description provided.",
    schema: z.object({ "state": z.any(), "text": z.string() })
  },
  exported: false
}, __toolRegistry);
async function ___setTableHeader_impl(state, cells) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/table.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["cells"] = cells;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/table.agency", scopeName: "_setTableHeader", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("cells" in __overrides) {
      cells = __overrides["cells"];
      __stack.args["cells"] = cells;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_setTableHeader",
            args: {
              state,
              cells
            },
            moduleId: "stdlib/ui/table.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.args.state.header = __stack.args.cells;
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(null);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_setTableHeader");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _setTableHeader threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_setTableHeader"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_setTableHeader",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_setTableHeader",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _setTableHeader = __AgencyFunction.create({
  name: "_setTableHeader",
  module: "stdlib/ui/table.agency",
  fn: ___setTableHeader_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "cells",
    hasDefault: false,
    defaultValue: void 0,
    variadic: true,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_setTableHeader",
    description: "No description provided.",
    schema: z.object({ "state": z.any(), "cells": z.array(Cell) })
  },
  exported: false
}, __toolRegistry);
async function ___addTableRow_impl(state, cells) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/table.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["cells"] = cells;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/table.agency", scopeName: "_addTableRow", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("cells" in __overrides) {
      cells = __overrides["cells"];
      __stack.args["cells"] = cells;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addTableRow",
            args: {
              state,
              cells
            },
            moduleId: "stdlib/ui/table.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        await __callMethod(__stack.args.state.body, "push", {
          type: "positional",
          args: [__stack.args.cells]
        });
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(null);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addTableRow");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addTableRow threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addTableRow"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addTableRow",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addTableRow",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addTableRow = __AgencyFunction.create({
  name: "_addTableRow",
  module: "stdlib/ui/table.agency",
  fn: ___addTableRow_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "cells",
    hasDefault: false,
    defaultValue: void 0,
    variadic: true,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addTableRow",
    description: "No description provided.",
    schema: z.object({ "state": z.any(), "cells": z.array(Cell) })
  },
  exported: false
}, __toolRegistry);
async function ___addTableFooter_impl(state, cells) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/table.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["cells"] = cells;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/table.agency", scopeName: "_addTableFooter", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("cells" in __overrides) {
      cells = __overrides["cells"];
      __stack.args["cells"] = cells;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addTableFooter",
            args: {
              state,
              cells
            },
            moduleId: "stdlib/ui/table.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        await __callMethod(__stack.args.state.footer, "push", {
          type: "positional",
          args: [__stack.args.cells]
        });
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(null);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addTableFooter");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addTableFooter threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addTableFooter"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addTableFooter",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addTableFooter",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addTableFooter = __AgencyFunction.create({
  name: "_addTableFooter",
  module: "stdlib/ui/table.agency",
  fn: ___addTableFooter_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "cells",
    hasDefault: false,
    defaultValue: void 0,
    variadic: true,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addTableFooter",
    description: "No description provided.",
    schema: z.object({ "state": z.any(), "cells": z.array(Cell) })
  },
  exported: false
}, __toolRegistry);
async function ___makeTableBuilder_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/table.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/table.agency", scopeName: "_makeTableBuilder", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_makeTableBuilder",
            args: {
              state
            },
            moduleId: "stdlib/ui/table.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "columns": await __callMethod(_setTableColumns, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              state: __stack.args.state
            }
          }),
          "caption": await __callMethod(_setTableCaption, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              state: __stack.args.state
            }
          }),
          "header": await __callMethod(_setTableHeader, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              state: __stack.args.state
            }
          }),
          "row": await __callMethod(_addTableRow, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              state: __stack.args.state
            }
          }),
          "footer": await __callMethod(_addTableFooter, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              state: __stack.args.state
            }
          })
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_makeTableBuilder");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _makeTableBuilder threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_makeTableBuilder"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_makeTableBuilder",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_makeTableBuilder",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _makeTableBuilder = __AgencyFunction.create({
  name: "_makeTableBuilder",
  module: "stdlib/ui/table.agency",
  fn: ___makeTableBuilder_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "_makeTableBuilder",
    description: "No description provided.",
    schema: z.object({ "state": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __table_impl(title = __UNSET, titleColor = __UNSET, borderStyle = __UNSET, borderColor = __UNSET, caption = __UNSET, cellPadding = __UNSET, width = __UNSET, columns = __UNSET, header = __UNSET, body = __UNSET, footer = __UNSET, headerDivider = __UNSET, footerDivider = __UNSET, rowDividers = __UNSET, columnDividers = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui/table.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["title"] = title === __UNSET ? `` : title;
  __stack.args["titleColor"] = titleColor === __UNSET ? `` : titleColor;
  __stack.args["borderStyle"] = borderStyle === __UNSET ? `rounded` : borderStyle;
  __stack.args["borderColor"] = borderColor === __UNSET ? `` : borderColor;
  __stack.args["caption"] = caption === __UNSET ? `` : caption;
  __stack.args["cellPadding"] = cellPadding === __UNSET ? 1 : cellPadding;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["columns"] = columns === __UNSET ? null : columns;
  __stack.args["header"] = header === __UNSET ? null : header;
  __stack.args["body"] = body === __UNSET ? null : body;
  __stack.args["footer"] = footer === __UNSET ? null : footer;
  __stack.args["headerDivider"] = headerDivider === __UNSET ? true : headerDivider;
  __stack.args["footerDivider"] = footerDivider === __UNSET ? true : footerDivider;
  __stack.args["rowDividers"] = rowDividers === __UNSET ? false : rowDividers;
  __stack.args["columnDividers"] = columnDividers === __UNSET ? true : columnDividers;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui/table.agency", scopeName: "table", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("title" in __overrides) {
      title = __overrides["title"];
      __stack.args["title"] = title;
    }
    if ("titleColor" in __overrides) {
      titleColor = __overrides["titleColor"];
      __stack.args["titleColor"] = titleColor;
    }
    if ("borderStyle" in __overrides) {
      borderStyle = __overrides["borderStyle"];
      __stack.args["borderStyle"] = borderStyle;
    }
    if ("borderColor" in __overrides) {
      borderColor = __overrides["borderColor"];
      __stack.args["borderColor"] = borderColor;
    }
    if ("caption" in __overrides) {
      caption = __overrides["caption"];
      __stack.args["caption"] = caption;
    }
    if ("cellPadding" in __overrides) {
      cellPadding = __overrides["cellPadding"];
      __stack.args["cellPadding"] = cellPadding;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("columns" in __overrides) {
      columns = __overrides["columns"];
      __stack.args["columns"] = columns;
    }
    if ("header" in __overrides) {
      header = __overrides["header"];
      __stack.args["header"] = header;
    }
    if ("body" in __overrides) {
      body = __overrides["body"];
      __stack.args["body"] = body;
    }
    if ("footer" in __overrides) {
      footer = __overrides["footer"];
      __stack.args["footer"] = footer;
    }
    if ("headerDivider" in __overrides) {
      headerDivider = __overrides["headerDivider"];
      __stack.args["headerDivider"] = headerDivider;
    }
    if ("footerDivider" in __overrides) {
      footerDivider = __overrides["footerDivider"];
      __stack.args["footerDivider"] = footerDivider;
    }
    if ("rowDividers" in __overrides) {
      rowDividers = __overrides["rowDividers"];
      __stack.args["rowDividers"] = rowDividers;
    }
    if ("columnDividers" in __overrides) {
      columnDividers = __overrides["columnDividers"];
      __stack.args["columnDividers"] = columnDividers;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "table",
            args: {
              title,
              titleColor,
              borderStyle,
              borderColor,
              caption,
              cellPadding,
              width,
              columns,
              header,
              body,
              footer,
              headerDivider,
              footerDivider,
              rowDividers,
              columnDividers,
              block
            },
            moduleId: "stdlib/ui/table.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.bodyArr = [];
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.body, null),
          body: async (runner2) => {
            await runner2.loop(0, async () => __stack.args.body, async (r, _, runner3) => {
              await runner3.step(0, async (runner4) => {
                await __callMethod(__stack.locals.bodyArr, "push", {
                  type: "positional",
                  args: [r]
                });
              });
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.footerArr = [];
      });
      await runner.ifElse(4, [
        {
          condition: async () => !__eq(__stack.args.footer, null),
          body: async (runner2) => {
            await runner2.loop(0, async () => __stack.args.footer, async (r, _, runner3) => {
              await runner3.step(0, async (runner4) => {
                await __callMethod(__stack.locals.footerArr, "push", {
                  type: "positional",
                  args: [r]
                });
              });
            });
          }
        }
      ]);
      await runner.step(5, async (runner2) => {
        __stack.locals.state = {
          "header": __stack.args.header,
          "body": __stack.locals.bodyArr,
          "footer": __stack.locals.footerArr,
          "columns": __stack.args.columns,
          "caption": __stack.args.caption
        };
      });
      await runner.ifElse(6, [
        {
          condition: async () => !__eq(__stack.args.block, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(__stack.args.block, {
                type: "positional",
                args: [await __call(_makeTableBuilder, {
                  type: "positional",
                  args: [__stack.locals.state]
                })]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "table"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(7, async (runner2) => {
        __stack.locals.attrs = {
          "title": __stack.args.title,
          "titleColor": __stack.args.titleColor,
          "borderStyle": __stack.args.borderStyle,
          "borderColor": __stack.args.borderColor,
          "caption": __stack.locals.state.caption,
          "cellPadding": __stack.args.cellPadding,
          "columns": __stack.locals.state.columns,
          "header": __stack.locals.state.header,
          "body": __stack.locals.state.body,
          "footer": __stack.locals.state.footer,
          "headerDivider": __stack.args.headerDivider,
          "footerDivider": __stack.args.footerDivider,
          "rowDividers": __stack.args.rowDividers,
          "columnDividers": __stack.args.columnDividers
        };
      });
      await runner.ifElse(8, [
        {
          condition: async () => !__eq(__stack.args.width, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.attrs.width = __stack.args.width;
            });
          }
        }
      ]);
      await runner.step(9, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `table`,
          "attrs": __stack.locals.attrs,
          "children": []
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "table");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function table threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "table"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "table",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "table",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const table = __AgencyFunction.create({
  name: "table",
  module: "stdlib/ui/table.agency",
  fn: __table_impl,
  params: [{
    name: "title",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "titleColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderStyle",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "caption",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cellPadding",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "columns",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "header",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "body",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "footer",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "headerDivider",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "footerDivider",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "rowDividers",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "columnDividers",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "table",
    description: `Build a bordered table as a layout node. Pass the data form: \`header\`,
  \`body\`, and \`footer\` as arrays of cells, where every row has the same
  number of cells. Render the returned node to display it.

  @param title - Title shown in the top border
  @param titleColor - Color of the title text
  @param borderStyle - Frame style
  @param borderColor - Color of the border characters
  @param caption - Caption shown beneath the table
  @param cellPadding - Horizontal padding inside each cell, in cells
  @param width - Table width in cells, or "full" / "N%"
  @param columns - Per-column configuration (alignment, width, color)
  @param header - Header cells
  @param body - Body rows, each an array of cells
  @param footer - Footer rows, each an array of cells
  @param headerDivider - Draw a divider line beneath the header
  @param footerDivider - Draw a divider line above the footer
  @param rowDividers - Draw a divider between every body row
  @param columnDividers - Draw vertical dividers between columns`,
    schema: z.object({ "title": z.string().nullable().describe("Default: "), "titleColor": z.string().nullable().describe("Default: "), "borderStyle": BorderStyle.nullable().describe("Default: rounded"), "borderColor": z.string().nullable().describe("Default: "), "caption": z.string().nullable().describe("Default: "), "cellPadding": z.number().nullable().describe("Default: 1"), "width": Width.nullable().describe("Default: null"), "columns": z.array(ColumnSpec).nullable().describe("Default: null"), "header": z.array(Cell).nullable().describe("Default: null"), "body": z.array(CellRow).nullable().describe("Default: null"), "footer": z.array(CellRow).nullable().describe("Default: null"), "headerDivider": z.boolean().nullable().describe("Default: true"), "footerDivider": z.boolean().nullable().describe("Default: true"), "rowDividers": z.boolean().nullable().describe("Default: false"), "columnDividers": z.boolean().nullable().describe("Default: true") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/ui/table.agency:_setTableColumns": { "1": { "line": 82, "col": 2 }, "2": { "line": 83, "col": 2 } }, "stdlib/ui/table.agency:_setTableCaption": { "1": { "line": 87, "col": 2 }, "2": { "line": 88, "col": 2 } }, "stdlib/ui/table.agency:_setTableHeader": { "1": { "line": 92, "col": 2 }, "2": { "line": 93, "col": 2 } }, "stdlib/ui/table.agency:_addTableRow": { "1": { "line": 97, "col": 2 }, "2": { "line": 98, "col": 2 } }, "stdlib/ui/table.agency:_addTableFooter": { "1": { "line": 102, "col": 2 }, "2": { "line": 103, "col": 2 } }, "stdlib/ui/table.agency:_makeTableBuilder": { "1": { "line": 107, "col": 2 } }, "stdlib/ui/table.agency:table": { "1": { "line": 155, "col": 2 }, "2": { "line": 156, "col": 2 }, "3": { "line": 161, "col": 2 }, "4": { "line": 162, "col": 2 }, "5": { "line": 167, "col": 2 }, "6": { "line": 174, "col": 2 }, "7": { "line": 177, "col": 2 }, "8": { "line": 193, "col": 2 }, "9": { "line": 196, "col": 2 }, "2.0.0": { "line": 158, "col": 6 }, "2.0": { "line": 157, "col": 4 }, "4.0.0": { "line": 164, "col": 6 }, "4.0": { "line": 163, "col": 4 }, "6.0": { "line": 175, "col": 4 }, "8.0": { "line": 194, "col": 4 } } };
export {
  Cell,
  CellRow,
  ColumnSpec,
  TableBuilder,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  _addTableFooter,
  _addTableRow,
  _makeTableBuilder,
  _setTableCaption,
  _setTableColumns,
  _setTableHeader,
  approve,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  reject,
  respondToInterrupts,
  rewindFrom,
  table
};
