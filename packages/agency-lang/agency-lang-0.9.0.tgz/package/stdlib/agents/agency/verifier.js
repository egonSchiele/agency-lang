import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { runCode } from "agency-lang/stdlib/agency.js";
import { failOpenFeedback, Feedback } from "agency-lang/stdlib/agents/lib/feedback.js";
import { llmOptions } from "agency-lang/stdlib/agents/lib/shared.js";
import { readOnlyFileTools, shellTools } from "agency-lang/stdlib/agents/lib/toolkits.js";
import { agentSkill } from "agency-lang/stdlib/skills.js";
import { systemMessage, threadIsNew } from "agency-lang/stdlib/thread.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  runPrompt,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isFailure,
  stampFailureBoundary,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __threads,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/agents/agency/verifier.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(runCode);
__registerTool(failOpenFeedback);
__registerTool(Feedback);
__registerTool(llmOptions);
__registerTool(readOnlyFileTools);
__registerTool(shellTools);
__registerTool(agentSkill);
__registerTool(systemMessage);
__registerTool(threadIsNew);
let __staticInitPromise = null;
let systemPrompt = __UNINIT_STATIC;
let skills = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    systemPrompt = __deepFreeze(`You judge whether a program's actual result satisfies a task.

The value the program returned is only part of its result. When the task asks for a file, inspect what the program actually wrote with your tools and judge that too: a program that returns "done" and writes nothing has not done the task.

For each finding, return a Feedback item: error=true when it fails the task (name the specific problem), error=false for a satisfied point.`);
    skills = __deepFreeze(await __call(agentSkill, {
      type: "positional",
      args: [`agency/verifier`]
    }));
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    systemPrompt,
    skills
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/agents/agency/verifier.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/agents/agency/verifier.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/agents/agency/verifier.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/agents/agency/verifier.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/agents/agency/verifier.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
async function __buildTools_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/verifier.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/verifier.agency", scopeName: "buildTools", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildTools",
            args: {},
            moduleId: "stdlib/agents/agency/verifier.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt([...await __call(readOnlyFileTools, {
          type: "positional",
          args: []
        }), ...await __call(shellTools, {
          type: "positional",
          args: []
        }), __readStatic(skills, "skills", "stdlib/agents/agency/verifier.agency")]);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildTools");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildTools threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildTools"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildTools",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildTools",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildTools = __AgencyFunction.create({
  name: "buildTools",
  module: "stdlib/agents/agency/verifier.agency",
  fn: __buildTools_impl,
  params: [],
  toolDefinition: {
    name: "buildTools",
    description: `Return the Agency verifier's tools. It reads and measures what the program
  left behind; it has no write tools, because a verifier that can fix things
  is no longer a verifier.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __judgeResult_impl(task, data, model, provider, extraTools) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/verifier.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["data"] = data;
  __stack.args["model"] = model;
  __stack.args["provider"] = provider;
  __stack.args["extraTools"] = extraTools;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/verifier.agency", scopeName: "judgeResult", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("data" in __overrides) {
      data = __overrides["data"];
      __stack.args["data"] = data;
    }
    if ("model" in __overrides) {
      model = __overrides["model"];
      __stack.args["model"] = model;
    }
    if ("provider" in __overrides) {
      provider = __overrides["provider"];
      __stack.args["provider"] = provider;
    }
    if ("extraTools" in __overrides) {
      extraTools = __overrides["extraTools"];
      __stack.args["extraTools"] = extraTools;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "judgeResult",
            args: {
              task,
              data,
              model,
              provider,
              extraTools
            },
            moduleId: "stdlib/agents/agency/verifier.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => await __call(threadIsNew, {
            type: "positional",
            args: []
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(systemMessage, {
                type: "positional",
                args: [__readStatic(systemPrompt, "systemPrompt", "stdlib/agents/agency/verifier.agency")]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "judgeResult"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __stack.locals.prompt = `
Task:
${__stack.args.task}

The program ran and produced this result:
${__stack.args.data}
`;
      });
      await runner.step(3, async (runner2) => {
        __self.__removedTools = __self.__removedTools || [];
        __stack.locals.items = await runPrompt({
          prompt: __stack.locals.prompt,
          messages: __threads().getOrCreateActive(),
          responseFormat: z.object({
            response: z.array(Feedback)
          }),
          clientConfig: await __call(llmOptions, {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              model: __stack.args.model,
              provider: __stack.args.provider,
              tools: await __callMethod(await await __call(buildTools, {
                type: "positional",
                args: []
              }), "concat", {
                type: "positional",
                args: [__stack.args.extraTools]
              })
            }
          }),
          draftSchema: z.array(Feedback),
          maxToolCallRounds: 10,
          removedTools: __self.__removedTools,
          destructiveSink: __self,
          checkpointInfo: runner2.getCheckpointInfo()
        });
        if (hasInterrupts(__stack.locals.items)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.items);
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.items);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "judgeResult");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function judgeResult threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "judgeResult"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "judgeResult",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "judgeResult",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const judgeResult = __AgencyFunction.create({
  name: "judgeResult",
  module: "stdlib/agents/agency/verifier.agency",
  fn: __judgeResult_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "data",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "model",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "provider",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "extraTools",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "judgeResult",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "data": z.any(), "model": z.string(), "provider": z.string(), "extraTools": z.array(z.any()) })
  },
  exported: false
}, __toolRegistry);
async function __runAndJudge_impl(source, task, model, provider, session, extraTools) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/verifier.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __stack.args["task"] = task;
  __stack.args["model"] = model;
  __stack.args["provider"] = provider;
  __stack.args["session"] = session;
  __stack.args["extraTools"] = extraTools;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/verifier.agency", scopeName: "runAndJudge", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("model" in __overrides) {
      model = __overrides["model"];
      __stack.args["model"] = model;
    }
    if ("provider" in __overrides) {
      provider = __overrides["provider"];
      __stack.args["provider"] = provider;
    }
    if ("session" in __overrides) {
      session = __overrides["session"];
      __stack.args["session"] = session;
    }
    if ("extraTools" in __overrides) {
      extraTools = __overrides["extraTools"];
      __stack.args["extraTools"] = extraTools;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "runAndJudge",
            args: {
              source,
              task,
              model,
              provider,
              session,
              extraTools
            },
            moduleId: "stdlib/agents/agency/verifier.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.ran = await __call(runCode, {
          type: "positional",
          args: [__stack.args.source]
        });
        if (hasInterrupts(__stack.locals.ran)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.ran);
          return;
        }
        if (isAborted(__stack.locals.ran)) {
          runner2.halt(__stack.locals.ran.carryThrough(__stack, "runAndJudge"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.ran),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.err = __stack.locals.ran.error;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt([{
                "error": true,
                "feedback": `The program failed to run: ${__stack.locals.err}`
              }]);
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.items = [];
      });
      await runner.thread(4, "create", async () => ({ label: `agencyVerifierAgent`, session: __stack.args.session }), async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.items = await __call(judgeResult, {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              task: __stack.args.task,
              data: __stack.locals.ran.value,
              model: __stack.args.model,
              provider: __stack.args.provider,
              extraTools: __stack.args.extraTools
            }
          });
          if (hasInterrupts(__stack.locals.items)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.items);
            return;
          }
          if (isAborted(__stack.locals.items)) {
            runner3.halt(__stack.locals.items.carryThrough(__stack, "runAndJudge"));
            return;
          }
        });
      });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.items);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "runAndJudge");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function runAndJudge threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "runAndJudge"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "runAndJudge",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "runAndJudge",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const runAndJudge = __AgencyFunction.create({
  name: "runAndJudge",
  module: "stdlib/agents/agency/verifier.agency",
  fn: __runAndJudge_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "model",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "provider",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "session",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "extraTools",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "runAndJudge",
    description: "No description provided.",
    schema: z.object({ "source": z.string(), "task": z.string(), "model": z.string(), "provider": z.string(), "session": z.string(), "extraTools": z.array(z.any()) })
  },
  exported: false
}, __toolRegistry);
async function __agencyVerifierAgent_impl(source, task, context = __UNSET, maxCost = __UNSET, maxTime = __UNSET, model = __UNSET, provider = __UNSET, session = __UNSET, extraTools = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/agency/verifier.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __stack.args["task"] = task;
  __stack.args["context"] = context === __UNSET ? `` : context;
  __stack.args["maxCost"] = maxCost === __UNSET ? 20 : maxCost;
  __stack.args["maxTime"] = maxTime === __UNSET ? 9e5 : maxTime;
  __stack.args["model"] = model === __UNSET ? `` : model;
  __stack.args["provider"] = provider === __UNSET ? `` : provider;
  __stack.args["session"] = session === __UNSET ? `` : session;
  __stack.args["extraTools"] = extraTools === __UNSET ? [] : extraTools;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/agency/verifier.agency", scopeName: "agencyVerifierAgent", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
    if ("maxTime" in __overrides) {
      maxTime = __overrides["maxTime"];
      __stack.args["maxTime"] = maxTime;
    }
    if ("model" in __overrides) {
      model = __overrides["model"];
      __stack.args["model"] = model;
    }
    if ("provider" in __overrides) {
      provider = __overrides["provider"];
      __stack.args["provider"] = provider;
    }
    if ("session" in __overrides) {
      session = __overrides["session"];
      __stack.args["session"] = session;
    }
    if ("extraTools" in __overrides) {
      extraTools = __overrides["extraTools"];
      __stack.args["extraTools"] = extraTools;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "agencyVerifierAgent",
            args: {
              source,
              task,
              context,
              maxCost,
              maxTime,
              model,
              provider,
              session,
              extraTools
            },
            moduleId: "stdlib/agents/agency/verifier.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.captured = await __call(_guard, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            cost: __stack.args.maxCost,
            time: __stack.args.maxTime
          },
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/agents/agency/verifier.agency", fn: async () => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/agency/verifier.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(await __call(runAndJudge, {
                  type: "named",
                  positionalArgs: [],
                  namedArgs: {
                    source: __stack.args.source,
                    task: __stack.args.task,
                    model: __stack.args.model,
                    provider: __stack.args.provider,
                    session: __stack.args.session,
                    extraTools: __stack.args.extraTools
                  }
                }));
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_0");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.captured)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.captured);
          return;
        }
        if (isAborted(__stack.locals.captured)) {
          runner2.halt(__stack.locals.captured.carryThrough(__stack, "agencyVerifierAgent"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(failOpenFeedback, {
          type: "positional",
          args: [__stack.locals.captured]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "agencyVerifierAgent");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function agencyVerifierAgent threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "agencyVerifierAgent"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "agencyVerifierAgent",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "agencyVerifierAgent",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const agencyVerifierAgent = __AgencyFunction.create({
  name: "agencyVerifierAgent",
  module: "stdlib/agents/agency/verifier.agency",
  fn: __agencyVerifierAgent_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxTime",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "model",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "provider",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "session",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "extraTools",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "agencyVerifierAgent",
    description: `Run an Agency program and judge its result against the task. A program that
  fails to run yields a single error finding rather than a failure, so callers
  can always read findings.

  @param source - The Agency program to run
  @param task - What the program's result must satisfy
  @param context - Extra material for the judgment, or ""
  @param maxCost - Hard spend cap
  @param maxTime - Hard wall-clock cap
  @param model - Model override, or "" for the ambient model
  @param provider - Provider for the model override
  @param session - Session name to share a thread across calls, or "" for isolated
  @param extraTools - Extra tools to offer the LLM, appended to the built-in set`,
    schema: z.object({ "source": z.string(), "task": z.string(), "context": z.string().nullable().describe("Default: "), "maxCost": z.number().nullable().describe("Default: $20.00"), "maxTime": z.number().nullable().describe("Default: 15m"), "model": z.string().nullable().describe("Default: "), "provider": z.string().nullable().describe("Default: "), "session": z.string().nullable().describe("Default: "), "extraTools": z.array(z.any()).nullable().describe("Default: []") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/agents/agency/verifier.agency:buildTools": { "1": { "line": 27, "col": 2 } }, "stdlib/agents/agency/verifier.agency:judgeResult": { "1": { "line": 37, "col": 2 }, "2": { "line": 40, "col": 2 }, "3": { "line": 47, "col": 2 }, "4": { "line": 55, "col": 2 }, "1.0": { "line": 38, "col": 4 } }, "stdlib/agents/agency/verifier.agency:runAndJudge": { "1": { "line": 69, "col": 2 }, "2": { "line": 70, "col": 2 }, "3": { "line": 73, "col": 2 }, "4": { "line": 74, "col": 2 }, "5": { "line": 83, "col": 2 }, "2.0": { "line": 70, "col": 2 }, "2.1": { "line": 71, "col": 4 }, "4.0": { "line": 75, "col": 4 } }, "stdlib/agents/agency/verifier.agency:agencyVerifierAgent": { "1": { "line": 112, "col": 2 }, "2": { "line": 122, "col": 2 } }, "stdlib/agents/agency/verifier.agency:__block_0": { "1.0": { "line": 113, "col": 4 } } };
export {
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  agencyVerifierAgent,
  approve,
  buildTools,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  judgeResult,
  reject,
  respondToInterrupts,
  rewindFrom,
  runAndJudge
};
