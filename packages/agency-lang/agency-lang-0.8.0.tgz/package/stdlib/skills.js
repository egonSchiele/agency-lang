import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { map } from "agency-lang/stdlib/array.js";
import { frontmatter } from "agency-lang/stdlib/markdown.js";
import { _read } from "agency-lang/stdlib-lib/builtins.js";
import { _glob } from "agency-lang/stdlib-lib/shell.js";
import { _docsDir } from "agency-lang/stdlib-lib/skills.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  __readStatic,
  __registerGlobalsInit,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __pipeBind,
  __tryCall,
  __catchResult,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/skills.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(map);
__registerTool(frontmatter);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/skills.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/skills.agency");
  __ctx.globals.set("stdlib/skills.agency", "MAX_TOOL_NAME_LEN", 64);
}
__registerGlobalsInit("stdlib/skills.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const SkillEntry = z.object({ "name": z.string(), "description": z.string(), "location": z.string() });
async function __xmlEscape_impl(s) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["s"] = s;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "xmlEscape", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("s" in __overrides) {
      s = __overrides["s"];
      __stack.args["s"] = s;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "xmlEscape",
            args: {
              s
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.out = __stack.args.s;
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.out = await __callMethod(__stack.locals.out, "replaceAll", {
          type: "positional",
          args: [`&`, `&amp;`]
        });
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.out = await __callMethod(__stack.locals.out, "replaceAll", {
          type: "positional",
          args: [`<`, `&lt;`]
        });
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.out = await __callMethod(__stack.locals.out, "replaceAll", {
          type: "positional",
          args: [`>`, `&gt;`]
        });
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.out = await __callMethod(__stack.locals.out, "replaceAll", {
          type: "positional",
          args: [`"`, `&quot;`]
        });
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.out = await __callMethod(__stack.locals.out, "replaceAll", {
          type: "positional",
          args: [`'`, `&apos;`]
        });
      });
      await runner.step(7, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.out);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function xmlEscape threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "xmlEscape"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "xmlEscape",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "xmlEscape",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const xmlEscape = __AgencyFunction.create({
  name: "xmlEscape",
  module: "stdlib/skills.agency",
  fn: __xmlEscape_impl,
  params: [{
    name: "s",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "xmlEscape",
    description: `Escape \`&\`, \`<\`, \`>\`, \`"\`, \`'\` so the result is safe to embed inside
  XML text or attribute values. Used before splicing frontmatter or
  filenames into the \`<available_skills>\` block. Without this, a
  description containing \`&\` or a closing tag would produce malformed
  markup and could inject extra tags into the prompt.

  @param s - The string to escape.`,
    schema: z.object({ "s": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __renderEntry_impl(entry) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["entry"] = entry;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "renderEntry", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("entry" in __overrides) {
      entry = __overrides["entry"];
      __stack.args["entry"] = entry;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "renderEntry",
            args: {
              entry
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.nameX = await __call(xmlEscape, {
          type: "positional",
          args: [__stack.args.entry.name]
        });
        if (hasInterrupts(__stack.locals.nameX)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.nameX);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.descX = await __call(xmlEscape, {
          type: "positional",
          args: [__stack.args.entry.description]
        });
        if (hasInterrupts(__stack.locals.descX)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.descX);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.locX = await __call(xmlEscape, {
          type: "positional",
          args: [__stack.args.entry.location]
        });
        if (hasInterrupts(__stack.locals.locX)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.locX);
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`  <skill>
    <name>${__stack.locals.nameX}</name>
    <description>${__stack.locals.descX}</description>
    <location>${__stack.locals.locX}</location>
  </skill>`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function renderEntry threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "renderEntry"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "renderEntry",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "renderEntry",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const renderEntry = __AgencyFunction.create({
  name: "renderEntry",
  module: "stdlib/skills.agency",
  fn: __renderEntry_impl,
  params: [{
    name: "entry",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "renderEntry",
    description: `Render one SkillEntry as a \`<skill>\` XML block. All string fields are
  XML-escaped because they originate from user-authored frontmatter or
  filenames. An unescaped \`<\` or \`&\` would otherwise corrupt the
  surrounding \`<available_skills>\` markup.

  @param entry - The skill entry to render.`,
    schema: z.object({ "entry": SkillEntry })
  },
  exported: false
}, __toolRegistry);
async function __flatEntry_impl(filename, parsedFrontmatter) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["filename"] = filename;
  __stack.args["parsedFrontmatter"] = parsedFrontmatter;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "flatEntry", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("parsedFrontmatter" in __overrides) {
      parsedFrontmatter = __overrides["parsedFrontmatter"];
      __stack.args["parsedFrontmatter"] = parsedFrontmatter;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "flatEntry",
            args: {
              filename,
              parsedFrontmatter
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "name": __stack.args.parsedFrontmatter.name ?? __stack.args.parsedFrontmatter.title ?? __stack.args.filename,
          "description": __stack.args.parsedFrontmatter.description ?? ``,
          "location": __stack.args.filename
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function flatEntry threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "flatEntry"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "flatEntry",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "flatEntry",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const flatEntry = __AgencyFunction.create({
  name: "flatEntry",
  module: "stdlib/skills.agency",
  fn: __flatEntry_impl,
  params: [{
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "parsedFrontmatter",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "flatEntry",
    description: `Build a SkillEntry for one file in the legacy flat-markdown layout.
  Prefers frontmatter \`name\`, then \`title\` (so VitePress-style docs
  still work), then the filename. \`description\` defaults to "".

  @param filename - The skill file path, relative to the skills root.
  @param parsedFrontmatter - The parsed YAML frontmatter object from the file.`,
    schema: z.object({ "filename": z.string(), "parsedFrontmatter": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __sanitizeToolSegment_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "sanitizeToolSegment", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "sanitizeToolSegment",
            args: {
              raw
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.cleaned = await __callMethod(__stack.args.raw, "replaceAll", {
          type: "positional",
          args: [/[^a-zA-Z0-9]+/g, `_`]
        });
      });
      await runner.whileLoop(2, async () => await __callMethod(__stack.locals.cleaned, "startsWith", {
        type: "positional",
        args: [`_`]
      }), async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.cleaned = await __callMethod(__stack.locals.cleaned, "slice", {
            type: "positional",
            args: [1]
          });
        });
      });
      await runner.whileLoop(3, async () => await __callMethod(__stack.locals.cleaned, "endsWith", {
        type: "positional",
        args: [`_`]
      }), async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.cleaned = await __callMethod(__stack.locals.cleaned, "slice", {
            type: "positional",
            args: [0, __stack.locals.cleaned.length - 1]
          });
        });
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.cleaned);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function sanitizeToolSegment threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "sanitizeToolSegment"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "sanitizeToolSegment",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "sanitizeToolSegment",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const sanitizeToolSegment = __AgencyFunction.create({
  name: "sanitizeToolSegment",
  module: "stdlib/skills.agency",
  fn: __sanitizeToolSegment_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "sanitizeToolSegment",
    description: `Reduce an arbitrary string to characters providers accept in a tool name.
  Replace every run of non-alphanumerics with a single underscore \u2014 one pass
  handles \`/\`, \`.\`, \`-\`, space, and crucially the Windows backslash and
  drive-letter colon (\`C:\\\\docs\\\\guide\`) \u2014 then trim edge underscores left by
  a leading \`../\` or a trailing slash so names read cleanly.`,
    schema: z.object({ "raw": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __capToolName_impl(name) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["name"] = name;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "capToolName", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "capToolName",
            args: {
              name
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.name.length <= __globals().get("stdlib/skills.agency", "MAX_TOOL_NAME_LEN"),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.args.name);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __stack.locals.capped = await __callMethod(__stack.args.name, "slice", {
          type: "positional",
          args: [__stack.args.name.length - __globals().get("stdlib/skills.agency", "MAX_TOOL_NAME_LEN"), __stack.args.name.length]
        });
      });
      await runner.whileLoop(3, async () => await __callMethod(__stack.locals.capped, "startsWith", {
        type: "positional",
        args: [`_`]
      }), async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.capped = await __callMethod(__stack.locals.capped, "slice", {
            type: "positional",
            args: [1]
          });
        });
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.capped);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function capToolName threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "capToolName"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "capToolName",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "capToolName",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const capToolName = __AgencyFunction.create({
  name: "capToolName",
  module: "stdlib/skills.agency",
  fn: __capToolName_impl,
  params: [{
    name: "name",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "capToolName",
    description: `Cap a tool name to the provider limit, keeping the TAIL. For a deep path
  the distinctive part (the leaf skill dir, e.g. \`docs_guide\`) is at the end,
  and sibling skill dirs share a long common prefix, so dropping the head
  preserves both readability and uniqueness better than truncating the tail.`,
    schema: z.object({ "name": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __skillToolName_impl(dir) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "skillToolName", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "skillToolName",
            args: {
              dir
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.cleaned = await __call(sanitizeToolSegment, {
          type: "positional",
          args: [__stack.args.dir]
        });
        if (hasInterrupts(__stack.locals.cleaned)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.cleaned);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => __eq(__stack.locals.cleaned, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.cleaned = `root`;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(capToolName, {
          type: "positional",
          args: [`skills_${__stack.locals.cleaned}`]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function skillToolName threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "skillToolName"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "skillToolName",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "skillToolName",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const skillToolName = __AgencyFunction.create({
  name: "skillToolName",
  module: "stdlib/skills.agency",
  fn: __skillToolName_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "skillToolName",
    description: `Derive a unique, readable LLM tool name from a skills directory. The
  returned tool is \`read.partial(dir)\`, and \`.partial()\` keeps the base
  name \`read\`. So two \`skillsDir(...)\` results in one \`tools:\` list would
  collide, because providers require unique tool names. Naming each after
  its directory keeps them distinct AND makes tool-call traces legible.
  The result is capped at 64 characters (see \`capToolName\`); pass an explicit
  \`name\` to \`skillsDir\` to override the derived name entirely.

  @param dir - The skills directory the tool reads from.`,
    schema: z.object({ "dir": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __standardEntry_impl(skillPath, parsedFrontmatter) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["skillPath"] = skillPath;
  __stack.args["parsedFrontmatter"] = parsedFrontmatter;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "standardEntry", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("skillPath" in __overrides) {
      skillPath = __overrides["skillPath"];
      __stack.args["skillPath"] = skillPath;
    }
    if ("parsedFrontmatter" in __overrides) {
      parsedFrontmatter = __overrides["parsedFrontmatter"];
      __stack.args["parsedFrontmatter"] = parsedFrontmatter;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "standardEntry",
            args: {
              skillPath,
              parsedFrontmatter
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.skillDir = await __callMethod(__stack.args.skillPath, "replace", {
          type: "positional",
          args: [`/SKILL.md`, ``]
        });
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "name": __stack.args.parsedFrontmatter.name ?? __stack.locals.skillDir,
          "description": __stack.args.parsedFrontmatter.description ?? ``,
          "location": __stack.args.skillPath
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function standardEntry threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "standardEntry"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "standardEntry",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "standardEntry",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const standardEntry = __AgencyFunction.create({
  name: "standardEntry",
  module: "stdlib/skills.agency",
  fn: __standardEntry_impl,
  params: [{
    name: "skillPath",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "parsedFrontmatter",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "standardEntry",
    description: `Build a SkillEntry for one skill in the standard SKILL.md layout.
  The skill name defaults to the skill's directory name when not in
  frontmatter.

  @param skillPath - [skill-dir]/SKILL.md relative to the skills root.
  @param parsedFrontmatter - The parsed YAML frontmatter object from SKILL.md.`,
    schema: z.object({ "skillPath": z.string(), "parsedFrontmatter": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __buildSkillsTool_impl(dir, layout, name = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __stack.args["layout"] = layout;
  __stack.args["name"] = name === __UNSET ? `` : name;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "buildSkillsTool", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("layout" in __overrides) {
      layout = __overrides["layout"];
      __stack.args["layout"] = layout;
    }
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildSkillsTool",
            args: {
              dir,
              layout,
              name
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.pattern = `*/SKILL.md`;
      });
      await runner.ifElse(2, [
        {
          condition: async () => __eq(__stack.args.layout, `flat`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.pattern = `*.{md,markdown}`;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.lines = [];
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.pathsResult = await __tryCall(async () => await __call(_glob, {
          type: "positional",
          args: [__stack.locals.pattern, __stack.args.dir, 500, []]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "buildSkillsTool",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.pathsResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.pathsResult);
          return;
        }
      });
      await runner.ifElse(5, [
        {
          condition: async () => await isSuccess(__stack.locals.pathsResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.paths = __stack.locals.pathsResult.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.lines = await __call(map, {
                type: "named",
                positionalArgs: [__stack.locals.paths],
                namedArgs: {},
                blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/skills.agency", fn: async (path2) => {
                  const __bsetup = setupFunction();
                  const __bstack = __bsetup.stack;
                  const __self2 = __bstack.locals;
                  const __bframe___block_0 = __bstack;
                  __bstack.args["path"] = path2;
                  const runner4 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/skills.agency", scopeName: "__block_0" });
                  try {
                    await runner4.step(0, async (runner5) => {
                      __bstack.locals.data = await __catchResult(await __pipeBind(await __tryCall(async () => await __call(_read, {
                        type: "positional",
                        args: [__stack.args.dir, path2, 0, 0]
                      })), async (__pipeArg) => await __call(__readStatic(frontmatter, "frontmatter", ""), {
                        type: "positional",
                        args: [__pipeArg]
                      })), async () => {
                        return {};
                      });
                      if (hasInterrupts(__bstack.locals.data)) {
                        await getRuntimeContext().ctx.pendingPromises.awaitAll();
                        runner5.halt(__bstack.locals.data);
                        return;
                      }
                    });
                    await runner4.step(1, async (runner5) => {
                      __bstack.locals.entry = await __call(flatEntry, {
                        type: "positional",
                        args: [__bstack.args.path, __bstack.locals.data]
                      });
                      if (hasInterrupts(__bstack.locals.entry)) {
                        await getRuntimeContext().ctx.pendingPromises.awaitAll();
                        runner5.halt(__bstack.locals.entry);
                        return;
                      }
                    });
                    await runner4.ifElse(2, [
                      {
                        condition: async () => __eq(__stack.args.layout, `standard`),
                        body: async (runner5) => {
                          await runner5.step(0, async (runner6) => {
                            __bstack.locals.entry = await __call(standardEntry, {
                              type: "positional",
                              args: [__bstack.args.path, __bstack.locals.data]
                            });
                            if (hasInterrupts(__bstack.locals.entry)) {
                              await getRuntimeContext().ctx.pendingPromises.awaitAll();
                              runner6.halt(__bstack.locals.entry);
                              return;
                            }
                          });
                        }
                      }
                    ]);
                    await runner4.step(3, async (runner5) => {
                      runner5.halt(await __call(renderEntry, {
                        type: "positional",
                        args: [__bstack.locals.entry]
                      }));
                      return;
                    });
                    return runner4.halted ? runner4.haltResult : void 0;
                  } finally {
                    __bsetup.stateStack.pop();
                  }
                }, params: [{ name: "path", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
              });
              if (hasInterrupts(__stack.locals.lines)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.lines);
                return;
              }
            });
          }
        }
      ]);
      await runner.step(6, async (runner2) => {
        __stack.locals.header = `Read a skill file from the skills directory '${__stack.args.dir}' by passing its <location> as \`filename\` to the tool. Available skills:
<available_skills>
`;
      });
      await runner.step(7, async (runner2) => {
        __stack.locals.footer = `
</available_skills>`;
      });
      await runner.step(8, async (runner2) => {
        __stack.locals.description = __stack.locals.header + await __callMethod(__stack.locals.lines, "join", {
          type: "positional",
          args: [`
`]
        }) + __stack.locals.footer;
      });
      await runner.step(9, async (runner2) => {
        __stack.locals.toolName = await __call(skillToolName, {
          type: "positional",
          args: [__stack.args.dir]
        });
        if (hasInterrupts(__stack.locals.toolName)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.toolName);
          return;
        }
      });
      await runner.ifElse(10, [
        {
          condition: async () => !__eq(__stack.args.name, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.explicit = await __call(sanitizeToolSegment, {
                type: "positional",
                args: [__stack.args.name]
              });
              if (hasInterrupts(__stack.locals.explicit)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.explicit);
                return;
              }
            });
            await runner2.ifElse(2, [
              {
                condition: async () => !__eq(__stack.locals.explicit, ``),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __stack.locals.toolName = await __call(capToolName, {
                      type: "positional",
                      args: [__stack.locals.explicit]
                    });
                    if (hasInterrupts(__stack.locals.toolName)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner4.halt(__stack.locals.toolName);
                      return;
                    }
                  });
                }
              }
            ]);
          }
        }
      ]);
      await runner.step(11, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(await __callMethod(await __callMethod(__readStatic(read, "read", ""), "partial", {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            dir: __stack.args.dir
          }
        }), "describe", {
          type: "positional",
          args: [__stack.locals.description]
        }), "rename", {
          type: "positional",
          args: [__stack.locals.toolName]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildSkillsTool threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildSkillsTool"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildSkillsTool",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildSkillsTool",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildSkillsTool = __AgencyFunction.create({
  name: "buildSkillsTool",
  module: "stdlib/skills.agency",
  fn: __buildSkillsTool_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "layout",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "name",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildSkillsTool",
    description: "No description provided.",
    schema: z.object({ "dir": z.string(), "layout": z.union([z.literal("flat"), z.literal("standard")]), "name": z.string().nullable().describe("Default: ") })
  },
  exported: false
}, __toolRegistry);
async function __skillsDir_impl(dir, layout = __UNSET, name = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __stack.args["layout"] = layout === __UNSET ? `standard` : layout;
  __stack.args["name"] = name === __UNSET ? `` : name;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "skillsDir", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("layout" in __overrides) {
      layout = __overrides["layout"];
      __stack.args["layout"] = layout;
    }
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "skillsDir",
            args: {
              dir,
              layout,
              name
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::skills::skillsDir", `Are you sure you want to scan this directory for skill files?`, {
            "dir": __stack.args.dir,
            "layout": __stack.args.layout
          }, "std::skills", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/skills.agency", scopeName: "skillsDir", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(buildSkillsTool, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.layout, __stack.args.name]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function skillsDir threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "skillsDir"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "skillsDir",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "skillsDir",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const skillsDir = __AgencyFunction.create({
  name: "skillsDir",
  module: "stdlib/skills.agency",
  fn: __skillsDir_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "layout",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "name",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "skillsDir",
    description: `Build a skills tool for an LLM over a directory of skills.

  @param dir - Directory containing the skills.
  @param layout - "standard" (default) for subdirectory-per-skill with SKILL.md, "flat" for a directory of loose Markdown files.
  @param name - Optional explicit tool name. Sanitized to alphanumerics/underscores and capped at 64 characters. Defaults to a name derived from \`dir\`; set this to override it \u2014 e.g. for a stable, readable name, or to disambiguate two tools whose derived names would collide.`,
    schema: z.object({ "dir": z.string(), "layout": z.union([z.literal("flat"), z.literal("standard")]).nullable().describe("Default: standard"), "name": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __docsSkill_impl(section) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["section"] = section;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "docsSkill", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("section" in __overrides) {
      section = __overrides["section"];
      __stack.args["section"] = section;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "docsSkill",
            args: {
              section
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(buildSkillsTool, {
          type: "positional",
          args: [await __call(_docsDir, {
            type: "positional",
            args: [__stack.args.section]
          }), `flat`]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function docsSkill threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "docsSkill"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "docsSkill",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "docsSkill",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const docsSkill = __AgencyFunction.create({
  name: "docsSkill",
  module: "stdlib/skills.agency",
  fn: __docsSkill_impl,
  params: [{
    name: "section",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "docsSkill",
    description: `Build a docs tool for an LLM over the packaged Agency documentation.
  "guide" serves the language guide (syntax, types, control flow);
  "cli" serves the CLI reference; "diagnostics" serves the type-checker
  diagnostic codes (AG####) with explanations and fixes. The returned tool
  lists every page in its description and lets the model read any one on
  demand.

  @param section - Which documentation set to serve: "guide", "cli", or "diagnostics".`,
    schema: z.object({ "section": z.union([z.literal("guide"), z.literal("cli"), z.literal("diagnostics")]) })
  },
  exported: true
}, __toolRegistry);
async function __stripFm_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "stripFm", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "stripFm",
            args: {
              raw
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => !await __callMethod(__stack.args.raw, "startsWith", {
            type: "positional",
            args: [`---
`]
          }),
          body: async (runner2) => {
            await runner2.ifElse(0, [
              {
                condition: async () => await __callMethod(__stack.args.raw, "endsWith", {
                  type: "positional",
                  args: [`
`]
                }),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __functionCompleted = true;
                    runner4.halt(await __callMethod(__stack.args.raw, "slice", {
                      type: "positional",
                      args: [0, __stack.args.raw.length - 1]
                    }));
                    return;
                  });
                }
              }
            ]);
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.args.raw);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __stack.locals.idx = await __callMethod(__stack.args.raw, "indexOf", {
          type: "positional",
          args: [`
---
`, 4]
        });
      });
      await runner.ifElse(3, [
        {
          condition: async () => __eq(__stack.locals.idx, -1),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(``);
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __stack.locals.body = await __callMethod(__stack.args.raw, "slice", {
          type: "positional",
          args: [__stack.locals.idx + 5]
        });
      });
      await runner.ifElse(5, [
        {
          condition: async () => await __callMethod(__stack.locals.body, "endsWith", {
            type: "positional",
            args: [`
`]
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = await __callMethod(__stack.locals.body, "slice", {
                type: "positional",
                args: [0, __stack.locals.body.length - 1]
              });
            });
          }
        }
      ]);
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.body);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function stripFm threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "stripFm"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "stripFm",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "stripFm",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const stripFm = __AgencyFunction.create({
  name: "stripFm",
  module: "stdlib/skills.agency",
  fn: __stripFm_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "stripFm",
    description: "No description provided.",
    schema: z.object({ "raw": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __commandsDir_impl(dir) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "commandsDir", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "commandsDir",
            args: {
              dir
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::skills::commandsDir", `Are you sure you want to scan this directory for slash command files?`, {
            "dir": __stack.args.dir
          }, "std::skills", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/skills.agency", scopeName: "commandsDir", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.pathsResult = await __tryCall(async () => await __call(_glob, {
          type: "positional",
          args: [`*.md`, __stack.args.dir, 500, []]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "commandsDir",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.pathsResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.pathsResult);
          return;
        }
      });
      await runner.ifElse(3, [
        {
          condition: async () => await isSuccess(__stack.locals.pathsResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.paths = __stack.locals.pathsResult.value;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await __call(map, {
                type: "named",
                positionalArgs: [__stack.locals.paths],
                namedArgs: {},
                blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/skills.agency", fn: async (p) => {
                  const __bsetup = setupFunction();
                  const __bstack = __bsetup.stack;
                  const __self2 = __bstack.locals;
                  const __bframe___block_1 = __bstack;
                  __bstack.args["p"] = p;
                  const runner4 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/skills.agency", scopeName: "__block_1" });
                  try {
                    await runner4.step(0, async (runner5) => {
                      __bstack.locals.raw = await __catchResult(await __tryCall(async () => await __call(_read, {
                        type: "positional",
                        args: [__stack.args.dir, p, 0, 0]
                      })), async () => {
                        return ``;
                      });
                      if (hasInterrupts(__bstack.locals.raw)) {
                        await getRuntimeContext().ctx.pendingPromises.awaitAll();
                        runner5.halt(__bstack.locals.raw);
                        return;
                      }
                    });
                    await runner4.step(1, async (runner5) => {
                      __bstack.locals.fm = await __catchResult(await __call(frontmatter, {
                        type: "positional",
                        args: [__bstack.locals.raw]
                      }), async () => {
                        return {};
                      });
                    });
                    await runner4.step(2, async (runner5) => {
                      __bstack.locals.descriptionRaw = __bstack.locals.fm.description ?? ``;
                    });
                    await runner4.step(3, async (runner5) => {
                      __bstack.locals.argHintRaw = __nn(__bstack.locals.fm[`argument-hint`]) ?? ``;
                    });
                    await runner4.step(4, async (runner5) => {
                      __bstack.locals.name = __bstack.args.p;
                    });
                    await runner4.ifElse(5, [
                      {
                        condition: async () => await __callMethod(__bstack.locals.name, "endsWith", {
                          type: "positional",
                          args: [`.md`]
                        }),
                        body: async (runner5) => {
                          await runner5.step(0, async (runner6) => {
                            __bstack.locals.name = await __callMethod(__bstack.locals.name, "slice", {
                              type: "positional",
                              args: [0, __bstack.locals.name.length - 3]
                            });
                          });
                        }
                      }
                    ]);
                    await runner4.step(6, async (runner5) => {
                      runner5.halt({
                        "name": __bstack.locals.name,
                        "description": `${__bstack.locals.descriptionRaw}`,
                        "argHint": `${__bstack.locals.argHintRaw}`,
                        "body": await __call(stripFm, {
                          type: "positional",
                          args: [__bstack.locals.raw]
                        })
                      });
                      return;
                    });
                    return runner4.halted ? runner4.haltResult : void 0;
                  } finally {
                    __bsetup.stateStack.pop();
                  }
                }, params: [{ name: "p", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
              }));
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt([]);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function commandsDir threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "commandsDir"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "commandsDir",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "commandsDir",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const commandsDir = __AgencyFunction.create({
  name: "commandsDir",
  module: "stdlib/skills.agency",
  fn: __commandsDir_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "commandsDir",
    description: `Discover .md files under \`dir\` and parse each as a slash-command
  template. Returns [] if \`dir\` is missing or empty.

  @param dir - Directory containing command markdown files. Pass an
    absolute path (e.g. cwd()/.claude/commands) to anchor at the
    project root rather than the calling module's directory.`,
    schema: z.object({ "dir": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __expandSlash_impl(msg, commands) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/skills.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["msg"] = msg;
  __stack.args["commands"] = commands;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/skills.agency", scopeName: "expandSlash", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("msg" in __overrides) {
      msg = __overrides["msg"];
      __stack.args["msg"] = msg;
    }
    if ("commands" in __overrides) {
      commands = __overrides["commands"];
      __stack.args["commands"] = commands;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "expandSlash",
            args: {
              msg,
              commands
            },
            moduleId: "stdlib/skills.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.trimmed = await __callMethod(__stack.args.msg, "trim", {
          type: "positional",
          args: []
        });
      });
      await runner.ifElse(2, [
        {
          condition: async () => !await __callMethod(__stack.locals.trimmed, "startsWith", {
            type: "positional",
            args: [`/`]
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.args.msg);
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.nameEnd = __stack.locals.trimmed.length;
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.i = 1;
      });
      await runner.whileLoop(5, async () => __stack.locals.i < __stack.locals.trimmed.length, async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.c = __nn(__stack.locals.trimmed[__stack.locals.i]);
        });
        await runner2.ifElse(1, [
          {
            condition: async () => __eq(__stack.locals.c, ` `) || __eq(__stack.locals.c, `	`) || __eq(__stack.locals.c, `
`),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.nameEnd = __stack.locals.i;
              });
              await runner3.step(1, async (runner4) => {
                __stack.locals.i = __stack.locals.trimmed.length;
              });
            }
          }
        ], async (runner3) => {
          await runner3.step(2, async (runner4) => {
            __stack.locals.i = __stack.locals.i + 1;
          });
        });
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.name = await __callMethod(__stack.locals.trimmed, "slice", {
          type: "positional",
          args: [1, __stack.locals.nameEnd]
        });
      });
      await runner.step(7, async (runner2) => {
        __stack.locals.rawArgs = ``;
      });
      await runner.ifElse(8, [
        {
          condition: async () => __stack.locals.nameEnd < __stack.locals.trimmed.length,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.rawArgs = await __callMethod(await __callMethod(__stack.locals.trimmed, "slice", {
                type: "positional",
                args: [__stack.locals.nameEnd + 1]
              }), "trim", {
                type: "positional",
                args: []
              });
            });
          }
        }
      ]);
      await runner.loop(9, async () => __stack.args.commands, async (cmd, _, runner2) => {
        await runner2.ifElse(0, [
          {
            condition: async () => __eq(cmd.name, __stack.locals.name),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.out = await __callMethod(cmd.body, "replaceAll", {
                  type: "positional",
                  args: [`$ARGUMENTS`, __stack.locals.rawArgs]
                });
              });
              await runner3.ifElse(1, [
                {
                  condition: async () => !await __callMethod(cmd.body, "includes", {
                    type: "positional",
                    args: [`$ARGUMENTS`]
                  }) && !__eq(__stack.locals.rawArgs, ``),
                  body: async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      __stack.locals.out = __stack.locals.out + `

ARGUMENTS: ${__stack.locals.rawArgs}`;
                    });
                  }
                }
              ]);
              await runner3.step(2, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(__stack.locals.out);
                return;
              });
            }
          }
        ]);
      });
      await runner.step(10, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.args.msg);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function expandSlash threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "expandSlash"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "expandSlash",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "expandSlash",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const expandSlash = __AgencyFunction.create({
  name: "expandSlash",
  module: "stdlib/skills.agency",
  fn: __expandSlash_impl,
  params: [{
    name: "msg",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "commands",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "expandSlash",
    description: `Expand a /command in \`msg\` into its command body. Returns the rendered
  body with $ARGUMENTS substituted, or \`msg\` unchanged if no command matches.

  @param msg - The raw input line (may have leading/trailing whitespace or newlines).
  @param commands - Array of command records to match against.`,
    schema: z.object({ "msg": z.string(), "commands": z.array(z.any()) })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/skills.agency:xmlEscape": { "1": { "line": 50, "col": 2 }, "2": { "line": 51, "col": 2 }, "3": { "line": 52, "col": 2 }, "4": { "line": 53, "col": 2 }, "5": { "line": 54, "col": 2 }, "6": { "line": 55, "col": 2 }, "7": { "line": 56, "col": 2 } }, "stdlib/skills.agency:renderEntry": { "1": { "line": 68, "col": 2 }, "2": { "line": 69, "col": 2 }, "3": { "line": 70, "col": 2 }, "4": { "line": 71, "col": 2 } }, "stdlib/skills.agency:flatEntry": { "1": { "line": 87, "col": 2 } }, "stdlib/skills.agency:sanitizeToolSegment": { "1": { "line": 106, "col": 2 }, "2": { "line": 107, "col": 2 }, "3": { "line": 110, "col": 2 }, "4": { "line": 113, "col": 2 }, "2.0": { "line": 108, "col": 4 }, "3.0": { "line": 111, "col": 4 } }, "stdlib/skills.agency:capToolName": { "1": { "line": 123, "col": 2 }, "2": { "line": 126, "col": 2 }, "3": { "line": 128, "col": 2 }, "4": { "line": 131, "col": 2 }, "1.0": { "line": 124, "col": 4 }, "3.0": { "line": 129, "col": 4 } }, "stdlib/skills.agency:skillToolName": { "1": { "line": 146, "col": 2 }, "2": { "line": 147, "col": 2 }, "3": { "line": 150, "col": 2 }, "2.0": { "line": 148, "col": 4 } }, "stdlib/skills.agency:standardEntry": { "1": { "line": 162, "col": 2 }, "2": { "line": 163, "col": 2 } }, "stdlib/skills.agency:buildSkillsTool": { "1": { "line": 187, "col": 2 }, "2": { "line": 188, "col": 2 }, "3": { "line": 191, "col": 2 }, "4": { "line": 192, "col": 2 }, "5": { "line": 193, "col": 2 }, "6": { "line": 204, "col": 2 }, "7": { "line": 205, "col": 2 }, "8": { "line": 206, "col": 2 }, "9": { "line": 210, "col": 2 }, "10": { "line": 211, "col": 2 }, "11": { "line": 219, "col": 2 }, "2.0": { "line": 189, "col": 4 }, "5.0": { "line": 193, "col": 2 }, "5.1": { "line": 194, "col": 4 }, "10.1": { "line": 214, "col": 4 }, "10.2.0": { "line": 216, "col": 6 }, "10.2": { "line": 215, "col": 4 } }, "stdlib/skills.agency:__block_0": { "5.1.0": { "line": 195, "col": 6 }, "5.1.1": { "line": 196, "col": 6 }, "5.1.2.0": { "line": 198, "col": 8 }, "5.1.2": { "line": 197, "col": 6 }, "5.1.3": { "line": 200, "col": 6 } }, "stdlib/skills.agency:skillsDir": { "1": { "line": 230, "col": 2 }, "2": { "line": 235, "col": 2 } }, "stdlib/skills.agency:docsSkill": { "2": { "line": 254, "col": 2 } }, "stdlib/skills.agency:stripFm": { "1": { "line": 277, "col": 2 }, "2": { "line": 283, "col": 2 }, "3": { "line": 284, "col": 2 }, "4": { "line": 287, "col": 2 }, "5": { "line": 288, "col": 2 }, "6": { "line": 291, "col": 2 }, "1.0.0": { "line": 279, "col": 6 }, "1.0": { "line": 278, "col": 4 }, "1.1": { "line": 281, "col": 4 }, "3.0": { "line": 285, "col": 4 }, "5.0": { "line": 289, "col": 4 } }, "stdlib/skills.agency:commandsDir": { "1": { "line": 333, "col": 2 }, "2": { "line": 337, "col": 2 }, "3": { "line": 338, "col": 2 }, "4": { "line": 361, "col": 2 }, "3.0": { "line": 338, "col": 2 }, "3.1": { "line": 339, "col": 4 } }, "stdlib/skills.agency:__block_1": { "3.1.0": { "line": 340, "col": 6 }, "3.1.1": { "line": 343, "col": 6 }, "3.1.2": { "line": 347, "col": 6 }, "3.1.3": { "line": 348, "col": 6 }, "3.1.4": { "line": 349, "col": 6 }, "3.1.5.0": { "line": 351, "col": 8 }, "3.1.5": { "line": 350, "col": 6 }, "3.1.6": { "line": 353, "col": 6 } }, "stdlib/skills.agency:expandSlash": { "1": { "line": 389, "col": 2 }, "2": { "line": 390, "col": 2 }, "3": { "line": 393, "col": 2 }, "4": { "line": 394, "col": 2 }, "5": { "line": 395, "col": 2 }, "6": { "line": 404, "col": 2 }, "7": { "line": 405, "col": 2 }, "8": { "line": 406, "col": 2 }, "9": { "line": 409, "col": 2 }, "10": { "line": 418, "col": 2 }, "2.0": { "line": 391, "col": 4 }, "5.0": { "line": 396, "col": 4 }, "5.1.0": { "line": 398, "col": 6 }, "5.1.1": { "line": 399, "col": 6 }, "5.1.2": { "line": 401, "col": 6 }, "5.1": { "line": 397, "col": 4 }, "8.0": { "line": 407, "col": 4 }, "9.0.0": { "line": 411, "col": 6 }, "9.0.1.0": { "line": 413, "col": 8 }, "9.0.1": { "line": 412, "col": 6 }, "9.0.2": { "line": 415, "col": 6 }, "9.0": { "line": 410, "col": 4 } } };
export {
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  buildSkillsTool,
  capToolName,
  commandsDir,
  stdin_default as default,
  docsSkill,
  expandSlash,
  flatEntry,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  reject,
  renderEntry,
  respondToInterrupts,
  rewindFrom,
  sanitizeToolSegment,
  skillToolName,
  skillsDir,
  standardEntry,
  stripFm,
  xmlEscape
};
