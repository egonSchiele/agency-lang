import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { getAgentCwd } from "agency-lang/stdlib/index.js";
import { _gitRun, _gitIsRepo, assertPathsContained, assertAllNotRestricted, assertBranchAllowed, statusArgs, logArgs, diffArgs, showArgs, branchListArgs, remoteListArgs, blameArgs, stashListArgs, addArgs, commitArgs, checkoutArgs, switchArgs, branchCreateArgs, branchDeleteArgs, stashPushArgs, stashPopArgs, restoreArgs, parseStatus, parseLog, parseDiff, parseBranchList, parseRemoteList, parseBlame, parseStashList } from "agency-lang/stdlib-lib/git.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  __registerGlobalsInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __eq,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/git.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(getAgentCwd);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/git.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/git.agency");
}
__registerGlobalsInit("stdlib/git.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const ChangeCode = z.union([z.literal("."), z.literal("M"), z.literal("A"), z.literal("D"), z.literal("R"), z.literal("C"), z.literal("U"), z.literal("T"), z.literal("?"), z.literal("!")]);
const FileStatus = z.object({ "path": z.string(), "index": ChangeCode, "worktree": ChangeCode, "renamedFrom": z.union([z.string(), z.null()]).optional().default(null) });
const GitStatus = z.object({ "branch": z.string(), "upstream": z.string(), "ahead": z.number(), "behind": z.number(), "entries": z.array(FileStatus) });
const GitCommit = z.object({ "sha": z.string(), "author": z.string(), "email": z.string(), "date": z.string(), "subject": z.string(), "body": z.string() });
const GitLog = z.object({ "commits": z.array(GitCommit) });
const FileDiff = z.object({ "path": z.string(), "status": ChangeCode, "additions": z.union([z.number(), z.null()]).optional().default(null), "deletions": z.union([z.number(), z.null()]).optional().default(null) });
const GitDiff = z.object({ "files": z.array(FileDiff), "patch": z.string() });
const GitBranch = z.object({ "name": z.string(), "current": z.boolean(), "upstream": z.string(), "sha": z.string() });
const BlameLine = z.object({ "sha": z.string(), "author": z.string(), "line": z.number(), "content": z.string() });
const GitRemote = z.object({ "name": z.string(), "url": z.string(), "direction": z.union([z.literal("fetch"), z.literal("push")]) });
const GitStash = z.object({ "ref": z.string(), "description": z.string() });
const GitRead = z.union([z.literal("std::git::status"), z.literal("std::git::log"), z.literal("std::git::diff"), z.literal("std::git::show"), z.literal("std::git::branchList"), z.literal("std::git::remoteList"), z.literal("std::git::blame"), z.literal("std::git::stashList")]);
const GitWrite = z.union([z.literal("std::git::add"), z.literal("std::git::commit"), z.literal("std::git::checkout"), z.literal("std::git::switch"), z.literal("std::git::branchCreate"), z.literal("std::git::branchDelete"), z.literal("std::git::stashPush"), z.literal("std::git::stashPop"), z.literal("std::git::restore")]);
const Git = z.union([GitRead, GitWrite]);
async function __repoDir_impl(cwd) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cwd"] = cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "repoDir", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "repoDir",
            args: {
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => !__eq(__stack.args.cwd, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.args.cwd);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(getAgentCwd, {
          type: "positional",
          args: []
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function repoDir threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "repoDir"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "repoDir",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "repoDir",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const repoDir = __AgencyFunction.create({
  name: "repoDir",
  module: "stdlib/git.agency",
  fn: __repoDir_impl,
  params: [{
    name: "cwd",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "repoDir",
    description: "No description provided.",
    schema: z.object({ "cwd": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __gitIsRepo_impl(cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitIsRepo", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitIsRepo",
            args: {
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::status", `Check whether this is a git repository`, {
            "cwd": __stack.locals.dir
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitIsRepo", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_gitIsRepo, {
          type: "positional",
          args: [__stack.locals.dir]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitIsRepo threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitIsRepo"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitIsRepo",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitIsRepo",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitIsRepo = __AgencyFunction.create({
  name: "gitIsRepo",
  module: "stdlib/git.agency",
  fn: __gitIsRepo_impl,
  params: [{
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitIsRepo",
    description: `True when \`cwd\` is inside a git work tree. Never fails: a directory that is not
  a git repository (or does not exist) returns false, so callers can guard on it
  before running other git tools.
  @param cwd - The directory to check. Defaults to the agent working directory.`,
    schema: z.object({ "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __gitStatus_impl(cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitStatus", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitStatus",
            args: {
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::status", `Show git status`, {
            "cwd": __stack.locals.dir
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitStatus", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(parseStatus, {
          type: "positional",
          args: [await __call(_gitRun, {
            type: "positional",
            args: [__stack.locals.dir, await __call(statusArgs, {
              type: "positional",
              args: []
            })]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitStatus threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitStatus"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitStatus",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitStatus",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitStatus = __AgencyFunction.create({
  name: "gitStatus",
  module: "stdlib/git.agency",
  fn: __gitStatus_impl,
  params: [{
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitStatus",
    description: `Show the working-tree status: current branch, ahead/behind counts, and
  changed files.
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __gitLog_impl(n = __UNSET, oneline = __UNSET, path2 = __UNSET, ref = __UNSET, author = __UNSET, allowedPaths = __UNSET, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["n"] = n === __UNSET ? 20 : n;
  __stack.args["oneline"] = oneline === __UNSET ? false : oneline;
  __stack.args["path"] = path2 === __UNSET ? `` : path2;
  __stack.args["ref"] = ref === __UNSET ? `` : ref;
  __stack.args["author"] = author === __UNSET ? `` : author;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitLog", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("n" in __overrides) {
      n = __overrides["n"];
      __stack.args["n"] = n;
    }
    if ("oneline" in __overrides) {
      oneline = __overrides["oneline"];
      __stack.args["oneline"] = oneline;
    }
    if ("path" in __overrides) {
      path2 = __overrides["path"];
      __stack.args["path"] = path2;
    }
    if ("ref" in __overrides) {
      ref = __overrides["ref"];
      __stack.args["ref"] = ref;
    }
    if ("author" in __overrides) {
      author = __overrides["author"];
      __stack.args["author"] = author;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitLog",
            args: {
              n,
              oneline,
              path: path2,
              ref,
              author,
              allowedPaths,
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.path, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(assertPathsContained, {
                type: "positional",
                args: [[__stack.args.path], __stack.args.allowedPaths, __stack.locals.dir]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_3);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::log", `Show git log`, {
            "cwd": __stack.locals.dir,
            "ref": __stack.args.ref,
            "path": __stack.args.path
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_3 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitLog", stepPath: "3" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(parseLog, {
          type: "positional",
          args: [await __call(_gitRun, {
            type: "positional",
            args: [__stack.locals.dir, await __call(logArgs, {
              type: "positional",
              args: [{
                "count": __stack.args.n,
                "oneline": __stack.args.oneline,
                "path": __stack.args.path,
                "ref": __stack.args.ref,
                "author": __stack.args.author
              }]
            })]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitLog threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitLog"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitLog",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitLog",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitLog = __AgencyFunction.create({
  name: "gitLog",
  module: "stdlib/git.agency",
  fn: __gitLog_impl,
  params: [{
    name: "n",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "oneline",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "path",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ref",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "author",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitLog",
    description: `Show commit history as structured commits.
  @param n - Max number of commits (default 20).
  @param oneline - Omit commit bodies.
  @param path - Limit to commits touching this path (may not start with "-").
  @param ref - Start from this revision (e.g. HEAD~5, a branch, a sha).
  @param author - Filter by author substring.
  @param allowedPaths - If non-empty, path must fall under one of these prefixes.
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "n": z.number().nullable().describe("Default: 20"), "oneline": z.boolean().nullable().describe("Default: false"), "path": z.string().nullable().describe("Default: "), "ref": z.string().nullable().describe("Default: "), "author": z.string().nullable().describe("Default: "), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __gitDiff_impl(ref = __UNSET, ref2 = __UNSET, staged = __UNSET, path2 = __UNSET, allowedPaths = __UNSET, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["ref"] = ref === __UNSET ? `` : ref;
  __stack.args["ref2"] = ref2 === __UNSET ? `` : ref2;
  __stack.args["staged"] = staged === __UNSET ? false : staged;
  __stack.args["path"] = path2 === __UNSET ? `` : path2;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitDiff", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("ref" in __overrides) {
      ref = __overrides["ref"];
      __stack.args["ref"] = ref;
    }
    if ("ref2" in __overrides) {
      ref2 = __overrides["ref2"];
      __stack.args["ref2"] = ref2;
    }
    if ("staged" in __overrides) {
      staged = __overrides["staged"];
      __stack.args["staged"] = staged;
    }
    if ("path" in __overrides) {
      path2 = __overrides["path"];
      __stack.args["path"] = path2;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitDiff",
            args: {
              ref,
              ref2,
              staged,
              path: path2,
              allowedPaths,
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.path, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(assertPathsContained, {
                type: "positional",
                args: [[__stack.args.path], __stack.args.allowedPaths, __stack.locals.dir]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_3);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::diff", `Show git diff`, {
            "cwd": __stack.locals.dir,
            "ref": __stack.args.ref,
            "ref2": __stack.args.ref2,
            "staged": __stack.args.staged,
            "path": __stack.args.path
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_3 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitDiff", stepPath: "3" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(parseDiff, {
          type: "positional",
          args: [await __call(_gitRun, {
            type: "positional",
            args: [__stack.locals.dir, await __call(diffArgs, {
              type: "positional",
              args: [{
                "ref": __stack.args.ref,
                "ref2": __stack.args.ref2,
                "staged": __stack.args.staged,
                "path": __stack.args.path
              }]
            })]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitDiff threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitDiff"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitDiff",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitDiff",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitDiff = __AgencyFunction.create({
  name: "gitDiff",
  module: "stdlib/git.agency",
  fn: __gitDiff_impl,
  params: [{
    name: "ref",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ref2",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "staged",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "path",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitDiff",
    description: `Show a diff as a structured per-file summary plus the raw unified patch.
  @param ref - Compare against this revision (default: working tree vs index).
  @param ref2 - Optional second revision to diff ref..ref2.
  @param staged - Diff the index (staged changes) instead of the working tree.
  @param path - Limit the diff to this path (may not start with "-").
  @param allowedPaths - If non-empty, path must fall under one of these prefixes.
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "ref": z.string().nullable().describe("Default: "), "ref2": z.string().nullable().describe("Default: "), "staged": z.boolean().nullable().describe("Default: false"), "path": z.string().nullable().describe("Default: "), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __gitShow_impl(ref = __UNSET, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["ref"] = ref === __UNSET ? `HEAD` : ref;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitShow", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("ref" in __overrides) {
      ref = __overrides["ref"];
      __stack.args["ref"] = ref;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitShow",
            args: {
              ref,
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::show", `Show git commit`, {
            "cwd": __stack.locals.dir,
            "ref": __stack.args.ref
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitShow", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(parseDiff, {
          type: "positional",
          args: [await __call(_gitRun, {
            type: "positional",
            args: [__stack.locals.dir, await __call(showArgs, {
              type: "positional",
              args: [{
                "ref": __stack.args.ref
              }]
            })]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitShow threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitShow"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitShow",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitShow",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitShow = __AgencyFunction.create({
  name: "gitShow",
  module: "stdlib/git.agency",
  fn: __gitShow_impl,
  params: [{
    name: "ref",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitShow",
    description: `Show a commit as a structured per-file summary plus the raw patch. Line
  counts are approximate for merge commits (combined diffs are not counted).
  @param ref - The revision to show (default HEAD).
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "ref": z.string().nullable().describe("Default: HEAD"), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __gitBranchList_impl(cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitBranchList", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitBranchList",
            args: {
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::branchList", `List git branches`, {
            "cwd": __stack.locals.dir
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitBranchList", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(parseBranchList, {
          type: "positional",
          args: [await __call(_gitRun, {
            type: "positional",
            args: [__stack.locals.dir, await __call(branchListArgs, {
              type: "positional",
              args: []
            })]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitBranchList threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitBranchList"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitBranchList",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitBranchList",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitBranchList = __AgencyFunction.create({
  name: "gitBranchList",
  module: "stdlib/git.agency",
  fn: __gitBranchList_impl,
  params: [{
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitBranchList",
    description: `List local branches with their current-marker, upstream, and sha.
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __gitRemoteList_impl(cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitRemoteList", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitRemoteList",
            args: {
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::remoteList", `List git remotes`, {
            "cwd": __stack.locals.dir
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitRemoteList", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(parseRemoteList, {
          type: "positional",
          args: [await __call(_gitRun, {
            type: "positional",
            args: [__stack.locals.dir, await __call(remoteListArgs, {
              type: "positional",
              args: []
            })]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitRemoteList threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitRemoteList"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitRemoteList",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitRemoteList",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitRemoteList = __AgencyFunction.create({
  name: "gitRemoteList",
  module: "stdlib/git.agency",
  fn: __gitRemoteList_impl,
  params: [{
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitRemoteList",
    description: `List configured remotes with their fetch/push URLs.
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __gitBlame_impl(path2, ref = __UNSET, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["path"] = path2;
  __stack.args["ref"] = ref === __UNSET ? `` : ref;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitBlame", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("path" in __overrides) {
      path2 = __overrides["path"];
      __stack.args["path"] = path2;
    }
    if ("ref" in __overrides) {
      ref = __overrides["ref"];
      __stack.args["ref"] = ref;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitBlame",
            args: {
              path: path2,
              ref,
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::blame", `Show git blame`, {
            "cwd": __stack.locals.dir,
            "path": __stack.args.path
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitBlame", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(parseBlame, {
          type: "positional",
          args: [await __call(_gitRun, {
            type: "positional",
            args: [__stack.locals.dir, await __call(blameArgs, {
              type: "positional",
              args: [{
                "path": __stack.args.path,
                "ref": __stack.args.ref
              }]
            })]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitBlame threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitBlame"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitBlame",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitBlame",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitBlame = __AgencyFunction.create({
  name: "gitBlame",
  module: "stdlib/git.agency",
  fn: __gitBlame_impl,
  params: [{
    name: "path",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ref",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitBlame",
    description: `Show line-by-line authorship for a file.
  @param path - The file to blame (may not start with "-").
  @param ref - Optional revision to blame at.
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "path": z.string(), "ref": z.string().nullable().describe("Default: "), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __gitStashList_impl(cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitStashList", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitStashList",
            args: {
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::stashList", `List git stashes`, {
            "cwd": __stack.locals.dir
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitStashList", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(parseStashList, {
          type: "positional",
          args: [await __call(_gitRun, {
            type: "positional",
            args: [__stack.locals.dir, await __call(stashListArgs, {
              type: "positional",
              args: []
            })]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitStashList threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitStashList"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitStashList",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitStashList",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitStashList = __AgencyFunction.create({
  name: "gitStashList",
  module: "stdlib/git.agency",
  fn: __gitStashList_impl,
  params: [{
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitStashList",
    description: `List stashes with their ref and description.
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __gitAdd_impl(paths = __UNSET, all = __UNSET, allowedPaths = __UNSET, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["paths"] = paths === __UNSET ? [] : paths;
  __stack.args["all"] = all === __UNSET ? false : all;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitAdd", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("paths" in __overrides) {
      paths = __overrides["paths"];
      __stack.args["paths"] = paths;
    }
    if ("all" in __overrides) {
      all = __overrides["all"];
      __stack.args["all"] = all;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitAdd",
            args: {
              paths,
              all,
              allowedPaths,
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __funcResult = await __call(assertAllNotRestricted, {
          type: "positional",
          args: [__stack.args.all, __stack.args.allowedPaths]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        const __funcResult = await __call(assertPathsContained, {
          type: "positional",
          args: [__stack.args.paths, __stack.args.allowedPaths, __stack.locals.dir]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_4);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::add", `Stage changes`, {
            "cwd": __stack.locals.dir,
            "paths": __stack.args.paths,
            "all": __stack.args.all
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_4 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitAdd", stepPath: "4" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(5, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(6, async (runner2) => {
        const __funcResult = await __call(_gitRun, {
          type: "positional",
          args: [__stack.locals.dir, await __call(addArgs, {
            type: "positional",
            args: [{
              "paths": __stack.args.paths,
              "all": __stack.args.all
            }]
          })]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
      });
      await runner.step(7, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`Staged changes`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitAdd threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitAdd"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitAdd",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitAdd",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitAdd = __AgencyFunction.create({
  name: "gitAdd",
  module: "stdlib/git.agency",
  fn: __gitAdd_impl,
  params: [{
    name: "paths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "all",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitAdd",
    description: `Stage changes for commit.
  @param paths - Files to stage (may not start with "-").
  @param all - Stage every change in the repo (git add -A).
  @param allowedPaths - If non-empty, each path must fall under one of these prefixes.
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "paths": z.array(z.string()).nullable().describe("Default: []"), "all": z.boolean().nullable().describe("Default: false"), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __gitCommit_impl(message, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["message"] = message;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitCommit", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("message" in __overrides) {
      message = __overrides["message"];
      __stack.args["message"] = message;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitCommit",
            args: {
              message,
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::commit", `Create commit: ${__stack.args.message}`, {
            "cwd": __stack.locals.dir,
            "message": __stack.args.message
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitCommit", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_gitRun, {
          type: "positional",
          args: [__stack.locals.dir, await __call(commitArgs, {
            type: "positional",
            args: [{
              "message": __stack.args.message
            }]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitCommit threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitCommit"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitCommit",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitCommit",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitCommit = __AgencyFunction.create({
  name: "gitCommit",
  module: "stdlib/git.agency",
  fn: __gitCommit_impl,
  params: [{
    name: "message",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitCommit",
    description: `Create a commit from the staged changes.
  @param message - The commit message.
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "message": z.string(), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __gitCheckout_impl(target, force = __UNSET, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["target"] = target;
  __stack.args["force"] = force === __UNSET ? false : force;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitCheckout", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("target" in __overrides) {
      target = __overrides["target"];
      __stack.args["target"] = target;
    }
    if ("force" in __overrides) {
      force = __overrides["force"];
      __stack.args["force"] = force;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitCheckout",
            args: {
              target,
              force,
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.message = `Checkout ${__stack.args.target}`;
      });
      await runner.ifElse(3, [
        {
          condition: async () => __stack.args.force,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.message = `Force checkout ${__stack.args.target} (DISCARDS local changes, cannot be undone)`;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_4);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::checkout", __stack.locals.message, {
            "cwd": __stack.locals.dir,
            "target": __stack.args.target,
            "force": __stack.args.force
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_4 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitCheckout", stepPath: "4" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(5, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_gitRun, {
          type: "positional",
          args: [__stack.locals.dir, await __call(checkoutArgs, {
            type: "positional",
            args: [{
              "target": __stack.args.target,
              "force": __stack.args.force
            }]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitCheckout threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitCheckout"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitCheckout",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitCheckout",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitCheckout = __AgencyFunction.create({
  name: "gitCheckout",
  module: "stdlib/git.agency",
  fn: __gitCheckout_impl,
  params: [{
    name: "target",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "force",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitCheckout",
    description: `Check out a branch, commit, or path.
  @param target - The branch/commit/path (may not start with "-").
  @param force - Discard local changes while checking out (git checkout --force).
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "target": z.string(), "force": z.boolean().nullable().describe("Default: false"), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __gitSwitch_impl(branch, create = __UNSET, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["branch"] = branch;
  __stack.args["create"] = create === __UNSET ? false : create;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitSwitch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("branch" in __overrides) {
      branch = __overrides["branch"];
      __stack.args["branch"] = branch;
    }
    if ("create" in __overrides) {
      create = __overrides["create"];
      __stack.args["create"] = create;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitSwitch",
            args: {
              branch,
              create,
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::switch", `Switch to branch ${__stack.args.branch}`, {
            "cwd": __stack.locals.dir,
            "branch": __stack.args.branch,
            "create": __stack.args.create
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitSwitch", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_gitRun, {
          type: "positional",
          args: [__stack.locals.dir, await __call(switchArgs, {
            type: "positional",
            args: [{
              "branch": __stack.args.branch,
              "create": __stack.args.create
            }]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitSwitch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitSwitch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitSwitch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitSwitch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitSwitch = __AgencyFunction.create({
  name: "gitSwitch",
  module: "stdlib/git.agency",
  fn: __gitSwitch_impl,
  params: [{
    name: "branch",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "create",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitSwitch",
    description: `Switch to a branch.
  @param branch - The branch to switch to (may not start with "-").
  @param create - Create the branch first (git switch -c).
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "branch": z.string(), "create": z.boolean().nullable().describe("Default: false"), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __gitBranchCreate_impl(branch, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["branch"] = branch;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitBranchCreate", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("branch" in __overrides) {
      branch = __overrides["branch"];
      __stack.args["branch"] = branch;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitBranchCreate",
            args: {
              branch,
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::branchCreate", `Create branch ${__stack.args.branch}`, {
            "cwd": __stack.locals.dir,
            "branch": __stack.args.branch
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitBranchCreate", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(4, async (runner2) => {
        const __funcResult = await __call(_gitRun, {
          type: "positional",
          args: [__stack.locals.dir, await __call(branchCreateArgs, {
            type: "positional",
            args: [{
              "branch": __stack.args.branch
            }]
          })]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
      });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`Created branch ${__stack.args.branch}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitBranchCreate threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitBranchCreate"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitBranchCreate",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitBranchCreate",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitBranchCreate = __AgencyFunction.create({
  name: "gitBranchCreate",
  module: "stdlib/git.agency",
  fn: __gitBranchCreate_impl,
  params: [{
    name: "branch",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitBranchCreate",
    description: `Create a new branch at HEAD (does not switch to it).
  @param branch - The new branch name (may not start with "-").
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "branch": z.string(), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __gitBranchDelete_impl(branch, force = __UNSET, protectedBranches = __UNSET, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["branch"] = branch;
  __stack.args["force"] = force === __UNSET ? false : force;
  __stack.args["protectedBranches"] = protectedBranches === __UNSET ? [] : protectedBranches;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitBranchDelete", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("branch" in __overrides) {
      branch = __overrides["branch"];
      __stack.args["branch"] = branch;
    }
    if ("force" in __overrides) {
      force = __overrides["force"];
      __stack.args["force"] = force;
    }
    if ("protectedBranches" in __overrides) {
      protectedBranches = __overrides["protectedBranches"];
      __stack.args["protectedBranches"] = protectedBranches;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitBranchDelete",
            args: {
              branch,
              force,
              protectedBranches,
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __funcResult = await __call(assertBranchAllowed, {
          type: "positional",
          args: [__stack.args.branch, __stack.args.protectedBranches]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.message = `Delete branch ${__stack.args.branch}`;
      });
      await runner.ifElse(4, [
        {
          condition: async () => __stack.args.force,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.message = `Force-delete branch ${__stack.args.branch} (may discard unmerged commits, cannot be undone)`;
            });
          }
        }
      ]);
      await runner.step(5, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_5);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::branchDelete", __stack.locals.message, {
            "cwd": __stack.locals.dir,
            "branch": __stack.args.branch,
            "force": __stack.args.force
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_5 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitBranchDelete", stepPath: "5" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(6, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(7, async (runner2) => {
        const __funcResult = await __call(_gitRun, {
          type: "positional",
          args: [__stack.locals.dir, await __call(branchDeleteArgs, {
            type: "positional",
            args: [{
              "branch": __stack.args.branch,
              "force": __stack.args.force,
              "protectedBranches": __stack.args.protectedBranches
            }]
          })]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
      });
      await runner.step(8, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`Deleted branch ${__stack.args.branch}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitBranchDelete threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitBranchDelete"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitBranchDelete",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitBranchDelete",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitBranchDelete = __AgencyFunction.create({
  name: "gitBranchDelete",
  module: "stdlib/git.agency",
  fn: __gitBranchDelete_impl,
  params: [{
    name: "branch",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "force",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "protectedBranches",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitBranchDelete",
    description: `Delete a local branch.
  @param branch - The branch to delete (may not start with "-").
  @param force - Delete even if the branch is unmerged (git branch -D).
  @param protectedBranches - Branch names that may never be deleted (e.g. ["main", "master"]).
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "branch": z.string(), "force": z.boolean().nullable().describe("Default: false"), "protectedBranches": z.array(z.string()).nullable().describe("Default: []"), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __gitStashPush_impl(message = __UNSET, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["message"] = message === __UNSET ? `` : message;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitStashPush", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("message" in __overrides) {
      message = __overrides["message"];
      __stack.args["message"] = message;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitStashPush",
            args: {
              message,
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::stashPush", `Stash changes`, {
            "cwd": __stack.locals.dir,
            "message": __stack.args.message
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitStashPush", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_gitRun, {
          type: "positional",
          args: [__stack.locals.dir, await __call(stashPushArgs, {
            type: "positional",
            args: [{
              "message": __stack.args.message
            }]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitStashPush threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitStashPush"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitStashPush",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitStashPush",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitStashPush = __AgencyFunction.create({
  name: "gitStashPush",
  module: "stdlib/git.agency",
  fn: __gitStashPush_impl,
  params: [{
    name: "message",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitStashPush",
    description: `Stash the working-tree changes.
  @param message - Optional stash message.
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "message": z.string().nullable().describe("Default: "), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __gitStashPop_impl(cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitStashPop", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitStashPop",
            args: {
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::stashPop", `Pop the latest stash`, {
            "cwd": __stack.locals.dir
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitStashPop", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_gitRun, {
          type: "positional",
          args: [__stack.locals.dir, await __call(stashPopArgs, {
            type: "positional",
            args: []
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitStashPop threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitStashPop"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitStashPop",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitStashPop",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitStashPop = __AgencyFunction.create({
  name: "gitStashPop",
  module: "stdlib/git.agency",
  fn: __gitStashPop_impl,
  params: [{
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitStashPop",
    description: `Apply and drop the most recent stash.
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __gitRestore_impl(paths, staged = __UNSET, allowedPaths = __UNSET, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/git.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["paths"] = paths;
  __stack.args["staged"] = staged === __UNSET ? false : staged;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/git.agency", scopeName: "gitRestore", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("paths" in __overrides) {
      paths = __overrides["paths"];
      __stack.args["paths"] = paths;
    }
    if ("staged" in __overrides) {
      staged = __overrides["staged"];
      __stack.args["staged"] = staged;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "gitRestore",
            args: {
              paths,
              staged,
              allowedPaths,
              cwd
            },
            moduleId: "stdlib/git.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.dir = await __call(repoDir, {
          type: "positional",
          args: [__stack.args.cwd]
        });
        if (hasInterrupts(__stack.locals.dir)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.dir);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        const __funcResult = await __call(assertPathsContained, {
          type: "positional",
          args: [__stack.args.paths, __stack.args.allowedPaths, __stack.locals.dir]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.message = `Discard working-tree changes to ${__stack.args.paths.length} file(s) (cannot be undone)`;
      });
      await runner.ifElse(4, [
        {
          condition: async () => __stack.args.staged,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.message = `Unstage ${__stack.args.paths.length} file(s)`;
            });
          }
        }
      ]);
      await runner.step(5, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_5);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::git::restore", __stack.locals.message, {
            "cwd": __stack.locals.dir,
            "paths": __stack.args.paths,
            "staged": __stack.args.staged
          }, "std::git", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_5 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/git.agency", scopeName: "gitRestore", stepPath: "5" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(6, async (runner2) => {
        __self.__destructiveRan = true;
      });
      await runner.step(7, async (runner2) => {
        const __funcResult = await __call(_gitRun, {
          type: "positional",
          args: [__stack.locals.dir, await __call(restoreArgs, {
            type: "positional",
            args: [{
              "paths": __stack.args.paths,
              "staged": __stack.args.staged
            }]
          })]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
      });
      await runner.step(8, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`Restored ${__stack.args.paths.length} file(s)`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function gitRestore threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "gitRestore"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "gitRestore",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "gitRestore",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const gitRestore = __AgencyFunction.create({
  name: "gitRestore",
  module: "stdlib/git.agency",
  fn: __gitRestore_impl,
  params: [{
    name: "paths",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "staged",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "gitRestore",
    description: `Restore files to a previous state.
  @param paths - Files to restore (may not start with "-").
  @param staged - Unstage the files instead of discarding working-tree changes.
  @param allowedPaths - If non-empty, each path must fall under one of these prefixes.
  @param cwd - The git repo directory. Defaults to the agent working directory. Pass an absolute path to target a different repo.`,
    schema: z.object({ "paths": z.array(z.string()), "staged": z.boolean().nullable().describe("Default: false"), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/git.agency:repoDir": { "1": { "line": 126, "col": 2 }, "2": { "line": 129, "col": 2 }, "1.0": { "line": 127, "col": 4 } }, "stdlib/git.agency:gitIsRepo": { "1": { "line": 141, "col": 2 }, "2": { "line": 142, "col": 2 }, "3": { "line": 143, "col": 2 } }, "stdlib/git.agency:gitStatus": { "1": { "line": 152, "col": 2 }, "2": { "line": 153, "col": 2 }, "3": { "line": 154, "col": 2 } }, "stdlib/git.agency:gitLog": { "1": { "line": 174, "col": 2 }, "2": { "line": 175, "col": 2 }, "3": { "line": 178, "col": 2 }, "4": { "line": 179, "col": 2 }, "2.0": { "line": 176, "col": 4 } }, "stdlib/git.agency:gitDiff": { "1": { "line": 197, "col": 2 }, "2": { "line": 198, "col": 2 }, "3": { "line": 201, "col": 2 }, "4": { "line": 202, "col": 2 }, "2.0": { "line": 199, "col": 4 } }, "stdlib/git.agency:gitShow": { "1": { "line": 212, "col": 2 }, "2": { "line": 213, "col": 2 }, "3": { "line": 214, "col": 2 } }, "stdlib/git.agency:gitBranchList": { "1": { "line": 222, "col": 2 }, "2": { "line": 223, "col": 2 }, "3": { "line": 224, "col": 2 } }, "stdlib/git.agency:gitRemoteList": { "1": { "line": 232, "col": 2 }, "2": { "line": 233, "col": 2 }, "3": { "line": 234, "col": 2 } }, "stdlib/git.agency:gitBlame": { "1": { "line": 244, "col": 2 }, "2": { "line": 245, "col": 2 }, "3": { "line": 246, "col": 2 } }, "stdlib/git.agency:gitStashList": { "1": { "line": 254, "col": 2 }, "2": { "line": 255, "col": 2 }, "3": { "line": 256, "col": 2 } }, "stdlib/git.agency:gitAdd": { "1": { "line": 272, "col": 2 }, "2": { "line": 273, "col": 2 }, "3": { "line": 274, "col": 2 }, "4": { "line": 275, "col": 2 }, "6": { "line": 277, "col": 4 }, "7": { "line": 278, "col": 4 } }, "stdlib/git.agency:gitCommit": { "1": { "line": 288, "col": 2 }, "2": { "line": 289, "col": 2 }, "4": { "line": 291, "col": 4 } }, "stdlib/git.agency:gitCheckout": { "1": { "line": 303, "col": 2 }, "2": { "line": 304, "col": 2 }, "3": { "line": 305, "col": 2 }, "4": { "line": 308, "col": 2 }, "6": { "line": 310, "col": 4 }, "3.0": { "line": 306, "col": 4 } }, "stdlib/git.agency:gitSwitch": { "1": { "line": 321, "col": 2 }, "2": { "line": 322, "col": 2 }, "4": { "line": 324, "col": 4 } }, "stdlib/git.agency:gitBranchCreate": { "1": { "line": 334, "col": 2 }, "2": { "line": 335, "col": 2 }, "4": { "line": 337, "col": 4 }, "5": { "line": 338, "col": 4 } }, "stdlib/git.agency:gitBranchDelete": { "1": { "line": 352, "col": 2 }, "2": { "line": 353, "col": 2 }, "3": { "line": 354, "col": 2 }, "4": { "line": 355, "col": 2 }, "5": { "line": 358, "col": 2 }, "7": { "line": 360, "col": 4 }, "8": { "line": 361, "col": 4 }, "4.0": { "line": 356, "col": 4 } }, "stdlib/git.agency:gitStashPush": { "1": { "line": 371, "col": 2 }, "2": { "line": 372, "col": 2 }, "4": { "line": 374, "col": 4 } }, "stdlib/git.agency:gitStashPop": { "1": { "line": 383, "col": 2 }, "2": { "line": 384, "col": 2 }, "4": { "line": 386, "col": 4 } }, "stdlib/git.agency:gitRestore": { "1": { "line": 400, "col": 2 }, "2": { "line": 401, "col": 2 }, "3": { "line": 402, "col": 2 }, "4": { "line": 403, "col": 2 }, "5": { "line": 406, "col": 2 }, "7": { "line": 408, "col": 4 }, "8": { "line": 409, "col": 4 }, "4.0": { "line": 404, "col": 4 } } };
export {
  BlameLine,
  ChangeCode,
  FileDiff,
  FileStatus,
  Git,
  GitBranch,
  GitCommit,
  GitDiff,
  GitLog,
  GitRead,
  GitRemote,
  GitStash,
  GitStatus,
  GitWrite,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  stdin_default as default,
  gitAdd,
  gitBlame,
  gitBranchCreate,
  gitBranchDelete,
  gitBranchList,
  gitCheckout,
  gitCommit,
  gitDiff,
  gitIsRepo,
  gitLog,
  gitRemoteList,
  gitRestore,
  gitShow,
  gitStashList,
  gitStashPop,
  gitStashPush,
  gitStatus,
  gitSwitch,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  reject,
  repoDir,
  respondToInterrupts,
  rewindFrom
};
