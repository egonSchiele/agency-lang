import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { ls, glob, grep, exec } from "agency-lang/stdlib/shell.js";
import { _compile, _compileFile, _typecheck, _typecheckFile, _getEffects, _parseAST, _writeAST, _format, _formatFile, _walkAST, _getNodesOfType, _filterImports, _subprocessDepth } from "agency-lang/stdlib-lib/agency.js";
import { VERSION } from "agency-lang/stdlib-lib/version.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  success,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __tryCall,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/agency.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(ls);
__registerTool(glob);
__registerTool(grep);
__registerTool(exec);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/agency.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/agency.agency");
}
__registerGlobalsInit("stdlib/agency.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/agency.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const CompiledProgram = z.object({ "moduleId": z.string() });
const SourceLocation = z.object({ "line": z.number(), "col": z.number(), "start": z.number(), "end": z.number() });
const TypeCheckDiagnostic = z.object({ "code": z.string(), "severity": z.string(), "message": z.string(), "loc": z.union([SourceLocation, z.null()]).optional().default(null), "params": z.record(z.string(), z.union([z.string(), z.number()])) });
const TypeCheckReport = z.object({ "errors": z.array(TypeCheckDiagnostic), "warnings": z.array(TypeCheckDiagnostic) });
async function __compile_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "compile", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "compile",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_compile, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "compile",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "compile");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function compile threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "compile"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "compile",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "compile",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const compile = __AgencyFunction.create({
  name: "compile",
  module: "stdlib/agency.agency",
  fn: __compile_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "compile",
    description: `Compile Agency source code. Returns a CompiledProgram on success, or a failure with compilation errors. Only standard library (\`std::\`) imports are allowed in the compiled code.

  @param source - Agency source code as a string`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __run_impl(compiled, node, args = __UNSET, wallClock = __UNSET, memory = __UNSET, ipcPayload = __UNSET, stdout = __UNSET, logFile = __UNSET, cwd = __UNSET, maxDepth = __UNSET, maxCost = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["compiled"] = compiled;
  __stack.args["node"] = node;
  __stack.args["args"] = args === __UNSET ? {} : args;
  __stack.args["wallClock"] = wallClock === __UNSET ? 6e4 : wallClock;
  __stack.args["memory"] = memory === __UNSET ? 536870912 : memory;
  __stack.args["ipcPayload"] = ipcPayload === __UNSET ? 104857600 : ipcPayload;
  __stack.args["stdout"] = stdout === __UNSET ? 1048576 : stdout;
  __stack.args["logFile"] = logFile === __UNSET ? `` : logFile;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __stack.args["maxDepth"] = maxDepth === __UNSET ? 5 : maxDepth;
  __stack.args["maxCost"] = maxCost === __UNSET ? null : maxCost;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "run", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("compiled" in __overrides) {
      compiled = __overrides["compiled"];
      __stack.args["compiled"] = compiled;
    }
    if ("node" in __overrides) {
      node = __overrides["node"];
      __stack.args["node"] = node;
    }
    if ("args" in __overrides) {
      args = __overrides["args"];
      __stack.args["args"] = args;
    }
    if ("wallClock" in __overrides) {
      wallClock = __overrides["wallClock"];
      __stack.args["wallClock"] = wallClock;
    }
    if ("memory" in __overrides) {
      memory = __overrides["memory"];
      __stack.args["memory"] = memory;
    }
    if ("ipcPayload" in __overrides) {
      ipcPayload = __overrides["ipcPayload"];
      __stack.args["ipcPayload"] = ipcPayload;
    }
    if ("stdout" in __overrides) {
      stdout = __overrides["stdout"];
      __stack.args["stdout"] = stdout;
    }
    if ("logFile" in __overrides) {
      logFile = __overrides["logFile"];
      __stack.args["logFile"] = logFile;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
    if ("maxDepth" in __overrides) {
      maxDepth = __overrides["maxDepth"];
      __stack.args["maxDepth"] = maxDepth;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "run",
            args: {
              compiled,
              node,
              args,
              wallClock,
              memory,
              ipcPayload,
              stdout,
              logFile,
              cwd,
              maxDepth,
              maxCost
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.configOverrides = null;
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.logFile, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.configOverrides = {
                "observability": true,
                "log": {
                  "logFile": __stack.args.logFile
                }
              };
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_3);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::run", `Running agent-generated code in subprocess`, {
            "moduleId": __stack.args.compiled.moduleId,
            "node": __stack.args.node,
            "args": __stack.args.args,
            "limits": {
              "wallClock": __stack.args.wallClock,
              "memory": __stack.args.memory,
              "ipcPayload": __stack.args.ipcPayload,
              "stdout": __stack.args.stdout,
              "maxCost": __stack.args.maxCost
            },
            "cwd": __stack.args.cwd,
            "logFile": __stack.args.logFile,
            "depth": await __call(_subprocessDepth, {
              type: "positional",
              args: []
            }) + 1
          }, "std::agency", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_3 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/agency.agency", scopeName: "run", stepPath: "3" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.NO_COST_CAP = -1;
      });
      await runner.ifElse(5, [
        {
          condition: async () => !__eq(__stack.args.maxCost, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.__ifbranch_3 = __stack.args.maxCost;
            });
            await runner2.step(1, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__ifbranch_3);
              return;
            });
          }
        }
      ], async (runner2) => {
        await runner2.step(2, async (runner3) => {
          __stack.locals.__ifbranch_2 = __stack.locals.NO_COST_CAP;
        });
        await runner2.step(3, async (runner3) => {
          runner3.exitMatch(1, __stack.locals.__ifbranch_2);
          return;
        });
      }, { matchId: 1 });
      await runner.step(6, async (runner2) => {
        __stack.locals.cap = __nn(__stack.locals.__matchval_1);
      });
      await runner.step(7, async (runner2) => {
        __stack.locals.guarded = await __call(_guard, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            cost: __stack.locals.cap
          },
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/agency.agency", fn: async () => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agency.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(await __tryCall(async () => await __call(_run, {
                  type: "positional",
                  args: [__stack.args.compiled, __stack.args.node, __stack.args.args, __stack.args.wallClock, __stack.args.memory, __stack.args.ipcPayload, __stack.args.stdout, __stack.locals.configOverrides, __stack.args.cwd, __stack.args.maxDepth]
                })));
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_0");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.guarded)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.guarded);
          return;
        }
        if (isAborted(__stack.locals.guarded)) {
          runner2.halt(__stack.locals.guarded.carryThrough(__stack, "run"));
          return;
        }
      });
      await runner.ifElse(8, [
        {
          condition: async () => await isFailure(__stack.locals.guarded),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.err = __stack.locals.guarded.error;
            });
            await runner2.ifElse(1, [
              {
                condition: async () => __eq(__stack.locals.err.type, `guardFailure`),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                  });
                  await runner3.step(1, async (runner4) => {
                    __functionCompleted = true;
                    runner4.halt(failure({
                      "reason": `limit_exceeded`,
                      "limit": `cost`,
                      "threshold": __stack.args.maxCost,
                      "value": __stack.locals.err.actualCost,
                      "message": `Subprocess exceeded cost limit of ${__stack.args.maxCost} (used ${__stack.locals.err.actualCost})`
                    }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "run", args: __stack.args }));
                    return;
                  });
                }
              }
            ]);
          }
        }
      ]);
      await runner.step(9, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.guarded);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "run");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function run threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "run"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "run",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "run",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const run = __AgencyFunction.create({
  name: "run",
  module: "stdlib/agency.agency",
  fn: __run_impl,
  params: [{
    name: "compiled",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "node",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "args",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "wallClock",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "memory",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ipcPayload",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "stdout",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "logFile",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxDepth",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "run",
    description: `Execute a compiled Agency program in a subprocess and return the node's result.

  @param compiled - A compiled Agency program
  @param node - Which exported node to run
  @param args - Arguments to pass to the node
  @param wallClock - Max wall-clock time in MILLISECONDS before SIGKILL (default 60000 = 60s, max 1h). Pass null for the default.
  @param memory - Max V8 heap size in BYTES (default 536870912 = 512mb, max 4gb). Pass null for the default.
  @param ipcPayload - Max single IPC message size in BYTES (default 104857600 = 100mb, max 1gb). Pass null for the default.
  @param stdout - Max combined stdout+stderr output in BYTES (default 1048576 = 1mb, max 100mb). Pass null for the default.
  @param logFile - Optional statelog JSONL file path for this subprocess run
  @param cwd - Optional working directory for this subprocess run
  @param maxDepth - Max subprocess nesting depth (default 5, hard ceiling 10).
  @param maxCost - Max subprocess LLM spend in dollars (e.g. $0.50). null = no cost limit.`,
    schema: z.object({ "compiled": CompiledProgram, "node": z.string(), "args": z.record(z.string(), z.any()).nullable().describe("Default: {}"), "wallClock": z.number().nullable().describe("Default: 60s"), "memory": z.number().nullable().describe("Default: 512mb"), "ipcPayload": z.number().nullable().describe("Default: 100mb"), "stdout": z.number().nullable().describe("Default: 1mb"), "logFile": z.string().nullable().describe("Default: "), "cwd": z.string().nullable().describe("Default: "), "maxDepth": z.number().nullable().describe("Default: 5"), "maxCost": z.union([z.number(), z.null()]).describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
async function __runFile_impl(dir, filename, node, args = __UNSET, wallClock = __UNSET, memory = __UNSET, ipcPayload = __UNSET, stdout = __UNSET, maxCost = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __stack.args["filename"] = filename;
  __stack.args["node"] = node;
  __stack.args["args"] = args === __UNSET ? {} : args;
  __stack.args["wallClock"] = wallClock === __UNSET ? 6e4 : wallClock;
  __stack.args["memory"] = memory === __UNSET ? 536870912 : memory;
  __stack.args["ipcPayload"] = ipcPayload === __UNSET ? 104857600 : ipcPayload;
  __stack.args["stdout"] = stdout === __UNSET ? 1048576 : stdout;
  __stack.args["maxCost"] = maxCost === __UNSET ? null : maxCost;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "runFile", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("node" in __overrides) {
      node = __overrides["node"];
      __stack.args["node"] = node;
    }
    if ("args" in __overrides) {
      args = __overrides["args"];
      __stack.args["args"] = args;
    }
    if ("wallClock" in __overrides) {
      wallClock = __overrides["wallClock"];
      __stack.args["wallClock"] = wallClock;
    }
    if ("memory" in __overrides) {
      memory = __overrides["memory"];
      __stack.args["memory"] = memory;
    }
    if ("ipcPayload" in __overrides) {
      ipcPayload = __overrides["ipcPayload"];
      __stack.args["ipcPayload"] = ipcPayload;
    }
    if ("stdout" in __overrides) {
      stdout = __overrides["stdout"];
      __stack.args["stdout"] = stdout;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "runFile",
            args: {
              dir,
              filename,
              node,
              args,
              wallClock,
              memory,
              ipcPayload,
              stdout,
              maxCost
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.compileResult = await __tryCall(async () => await __call(_compileFile, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.filename]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "runFile",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.compileResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.compileResult);
          return;
        }
        if (isAborted(__stack.locals.compileResult)) {
          runner2.halt(__stack.locals.compileResult.carryThrough(__stack, "runFile"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.compileResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.locals.compileResult);
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(run, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            compiled: __stack.locals.compileResult.value,
            node: __stack.args.node,
            args: __stack.args.args,
            wallClock: __stack.args.wallClock,
            memory: __stack.args.memory,
            ipcPayload: __stack.args.ipcPayload,
            stdout: __stack.args.stdout,
            maxCost: __stack.args.maxCost
          }
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "runFile");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function runFile threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "runFile"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "runFile",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "runFile",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const runFile = __AgencyFunction.create({
  name: "runFile",
  module: "stdlib/agency.agency",
  fn: __runFile_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "node",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "args",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "wallClock",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "memory",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ipcPayload",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "stdout",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "runFile",
    description: `Compile and execute an Agency file in a subprocess and return the node's result.
  Only standard-library (\`std::\`) imports are allowed in the file.

  @param dir - The directory containing the file
  @param filename - The agency file to compile and run
  @param node - Which node to run
  @param args - Arguments to pass to the node
  @param wallClock - Max wall-clock time in MILLISECONDS before SIGKILL (default 60000 = 60s, max 1h). Pass null for the default.
  @param memory - Max V8 heap size in BYTES (default 536870912 = 512mb, max 4gb). Pass null for the default.
  @param ipcPayload - Max single IPC message size in BYTES (default 104857600 = 100mb, max 1gb). Pass null for the default.
  @param stdout - Max combined stdout+stderr output in BYTES (default 1048576 = 1mb, max 100mb). Pass null for the default.
  @param maxCost - Max subprocess LLM spend in dollars (e.g. $0.50). null = no cost limit.`,
    schema: z.object({ "dir": z.string(), "filename": z.string(), "node": z.string(), "args": z.record(z.string(), z.any()).nullable().describe("Default: {}"), "wallClock": z.number().nullable().describe("Default: 60s"), "memory": z.number().nullable().describe("Default: 512mb"), "ipcPayload": z.number().nullable().describe("Default: 100mb"), "stdout": z.number().nullable().describe("Default: 1mb"), "maxCost": z.union([z.number(), z.null()]).describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
async function __checkRunCodeLimits_impl(wallClock, memory, ipcPayload, stdout) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["wallClock"] = wallClock;
  __stack.args["memory"] = memory;
  __stack.args["ipcPayload"] = ipcPayload;
  __stack.args["stdout"] = stdout;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "checkRunCodeLimits", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("wallClock" in __overrides) {
      wallClock = __overrides["wallClock"];
      __stack.args["wallClock"] = wallClock;
    }
    if ("memory" in __overrides) {
      memory = __overrides["memory"];
      __stack.args["memory"] = memory;
    }
    if ("ipcPayload" in __overrides) {
      ipcPayload = __overrides["ipcPayload"];
      __stack.args["ipcPayload"] = ipcPayload;
    }
    if ("stdout" in __overrides) {
      stdout = __overrides["stdout"];
      __stack.args["stdout"] = stdout;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "checkRunCodeLimits",
            args: {
              wallClock,
              memory,
              ipcPayload,
              stdout
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.checks = [{
          "name": `wallClock`,
          "value": __stack.args.wallClock,
          "max": 36e5,
          "unit": `milliseconds`
        }, {
          "name": `memory`,
          "value": __stack.args.memory,
          "max": 4294967296,
          "unit": `bytes`
        }, {
          "name": `ipcPayload`,
          "value": __stack.args.ipcPayload,
          "max": 1073741824,
          "unit": `bytes`
        }, {
          "name": `stdout`,
          "value": __stack.args.stdout,
          "max": 104857600,
          "unit": `bytes`
        }];
      });
      await runner.loop(2, async () => __stack.locals.checks, async (check, _, runner2) => {
        await runner2.ifElse(0, [
          {
            condition: async () => check.value <= 0,
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(`${check.name} must be a positive number of ${check.unit} (got ${check.value}).`);
                return;
              });
            }
          }
        ]);
        await runner2.ifElse(1, [
          {
            condition: async () => check.value > check.max,
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(`${check.name} is too large: ${check.value} ${check.unit} exceeds the maximum of ${check.max} ${check.unit}.`);
                return;
              });
            }
          }
        ]);
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(``);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "checkRunCodeLimits");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function checkRunCodeLimits threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "checkRunCodeLimits"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "checkRunCodeLimits",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "checkRunCodeLimits",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const checkRunCodeLimits = __AgencyFunction.create({
  name: "checkRunCodeLimits",
  module: "stdlib/agency.agency",
  fn: __checkRunCodeLimits_impl,
  params: [{
    name: "wallClock",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "memory",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ipcPayload",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "stdout",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "checkRunCodeLimits",
    description: "No description provided.",
    schema: z.object({ "wallClock": z.number(), "memory": z.number(), "ipcPayload": z.number(), "stdout": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __runCode_impl(source, node = __UNSET, args = __UNSET, wallClock = __UNSET, memory = __UNSET, ipcPayload = __UNSET, stdout = __UNSET, maxCost = __UNSET, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __stack.args["node"] = node === __UNSET ? `main` : node;
  __stack.args["args"] = args === __UNSET ? {} : args;
  __stack.args["wallClock"] = wallClock === __UNSET ? 6e4 : wallClock;
  __stack.args["memory"] = memory === __UNSET ? 536870912 : memory;
  __stack.args["ipcPayload"] = ipcPayload === __UNSET ? 104857600 : ipcPayload;
  __stack.args["stdout"] = stdout === __UNSET ? 1048576 : stdout;
  __stack.args["maxCost"] = maxCost === __UNSET ? null : maxCost;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "runCode", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("node" in __overrides) {
      node = __overrides["node"];
      __stack.args["node"] = node;
    }
    if ("args" in __overrides) {
      args = __overrides["args"];
      __stack.args["args"] = args;
    }
    if ("wallClock" in __overrides) {
      wallClock = __overrides["wallClock"];
      __stack.args["wallClock"] = wallClock;
    }
    if ("memory" in __overrides) {
      memory = __overrides["memory"];
      __stack.args["memory"] = memory;
    }
    if ("ipcPayload" in __overrides) {
      ipcPayload = __overrides["ipcPayload"];
      __stack.args["ipcPayload"] = ipcPayload;
    }
    if ("stdout" in __overrides) {
      stdout = __overrides["stdout"];
      __stack.args["stdout"] = stdout;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "runCode",
            args: {
              source,
              node,
              args,
              wallClock,
              memory,
              ipcPayload,
              stdout,
              maxCost,
              cwd
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.limitError = await __call(checkRunCodeLimits, {
          type: "positional",
          args: [__stack.args.wallClock, __stack.args.memory, __stack.args.ipcPayload, __stack.args.stdout]
        });
        if (hasInterrupts(__stack.locals.limitError)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.limitError);
          return;
        }
        if (isAborted(__stack.locals.limitError)) {
          runner2.halt(__stack.locals.limitError.carryThrough(__stack, "runCode"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.locals.limitError, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(__stack.locals.limitError, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "runCode", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.compileResult = await __tryCall(async () => await __call(_compile, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "runCode",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.compileResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.compileResult);
          return;
        }
        if (isAborted(__stack.locals.compileResult)) {
          runner2.halt(__stack.locals.compileResult.carryThrough(__stack, "runCode"));
          return;
        }
      });
      await runner.ifElse(4, [
        {
          condition: async () => await isFailure(__stack.locals.compileResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.compileErr = __stack.locals.compileResult.error;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.locals.compileResult);
              return;
            });
          }
        }
      ]);
      await runner.step(5, async (runner2) => {
        __stack.locals.result = await __call(run, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            compiled: __stack.locals.compileResult.value,
            node: __stack.args.node,
            args: __stack.args.args,
            wallClock: __stack.args.wallClock,
            memory: __stack.args.memory,
            ipcPayload: __stack.args.ipcPayload,
            stdout: __stack.args.stdout,
            maxCost: __stack.args.maxCost,
            cwd: __stack.args.cwd
          }
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "runCode"));
          return;
        }
      });
      await runner.ifElse(6, [
        {
          condition: async () => await isSuccess(__stack.locals.result),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.envelope = __stack.locals.result.value;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await success(__stack.locals.envelope.data));
              return;
            });
          }
        }
      ]);
      await runner.step(7, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "runCode");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function runCode threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "runCode"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "runCode",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "runCode",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const runCode = __AgencyFunction.create({
  name: "runCode",
  module: "stdlib/agency.agency",
  fn: __runCode_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "node",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "args",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "wallClock",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "memory",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ipcPayload",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "stdout",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "runCode",
    description: `Compile Agency source code and execute one of its nodes in a subprocess,
  returning the value the node returned. Prefer this over separate
  compile() and run() calls. Only standard-library (\`std::\`) imports are
  allowed in the source. Compile errors are returned as a failure without
  running anything; fix the source and call again.

  @param source - Agency source code as a string
  @param node - Which exported node to run (default "main")
  @param args - Arguments to pass to the node
  @param wallClock - Max wall-clock time in MILLISECONDS before SIGKILL (default 60000 = 60s, max 3600000 = 1h). Pass null for the default.
  @param memory - Max V8 heap size in BYTES (default 536870912 = 512mb, max 4294967296 = 4gb). Pass null for the default.
  @param ipcPayload - Max single IPC message size in BYTES (default 104857600 = 100mb, max 1073741824 = 1gb). Pass null for the default.
  @param stdout - Max combined stdout+stderr output in BYTES (default 1048576 = 1mb, max 104857600 = 100mb). Pass null for the default.
  @param maxCost - Max subprocess LLM spend in dollars (e.g. 0.50). null = no cost limit.
  @param cwd - Working directory for the subprocess. Empty inherits the caller's process cwd (which may be the package dir, not where you want files); pass the agent working directory so the generated program's file writes land there.`,
    schema: z.object({ "source": z.string(), "node": z.string().nullable().describe("Default: main"), "args": z.record(z.string(), z.any()).nullable().describe("Default: {}"), "wallClock": z.number().nullable().describe("Default: 60s"), "memory": z.number().nullable().describe("Default: 512mb"), "ipcPayload": z.number().nullable().describe("Default: 100mb"), "stdout": z.number().nullable().describe("Default: 1mb"), "maxCost": z.union([z.number(), z.null()]).describe("Default: null"), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __typecheck_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "typecheck", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "typecheck",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_typecheck, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "typecheck",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "typecheck");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function typecheck threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "typecheck"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "typecheck",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "typecheck",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const typecheck = __AgencyFunction.create({
  name: "typecheck",
  module: "stdlib/agency.agency",
  fn: __typecheck_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "typecheck",
    description: `Type-check Agency source code.

  @param source - Agency source code as a string`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
const EffectsByExport = z.record(z.string(), z.array(z.string()));
async function __getEffects_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "getEffects", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getEffects",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_getEffects, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "getEffects",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "getEffects");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getEffects threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getEffects"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getEffects",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getEffects",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getEffects = __AgencyFunction.create({
  name: "getEffects",
  module: "stdlib/agency.agency",
  fn: __getEffects_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "getEffects",
    description: `Map each exported node and function in the source to the list of
  interrupt effects it can raise, transitively. Bare \`interrupt(...)\`
  sites appear as the sentinel "unknown", so the envelope never
  silently under-reports. Use this to show or check what a program can
  do before running it.

  @param source - Agency source code as a string`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
const FilterImportsResult = z.object({ "source": z.string(), "filtered": z.boolean() });
async function __typecheckFile_impl(dir, filename) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __stack.args["filename"] = filename;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "typecheckFile", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "typecheckFile",
            args: {
              dir,
              filename
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::read", `Are you sure you want to read this file?`, {
            "dir": __stack.args.dir,
            "filename": __stack.args.filename
          }, "std::agency", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/agency.agency", scopeName: "typecheckFile", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_typecheckFile, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.filename]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "typecheckFile",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "typecheckFile");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function typecheckFile threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "typecheckFile"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "typecheckFile",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "typecheckFile",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const typecheckFile = __AgencyFunction.create({
  name: "typecheckFile",
  module: "stdlib/agency.agency",
  fn: __typecheckFile_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "typecheckFile",
    description: `Type-check an Agency file on disk. The file is read from dir/filename,
  with relative imports inside it resolved against the file's directory.

  @param dir - The directory containing the file
  @param filename - The agency file to type-check`,
    schema: z.object({ "dir": z.string(), "filename": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
const AST = z.object({ "type": z.literal("agencyProgram"), "nodes": z.array(z.any()), "docComment": z.union([z.any(), z.null()]).optional().default(null) });
async function __parseAST_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "parseAST", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseAST",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_parseAST, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "parseAST",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseAST");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseAST threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseAST"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseAST",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseAST",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseAST = __AgencyFunction.create({
  name: "parseAST",
  module: "stdlib/agency.agency",
  fn: __parseAST_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "parseAST",
    description: `Parse Agency source code into an abstract syntax tree.

  @param source - Agency source code as a string`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __writeAST_impl(ast, dir, filename, overwrite = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["ast"] = ast;
  __stack.args["dir"] = dir;
  __stack.args["filename"] = filename;
  __stack.args["overwrite"] = overwrite === __UNSET ? true : overwrite;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "writeAST", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("ast" in __overrides) {
      ast = __overrides["ast"];
      __stack.args["ast"] = ast;
    }
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("overwrite" in __overrides) {
      overwrite = __overrides["overwrite"];
      __stack.args["overwrite"] = overwrite;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "writeAST",
            args: {
              ast,
              dir,
              filename,
              overwrite
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::write", `Are you sure you want to write this file?`, {
            "dir": __stack.args.dir,
            "filename": __stack.args.filename,
            "overwrite": __stack.args.overwrite
          }, "std::agency", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/agency.agency", scopeName: "writeAST", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_writeAST, {
          type: "positional",
          args: [__stack.args.ast, __stack.args.dir, __stack.args.filename, __stack.args.overwrite]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "writeAST",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "writeAST");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function writeAST threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "writeAST"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "writeAST",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "writeAST",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const writeAST = __AgencyFunction.create({
  name: "writeAST",
  module: "stdlib/agency.agency",
  fn: __writeAST_impl,
  params: [{
    name: "ast",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "overwrite",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "writeAST",
    description: `Format an AST as Agency source and write it to dir/filename. Absolute paths and .. segments cannot escape dir. Symlinks on existing files are followed and re-checked.

  @param ast - The AST to write (typically a parsed Agency AST)
  @param dir - The sandbox directory
  @param filename - The agency file to write, resolved relative to dir
  @param overwrite - If false, fail when the file already exists (default true)`,
    schema: z.object({ "ast": AST, "dir": z.string(), "filename": z.string(), "overwrite": z.boolean().nullable().describe("Default: true") })
  },
  exported: true
}, __toolRegistry);
async function __format_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "format", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "format",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_format, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "format",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "format");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function format threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "format"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "format",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "format",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const format = __AgencyFunction.create({
  name: "format",
  module: "stdlib/agency.agency",
  fn: __format_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "format",
    description: `Format Agency source code with the standard Agency formatter.

  @param source - Agency source code as a string`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __formatFile_impl(dir, filename) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __stack.args["filename"] = filename;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "formatFile", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "formatFile",
            args: {
              dir,
              filename
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::write", `Are you sure you want to format this file in place?`, {
            "dir": __stack.args.dir,
            "filename": __stack.args.filename
          }, "std::agency", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/agency.agency", scopeName: "formatFile", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_formatFile, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.filename]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "formatFile",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "formatFile");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function formatFile threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "formatFile"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "formatFile",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "formatFile",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const formatFile = __AgencyFunction.create({
  name: "formatFile",
  module: "stdlib/agency.agency",
  fn: __formatFile_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "formatFile",
    description: `Format an Agency file in place using the standard Agency formatter.

  @param dir - The directory containing the file
  @param filename - The agency file to format`,
    schema: z.object({ "dir": z.string(), "filename": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __walkAST_impl(ast, visitor) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["ast"] = ast;
  __stack.args["visitor"] = visitor;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "walkAST", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("ast" in __overrides) {
      ast = __overrides["ast"];
      __stack.args["ast"] = ast;
    }
    if ("visitor" in __overrides) {
      visitor = __overrides["visitor"];
      __stack.args["visitor"] = visitor;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "walkAST",
            args: {
              ast,
              visitor
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.result = await __call(_walkAST, {
          type: "positional",
          args: [__stack.args.ast]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "walkAST"));
          return;
        }
      });
      await runner.loop(2, async () => __stack.locals.result.visits, async (visit, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          const __funcResult = await __call(__stack.args.visitor, {
            type: "positional",
            args: [visit.node, visit.ancestors]
          });
          if (hasInterrupts(__funcResult)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__funcResult);
            return;
          }
          if (isAborted(__funcResult)) {
            runner3.halt(__funcResult.carryThrough(__stack, "walkAST"));
            return;
          }
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result.clone);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "walkAST");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function walkAST threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "walkAST"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "walkAST",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "walkAST",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const walkAST = __AgencyFunction.create({
  name: "walkAST",
  module: "stdlib/agency.agency",
  fn: __walkAST_impl,
  params: [{
    name: "ast",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "visitor",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "walkAST",
    description: `Walk every node in a deep-cloned copy of the AST, invoking the visitor
  with each (node, ancestors) pair, and return the modified clone.
  The visitor may mutate nodes in place. This will not modify the original tree.
  The ancestors array lists every enclosing node from the root outward, excluding the node itself.

  @param ast - The AST to walk
  @param visitor - Called once per node as visitor(node, ancestors). Mutate node in place, return value is ignored.`,
    schema: z.object({ "ast": AST })
  },
  exported: true
}, __toolRegistry);
async function __getNodesOfType_impl(source, types) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __stack.args["types"] = types;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "getNodesOfType", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("types" in __overrides) {
      types = __overrides["types"];
      __stack.args["types"] = types;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getNodesOfType",
            args: {
              source,
              types
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_getNodesOfType, {
          type: "positional",
          args: [__stack.args.source, __stack.args.types]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "getNodesOfType",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "getNodesOfType");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getNodesOfType threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getNodesOfType"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getNodesOfType",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getNodesOfType",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getNodesOfType = __AgencyFunction.create({
  name: "getNodesOfType",
  module: "stdlib/agency.agency",
  fn: __getNodesOfType_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "types",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "getNodesOfType",
    description: `Parse Agency source code and return every AST node whose \`type\` field matches any of the provided types.

  @param source - Agency source code
  @param types - List of AST type strings to match (e.g. ["function", "graphNode"])`,
    schema: z.object({ "source": z.string(), "types": z.array(z.string()) })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __getImports_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "getImports", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getImports",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(getNodesOfType, {
          type: "positional",
          args: [__stack.args.source, [`importStatement`]]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "getImports");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getImports threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getImports"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getImports",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getImports",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getImports = __AgencyFunction.create({
  name: "getImports",
  module: "stdlib/agency.agency",
  fn: __getImports_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "getImports",
    description: `Return every import statement in the source (i.e. \`import { x } from "..."\`).

  @param source - Agency source code`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __getFunctions_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "getFunctions", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getFunctions",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(getNodesOfType, {
          type: "positional",
          args: [__stack.args.source, [`function`]]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "getFunctions");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getFunctions threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getFunctions"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getFunctions",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getFunctions",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getFunctions = __AgencyFunction.create({
  name: "getFunctions",
  module: "stdlib/agency.agency",
  fn: __getFunctions_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "getFunctions",
    description: `Return every function definition (\`def foo(...) { ... }\`) in the source.

  @param source - Agency source code`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __getGraphNodes_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "getGraphNodes", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getGraphNodes",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(getNodesOfType, {
          type: "positional",
          args: [__stack.args.source, [`graphNode`]]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "getGraphNodes");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getGraphNodes threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getGraphNodes"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getGraphNodes",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getGraphNodes",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getGraphNodes = __AgencyFunction.create({
  name: "getGraphNodes",
  module: "stdlib/agency.agency",
  fn: __getGraphNodes_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "getGraphNodes",
    description: `Return every graph node definition (\`node main() { ... }\`) in the source.

  @param source - Agency source code`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __filterImports_impl(source, allowedPackages = __UNSET, excludedPackages = __UNSET, allowKinds = __UNSET, excludeKinds = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __stack.args["allowedPackages"] = allowedPackages === __UNSET ? [] : allowedPackages;
  __stack.args["excludedPackages"] = excludedPackages === __UNSET ? [] : excludedPackages;
  __stack.args["allowKinds"] = allowKinds === __UNSET ? [] : allowKinds;
  __stack.args["excludeKinds"] = excludeKinds === __UNSET ? [] : excludeKinds;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "filterImports", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("allowedPackages" in __overrides) {
      allowedPackages = __overrides["allowedPackages"];
      __stack.args["allowedPackages"] = allowedPackages;
    }
    if ("excludedPackages" in __overrides) {
      excludedPackages = __overrides["excludedPackages"];
      __stack.args["excludedPackages"] = excludedPackages;
    }
    if ("allowKinds" in __overrides) {
      allowKinds = __overrides["allowKinds"];
      __stack.args["allowKinds"] = allowKinds;
    }
    if ("excludeKinds" in __overrides) {
      excludeKinds = __overrides["excludeKinds"];
      __stack.args["excludeKinds"] = excludeKinds;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "filterImports",
            args: {
              source,
              allowedPackages,
              excludedPackages,
              allowKinds,
              excludeKinds
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_filterImports, {
          type: "positional",
          args: [__stack.args.source, __stack.args.allowedPackages, __stack.args.excludedPackages, __stack.args.allowKinds, __stack.args.excludeKinds]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "filterImports",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "filterImports");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function filterImports threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "filterImports"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "filterImports",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "filterImports",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const filterImports = __AgencyFunction.create({
  name: "filterImports",
  module: "stdlib/agency.agency",
  fn: __filterImports_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPackages",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "excludedPackages",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowKinds",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "excludeKinds",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "filterImports",
    description: `Filter imports in Agency source code according to the given policy.
  Returns the filtered source and a boolean indicating whether any imports were dropped.

  @param source - Agency source code
  @param allowedPackages - Glob patterns; matched imports are allowed (subject to excludes)
  @param excludedPackages - Glob patterns; matched imports are dropped
  @param allowKinds - Kind strings ("stdlib" | "pkg" | "local" | "node") to allow
  @param excludeKinds - Kind strings to drop`,
    schema: z.object({ "source": z.string(), "allowedPackages": z.array(z.string()).nullable().describe("Default: []"), "excludedPackages": z.array(z.string()).nullable().describe("Default: []"), "allowKinds": z.array(z.string()).nullable().describe("Default: []"), "excludeKinds": z.array(z.string()).nullable().describe("Default: []") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __getVersion_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "getVersion", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getVersion",
            args: {},
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(VERSION);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "getVersion");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getVersion threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getVersion"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getVersion",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getVersion",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getVersion = __AgencyFunction.create({
  name: "getVersion",
  module: "stdlib/agency.agency",
  fn: __getVersion_impl,
  params: [],
  toolDefinition: {
    name: "getVersion",
    description: `Get the current version of the Agency standard library.`,
    schema: z.object({})
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/agency.agency:compile": { "1": { "line": 93, "col": 2 } }, "stdlib/agency.agency:run": { "1": { "line": 135, "col": 2 }, "2": { "line": 136, "col": 2 }, "3": { "line": 144, "col": 2 }, "4": { "line": 164, "col": 2 }, "5": { "line": 165, "col": 14 }, "6": { "line": 165, "col": 2 }, "7": { "line": 166, "col": 2 }, "8": { "line": 184, "col": 2 }, "9": { "line": 200, "col": 2 }, "2.0": { "line": 137, "col": 4 }, "5.0": { "line": 165, "col": 38 }, "5.1": { "line": 165, "col": 38 }, "5.2": { "line": 165, "col": 51 }, "5.3": { "line": 165, "col": 51 }, "8.0": { "line": 184, "col": 2 }, "8.1.1": { "line": 189, "col": 6 }, "8.1": { "line": 185, "col": 4 } }, "stdlib/agency.agency:__block_0": { "7.0": { "line": 167, "col": 4 } }, "stdlib/agency.agency:runFile": { "1": { "line": 232, "col": 2 }, "2": { "line": 233, "col": 2 }, "3": { "line": 236, "col": 2 }, "2.0": { "line": 234, "col": 4 } }, "stdlib/agency.agency:checkRunCodeLimits": { "1": { "line": 256, "col": 2 }, "2": { "line": 282, "col": 2 }, "3": { "line": 290, "col": 2 }, "2.0.0": { "line": 284, "col": 6 }, "2.0": { "line": 283, "col": 4 }, "2.1.0": { "line": 287, "col": 6 }, "2.1": { "line": 286, "col": 4 } }, "stdlib/agency.agency:runCode": { "1": { "line": 335, "col": 2 }, "2": { "line": 336, "col": 2 }, "3": { "line": 339, "col": 2 }, "4": { "line": 340, "col": 2 }, "5": { "line": 343, "col": 2 }, "6": { "line": 358, "col": 2 }, "7": { "line": 361, "col": 2 }, "2.0": { "line": 337, "col": 4 }, "4.0": { "line": 340, "col": 2 }, "4.1": { "line": 341, "col": 4 }, "6.0": { "line": 358, "col": 2 }, "6.1": { "line": 359, "col": 4 } }, "stdlib/agency.agency:typecheck": { "1": { "line": 374, "col": 2 } }, "stdlib/agency.agency:getEffects": { "1": { "line": 390, "col": 2 } }, "stdlib/agency.agency:typecheckFile": { "1": { "line": 407, "col": 2 }, "2": { "line": 411, "col": 2 } }, "stdlib/agency.agency:parseAST": { "1": { "line": 431, "col": 2 } }, "stdlib/agency.agency:writeAST": { "1": { "line": 451, "col": 2 }, "2": { "line": 456, "col": 2 } }, "stdlib/agency.agency:format": { "1": { "line": 465, "col": 2 } }, "stdlib/agency.agency:formatFile": { "1": { "line": 477, "col": 2 }, "2": { "line": 481, "col": 2 } }, "stdlib/agency.agency:walkAST": { "1": { "line": 502, "col": 2 }, "2": { "line": 503, "col": 2 }, "3": { "line": 506, "col": 2 }, "2.0": { "line": 504, "col": 4 } }, "stdlib/agency.agency:getNodesOfType": { "1": { "line": 519, "col": 2 } }, "stdlib/agency.agency:getImports": { "1": { "line": 528, "col": 2 } }, "stdlib/agency.agency:getFunctions": { "1": { "line": 537, "col": 2 } }, "stdlib/agency.agency:getGraphNodes": { "1": { "line": 546, "col": 2 } }, "stdlib/agency.agency:filterImports": { "1": { "line": 584, "col": 2 } }, "stdlib/agency.agency:getVersion": { "1": { "line": 597, "col": 2 } } };
export {
  AST,
  CompiledProgram,
  EffectsByExport,
  SourceLocation,
  TypeCheckDiagnostic,
  TypeCheckReport,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  checkRunCodeLimits,
  compile,
  stdin_default as default,
  filterImports,
  format,
  formatFile,
  getEffects,
  getFunctions,
  getGraphNodes,
  getImports,
  getNodesOfType,
  getVersion,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  parseAST,
  reject,
  respondToInterrupts,
  rewindFrom,
  run,
  runCode,
  runFile,
  typecheck,
  typecheckFile,
  walkAST,
  writeAST
};
