import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { fetchJSON } from "agency-lang/stdlib/http.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  __registerCallbacksInit,
  success,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/data/tech/hackernews.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(fetchJSON);
let __staticInitPromise = null;
let HN_BASE = __UNINIT_STATIC;
let HN_DOMAINS = __UNINIT_STATIC;
let HN_ALGOLIA_BASE = __UNINIT_STATIC;
let HN_ALGOLIA_DOMAINS = __UNINIT_STATIC;
let HN_LISTS = __UNINIT_STATIC;
let HN_LIST_FILES = __UNINIT_STATIC;
let HN_SORTS = __UNINIT_STATIC;
let HN_SORT_ENDPOINTS = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    HN_BASE = __deepFreeze(`https://hacker-news.firebaseio.com/v0`);
    HN_DOMAINS = __deepFreeze([`hacker-news.firebaseio.com`]);
    HN_ALGOLIA_BASE = __deepFreeze(`https://hn.algolia.com/api/v1`);
    HN_ALGOLIA_DOMAINS = __deepFreeze([`hn.algolia.com`]);
    HN_LISTS = __deepFreeze([`top`, `new`, `best`, `ask`, `show`, `job`]);
    HN_LIST_FILES = __deepFreeze([`topstories`, `newstories`, `beststories`, `askstories`, `showstories`, `jobstories`]);
    HN_SORTS = __deepFreeze([`relevance`, `recent`]);
    HN_SORT_ENDPOINTS = __deepFreeze([`search`, `search_by_date`]);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    HN_BASE,
    HN_DOMAINS,
    HN_ALGOLIA_BASE,
    HN_ALGOLIA_DOMAINS,
    HN_LISTS,
    HN_LIST_FILES,
    HN_SORTS,
    HN_SORT_ENDPOINTS
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/data/tech/hackernews.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/data/tech/hackernews.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/data/tech/hackernews.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/data/tech/hackernews.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/data/tech/hackernews.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const Story = z.object({ "id": z.number(), "title": z.string(), "url": z.string(), "by": z.string(), "score": z.number(), "time": z.number(), "descendants": z.number(), "type": z.string() });
const Item = z.object({ "id": z.number(), "type": z.string(), "by": z.string(), "time": z.number(), "title": z.string(), "url": z.string(), "text": z.string(), "score": z.number(), "descendants": z.number(), "parent": z.union([z.number(), z.null()]).optional().default(null), "kids": z.array(z.number()) });
const User = z.object({ "id": z.string(), "created": z.number(), "karma": z.number(), "about": z.string(), "submitted": z.array(z.number()) });
async function __parseStoryList_impl(list) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["list"] = list;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "parseStoryList", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("list" in __overrides) {
      list = __overrides["list"];
      __stack.args["list"] = list;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseStoryList",
            args: {
              list
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.idx = await __callMethod(__readStatic(HN_LISTS, "HN_LISTS", "stdlib/data/tech/hackernews.agency"), "indexOf", {
          type: "positional",
          args: [__stack.args.list]
        });
      });
      await runner.ifElse(2, [
        {
          condition: async () => __stack.locals.idx < 0,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(`unknown list '${__stack.args.list}'; valid: ${await __callMethod(__readStatic(HN_LISTS, "HN_LISTS", "stdlib/data/tech/hackernews.agency"), "join", {
                type: "positional",
                args: [`, `]
              })}`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "parseStoryList", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await success(__nn(__readStatic(HN_LIST_FILES, "HN_LIST_FILES", "stdlib/data/tech/hackernews.agency")[__stack.locals.idx])));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseStoryList");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseStoryList threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseStoryList"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseStoryList",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseStoryList",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseStoryList = __AgencyFunction.create({
  name: "parseStoryList",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __parseStoryList_impl,
  params: [{
    name: "list",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "parseStoryList",
    description: "No description provided.",
    schema: z.object({ "list": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __parseSort_impl(sort) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["sort"] = sort;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "parseSort", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("sort" in __overrides) {
      sort = __overrides["sort"];
      __stack.args["sort"] = sort;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseSort",
            args: {
              sort
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.idx = await __callMethod(__readStatic(HN_SORTS, "HN_SORTS", "stdlib/data/tech/hackernews.agency"), "indexOf", {
          type: "positional",
          args: [__stack.args.sort]
        });
      });
      await runner.ifElse(2, [
        {
          condition: async () => __stack.locals.idx < 0,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(`unknown sort '${__stack.args.sort}'; valid: ${await __callMethod(__readStatic(HN_SORTS, "HN_SORTS", "stdlib/data/tech/hackernews.agency"), "join", {
                type: "positional",
                args: [`, `]
              })}`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "parseSort", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await success(__nn(__readStatic(HN_SORT_ENDPOINTS, "HN_SORT_ENDPOINTS", "stdlib/data/tech/hackernews.agency")[__stack.locals.idx])));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseSort");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseSort threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseSort"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseSort",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseSort",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseSort = __AgencyFunction.create({
  name: "parseSort",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __parseSort_impl,
  params: [{
    name: "sort",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "parseSort",
    description: "No description provided.",
    schema: z.object({ "sort": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __capLimit_impl(n, cap) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["n"] = n;
  __stack.args["cap"] = cap;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "capLimit", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("n" in __overrides) {
      n = __overrides["n"];
      __stack.args["n"] = n;
    }
    if ("cap" in __overrides) {
      cap = __overrides["cap"];
      __stack.args["cap"] = cap;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "capLimit",
            args: {
              n,
              cap
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.n > __stack.args.cap,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.args.cap);
              return;
            });
          }
        }
      ]);
      await runner.ifElse(2, [
        {
          condition: async () => __stack.args.n < 0,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(0);
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.args.n);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "capLimit");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function capLimit threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "capLimit"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "capLimit",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "capLimit",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const capLimit = __AgencyFunction.create({
  name: "capLimit",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __capLimit_impl,
  params: [{
    name: "n",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cap",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "capLimit",
    description: "No description provided.",
    schema: z.object({ "n": z.number(), "cap": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __takeFirst_impl(ids, n) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["ids"] = ids;
  __stack.args["n"] = n;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "takeFirst", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("ids" in __overrides) {
      ids = __overrides["ids"];
      __stack.args["ids"] = ids;
    }
    if ("n" in __overrides) {
      n = __overrides["n"];
      __stack.args["n"] = n;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "takeFirst",
            args: {
              ids,
              n
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.n <= 0,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt([]);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(__stack.args.ids, "slice", {
          type: "positional",
          args: [0, __stack.args.n]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "takeFirst");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function takeFirst threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "takeFirst"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "takeFirst",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "takeFirst",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const takeFirst = __AgencyFunction.create({
  name: "takeFirst",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __takeFirst_impl,
  params: [{
    name: "ids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "n",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "takeFirst",
    description: "No description provided.",
    schema: z.object({ "ids": z.array(z.number()), "n": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __buildStoryListPath_impl(file) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["file"] = file;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "buildStoryListPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("file" in __overrides) {
      file = __overrides["file"];
      __stack.args["file"] = file;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildStoryListPath",
            args: {
              file
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/${__stack.args.file}.json`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildStoryListPath");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildStoryListPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildStoryListPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildStoryListPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildStoryListPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildStoryListPath = __AgencyFunction.create({
  name: "buildStoryListPath",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __buildStoryListPath_impl,
  params: [{
    name: "file",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildStoryListPath",
    description: "No description provided.",
    schema: z.object({ "file": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildItemPath_impl(id) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["id"] = id;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "buildItemPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("id" in __overrides) {
      id = __overrides["id"];
      __stack.args["id"] = id;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildItemPath",
            args: {
              id
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/item/${__stack.args.id}.json`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildItemPath");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildItemPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildItemPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildItemPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildItemPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildItemPath = __AgencyFunction.create({
  name: "buildItemPath",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __buildItemPath_impl,
  params: [{
    name: "id",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildItemPath",
    description: "No description provided.",
    schema: z.object({ "id": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __buildUserPath_impl(username) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["username"] = username;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "buildUserPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("username" in __overrides) {
      username = __overrides["username"];
      __stack.args["username"] = username;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildUserPath",
            args: {
              username
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/user/${await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.username]
        })}.json`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildUserPath");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildUserPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildUserPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildUserPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildUserPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildUserPath = __AgencyFunction.create({
  name: "buildUserPath",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __buildUserPath_impl,
  params: [{
    name: "username",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildUserPath",
    description: "No description provided.",
    schema: z.object({ "username": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildSearchPath_impl(endpoint, query, tags, limit) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["endpoint"] = endpoint;
  __stack.args["query"] = query;
  __stack.args["tags"] = tags;
  __stack.args["limit"] = limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "buildSearchPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("endpoint" in __overrides) {
      endpoint = __overrides["endpoint"];
      __stack.args["endpoint"] = endpoint;
    }
    if ("query" in __overrides) {
      query = __overrides["query"];
      __stack.args["query"] = query;
    }
    if ("tags" in __overrides) {
      tags = __overrides["tags"];
      __stack.args["tags"] = tags;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildSearchPath",
            args: {
              endpoint,
              query,
              tags,
              limit
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.q = await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.query]
        });
        if (hasInterrupts(__stack.locals.q)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.q);
          return;
        }
        if (isAborted(__stack.locals.q)) {
          runner2.halt(__stack.locals.q.carryThrough(__stack, "buildSearchPath"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.t = await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.tags]
        });
        if (hasInterrupts(__stack.locals.t)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.t);
          return;
        }
        if (isAborted(__stack.locals.t)) {
          runner2.halt(__stack.locals.t.carryThrough(__stack, "buildSearchPath"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.n = await __call(capLimit, {
          type: "positional",
          args: [__stack.args.limit, 50]
        });
        if (hasInterrupts(__stack.locals.n)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.n);
          return;
        }
        if (isAborted(__stack.locals.n)) {
          runner2.halt(__stack.locals.n.carryThrough(__stack, "buildSearchPath"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/${__stack.args.endpoint}?query=${__stack.locals.q}&tags=${__stack.locals.t}&hitsPerPage=${__stack.locals.n}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildSearchPath");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildSearchPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildSearchPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildSearchPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildSearchPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildSearchPath = __AgencyFunction.create({
  name: "buildSearchPath",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __buildSearchPath_impl,
  params: [{
    name: "endpoint",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "query",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "tags",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildSearchPath",
    description: "No description provided.",
    schema: z.object({ "endpoint": z.string(), "query": z.string(), "tags": z.string(), "limit": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __parseStory_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "parseStory", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseStory",
            args: {
              raw
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "id": __stack.locals.r.id ?? 0,
          "title": __stack.locals.r.title ?? ``,
          "url": __stack.locals.r.url ?? ``,
          "by": __stack.locals.r.by ?? ``,
          "score": __stack.locals.r.score ?? 0,
          "time": __stack.locals.r.time ?? 0,
          "descendants": __stack.locals.r.descendants ?? 0,
          "type": __stack.locals.r.type ?? `story`
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseStory");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseStory threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseStory"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseStory",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseStory",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseStory = __AgencyFunction.create({
  name: "parseStory",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __parseStory_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseStory",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __parseItem_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "parseItem", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseItem",
            args: {
              raw
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "id": __stack.locals.r.id ?? 0,
          "type": __stack.locals.r.type ?? ``,
          "by": __stack.locals.r.by ?? ``,
          "time": __stack.locals.r.time ?? 0,
          "title": __stack.locals.r.title ?? ``,
          "url": __stack.locals.r.url ?? ``,
          "text": __stack.locals.r.text ?? ``,
          "score": __stack.locals.r.score ?? 0,
          "descendants": __stack.locals.r.descendants ?? 0,
          "parent": __stack.locals.r.parent ?? null,
          "kids": __stack.locals.r.kids ?? []
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseItem");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseItem threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseItem"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseItem",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseItem",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseItem = __AgencyFunction.create({
  name: "parseItem",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __parseItem_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseItem",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __parseUser_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "parseUser", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseUser",
            args: {
              raw
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "id": __stack.locals.r.id ?? ``,
          "created": __stack.locals.r.created ?? 0,
          "karma": __stack.locals.r.karma ?? 0,
          "about": __stack.locals.r.about ?? ``,
          "submitted": __stack.locals.r.submitted ?? []
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseUser");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseUser threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseUser"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseUser",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseUser",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseUser = __AgencyFunction.create({
  name: "parseUser",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __parseUser_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseUser",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __parseAlgoliaHits_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "parseAlgoliaHits", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseAlgoliaHits",
            args: {
              raw
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.hits = __stack.locals.r.hits ?? [];
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(map, {
          type: "named",
          positionalArgs: [__stack.locals.hits],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/data/tech/hackernews.agency", fn: async (h) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["h"] = h;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.hit = __bstack.args.h ?? {};
              });
              await runner3.step(1, async (runner4) => {
                runner4.halt({
                  "id": await __call(Number, {
                    type: "positional",
                    args: [__bstack.locals.hit.objectID ?? __bstack.locals.hit.story_id ?? 0]
                  }),
                  "title": __bstack.locals.hit.title ?? ``,
                  "url": __bstack.locals.hit.url ?? ``,
                  "by": __bstack.locals.hit.author ?? ``,
                  "score": __bstack.locals.hit.points ?? 0,
                  "time": __bstack.locals.hit.created_at_i ?? 0,
                  "descendants": __bstack.locals.hit.num_comments ?? 0,
                  "type": `story`
                });
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_0");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "h", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseAlgoliaHits");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseAlgoliaHits threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseAlgoliaHits"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseAlgoliaHits",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseAlgoliaHits",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseAlgoliaHits = __AgencyFunction.create({
  name: "parseAlgoliaHits",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __parseAlgoliaHits_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseAlgoliaHits",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __hnError_impl(err) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["err"] = err;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "hnError", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("err" in __overrides) {
      err = __overrides["err"];
      __stack.args["err"] = err;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "hnError",
            args: {
              err
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`Hacker News request failed (the API may be rate-limited): ${__stack.args.err.message ?? __stack.args.err}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "hnError");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function hnError threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "hnError"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "hnError",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "hnError",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const hnError = __AgencyFunction.create({
  name: "hnError",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __hnError_impl,
  params: [{
    name: "err",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "hnError",
    description: "No description provided.",
    schema: z.object({ "err": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __itemFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "itemFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "itemFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_3 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_3),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_3.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.b = __stack.locals.body ?? null;
            });
            await runner2.ifElse(2, [
              {
                condition: async () => __eq(__stack.locals.b, null),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    runner4.exitMatch(1, failure(`Hacker News returned no item`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "itemFinalize", args: __stack.args }));
                    return;
                  });
                }
              }
            ]);
            await runner2.step(3, async (runner3) => {
              runner3.exitMatch(1, await success(await __call(parseItem, {
                type: "positional",
                args: [__stack.locals.b]
              })));
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_3),
          body: async (runner2) => {
            await runner2.step(4, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_3.error;
            });
            await runner2.step(5, async (runner3) => {
              __stack.locals.__armval_2 = failure(await __call(hnError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "itemFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_2)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_2);
                return;
              }
              if (isAborted(__stack.locals.__armval_2)) {
                runner3.halt(__stack.locals.__armval_2.carryThrough(__stack, "itemFinalize"));
                return;
              }
            });
            await runner2.step(6, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_2);
              return;
            });
          }
        }
      ], void 0, { matchId: 1 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "itemFinalize");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function itemFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "itemFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "itemFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "itemFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const itemFinalize = __AgencyFunction.create({
  name: "itemFinalize",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __itemFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "itemFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __userFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "userFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "userFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_6 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_6),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_6.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.b = __stack.locals.body ?? null;
            });
            await runner2.ifElse(2, [
              {
                condition: async () => __eq(__stack.locals.b, null),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    runner4.exitMatch(4, failure(`Hacker News returned no user`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "userFinalize", args: __stack.args }));
                    return;
                  });
                }
              }
            ]);
            await runner2.step(3, async (runner3) => {
              runner3.exitMatch(4, await success(await __call(parseUser, {
                type: "positional",
                args: [__stack.locals.b]
              })));
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_6),
          body: async (runner2) => {
            await runner2.step(4, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_6.error;
            });
            await runner2.step(5, async (runner3) => {
              __stack.locals.__armval_5 = failure(await __call(hnError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "userFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_5)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_5);
                return;
              }
              if (isAborted(__stack.locals.__armval_5)) {
                runner3.halt(__stack.locals.__armval_5.carryThrough(__stack, "userFinalize"));
                return;
              }
            });
            await runner2.step(6, async (runner3) => {
              runner3.exitMatch(4, __stack.locals.__armval_5);
              return;
            });
          }
        }
      ], void 0, { matchId: 4 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_4));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "userFinalize");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function userFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "userFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "userFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "userFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const userFinalize = __AgencyFunction.create({
  name: "userFinalize",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __userFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "userFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __searchFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "searchFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "searchFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_10 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_10),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_10.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_8 = await success(await __call(parseAlgoliaHits, {
                type: "positional",
                args: [__stack.locals.body]
              }));
              if (hasInterrupts(__stack.locals.__armval_8)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_8);
                return;
              }
              if (isAborted(__stack.locals.__armval_8)) {
                runner3.halt(__stack.locals.__armval_8.carryThrough(__stack, "searchFinalize"));
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(7, __stack.locals.__armval_8);
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_10),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_10.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_9 = failure(await __call(hnError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "searchFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_9)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_9);
                return;
              }
              if (isAborted(__stack.locals.__armval_9)) {
                runner3.halt(__stack.locals.__armval_9.carryThrough(__stack, "searchFinalize"));
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(7, __stack.locals.__armval_9);
              return;
            });
          }
        }
      ], void 0, { matchId: 7 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_7));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "searchFinalize");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function searchFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "searchFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "searchFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "searchFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const searchFinalize = __AgencyFunction.create({
  name: "searchFinalize",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __searchFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "searchFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __hnFetch_impl(base, domains, path2) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["base"] = base;
  __stack.args["domains"] = domains;
  __stack.args["path"] = path2;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "hnFetch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("base" in __overrides) {
      base = __overrides["base"];
      __stack.args["base"] = base;
    }
    if ("domains" in __overrides) {
      domains = __overrides["domains"];
      __stack.args["domains"] = domains;
    }
    if ("path" in __overrides) {
      path2 = __overrides["path"];
      __stack.args["path"] = path2;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "hnFetch",
            args: {
              base,
              domains,
              path: path2
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.handle(1, async (data) => {
        if (__eq(data.effect, `std::http::fetchJSON`)) {
          return await approve();
        }
      }, async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __functionCompleted = true;
          runner3.halt(await __call(fetchJSON, {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              baseUrl: __stack.args.base,
              path: __stack.args.path,
              allowedDomains: __stack.args.domains
            }
          }));
          return;
        });
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "hnFetch");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function hnFetch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "hnFetch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "hnFetch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "hnFetch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const hnFetch = __AgencyFunction.create({
  name: "hnFetch",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __hnFetch_impl,
  params: [{
    name: "base",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "domains",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "path",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "hnFetch",
    description: "No description provided.",
    schema: z.object({ "base": z.string(), "domains": z.array(z.string()), "path": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __hydrateStories_impl(ids, limit) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["ids"] = ids;
  __stack.args["limit"] = limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "hydrateStories", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("ids" in __overrides) {
      ids = __overrides["ids"];
      __stack.args["ids"] = ids;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "hydrateStories",
            args: {
              ids,
              limit
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.stories = [];
      });
      await runner.loop(2, async () => await __call(takeFirst, {
        type: "positional",
        args: [__stack.args.ids, __stack.args.limit]
      }), async (id, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.itemResult = await __call(hnFetch, {
            type: "positional",
            args: [__readStatic(HN_BASE, "HN_BASE", "stdlib/data/tech/hackernews.agency"), __readStatic(HN_DOMAINS, "HN_DOMAINS", "stdlib/data/tech/hackernews.agency"), await __call(buildItemPath, {
              type: "positional",
              args: [id]
            })]
          });
          if (hasInterrupts(__stack.locals.itemResult)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.itemResult);
            return;
          }
          if (isAborted(__stack.locals.itemResult)) {
            runner3.halt(__stack.locals.itemResult.carryThrough(__stack, "hydrateStories"));
            return;
          }
        });
        await runner2.ifElse(1, [
          {
            condition: async () => await isSuccess(__stack.locals.itemResult),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.body = __stack.locals.itemResult.value;
              });
              await runner3.step(1, async (runner4) => {
                await __callMethod(__stack.locals.stories, "push", {
                  type: "positional",
                  args: [await __call(parseStory, {
                    type: "positional",
                    args: [__stack.locals.body]
                  })]
                });
              });
            }
          }
        ]);
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.stories);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "hydrateStories");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function hydrateStories threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "hydrateStories"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "hydrateStories",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "hydrateStories",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const hydrateStories = __AgencyFunction.create({
  name: "hydrateStories",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __hydrateStories_impl,
  params: [{
    name: "ids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "hydrateStories",
    description: "No description provided.",
    schema: z.object({ "ids": z.array(z.number()), "limit": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __storiesFromFetch_impl(idsResult, limit) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["idsResult"] = idsResult;
  __stack.args["limit"] = limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "storiesFromFetch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("idsResult" in __overrides) {
      idsResult = __overrides["idsResult"];
      __stack.args["idsResult"] = idsResult;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "storiesFromFetch",
            args: {
              idsResult,
              limit
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_14 = __stack.args.idsResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_14),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_14.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_12 = await success(await __call(hydrateStories, {
                type: "positional",
                args: [__stack.locals.body ?? [], __stack.args.limit]
              }));
              if (hasInterrupts(__stack.locals.__armval_12)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_12);
                return;
              }
              if (isAborted(__stack.locals.__armval_12)) {
                runner3.halt(__stack.locals.__armval_12.carryThrough(__stack, "storiesFromFetch"));
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(11, __stack.locals.__armval_12);
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_14),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_14.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_13 = failure(await __call(hnError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "storiesFromFetch", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_13)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_13);
                return;
              }
              if (isAborted(__stack.locals.__armval_13)) {
                runner3.halt(__stack.locals.__armval_13.carryThrough(__stack, "storiesFromFetch"));
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(11, __stack.locals.__armval_13);
              return;
            });
          }
        }
      ], void 0, { matchId: 11 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_11));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "storiesFromFetch");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function storiesFromFetch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "storiesFromFetch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "storiesFromFetch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "storiesFromFetch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const storiesFromFetch = __AgencyFunction.create({
  name: "storiesFromFetch",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __storiesFromFetch_impl,
  params: [{
    name: "idsResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "limit",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "storiesFromFetch",
    description: "No description provided.",
    schema: z.object({ "idsResult": z.any(), "limit": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __hnStories_impl(list = __UNSET, limit = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["list"] = list === __UNSET ? `top` : list;
  __stack.args["limit"] = limit === __UNSET ? 30 : limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "hnStories", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("list" in __overrides) {
      list = __overrides["list"];
      __stack.args["list"] = list;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "hnStories",
            args: {
              list,
              limit
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.listResult = await __call(parseStoryList, {
          type: "positional",
          args: [__stack.args.list]
        });
        if (hasInterrupts(__stack.locals.listResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.listResult);
          return;
        }
        if (isAborted(__stack.locals.listResult)) {
          runner2.halt(__stack.locals.listResult.carryThrough(__stack, "hnStories"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.listResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.msg = __stack.locals.listResult.error;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(__stack.locals.msg, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "hnStories", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.file = __stack.locals.listResult.value;
      });
      await runner.step(4, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_4);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::hackernews", `Fetch this Hacker News story list?`, {
            "op": `stories`,
            "query": __stack.args.list
          }, "std::data/tech/hackernews", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_4 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "hnStories", stepPath: "4" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.idsResult = await __call(hnFetch, {
          type: "positional",
          args: [__readStatic(HN_BASE, "HN_BASE", "stdlib/data/tech/hackernews.agency"), __readStatic(HN_DOMAINS, "HN_DOMAINS", "stdlib/data/tech/hackernews.agency"), await __call(buildStoryListPath, {
            type: "positional",
            args: [__stack.locals.file]
          })]
        });
        if (hasInterrupts(__stack.locals.idsResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.idsResult);
          return;
        }
        if (isAborted(__stack.locals.idsResult)) {
          runner2.halt(__stack.locals.idsResult.carryThrough(__stack, "hnStories"));
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(storiesFromFetch, {
          type: "positional",
          args: [__stack.locals.idsResult, await __call(capLimit, {
            type: "positional",
            args: [__stack.args.limit, 100]
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "hnStories");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function hnStories threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "hnStories"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "hnStories",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "hnStories",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const hnStories = __AgencyFunction.create({
  name: "hnStories",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __hnStories_impl,
  params: [{
    name: "list",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "hnStories",
    description: `Fetch a Hacker News story list and hydrate the top items into full stories (title, url, author,
  score, comment count). Fetches the id list plus one request per item, so a large limit means many
  requests (capped at 100).

  @param list - Which ranked list to read: "top", "new", "best", "ask", "show", or "job"
  @param limit - How many stories to hydrate (capped at 100)`,
    schema: z.object({ "list": z.string().nullable().describe("Default: top"), "limit": z.number().nullable().describe("Default: 30") })
  },
  exported: true
}, __toolRegistry);
async function __hnItem_impl(id) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["id"] = id;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "hnItem", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("id" in __overrides) {
      id = __overrides["id"];
      __stack.args["id"] = id;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "hnItem",
            args: {
              id
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::hackernews", `Fetch this Hacker News item?`, {
            "op": `item`,
            "query": `${__stack.args.id}`
          }, "std::data/tech/hackernews", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "hnItem", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(hnFetch, {
          type: "positional",
          args: [__readStatic(HN_BASE, "HN_BASE", "stdlib/data/tech/hackernews.agency"), __readStatic(HN_DOMAINS, "HN_DOMAINS", "stdlib/data/tech/hackernews.agency"), await __call(buildItemPath, {
            type: "positional",
            args: [__stack.args.id]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "hnItem"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(itemFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "hnItem");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function hnItem threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "hnItem"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "hnItem",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "hnItem",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const hnItem = __AgencyFunction.create({
  name: "hnItem",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __hnItem_impl,
  params: [{
    name: "id",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "hnItem",
    description: `Fetch one Hacker News item by id \u2014 a story, comment, job, or poll. Returns its text, author,
  score, and the ids of its direct child comments. An unknown id returns a failure.

  @param id - The Hacker News item id`,
    schema: z.object({ "id": z.number() })
  },
  exported: true
}, __toolRegistry);
async function __hnUser_impl(username) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["username"] = username;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "hnUser", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("username" in __overrides) {
      username = __overrides["username"];
      __stack.args["username"] = username;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "hnUser",
            args: {
              username
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::hackernews", `Fetch this Hacker News user?`, {
            "op": `user`,
            "query": __stack.args.username
          }, "std::data/tech/hackernews", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "hnUser", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(hnFetch, {
          type: "positional",
          args: [__readStatic(HN_BASE, "HN_BASE", "stdlib/data/tech/hackernews.agency"), __readStatic(HN_DOMAINS, "HN_DOMAINS", "stdlib/data/tech/hackernews.agency"), await __call(buildUserPath, {
            type: "positional",
            args: [__stack.args.username]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "hnUser"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(userFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "hnUser");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function hnUser threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "hnUser"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "hnUser",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "hnUser",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const hnUser = __AgencyFunction.create({
  name: "hnUser",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __hnUser_impl,
  params: [{
    name: "username",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "hnUser",
    description: `Fetch a Hacker News user's public profile: karma, account age, about text, and submitted item
  ids. An unknown username returns a failure.

  @param username - The Hacker News username (case-sensitive)`,
    schema: z.object({ "username": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __hnSearch_impl(query, sort = __UNSET, tags = __UNSET, limit = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/tech/hackernews.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["query"] = query;
  __stack.args["sort"] = sort === __UNSET ? `relevance` : sort;
  __stack.args["tags"] = tags === __UNSET ? `story` : tags;
  __stack.args["limit"] = limit === __UNSET ? 20 : limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "hnSearch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("query" in __overrides) {
      query = __overrides["query"];
      __stack.args["query"] = query;
    }
    if ("sort" in __overrides) {
      sort = __overrides["sort"];
      __stack.args["sort"] = sort;
    }
    if ("tags" in __overrides) {
      tags = __overrides["tags"];
      __stack.args["tags"] = tags;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "hnSearch",
            args: {
              query,
              sort,
              tags,
              limit
            },
            moduleId: "stdlib/data/tech/hackernews.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.sortResult = await __call(parseSort, {
          type: "positional",
          args: [__stack.args.sort]
        });
        if (hasInterrupts(__stack.locals.sortResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.sortResult);
          return;
        }
        if (isAborted(__stack.locals.sortResult)) {
          runner2.halt(__stack.locals.sortResult.carryThrough(__stack, "hnSearch"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.sortResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.msg = __stack.locals.sortResult.error;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(__stack.locals.msg, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "hnSearch", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.endpoint = __stack.locals.sortResult.value;
      });
      await runner.step(4, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_4);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::hackernews", `Search Hacker News for this query?`, {
            "op": `search`,
            "query": __stack.args.query
          }, "std::data/tech/hackernews", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_4 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/tech/hackernews.agency", scopeName: "hnSearch", stepPath: "4" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.result = await __call(hnFetch, {
          type: "positional",
          args: [__readStatic(HN_ALGOLIA_BASE, "HN_ALGOLIA_BASE", "stdlib/data/tech/hackernews.agency"), __readStatic(HN_ALGOLIA_DOMAINS, "HN_ALGOLIA_DOMAINS", "stdlib/data/tech/hackernews.agency"), await __call(buildSearchPath, {
            type: "positional",
            args: [__stack.locals.endpoint, __stack.args.query, __stack.args.tags, __stack.args.limit]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "hnSearch"));
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(searchFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "hnSearch");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function hnSearch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "hnSearch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "hnSearch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "hnSearch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const hnSearch = __AgencyFunction.create({
  name: "hnSearch",
  module: "stdlib/data/tech/hackernews.agency",
  fn: __hnSearch_impl,
  params: [{
    name: "query",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "sort",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "tags",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "hnSearch",
    description: `Search Hacker News stories by keyword via the Algolia index. Returns matching stories (title,
  url, author, score, comment count), sorted by relevance or recency.

  @param query - The search keywords
  @param sort - Result ordering: "relevance" or "recent"
  @param tags - Algolia tag filter, e.g. "story", "comment", "ask_hn", "show_hn"
  @param limit - Maximum results (capped at 50)`,
    schema: z.object({ "query": z.string(), "sort": z.string().nullable().describe("Default: relevance"), "tags": z.string().nullable().describe("Default: story"), "limit": z.number().nullable().describe("Default: 20") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/data/tech/hackernews.agency:parseStoryList": { "1": { "line": 82, "col": 2 }, "2": { "line": 83, "col": 2 }, "3": { "line": 86, "col": 2 }, "2.0": { "line": 84, "col": 4 } }, "stdlib/data/tech/hackernews.agency:parseSort": { "1": { "line": 91, "col": 2 }, "2": { "line": 92, "col": 2 }, "3": { "line": 95, "col": 2 }, "2.0": { "line": 93, "col": 4 } }, "stdlib/data/tech/hackernews.agency:capLimit": { "1": { "line": 100, "col": 2 }, "2": { "line": 103, "col": 2 }, "3": { "line": 106, "col": 2 }, "1.0": { "line": 101, "col": 4 }, "2.0": { "line": 104, "col": 4 } }, "stdlib/data/tech/hackernews.agency:takeFirst": { "1": { "line": 111, "col": 2 }, "2": { "line": 114, "col": 2 }, "1.0": { "line": 112, "col": 4 } }, "stdlib/data/tech/hackernews.agency:buildStoryListPath": { "1": { "line": 119, "col": 2 } }, "stdlib/data/tech/hackernews.agency:buildItemPath": { "1": { "line": 124, "col": 2 } }, "stdlib/data/tech/hackernews.agency:buildUserPath": { "1": { "line": 129, "col": 2 } }, "stdlib/data/tech/hackernews.agency:buildSearchPath": { "1": { "line": 134, "col": 2 }, "2": { "line": 135, "col": 2 }, "3": { "line": 136, "col": 2 }, "4": { "line": 137, "col": 2 } }, "stdlib/data/tech/hackernews.agency:parseStory": { "1": { "line": 142, "col": 2 }, "2": { "line": 143, "col": 2 } }, "stdlib/data/tech/hackernews.agency:parseItem": { "1": { "line": 157, "col": 2 }, "2": { "line": 158, "col": 2 } }, "stdlib/data/tech/hackernews.agency:parseUser": { "1": { "line": 175, "col": 2 }, "2": { "line": 176, "col": 2 } }, "stdlib/data/tech/hackernews.agency:parseAlgoliaHits": { "1": { "line": 188, "col": 2 }, "2": { "line": 189, "col": 2 }, "3": { "line": 190, "col": 2 } }, "stdlib/data/tech/hackernews.agency:__block_0": { "3.0": { "line": 191, "col": 4 }, "3.1": { "line": 192, "col": 4 } }, "stdlib/data/tech/hackernews.agency:hnError": { "1": { "line": 207, "col": 2 } }, "stdlib/data/tech/hackernews.agency:itemFinalize": { "1": { "line": 212, "col": 9 }, "2": { "line": 212, "col": 9 }, "3": { "line": 212, "col": 2 }, "2.0": { "line": 212, "col": 9 }, "2.1": { "line": 214, "col": 6 }, "2.2.0": { "line": 216, "col": 8 }, "2.2": { "line": 215, "col": 6 }, "2.3": { "line": 218, "col": 6 }, "2.4": { "line": 212, "col": 9 }, "2.5": { "line": 220, "col": 20 }, "2.6": { "line": 220, "col": 20 } }, "stdlib/data/tech/hackernews.agency:userFinalize": { "1": { "line": 226, "col": 9 }, "2": { "line": 226, "col": 9 }, "3": { "line": 226, "col": 2 }, "2.0": { "line": 226, "col": 9 }, "2.1": { "line": 228, "col": 6 }, "2.2.0": { "line": 230, "col": 8 }, "2.2": { "line": 229, "col": 6 }, "2.3": { "line": 232, "col": 6 }, "2.4": { "line": 226, "col": 9 }, "2.5": { "line": 234, "col": 20 }, "2.6": { "line": 234, "col": 20 } }, "stdlib/data/tech/hackernews.agency:searchFinalize": { "1": { "line": 240, "col": 9 }, "2": { "line": 240, "col": 9 }, "3": { "line": 240, "col": 2 }, "2.0": { "line": 240, "col": 9 }, "2.1": { "line": 241, "col": 21 }, "2.2": { "line": 241, "col": 21 }, "2.3": { "line": 240, "col": 9 }, "2.4": { "line": 242, "col": 20 }, "2.5": { "line": 242, "col": 20 } }, "stdlib/data/tech/hackernews.agency:hnFetch": { "1": { "line": 251, "col": 2 }, "1.0": { "line": 252, "col": 4 } }, "stdlib/data/tech/hackernews.agency:hydrateStories": { "1": { "line": 263, "col": 2 }, "2": { "line": 264, "col": 2 }, "3": { "line": 270, "col": 2 }, "2.0": { "line": 265, "col": 4 }, "2.1.0": { "line": 266, "col": 4 }, "2.1.1": { "line": 267, "col": 6 }, "2.1": { "line": 266, "col": 4 } }, "stdlib/data/tech/hackernews.agency:storiesFromFetch": { "1": { "line": 276, "col": 9 }, "2": { "line": 276, "col": 9 }, "3": { "line": 276, "col": 2 }, "2.0": { "line": 276, "col": 9 }, "2.1": { "line": 277, "col": 21 }, "2.2": { "line": 277, "col": 21 }, "2.3": { "line": 276, "col": 9 }, "2.4": { "line": 278, "col": 20 }, "2.5": { "line": 278, "col": 20 } }, "stdlib/data/tech/hackernews.agency:hnStories": { "1": { "line": 291, "col": 2 }, "2": { "line": 292, "col": 2 }, "3": { "line": 295, "col": 2 }, "4": { "line": 296, "col": 2 }, "5": { "line": 297, "col": 2 }, "6": { "line": 298, "col": 2 }, "2.0": { "line": 292, "col": 2 }, "2.1": { "line": 293, "col": 4 } }, "stdlib/data/tech/hackernews.agency:hnItem": { "1": { "line": 308, "col": 2 }, "2": { "line": 309, "col": 2 }, "3": { "line": 310, "col": 2 } }, "stdlib/data/tech/hackernews.agency:hnUser": { "1": { "line": 320, "col": 2 }, "2": { "line": 321, "col": 2 }, "3": { "line": 322, "col": 2 } }, "stdlib/data/tech/hackernews.agency:hnSearch": { "1": { "line": 335, "col": 2 }, "2": { "line": 336, "col": 2 }, "3": { "line": 339, "col": 2 }, "4": { "line": 340, "col": 2 }, "5": { "line": 341, "col": 2 }, "6": { "line": 342, "col": 2 }, "2.0": { "line": 336, "col": 2 }, "2.1": { "line": 337, "col": 4 } } };
export {
  Item,
  Story,
  User,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  buildItemPath,
  buildSearchPath,
  buildStoryListPath,
  buildUserPath,
  capLimit,
  stdin_default as default,
  hasInterrupts,
  hnError,
  hnFetch,
  hnItem,
  hnSearch,
  hnStories,
  hnUser,
  hydrateStories,
  interrupt,
  isDebugger,
  isInterrupt,
  itemFinalize,
  parseAlgoliaHits,
  parseItem,
  parseSort,
  parseStory,
  parseStoryList,
  parseUser,
  reject,
  respondToInterrupts,
  rewindFrom,
  searchFinalize,
  storiesFromFetch,
  takeFirst,
  userFinalize
};
