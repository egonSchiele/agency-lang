import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { fetchJSON, HttpMethod } from "agency-lang/stdlib/http.js";
import { keys } from "agency-lang/stdlib/object.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  success,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/data/usaspending.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(fetchJSON);
__registerTool(HttpMethod);
__registerTool(keys);
let __staticInitPromise = null;
let USA_BASE = __UNINIT_STATIC;
let USA_DOMAINS = __UNINIT_STATIC;
let AWARD_TYPE_CODES = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    USA_BASE = __deepFreeze(`https://api.usaspending.gov`);
    USA_DOMAINS = __deepFreeze([`api.usaspending.gov`]);
    AWARD_TYPE_CODES = __deepFreeze({
      "contracts": [`A`, `B`, `C`, `D`],
      "grants": [`02`, `03`, `04`, `05`],
      "loans": [`07`, `08`],
      "direct_payments": [`06`, `10`],
      "other": [`09`, `11`, `-1`]
    });
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    USA_BASE,
    USA_DOMAINS,
    AWARD_TYPE_CODES
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/data/usaspending.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/data/usaspending.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/data/usaspending.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/data/usaspending.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const Award = z.object({ "internalId": z.number(), "generatedId": z.string(), "id": z.string(), "recipient": z.string(), "amount": z.number(), "awardingAgency": z.string(), "startDate": z.string(), "endDate": z.string(), "description": z.string() });
const Executive = z.object({ "name": z.string(), "amount": z.number() });
const AwardDetail = z.object({ "id": z.string(), "category": z.string(), "awardType": z.string(), "description": z.string(), "amount": z.number(), "recipient": z.string(), "recipientUei": z.string(), "awardingAgency": z.string(), "startDate": z.string(), "endDate": z.string(), "placeOfPerformance": z.string(), "subawardCount": z.number(), "subawardAmount": z.number(), "executives": z.array(Executive) });
async function __parseAwardType_impl(t) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/usaspending.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["t"] = t;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/usaspending.agency", scopeName: "parseAwardType", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("t" in __overrides) {
      t = __overrides["t"];
      __stack.args["t"] = t;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseAwardType",
            args: {
              t
            },
            moduleId: "stdlib/data/usaspending.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.valid = await __call(keys, {
          type: "positional",
          args: [__readStatic(AWARD_TYPE_CODES, "AWARD_TYPE_CODES", "stdlib/data/usaspending.agency")]
        });
        if (hasInterrupts(__stack.locals.valid)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.valid);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await __callMethod(__stack.locals.valid, "indexOf", {
            type: "positional",
            args: [__stack.args.t]
          }) < 0,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(`unknown awardType '${__stack.args.t}'; valid: ${await __callMethod(__stack.locals.valid, "join", {
                type: "positional",
                args: [`, `]
              })}`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "parseAwardType", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await success(__nn(__readStatic(AWARD_TYPE_CODES, "AWARD_TYPE_CODES", "stdlib/data/usaspending.agency")[__stack.args.t])));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseAwardType threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseAwardType"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseAwardType",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseAwardType",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseAwardType = __AgencyFunction.create({
  name: "parseAwardType",
  module: "stdlib/data/usaspending.agency",
  fn: __parseAwardType_impl,
  params: [{
    name: "t",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "parseAwardType",
    description: "No description provided.",
    schema: z.object({ "t": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildAwardsBody_impl(codes, recipient, agency, startDate, endDate, limit) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/usaspending.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["codes"] = codes;
  __stack.args["recipient"] = recipient;
  __stack.args["agency"] = agency;
  __stack.args["startDate"] = startDate;
  __stack.args["endDate"] = endDate;
  __stack.args["limit"] = limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/usaspending.agency", scopeName: "buildAwardsBody", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("codes" in __overrides) {
      codes = __overrides["codes"];
      __stack.args["codes"] = codes;
    }
    if ("recipient" in __overrides) {
      recipient = __overrides["recipient"];
      __stack.args["recipient"] = recipient;
    }
    if ("agency" in __overrides) {
      agency = __overrides["agency"];
      __stack.args["agency"] = agency;
    }
    if ("startDate" in __overrides) {
      startDate = __overrides["startDate"];
      __stack.args["startDate"] = startDate;
    }
    if ("endDate" in __overrides) {
      endDate = __overrides["endDate"];
      __stack.args["endDate"] = endDate;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildAwardsBody",
            args: {
              codes,
              recipient,
              agency,
              startDate,
              endDate,
              limit
            },
            moduleId: "stdlib/data/usaspending.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.filters = {
          "award_type_codes": __stack.args.codes
        };
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.recipient, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.filters[`recipient_search_text`] = [__stack.args.recipient];
            });
          }
        }
      ]);
      await runner.ifElse(3, [
        {
          condition: async () => !__eq(__stack.args.agency, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.filters[`agencies`] = [{
                "type": `awarding`,
                "tier": `toptier`,
                "name": __stack.args.agency
              }];
            });
          }
        }
      ]);
      await runner.ifElse(4, [
        {
          condition: async () => !__eq(__stack.args.startDate, ``) && !__eq(__stack.args.endDate, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.filters[`time_period`] = [{
                "start_date": __stack.args.startDate,
                "end_date": __stack.args.endDate
              }];
            });
          }
        }
      ]);
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "filters": __stack.locals.filters,
          "fields": [`Award ID`, `Recipient Name`, `Award Amount`, `Awarding Agency`, `Start Date`, `End Date`, `Description`],
          "limit": __stack.args.limit,
          "page": 1,
          "sort": `Award Amount`,
          "order": `desc`
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildAwardsBody threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildAwardsBody"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildAwardsBody",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildAwardsBody",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildAwardsBody = __AgencyFunction.create({
  name: "buildAwardsBody",
  module: "stdlib/data/usaspending.agency",
  fn: __buildAwardsBody_impl,
  params: [{
    name: "codes",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "recipient",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "agency",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "startDate",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "endDate",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildAwardsBody",
    description: "No description provided.",
    schema: z.object({ "codes": z.array(z.string()), "recipient": z.string(), "agency": z.string(), "startDate": z.string(), "endDate": z.string(), "limit": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __buildAwardPath_impl(awardId) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/usaspending.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["awardId"] = awardId;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/usaspending.agency", scopeName: "buildAwardPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("awardId" in __overrides) {
      awardId = __overrides["awardId"];
      __stack.args["awardId"] = awardId;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildAwardPath",
            args: {
              awardId
            },
            moduleId: "stdlib/data/usaspending.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/api/v2/awards/${await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.awardId]
        })}/`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildAwardPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildAwardPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildAwardPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildAwardPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildAwardPath = __AgencyFunction.create({
  name: "buildAwardPath",
  module: "stdlib/data/usaspending.agency",
  fn: __buildAwardPath_impl,
  params: [{
    name: "awardId",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildAwardPath",
    description: "No description provided.",
    schema: z.object({ "awardId": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __parseAwards_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/usaspending.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/usaspending.agency", scopeName: "parseAwards", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseAwards",
            args: {
              raw
            },
            moduleId: "stdlib/data/usaspending.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.results = __stack.locals.r.results ?? [];
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(map, {
          type: "named",
          positionalArgs: [__stack.locals.results],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/data/usaspending.agency", fn: async (a) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["a"] = a;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/usaspending.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.aw = __bstack.args.a ?? {};
              });
              await runner3.step(1, async (runner4) => {
                runner4.halt({
                  "internalId": __bstack.locals.aw.internal_id ?? 0,
                  "generatedId": __bstack.locals.aw.generated_internal_id ?? ``,
                  "id": __nn(__bstack.locals.aw[`Award ID`]) ?? ``,
                  "recipient": __nn(__bstack.locals.aw[`Recipient Name`]) ?? ``,
                  "amount": __nn(__bstack.locals.aw[`Award Amount`]) ?? 0,
                  "awardingAgency": __nn(__bstack.locals.aw[`Awarding Agency`]) ?? ``,
                  "startDate": __nn(__bstack.locals.aw[`Start Date`]) ?? ``,
                  "endDate": __nn(__bstack.locals.aw[`End Date`]) ?? ``,
                  "description": __nn(__bstack.locals.aw[`Description`]) ?? ``
                });
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "a", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseAwards threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseAwards"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseAwards",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseAwards",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseAwards = __AgencyFunction.create({
  name: "parseAwards",
  module: "stdlib/data/usaspending.agency",
  fn: __parseAwards_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseAwards",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __placeString_impl(city, state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/usaspending.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["city"] = city;
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/usaspending.agency", scopeName: "placeString", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("city" in __overrides) {
      city = __overrides["city"];
      __stack.args["city"] = city;
    }
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "placeString",
            args: {
              city,
              state
            },
            moduleId: "stdlib/data/usaspending.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.city, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.args.state);
              return;
            });
          }
        }
      ]);
      await runner.ifElse(2, [
        {
          condition: async () => __eq(__stack.args.state, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.args.city);
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`${__stack.args.city}, ${__stack.args.state}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function placeString threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "placeString"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "placeString",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "placeString",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const placeString = __AgencyFunction.create({
  name: "placeString",
  module: "stdlib/data/usaspending.agency",
  fn: __placeString_impl,
  params: [{
    name: "city",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "placeString",
    description: "No description provided.",
    schema: z.object({ "city": z.string(), "state": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __parseAwardDetail_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/usaspending.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/usaspending.agency", scopeName: "parseAwardDetail", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseAwardDetail",
            args: {
              raw
            },
            moduleId: "stdlib/data/usaspending.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.recipient = __stack.locals.r.recipient ?? {};
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.awarding = __stack.locals.r.awarding_agency ?? {};
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.toptier = __stack.locals.awarding.toptier_agency ?? {};
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.pop = __stack.locals.r.period_of_performance ?? {};
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.place = __stack.locals.r.place_of_performance ?? {};
      });
      await runner.step(7, async (runner2) => {
        __stack.locals.execDetails = __stack.locals.r.executive_details ?? {};
      });
      await runner.step(8, async (runner2) => {
        __stack.locals.officers = __stack.locals.execDetails.officers ?? [];
      });
      await runner.step(9, async (runner2) => {
        __stack.locals.city = __stack.locals.place.city_name ?? ``;
      });
      await runner.step(10, async (runner2) => {
        __stack.locals.state = __stack.locals.place.state_code ?? ``;
      });
      await runner.step(11, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "id": __stack.locals.r.generated_unique_award_id ?? ``,
          "category": __stack.locals.r.category ?? ``,
          "awardType": __stack.locals.r.type_description ?? ``,
          "description": __stack.locals.r.description ?? ``,
          "amount": __stack.locals.r.total_obligation ?? 0,
          "recipient": __stack.locals.recipient.recipient_name ?? ``,
          "recipientUei": __stack.locals.recipient.recipient_uei ?? ``,
          "awardingAgency": __stack.locals.toptier.name ?? ``,
          "startDate": __stack.locals.pop.start_date ?? ``,
          "endDate": __stack.locals.pop.end_date ?? ``,
          "placeOfPerformance": await __call(placeString, {
            type: "positional",
            args: [__stack.locals.city, __stack.locals.state]
          }),
          "subawardCount": __stack.locals.r.subaward_count ?? 0,
          "subawardAmount": __stack.locals.r.total_subaward_amount ?? 0,
          "executives": await __call(map, {
            type: "named",
            positionalArgs: [__stack.locals.officers],
            namedArgs: {},
            blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/data/usaspending.agency", fn: async (o) => {
              const __bsetup = setupFunction();
              const __bstack = __bsetup.stack;
              const __self2 = __bstack.locals;
              const __bframe___block_1 = __bstack;
              __bstack.args["o"] = o;
              const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/usaspending.agency", scopeName: "__block_1" });
              try {
                await runner3.step(0, async (runner4) => {
                  __bstack.locals.off = __bstack.args.o ?? {};
                });
                await runner3.step(1, async (runner4) => {
                  runner4.halt({
                    "name": __bstack.locals.off.name ?? ``,
                    "amount": __bstack.locals.off.amount ?? 0
                  });
                  return;
                });
                return runner3.halted ? runner3.haltResult : void 0;
              } finally {
                __bsetup.stateStack.pop();
              }
            }, params: [{ name: "o", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
          })
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseAwardDetail threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseAwardDetail"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseAwardDetail",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseAwardDetail",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseAwardDetail = __AgencyFunction.create({
  name: "parseAwardDetail",
  module: "stdlib/data/usaspending.agency",
  fn: __parseAwardDetail_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseAwardDetail",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __usaspendingError_impl(err) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/usaspending.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["err"] = err;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/usaspending.agency", scopeName: "usaspendingError", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("err" in __overrides) {
      err = __overrides["err"];
      __stack.args["err"] = err;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "usaspendingError",
            args: {
              err
            },
            moduleId: "stdlib/data/usaspending.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`USASpending request failed: ${__stack.args.err.message ?? __stack.args.err}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function usaspendingError threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "usaspendingError"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "usaspendingError",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "usaspendingError",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const usaspendingError = __AgencyFunction.create({
  name: "usaspendingError",
  module: "stdlib/data/usaspending.agency",
  fn: __usaspendingError_impl,
  params: [{
    name: "err",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "usaspendingError",
    description: "No description provided.",
    schema: z.object({ "err": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __awardsFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/usaspending.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/usaspending.agency", scopeName: "awardsFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "awardsFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/usaspending.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_4 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_4),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_4.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_2 = await success(await __call(parseAwards, {
                type: "positional",
                args: [__stack.locals.body]
              }));
              if (hasInterrupts(__stack.locals.__armval_2)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_2);
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_2);
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_4),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_4.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_3 = failure(await __call(usaspendingError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "awardsFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_3)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_3);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_3);
              return;
            });
          }
        }
      ], void 0, { matchId: 1 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function awardsFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "awardsFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "awardsFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "awardsFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const awardsFinalize = __AgencyFunction.create({
  name: "awardsFinalize",
  module: "stdlib/data/usaspending.agency",
  fn: __awardsFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "awardsFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __awardDetailFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/usaspending.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/usaspending.agency", scopeName: "awardDetailFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "awardDetailFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/usaspending.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_7 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_7),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_7.value;
            });
            await runner2.ifElse(1, [
              {
                condition: async () => __eq(__stack.locals.body, null),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    runner4.exitMatch(5, failure(`USASpending returned no award`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "awardDetailFinalize", args: __stack.args }));
                    return;
                  });
                }
              }
            ]);
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(5, await success(await __call(parseAwardDetail, {
                type: "positional",
                args: [__stack.locals.body]
              })));
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_7),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_7.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_6 = failure(await __call(usaspendingError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "awardDetailFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_6)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_6);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(5, __stack.locals.__armval_6);
              return;
            });
          }
        }
      ], void 0, { matchId: 5 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_5));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function awardDetailFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "awardDetailFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "awardDetailFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "awardDetailFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const awardDetailFinalize = __AgencyFunction.create({
  name: "awardDetailFinalize",
  module: "stdlib/data/usaspending.agency",
  fn: __awardDetailFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "awardDetailFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __usaspendingFetch_impl(path2, method, body) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/usaspending.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["path"] = path2;
  __stack.args["method"] = method;
  __stack.args["body"] = body;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/usaspending.agency", scopeName: "usaspendingFetch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("path" in __overrides) {
      path2 = __overrides["path"];
      __stack.args["path"] = path2;
    }
    if ("method" in __overrides) {
      method = __overrides["method"];
      __stack.args["method"] = method;
    }
    if ("body" in __overrides) {
      body = __overrides["body"];
      __stack.args["body"] = body;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "usaspendingFetch",
            args: {
              path: path2,
              method,
              body
            },
            moduleId: "stdlib/data/usaspending.agency"
          }
        });
      });
      await runner.handle(1, async (data) => {
        if (__eq(data.effect, `std::http::fetchJSON`)) {
          return await approve();
        }
      }, async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __functionCompleted = true;
          runner3.halt(await __call(fetchJSON, {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              baseUrl: __readStatic(USA_BASE, "USA_BASE", "stdlib/data/usaspending.agency"),
              path: __stack.args.path,
              allowedDomains: __readStatic(USA_DOMAINS, "USA_DOMAINS", "stdlib/data/usaspending.agency"),
              method: __stack.args.method,
              body: __stack.args.body
            }
          }));
          return;
        });
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function usaspendingFetch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "usaspendingFetch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "usaspendingFetch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "usaspendingFetch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const usaspendingFetch = __AgencyFunction.create({
  name: "usaspendingFetch",
  module: "stdlib/data/usaspending.agency",
  fn: __usaspendingFetch_impl,
  params: [{
    name: "path",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "method",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "body",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "usaspendingFetch",
    description: "No description provided.",
    schema: z.object({ "path": z.string(), "method": HttpMethod, "body": z.union([z.record(z.string(), z.any()), z.string(), z.null()]) })
  },
  exported: false
}, __toolRegistry);
async function __usaspendingAwards_impl(recipient = __UNSET, agency = __UNSET, awardType = __UNSET, startDate = __UNSET, endDate = __UNSET, limit = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/usaspending.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["recipient"] = recipient === __UNSET ? `` : recipient;
  __stack.args["agency"] = agency === __UNSET ? `` : agency;
  __stack.args["awardType"] = awardType === __UNSET ? `contracts` : awardType;
  __stack.args["startDate"] = startDate === __UNSET ? `` : startDate;
  __stack.args["endDate"] = endDate === __UNSET ? `` : endDate;
  __stack.args["limit"] = limit === __UNSET ? 20 : limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/usaspending.agency", scopeName: "usaspendingAwards", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("recipient" in __overrides) {
      recipient = __overrides["recipient"];
      __stack.args["recipient"] = recipient;
    }
    if ("agency" in __overrides) {
      agency = __overrides["agency"];
      __stack.args["agency"] = agency;
    }
    if ("awardType" in __overrides) {
      awardType = __overrides["awardType"];
      __stack.args["awardType"] = awardType;
    }
    if ("startDate" in __overrides) {
      startDate = __overrides["startDate"];
      __stack.args["startDate"] = startDate;
    }
    if ("endDate" in __overrides) {
      endDate = __overrides["endDate"];
      __stack.args["endDate"] = endDate;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "usaspendingAwards",
            args: {
              recipient,
              agency,
              awardType,
              startDate,
              endDate,
              limit
            },
            moduleId: "stdlib/data/usaspending.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.codesResult = await __call(parseAwardType, {
          type: "positional",
          args: [__stack.args.awardType]
        });
        if (hasInterrupts(__stack.locals.codesResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.codesResult);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.codesResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.msg = __stack.locals.codesResult.error;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(__stack.locals.msg, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "usaspendingAwards", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.codes = __stack.locals.codesResult.value;
      });
      await runner.step(4, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_4);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::usaspending", `Search USASpending federal awards?`, {
            "op": `awards`,
            "query": __stack.args.recipient
          }, "std::data/usaspending", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_4 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/usaspending.agency", scopeName: "usaspendingAwards", stepPath: "4" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.body = await __call(buildAwardsBody, {
          type: "positional",
          args: [__stack.locals.codes, __stack.args.recipient, __stack.args.agency, __stack.args.startDate, __stack.args.endDate, __stack.args.limit]
        });
        if (hasInterrupts(__stack.locals.body)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.body);
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.result = await __call(usaspendingFetch, {
          type: "positional",
          args: [`/api/v2/search/spending_by_award/`, `POST`, __stack.locals.body]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.step(7, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(awardsFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function usaspendingAwards threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "usaspendingAwards"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "usaspendingAwards",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "usaspendingAwards",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const usaspendingAwards = __AgencyFunction.create({
  name: "usaspendingAwards",
  module: "stdlib/data/usaspending.agency",
  fn: __usaspendingAwards_impl,
  params: [{
    name: "recipient",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "agency",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "awardType",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "startDate",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "endDate",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "usaspendingAwards",
    description: `Search U.S. federal awards. Returns each award's id, recipient, amount, awarding agency, dates, and
  description, most-funded first. An empty result set returns an empty list.

  @param recipient - Recipient or company name to filter by (blank = any)
  @param agency - Awarding agency name to filter by (blank = any)
  @param awardType - Award category: contracts, grants, loans, direct_payments, or other
  @param startDate - ISO start date bounding the award period; only applied when endDate is also set
  @param endDate - ISO end date bounding the award period; only applied when startDate is also set
  @param limit - Maximum number of awards to return`,
    schema: z.object({ "recipient": z.string().nullable().describe("Default: "), "agency": z.string().nullable().describe("Default: "), "awardType": z.string().nullable().describe("Default: contracts"), "startDate": z.string().nullable().describe("Default: "), "endDate": z.string().nullable().describe("Default: "), "limit": z.number().nullable().describe("Default: 20") })
  },
  exported: true
}, __toolRegistry);
async function __usaspendingAward_impl(awardId) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/usaspending.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["awardId"] = awardId;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/usaspending.agency", scopeName: "usaspendingAward", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("awardId" in __overrides) {
      awardId = __overrides["awardId"];
      __stack.args["awardId"] = awardId;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "usaspendingAward",
            args: {
              awardId
            },
            moduleId: "stdlib/data/usaspending.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::usaspending", `Fetch this USASpending award?`, {
            "op": `award`,
            "query": __stack.args.awardId
          }, "std::data/usaspending", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/usaspending.agency", scopeName: "usaspendingAward", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(usaspendingFetch, {
          type: "positional",
          args: [await __call(buildAwardPath, {
            type: "positional",
            args: [__stack.args.awardId]
          }), `GET`, null]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(awardDetailFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function usaspendingAward threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "usaspendingAward"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "usaspendingAward",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "usaspendingAward",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const usaspendingAward = __AgencyFunction.create({
  name: "usaspendingAward",
  module: "stdlib/data/usaspending.agency",
  fn: __usaspendingAward_impl,
  params: [{
    name: "awardId",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "usaspendingAward",
    description: `Fetch full detail for one federal award. Returns amount, recipient and UEI, awarding agency, dates,
  place of performance, sub-award totals, and recipient executive compensation. Unknown id returns a
  failure.

  @param awardId - The award id: the generatedId from a search, or the numeric internalId as a string`,
    schema: z.object({ "awardId": z.string() })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/data/usaspending.agency:parseAwardType": { "1": { "line": 84, "col": 2 }, "2": { "line": 85, "col": 2 }, "3": { "line": 88, "col": 2 }, "2.0": { "line": 86, "col": 4 } }, "stdlib/data/usaspending.agency:buildAwardsBody": { "1": { "line": 94, "col": 2 }, "2": { "line": 95, "col": 2 }, "3": { "line": 98, "col": 2 }, "4": { "line": 101, "col": 2 }, "5": { "line": 104, "col": 2 }, "2.0": { "line": 96, "col": 4 }, "3.0": { "line": 99, "col": 4 }, "4.0": { "line": 102, "col": 4 } }, "stdlib/data/usaspending.agency:buildAwardPath": { "1": { "line": 116, "col": 2 } }, "stdlib/data/usaspending.agency:parseAwards": { "1": { "line": 122, "col": 2 }, "2": { "line": 123, "col": 2 }, "3": { "line": 124, "col": 2 } }, "stdlib/data/usaspending.agency:__block_0": { "3.0": { "line": 125, "col": 4 }, "3.1": { "line": 126, "col": 4 } }, "stdlib/data/usaspending.agency:placeString": { "1": { "line": 143, "col": 2 }, "2": { "line": 146, "col": 2 }, "3": { "line": 149, "col": 2 }, "1.0": { "line": 144, "col": 4 }, "2.0": { "line": 147, "col": 4 } }, "stdlib/data/usaspending.agency:parseAwardDetail": { "1": { "line": 154, "col": 2 }, "2": { "line": 155, "col": 2 }, "3": { "line": 156, "col": 2 }, "4": { "line": 157, "col": 2 }, "5": { "line": 158, "col": 2 }, "6": { "line": 159, "col": 2 }, "7": { "line": 160, "col": 2 }, "8": { "line": 161, "col": 2 }, "9": { "line": 162, "col": 2 }, "10": { "line": 163, "col": 2 }, "11": { "line": 164, "col": 2 } }, "stdlib/data/usaspending.agency:__block_1": { "11.0": { "line": 179, "col": 6 }, "11.1": { "line": 180, "col": 6 } }, "stdlib/data/usaspending.agency:usaspendingError": { "1": { "line": 190, "col": 2 } }, "stdlib/data/usaspending.agency:awardsFinalize": { "1": { "line": 195, "col": 9 }, "2": { "line": 195, "col": 9 }, "3": { "line": 195, "col": 2 }, "2.0": { "line": 195, "col": 9 }, "2.1": { "line": 196, "col": 21 }, "2.2": { "line": 196, "col": 21 }, "2.3": { "line": 195, "col": 9 }, "2.4": { "line": 197, "col": 20 }, "2.5": { "line": 197, "col": 20 } }, "stdlib/data/usaspending.agency:awardDetailFinalize": { "1": { "line": 203, "col": 9 }, "2": { "line": 203, "col": 9 }, "3": { "line": 203, "col": 2 }, "2.0": { "line": 203, "col": 9 }, "2.1.0": { "line": 206, "col": 8 }, "2.1": { "line": 205, "col": 6 }, "2.2": { "line": 208, "col": 6 }, "2.3": { "line": 203, "col": 9 }, "2.4": { "line": 210, "col": 20 }, "2.5": { "line": 210, "col": 20 } }, "stdlib/data/usaspending.agency:usaspendingFetch": { "1": { "line": 219, "col": 2 }, "1.0": { "line": 220, "col": 4 } }, "stdlib/data/usaspending.agency:usaspendingAwards": { "1": { "line": 240, "col": 2 }, "2": { "line": 241, "col": 2 }, "3": { "line": 244, "col": 2 }, "4": { "line": 245, "col": 2 }, "5": { "line": 246, "col": 2 }, "6": { "line": 247, "col": 2 }, "7": { "line": 248, "col": 2 }, "2.0": { "line": 241, "col": 2 }, "2.1": { "line": 242, "col": 4 } }, "stdlib/data/usaspending.agency:usaspendingAward": { "1": { "line": 259, "col": 2 }, "2": { "line": 260, "col": 2 }, "3": { "line": 261, "col": 2 } } };
export {
  Award,
  AwardDetail,
  Executive,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  awardDetailFinalize,
  awardsFinalize,
  buildAwardPath,
  buildAwardsBody,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  parseAwardDetail,
  parseAwardType,
  parseAwards,
  placeString,
  reject,
  respondToInterrupts,
  rewindFrom,
  usaspendingAward,
  usaspendingAwards,
  usaspendingError,
  usaspendingFetch
};
