import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { syntaxHighlight as _syntaxHighlight, detectLanguage as _detectLanguage, _diff, _patch, BUILTIN_THEME_NAMES as _builtinThemeNames } from "agency-lang/stdlib-lib/syntax.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __registerStaticInit,
  __registerGlobalsInit,
  failure,
  isFailure,
  stampFailureBoundary,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/syntax.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
let __staticInitPromise = null;
let colorSchemes = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    colorSchemes = __deepFreeze(_builtinThemeNames);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    colorSchemes
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/syntax.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/syntax.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/syntax.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/syntax.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const HighlightMode = z.union([z.literal("shell"), z.literal("web")]);
async function __detectLanguage_impl(code) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/syntax.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["code"] = code;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/syntax.agency", scopeName: "detectLanguage", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("code" in __overrides) {
      code = __overrides["code"];
      __stack.args["code"] = code;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "detectLanguage",
            args: {
              code
            },
            moduleId: "stdlib/syntax.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_detectLanguage, {
          type: "positional",
          args: [__stack.args.code]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function detectLanguage threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "detectLanguage"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "detectLanguage",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "detectLanguage",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const detectLanguage = __AgencyFunction.create({
  name: "detectLanguage",
  module: "stdlib/syntax.agency",
  fn: __detectLanguage_impl,
  params: [{
    name: "code",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "detectLanguage",
    description: `Guess the programming language of a code snippet. Returns a highlight.js
  language name (e.g. "typescript", "python", "json"), or "plaintext" when it
  can't tell. Detection is heuristic and less reliable on short or ambiguous
  snippets.

  @param code - The code snippet to detect the language of`,
    schema: z.object({ "code": z.string() })
  },
  exported: true
}, __toolRegistry);
const Style = z.union([z.literal("bold"), z.literal("italic"), z.literal("underline"), z.literal("dim")]);
const TokenStyle = z.object({ "color": z.string(), "styles": z.union([z.array(Style), z.null()]).optional().default(null) });
const ColorScheme = z.object({ "keyword": z.union([TokenStyle, z.null()]).optional().default(null), "builtIn": z.union([TokenStyle, z.null()]).optional().default(null), "type": z.union([TokenStyle, z.null()]).optional().default(null), "literal": z.union([TokenStyle, z.null()]).optional().default(null), "number": z.union([TokenStyle, z.null()]).optional().default(null), "regexp": z.union([TokenStyle, z.null()]).optional().default(null), "string": z.union([TokenStyle, z.null()]).optional().default(null), "subst": z.union([TokenStyle, z.null()]).optional().default(null), "symbol": z.union([TokenStyle, z.null()]).optional().default(null), "class": z.union([TokenStyle, z.null()]).optional().default(null), "function": z.union([TokenStyle, z.null()]).optional().default(null), "title": z.union([TokenStyle, z.null()]).optional().default(null), "params": z.union([TokenStyle, z.null()]).optional().default(null), "comment": z.union([TokenStyle, z.null()]).optional().default(null), "doctag": z.union([TokenStyle, z.null()]).optional().default(null), "meta": z.union([TokenStyle, z.null()]).optional().default(null), "section": z.union([TokenStyle, z.null()]).optional().default(null), "tag": z.union([TokenStyle, z.null()]).optional().default(null), "name": z.union([TokenStyle, z.null()]).optional().default(null), "attr": z.union([TokenStyle, z.null()]).optional().default(null), "attribute": z.union([TokenStyle, z.null()]).optional().default(null), "variable": z.union([TokenStyle, z.null()]).optional().default(null), "bullet": z.union([TokenStyle, z.null()]).optional().default(null), "code": z.union([TokenStyle, z.null()]).optional().default(null), "emphasis": z.union([TokenStyle, z.null()]).optional().default(null), "strong": z.union([TokenStyle, z.null()]).optional().default(null), "formula": z.union([TokenStyle, z.null()]).optional().default(null), "link": z.union([TokenStyle, z.null()]).optional().default(null), "quote": z.union([TokenStyle, z.null()]).optional().default(null), "addition": z.union([TokenStyle, z.null()]).optional().default(null), "deletion": z.union([TokenStyle, z.null()]).optional().default(null), "default": z.union([TokenStyle, z.null()]).optional().default(null), "metaKeyword": z.union([TokenStyle, z.null()]).optional().default(null), "metaString": z.union([TokenStyle, z.null()]).optional().default(null), "builtinName": z.union([TokenStyle, z.null()]).optional().default(null), "selectorTag": z.union([TokenStyle, z.null()]).optional().default(null), "selectorId": z.union([TokenStyle, z.null()]).optional().default(null), "selectorClass": z.union([TokenStyle, z.null()]).optional().default(null), "selectorAttr": z.union([TokenStyle, z.null()]).optional().default(null), "selectorPseudo": z.union([TokenStyle, z.null()]).optional().default(null), "templateTag": z.union([TokenStyle, z.null()]).optional().default(null), "templateVariable": z.union([TokenStyle, z.null()]).optional().default(null) });
async function __highlight_impl(code, language = __UNSET, mode = __UNSET, theme = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/syntax.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["code"] = code;
  __stack.args["language"] = language === __UNSET ? `plaintext` : language;
  __stack.args["mode"] = mode === __UNSET ? `shell` : mode;
  __stack.args["theme"] = theme === __UNSET ? `vscode-dark` : theme;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/syntax.agency", scopeName: "highlight", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("code" in __overrides) {
      code = __overrides["code"];
      __stack.args["code"] = code;
    }
    if ("language" in __overrides) {
      language = __overrides["language"];
      __stack.args["language"] = language;
    }
    if ("mode" in __overrides) {
      mode = __overrides["mode"];
      __stack.args["mode"] = mode;
    }
    if ("theme" in __overrides) {
      theme = __overrides["theme"];
      __stack.args["theme"] = theme;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "highlight",
            args: {
              code,
              language,
              mode,
              theme
            },
            moduleId: "stdlib/syntax.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_syntaxHighlight, {
          type: "positional",
          args: [__stack.args.code, __stack.args.language, __stack.args.theme]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function highlight threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "highlight"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "highlight",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "highlight",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const highlight = __AgencyFunction.create({
  name: "highlight",
  module: "stdlib/syntax.agency",
  fn: __highlight_impl,
  params: [{
    name: "code",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "language",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "mode",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "theme",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "highlight",
    description: `Syntax-highlight a code snippet and return the highlighted string.

  @param code - The code snippet to highlight
  @param language - The programming language of the code (e.g. "javascript", "python", "json"). Use "auto" to auto-detect it (heuristic; less reliable on short snippets). Defaults to "plaintext".
  @param mode - Output format: "shell" for terminal output, "web" for web output
  @param theme - A named color scheme ("vscode-dark", "github-dark", "monokai", "dracula", "nord", "github", "a11y-dark", "a11y-light") or a custom ColorScheme object. An unknown scheme name or an invalid color returns a failure.`,
    schema: z.object({ "code": z.string(), "language": z.string().nullable().describe("Default: plaintext"), "mode": HighlightMode.nullable().describe("Default: shell"), "theme": z.union([z.string(), ColorScheme]).nullable().describe("Default: vscode-dark") })
  },
  exported: true
}, __toolRegistry);
async function __diff_impl(oldText, newText, context = __UNSET, lineNumbers = __UNSET, color2 = __UNSET, oldLabel = __UNSET, newLabel = __UNSET, ignoreWhitespace = __UNSET, hunkHeaders = __UNSET, summary = __UNSET, language = __UNSET, theme = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/syntax.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["oldText"] = oldText;
  __stack.args["newText"] = newText;
  __stack.args["context"] = context === __UNSET ? -1 : context;
  __stack.args["lineNumbers"] = lineNumbers === __UNSET ? false : lineNumbers;
  __stack.args["color"] = color2 === __UNSET ? `auto` : color2;
  __stack.args["oldLabel"] = oldLabel === __UNSET ? `` : oldLabel;
  __stack.args["newLabel"] = newLabel === __UNSET ? `` : newLabel;
  __stack.args["ignoreWhitespace"] = ignoreWhitespace === __UNSET ? false : ignoreWhitespace;
  __stack.args["hunkHeaders"] = hunkHeaders === __UNSET ? false : hunkHeaders;
  __stack.args["summary"] = summary === __UNSET ? false : summary;
  __stack.args["language"] = language === __UNSET ? `` : language;
  __stack.args["theme"] = theme === __UNSET ? `vscode-dark` : theme;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/syntax.agency", scopeName: "diff", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("oldText" in __overrides) {
      oldText = __overrides["oldText"];
      __stack.args["oldText"] = oldText;
    }
    if ("newText" in __overrides) {
      newText = __overrides["newText"];
      __stack.args["newText"] = newText;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("lineNumbers" in __overrides) {
      lineNumbers = __overrides["lineNumbers"];
      __stack.args["lineNumbers"] = lineNumbers;
    }
    if ("color" in __overrides) {
      color2 = __overrides["color"];
      __stack.args["color"] = color2;
    }
    if ("oldLabel" in __overrides) {
      oldLabel = __overrides["oldLabel"];
      __stack.args["oldLabel"] = oldLabel;
    }
    if ("newLabel" in __overrides) {
      newLabel = __overrides["newLabel"];
      __stack.args["newLabel"] = newLabel;
    }
    if ("ignoreWhitespace" in __overrides) {
      ignoreWhitespace = __overrides["ignoreWhitespace"];
      __stack.args["ignoreWhitespace"] = ignoreWhitespace;
    }
    if ("hunkHeaders" in __overrides) {
      hunkHeaders = __overrides["hunkHeaders"];
      __stack.args["hunkHeaders"] = hunkHeaders;
    }
    if ("summary" in __overrides) {
      summary = __overrides["summary"];
      __stack.args["summary"] = summary;
    }
    if ("language" in __overrides) {
      language = __overrides["language"];
      __stack.args["language"] = language;
    }
    if ("theme" in __overrides) {
      theme = __overrides["theme"];
      __stack.args["theme"] = theme;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "diff",
            args: {
              oldText,
              newText,
              context,
              lineNumbers,
              color: color2,
              oldLabel,
              newLabel,
              ignoreWhitespace,
              hunkHeaders,
              summary,
              language,
              theme
            },
            moduleId: "stdlib/syntax.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_diff, {
          type: "positional",
          args: [__stack.args.oldText, __stack.args.newText, __stack.args.context, __stack.args.lineNumbers, __stack.args.color, __stack.args.oldLabel, __stack.args.newLabel, __stack.args.ignoreWhitespace, __stack.args.hunkHeaders, __stack.args.summary, __stack.args.language, __stack.args.theme]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function diff threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "diff"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "diff",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "diff",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const diff = __AgencyFunction.create({
  name: "diff",
  module: "stdlib/syntax.agency",
  fn: __diff_impl,
  params: [{
    name: "oldText",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "newText",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "lineNumbers",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "color",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "oldLabel",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "newLabel",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ignoreWhitespace",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "hunkHeaders",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "summary",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "language",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "theme",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "diff",
    description: `Produce a human-readable diff of two strings and return it as a string.
  Shows the full text by default with changed words highlighted via \`-\`/\`+\`
  lines.

  @param oldText - The original text
  @param newText - The updated text
  @param context - Unchanged lines to keep around each change; -1 means show the full text
  @param lineNumbers - Prefix each line with its line number
  @param color - \`"auto"\` (default) emits ANSI colors only when stdout is a TTY; \`true\` always; \`false\` never. Coloring highlights deletions in red and insertions in green inline.
  @param oldLabel - When non-empty, render a \`--- <oldLabel>\` header
  @param newLabel - When non-empty, render a \`+++ <newLabel>\` header
  @param ignoreWhitespace - Treat whitespace-only changes as equal
  @param hunkHeaders - Emit \`@@ -l,c +l,c @@\` separators between change regions
  @param summary - Prefix the diff with an "N insertions, M deletions" line
  @param language - When non-empty (e.g. "agency", "ts", "python") and color is on, render changed lines with a dim red/green background and syntax-highlighted code instead of inline \`-\`/\`+\` coloring. Use "auto" to auto-detect the language once from the full text (heuristic).
  @param theme - When \`language\` is set, the syntax-highlighting color scheme: a named scheme (e.g. "dracula") or a custom ColorScheme object. An unknown scheme or invalid color returns a failure.`,
    schema: z.object({ "oldText": z.string(), "newText": z.string(), "context": z.number().nullable().describe("Default: -1"), "lineNumbers": z.boolean().nullable().describe("Default: false"), "color": z.union([z.literal("auto"), z.boolean()]).nullable().describe("Default: auto"), "oldLabel": z.string().nullable().describe("Default: "), "newLabel": z.string().nullable().describe("Default: "), "ignoreWhitespace": z.boolean().nullable().describe("Default: false"), "hunkHeaders": z.boolean().nullable().describe("Default: false"), "summary": z.boolean().nullable().describe("Default: false"), "language": z.string().nullable().describe("Default: "), "theme": z.union([z.string(), ColorScheme]).nullable().describe("Default: vscode-dark") })
  },
  exported: true
}, __toolRegistry);
async function __patch_impl(oldText, newText, filename, context = __UNSET, ignoreWhitespace = __UNSET, newFilename = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/syntax.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["oldText"] = oldText;
  __stack.args["newText"] = newText;
  __stack.args["filename"] = filename;
  __stack.args["context"] = context === __UNSET ? 3 : context;
  __stack.args["ignoreWhitespace"] = ignoreWhitespace === __UNSET ? false : ignoreWhitespace;
  __stack.args["newFilename"] = newFilename === __UNSET ? `` : newFilename;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/syntax.agency", scopeName: "patch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("oldText" in __overrides) {
      oldText = __overrides["oldText"];
      __stack.args["oldText"] = oldText;
    }
    if ("newText" in __overrides) {
      newText = __overrides["newText"];
      __stack.args["newText"] = newText;
    }
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("ignoreWhitespace" in __overrides) {
      ignoreWhitespace = __overrides["ignoreWhitespace"];
      __stack.args["ignoreWhitespace"] = ignoreWhitespace;
    }
    if ("newFilename" in __overrides) {
      newFilename = __overrides["newFilename"];
      __stack.args["newFilename"] = newFilename;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "patch",
            args: {
              oldText,
              newText,
              filename,
              context,
              ignoreWhitespace,
              newFilename
            },
            moduleId: "stdlib/syntax.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_patch, {
          type: "positional",
          args: [__stack.args.oldText, __stack.args.newText, __stack.args.filename, __stack.args.context, __stack.args.ignoreWhitespace, __stack.args.newFilename]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function patch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "patch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "patch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "patch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const patch = __AgencyFunction.create({
  name: "patch",
  module: "stdlib/syntax.agency",
  fn: __patch_impl,
  params: [{
    name: "oldText",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "newText",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ignoreWhitespace",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "newFilename",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "patch",
    description: `Produce a standard unified diff and return it as a string, in a format that
  \`git apply\` can apply. Pass the file's path as \`filename\`; an empty \`oldText\`
  produces a file-creation patch and an empty \`newText\` a deletion patch.

  @param oldText - The original file contents
  @param newText - The updated file contents
  @param filename - The path used in the patch headers (the \`a/\` and \`b/\` sides)
  @param context - Context lines to include around each hunk
  @param ignoreWhitespace - Treat whitespace-only changes as equal
  @param newFilename - When non-empty, use this path for the new (\`+++\`) side, e.g. to record a rename`,
    schema: z.object({ "oldText": z.string(), "newText": z.string(), "filename": z.string(), "context": z.number().nullable().describe("Default: 3"), "ignoreWhitespace": z.boolean().nullable().describe("Default: false"), "newFilename": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/syntax.agency:detectLanguage": { "1": { "line": 31, "col": 2 } }, "stdlib/syntax.agency:highlight": { "1": { "line": 127, "col": 2 } }, "stdlib/syntax.agency:diff": { "1": { "line": 162, "col": 2 } }, "stdlib/syntax.agency:patch": { "1": { "line": 198, "col": 2 } } };
export {
  ColorScheme,
  HighlightMode,
  Style,
  TokenStyle,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  colorSchemes,
  stdin_default as default,
  detectLanguage,
  diff,
  hasInterrupts,
  highlight,
  interrupt,
  isDebugger,
  isInterrupt,
  patch,
  reject,
  respondToInterrupts,
  rewindFrom
};
