import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { _compile, _compileFile, _typecheck, _typecheckFile, _getEffects, _parseAST, _writeAST, _format, _formatFile, _walkAST, _getNodesOfType, _filterImports, _subprocessDepth } from "agency-lang/stdlib-lib/agency.js";
import { VERSION } from "agency-lang/stdlib-lib/version.js";
import { guard, systemMessage } from "agency-lang/stdlib/thread.js";
import { docsSkill } from "agency-lang/stdlib/skills.js";
import { ls, glob, grep, exec } from "agency-lang/stdlib/shell.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  runPrompt,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  success,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __tryCall,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __threads,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/agency.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(guard);
__registerTool(systemMessage);
__registerTool(docsSkill);
__registerTool(ls);
__registerTool(glob);
__registerTool(grep);
__registerTool(exec);
let __staticInitPromise = null;
let verifyTools = __UNINIT_STATIC;
let verifySysPrompt = __UNINIT_STATIC;
let writeSysPrompt = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    verifyTools = __deepFreeze([await __callMethod(__readStatic(read, "read", ""), "partial", {
      type: "named",
      positionalArgs: [],
      namedArgs: {
        useAgentCwd: true
      }
    }), await __callMethod(__readStatic(ls, "ls", ""), "partial", {
      type: "named",
      positionalArgs: [],
      namedArgs: {
        useAgentCwd: true
      }
    }), await __callMethod(__readStatic(glob, "glob", ""), "partial", {
      type: "named",
      positionalArgs: [],
      namedArgs: {
        useAgentCwd: true
      }
    }), await __callMethod(__readStatic(grep, "grep", ""), "partial", {
      type: "named",
      positionalArgs: [],
      namedArgs: {
        useAgentCwd: true
      }
    }), await __callMethod(__readStatic(exec, "exec", ""), "partial", {
      type: "named",
      positionalArgs: [],
      namedArgs: {
        useAgentCwd: true
      }
    })]);
    verifySysPrompt = __deepFreeze(`You verify whether a coding task was completed correctly. You do NOT fix anything. Inspect, COMPUTE, and report.

The grading tests are hidden and NOT in this environment, so you must reconstruct and ACTUALLY RUN every check the task states \u2014 never eyeball the artifact.

Method:
1. Enumerate EVERY explicit success criterion in the task. Two kinds: the output contract (exact file path and name, format, JSON keys, field types, units, signed-vs-unsigned, the stated whitespace / trailing-newline requirement) AND every quantitative rule (lengths, ranges, counts, thresholds, temperatures, GC content, percentages, etc.).
2. For EACH criterion, use the \`exec\` tool to COMPUTE the artifact's actual value and compare it to the requirement. If the task names a specific tool or command to compute a value (e.g. a CLI with exact flags), install if needed and run THAT tool \u2014 it is the ground truth; do not approximate it with your own estimate.
3. A criterion you did NOT computationally verify is itself a gap \u2014 report it as one. A near-miss on any numeric constraint is an error: report the actual computed value vs. the requirement (e.g. "Tm difference 6.5\xB0C, limit 5\xB0C").

Never say the artifact "appears" or "should" satisfy something. Run it, measure it, and report a concrete pass/fail per criterion with the numbers.`);
    writeSysPrompt = __deepFreeze(`You write code in the Agency language.
Agency syntax rules you MUST follow:
- Functions: def name(param: Type): ReturnType { ... }
- Nodes: node name() { ... } \u2014 export the entry node.
- if / while / for require parentheses AND curly braces: if (x > 5) { ... }
- The ONLY for loop is for-in over an array: for (item in items) { ... }
  There is NO C-style for (let i = 0; i < n; i++) loop. To count, use a
  while loop:
    let i = 1
    while (i <= 3) {
      print(i)
      i = i + 1
    }
- Declare variables with let or const before use.
- No Python-style colon blocks. Always { ... }.

Here are complete, correct Agency programs. Copy their structure: the imports, the \`node main\`, and the explicit \`return\` at the end.

EXAMPLE 1, compute and return a value:
node main(): number {
  let total = 0
  for (x in [1, 2, 3]) {
    total = total + x
  }
  return total
}

EXAMPLE 2, import a tool and define and call a helper:
import { bash } from "std::shell"
def greet(name: string): string {
  return "Hello, \${name}"
}
node main(): string {
  bash(command: "echo starting")
  return greet("world")
}

EXAMPLE 3, get structured output from the model by annotating the result type:
type Summary = { title: string; points: string[] }
node main(): Summary {
  const s: Summary = llm("Summarize the water cycle with a title and three bullet points.")
  return s
}

Commonly useful standard library modules:
- std::shell: bash, exec, ls, grep, glob (run commands, inspect files)
- std::http: fetch, fetchJSON (call web APIs)
- std::array: map, filter (transform lists)
- std::agency: writeAgency, runCode, review (generate and run Agency code)

If you are unsure about syntax or a standard-library function, read the
relevant page with the docs tool before writing code.
Return only the complete program in the code field.`);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    verifyTools,
    verifySysPrompt,
    writeSysPrompt
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/agency.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/agency.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/agency.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/agency.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const CompiledProgram = z.object({ "moduleId": z.string() });
const SourceLocation = z.object({ "line": z.number(), "col": z.number(), "start": z.number(), "end": z.number() });
const TypeCheckDiagnostic = z.object({ "code": z.string(), "severity": z.string(), "message": z.string(), "loc": z.union([SourceLocation, z.null()]).optional().default(null), "params": z.record(z.string(), z.union([z.string(), z.number()])) });
const TypeCheckReport = z.object({ "errors": z.array(TypeCheckDiagnostic), "warnings": z.array(TypeCheckDiagnostic) });
async function __compile_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "compile", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "compile",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_compile, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "compile",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function compile threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "compile"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "compile",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "compile",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const compile = __AgencyFunction.create({
  name: "compile",
  module: "stdlib/agency.agency",
  fn: __compile_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "compile",
    description: `Compile Agency source code. Returns a CompiledProgram on success, or a failure with compilation errors. Only standard library (\`std::\`) imports are allowed in the compiled code.

  @param source - Agency source code as a string`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __run_impl(compiled, node, args = __UNSET, wallClock = __UNSET, memory = __UNSET, ipcPayload = __UNSET, stdout = __UNSET, logFile = __UNSET, cwd = __UNSET, maxDepth = __UNSET, maxCost = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["compiled"] = compiled;
  __stack.args["node"] = node;
  __stack.args["args"] = args === __UNSET ? {} : args;
  __stack.args["wallClock"] = wallClock === __UNSET ? 6e4 : wallClock;
  __stack.args["memory"] = memory === __UNSET ? 536870912 : memory;
  __stack.args["ipcPayload"] = ipcPayload === __UNSET ? 104857600 : ipcPayload;
  __stack.args["stdout"] = stdout === __UNSET ? 1048576 : stdout;
  __stack.args["logFile"] = logFile === __UNSET ? `` : logFile;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __stack.args["maxDepth"] = maxDepth === __UNSET ? 5 : maxDepth;
  __stack.args["maxCost"] = maxCost === __UNSET ? null : maxCost;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "run", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("compiled" in __overrides) {
      compiled = __overrides["compiled"];
      __stack.args["compiled"] = compiled;
    }
    if ("node" in __overrides) {
      node = __overrides["node"];
      __stack.args["node"] = node;
    }
    if ("args" in __overrides) {
      args = __overrides["args"];
      __stack.args["args"] = args;
    }
    if ("wallClock" in __overrides) {
      wallClock = __overrides["wallClock"];
      __stack.args["wallClock"] = wallClock;
    }
    if ("memory" in __overrides) {
      memory = __overrides["memory"];
      __stack.args["memory"] = memory;
    }
    if ("ipcPayload" in __overrides) {
      ipcPayload = __overrides["ipcPayload"];
      __stack.args["ipcPayload"] = ipcPayload;
    }
    if ("stdout" in __overrides) {
      stdout = __overrides["stdout"];
      __stack.args["stdout"] = stdout;
    }
    if ("logFile" in __overrides) {
      logFile = __overrides["logFile"];
      __stack.args["logFile"] = logFile;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
    if ("maxDepth" in __overrides) {
      maxDepth = __overrides["maxDepth"];
      __stack.args["maxDepth"] = maxDepth;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "run",
            args: {
              compiled,
              node,
              args,
              wallClock,
              memory,
              ipcPayload,
              stdout,
              logFile,
              cwd,
              maxDepth,
              maxCost
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.configOverrides = null;
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.logFile, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.configOverrides = {
                "observability": true,
                "log": {
                  "logFile": __stack.args.logFile
                }
              };
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_3);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::run", `Running agent-generated code in subprocess`, {
            "moduleId": __stack.args.compiled.moduleId,
            "node": __stack.args.node,
            "args": __stack.args.args,
            "limits": {
              "wallClock": __stack.args.wallClock,
              "memory": __stack.args.memory,
              "ipcPayload": __stack.args.ipcPayload,
              "stdout": __stack.args.stdout,
              "maxCost": __stack.args.maxCost
            },
            "cwd": __stack.args.cwd,
            "logFile": __stack.args.logFile,
            "depth": await __call(_subprocessDepth, {
              type: "positional",
              args: []
            }) + 1
          }, "std::agency", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_3 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/agency.agency", scopeName: "run", stepPath: "3" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.NO_COST_CAP = -1;
      });
      await runner.ifElse(5, [
        {
          condition: async () => !__eq(__stack.args.maxCost, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.__ifbranch_3 = __stack.args.maxCost;
            });
            await runner2.step(1, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__ifbranch_3);
              return;
            });
          }
        }
      ], async (runner2) => {
        await runner2.step(2, async (runner3) => {
          __stack.locals.__ifbranch_2 = __stack.locals.NO_COST_CAP;
        });
        await runner2.step(3, async (runner3) => {
          runner3.exitMatch(1, __stack.locals.__ifbranch_2);
          return;
        });
      }, { matchId: 1 });
      await runner.step(6, async (runner2) => {
        __stack.locals.cap = __nn(__stack.locals.__matchval_1);
      });
      await runner.step(7, async (runner2) => {
        __stack.locals.guarded = await __call(guard, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            cost: __stack.locals.cap
          },
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/agency.agency", fn: async () => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agency.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(await __tryCall(async () => await __call(_run, {
                  type: "positional",
                  args: [__stack.args.compiled, __stack.args.node, __stack.args.args, __stack.args.wallClock, __stack.args.memory, __stack.args.ipcPayload, __stack.args.stdout, __stack.locals.configOverrides, __stack.args.cwd, __stack.args.maxDepth]
                })));
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.guarded)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.guarded);
          return;
        }
      });
      await runner.ifElse(8, [
        {
          condition: async () => await isFailure(__stack.locals.guarded),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.err = __stack.locals.guarded.error;
            });
            await runner2.ifElse(1, [
              {
                condition: async () => __eq(__stack.locals.err.type, `guardFailure`),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                  });
                  await runner3.step(1, async (runner4) => {
                    __functionCompleted = true;
                    runner4.halt(failure({
                      "reason": `limit_exceeded`,
                      "limit": `cost`,
                      "threshold": __stack.args.maxCost,
                      "value": __stack.locals.err.actualCost,
                      "message": `Subprocess exceeded cost limit of ${__stack.args.maxCost} (used ${__stack.locals.err.actualCost})`
                    }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "run", args: __stack.args }));
                    return;
                  });
                }
              }
            ]);
          }
        }
      ]);
      await runner.step(9, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.guarded);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function run threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "run"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "run",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "run",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const run = __AgencyFunction.create({
  name: "run",
  module: "stdlib/agency.agency",
  fn: __run_impl,
  params: [{
    name: "compiled",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "node",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "args",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "wallClock",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "memory",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ipcPayload",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "stdout",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "logFile",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxDepth",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "run",
    description: `Execute a compiled Agency program in a subprocess and return the node's result.

  @param compiled - A compiled Agency program
  @param node - Which exported node to run
  @param args - Arguments to pass to the node
  @param wallClock - Max wall-clock time in MILLISECONDS before SIGKILL (default 60000 = 60s, max 1h). Pass null for the default.
  @param memory - Max V8 heap size in BYTES (default 536870912 = 512mb, max 4gb). Pass null for the default.
  @param ipcPayload - Max single IPC message size in BYTES (default 104857600 = 100mb, max 1gb). Pass null for the default.
  @param stdout - Max combined stdout+stderr output in BYTES (default 1048576 = 1mb, max 100mb). Pass null for the default.
  @param logFile - Optional statelog JSONL file path for this subprocess run
  @param cwd - Optional working directory for this subprocess run
  @param maxDepth - Max subprocess nesting depth (default 5, hard ceiling 10).
  @param maxCost - Max subprocess LLM spend in dollars (e.g. $0.50). null = no cost limit.`,
    schema: z.object({ "compiled": CompiledProgram, "node": z.string(), "args": z.record(z.string(), z.any()).nullable().describe("Default: {}"), "wallClock": z.number().nullable().describe("Default: 60s"), "memory": z.number().nullable().describe("Default: 512mb"), "ipcPayload": z.number().nullable().describe("Default: 100mb"), "stdout": z.number().nullable().describe("Default: 1mb"), "logFile": z.string().nullable().describe("Default: "), "cwd": z.string().nullable().describe("Default: "), "maxDepth": z.number().nullable().describe("Default: 5"), "maxCost": z.union([z.number(), z.null()]).describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
async function __runFile_impl(dir, filename, node, args = __UNSET, wallClock = __UNSET, memory = __UNSET, ipcPayload = __UNSET, stdout = __UNSET, maxCost = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __stack.args["filename"] = filename;
  __stack.args["node"] = node;
  __stack.args["args"] = args === __UNSET ? {} : args;
  __stack.args["wallClock"] = wallClock === __UNSET ? 6e4 : wallClock;
  __stack.args["memory"] = memory === __UNSET ? 536870912 : memory;
  __stack.args["ipcPayload"] = ipcPayload === __UNSET ? 104857600 : ipcPayload;
  __stack.args["stdout"] = stdout === __UNSET ? 1048576 : stdout;
  __stack.args["maxCost"] = maxCost === __UNSET ? null : maxCost;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "runFile", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("node" in __overrides) {
      node = __overrides["node"];
      __stack.args["node"] = node;
    }
    if ("args" in __overrides) {
      args = __overrides["args"];
      __stack.args["args"] = args;
    }
    if ("wallClock" in __overrides) {
      wallClock = __overrides["wallClock"];
      __stack.args["wallClock"] = wallClock;
    }
    if ("memory" in __overrides) {
      memory = __overrides["memory"];
      __stack.args["memory"] = memory;
    }
    if ("ipcPayload" in __overrides) {
      ipcPayload = __overrides["ipcPayload"];
      __stack.args["ipcPayload"] = ipcPayload;
    }
    if ("stdout" in __overrides) {
      stdout = __overrides["stdout"];
      __stack.args["stdout"] = stdout;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "runFile",
            args: {
              dir,
              filename,
              node,
              args,
              wallClock,
              memory,
              ipcPayload,
              stdout,
              maxCost
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.compileResult = await __tryCall(async () => await __call(_compileFile, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.filename]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "runFile",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.compileResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.compileResult);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.compileResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.locals.compileResult);
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(run, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            compiled: __stack.locals.compileResult.value,
            node: __stack.args.node,
            args: __stack.args.args,
            wallClock: __stack.args.wallClock,
            memory: __stack.args.memory,
            ipcPayload: __stack.args.ipcPayload,
            stdout: __stack.args.stdout,
            maxCost: __stack.args.maxCost
          }
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function runFile threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "runFile"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "runFile",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "runFile",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const runFile = __AgencyFunction.create({
  name: "runFile",
  module: "stdlib/agency.agency",
  fn: __runFile_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "node",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "args",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "wallClock",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "memory",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ipcPayload",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "stdout",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "runFile",
    description: `Compile and execute an Agency file in a subprocess and return the node's result.
  Only standard-library (\`std::\`) imports are allowed in the file.

  @param dir - The directory containing the file
  @param filename - The agency file to compile and run
  @param node - Which node to run
  @param args - Arguments to pass to the node
  @param wallClock - Max wall-clock time in MILLISECONDS before SIGKILL (default 60000 = 60s, max 1h). Pass null for the default.
  @param memory - Max V8 heap size in BYTES (default 536870912 = 512mb, max 4gb). Pass null for the default.
  @param ipcPayload - Max single IPC message size in BYTES (default 104857600 = 100mb, max 1gb). Pass null for the default.
  @param stdout - Max combined stdout+stderr output in BYTES (default 1048576 = 1mb, max 100mb). Pass null for the default.
  @param maxCost - Max subprocess LLM spend in dollars (e.g. $0.50). null = no cost limit.`,
    schema: z.object({ "dir": z.string(), "filename": z.string(), "node": z.string(), "args": z.record(z.string(), z.any()).nullable().describe("Default: {}"), "wallClock": z.number().nullable().describe("Default: 60s"), "memory": z.number().nullable().describe("Default: 512mb"), "ipcPayload": z.number().nullable().describe("Default: 100mb"), "stdout": z.number().nullable().describe("Default: 1mb"), "maxCost": z.union([z.number(), z.null()]).describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
async function __checkRunCodeLimits_impl(wallClock, memory, ipcPayload, stdout) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["wallClock"] = wallClock;
  __stack.args["memory"] = memory;
  __stack.args["ipcPayload"] = ipcPayload;
  __stack.args["stdout"] = stdout;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "checkRunCodeLimits", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("wallClock" in __overrides) {
      wallClock = __overrides["wallClock"];
      __stack.args["wallClock"] = wallClock;
    }
    if ("memory" in __overrides) {
      memory = __overrides["memory"];
      __stack.args["memory"] = memory;
    }
    if ("ipcPayload" in __overrides) {
      ipcPayload = __overrides["ipcPayload"];
      __stack.args["ipcPayload"] = ipcPayload;
    }
    if ("stdout" in __overrides) {
      stdout = __overrides["stdout"];
      __stack.args["stdout"] = stdout;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "checkRunCodeLimits",
            args: {
              wallClock,
              memory,
              ipcPayload,
              stdout
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.checks = [{
          "name": `wallClock`,
          "value": __stack.args.wallClock,
          "max": 36e5,
          "unit": `milliseconds`
        }, {
          "name": `memory`,
          "value": __stack.args.memory,
          "max": 4294967296,
          "unit": `bytes`
        }, {
          "name": `ipcPayload`,
          "value": __stack.args.ipcPayload,
          "max": 1073741824,
          "unit": `bytes`
        }, {
          "name": `stdout`,
          "value": __stack.args.stdout,
          "max": 104857600,
          "unit": `bytes`
        }];
      });
      await runner.loop(2, async () => __stack.locals.checks, async (check, _, runner2) => {
        await runner2.ifElse(0, [
          {
            condition: async () => check.value <= 0,
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(`${check.name} must be a positive number of ${check.unit} (got ${check.value}).`);
                return;
              });
            }
          }
        ]);
        await runner2.ifElse(1, [
          {
            condition: async () => check.value > check.max,
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(`${check.name} is too large: ${check.value} ${check.unit} exceeds the maximum of ${check.max} ${check.unit}.`);
                return;
              });
            }
          }
        ]);
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(``);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function checkRunCodeLimits threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "checkRunCodeLimits"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "checkRunCodeLimits",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "checkRunCodeLimits",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const checkRunCodeLimits = __AgencyFunction.create({
  name: "checkRunCodeLimits",
  module: "stdlib/agency.agency",
  fn: __checkRunCodeLimits_impl,
  params: [{
    name: "wallClock",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "memory",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ipcPayload",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "stdout",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "checkRunCodeLimits",
    description: "No description provided.",
    schema: z.object({ "wallClock": z.number(), "memory": z.number(), "ipcPayload": z.number(), "stdout": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __runCode_impl(source, node = __UNSET, args = __UNSET, wallClock = __UNSET, memory = __UNSET, ipcPayload = __UNSET, stdout = __UNSET, maxCost = __UNSET, cwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __stack.args["node"] = node === __UNSET ? `main` : node;
  __stack.args["args"] = args === __UNSET ? {} : args;
  __stack.args["wallClock"] = wallClock === __UNSET ? 6e4 : wallClock;
  __stack.args["memory"] = memory === __UNSET ? 536870912 : memory;
  __stack.args["ipcPayload"] = ipcPayload === __UNSET ? 104857600 : ipcPayload;
  __stack.args["stdout"] = stdout === __UNSET ? 1048576 : stdout;
  __stack.args["maxCost"] = maxCost === __UNSET ? null : maxCost;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "runCode", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("node" in __overrides) {
      node = __overrides["node"];
      __stack.args["node"] = node;
    }
    if ("args" in __overrides) {
      args = __overrides["args"];
      __stack.args["args"] = args;
    }
    if ("wallClock" in __overrides) {
      wallClock = __overrides["wallClock"];
      __stack.args["wallClock"] = wallClock;
    }
    if ("memory" in __overrides) {
      memory = __overrides["memory"];
      __stack.args["memory"] = memory;
    }
    if ("ipcPayload" in __overrides) {
      ipcPayload = __overrides["ipcPayload"];
      __stack.args["ipcPayload"] = ipcPayload;
    }
    if ("stdout" in __overrides) {
      stdout = __overrides["stdout"];
      __stack.args["stdout"] = stdout;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "runCode",
            args: {
              source,
              node,
              args,
              wallClock,
              memory,
              ipcPayload,
              stdout,
              maxCost,
              cwd
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.limitError = await __call(checkRunCodeLimits, {
          type: "positional",
          args: [__stack.args.wallClock, __stack.args.memory, __stack.args.ipcPayload, __stack.args.stdout]
        });
        if (hasInterrupts(__stack.locals.limitError)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.limitError);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.locals.limitError, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(__stack.locals.limitError, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "runCode", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.compileResult = await __tryCall(async () => await __call(_compile, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "runCode",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.compileResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.compileResult);
          return;
        }
      });
      await runner.ifElse(4, [
        {
          condition: async () => await isFailure(__stack.locals.compileResult),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.compileErr = __stack.locals.compileResult.error;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.locals.compileResult);
              return;
            });
          }
        }
      ]);
      await runner.step(5, async (runner2) => {
        __stack.locals.result = await __call(run, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            compiled: __stack.locals.compileResult.value,
            node: __stack.args.node,
            args: __stack.args.args,
            wallClock: __stack.args.wallClock,
            memory: __stack.args.memory,
            ipcPayload: __stack.args.ipcPayload,
            stdout: __stack.args.stdout,
            maxCost: __stack.args.maxCost,
            cwd: __stack.args.cwd
          }
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.ifElse(6, [
        {
          condition: async () => await isSuccess(__stack.locals.result),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.envelope = __stack.locals.result.value;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await success(__stack.locals.envelope.data));
              return;
            });
          }
        }
      ]);
      await runner.step(7, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function runCode threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "runCode"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "runCode",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "runCode",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const runCode = __AgencyFunction.create({
  name: "runCode",
  module: "stdlib/agency.agency",
  fn: __runCode_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "node",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "args",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "wallClock",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "memory",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "ipcPayload",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "stdout",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "runCode",
    description: `Compile Agency source code and execute one of its nodes in a subprocess,
  returning the value the node returned. Prefer this over separate
  compile() and run() calls. Only standard-library (\`std::\`) imports are
  allowed in the source. Compile errors are returned as a failure without
  running anything; fix the source and call again.

  @param source - Agency source code as a string
  @param node - Which exported node to run (default "main")
  @param args - Arguments to pass to the node
  @param wallClock - Max wall-clock time in MILLISECONDS before SIGKILL (default 60000 = 60s, max 3600000 = 1h). Pass null for the default.
  @param memory - Max V8 heap size in BYTES (default 536870912 = 512mb, max 4294967296 = 4gb). Pass null for the default.
  @param ipcPayload - Max single IPC message size in BYTES (default 104857600 = 100mb, max 1073741824 = 1gb). Pass null for the default.
  @param stdout - Max combined stdout+stderr output in BYTES (default 1048576 = 1mb, max 104857600 = 100mb). Pass null for the default.
  @param maxCost - Max subprocess LLM spend in dollars (e.g. 0.50). null = no cost limit.
  @param cwd - Working directory for the subprocess. Empty inherits the caller's process cwd (which may be the package dir, not where you want files); pass the agent working directory so the generated program's file writes land there.`,
    schema: z.object({ "source": z.string(), "node": z.string().nullable().describe("Default: main"), "args": z.record(z.string(), z.any()).nullable().describe("Default: {}"), "wallClock": z.number().nullable().describe("Default: 60s"), "memory": z.number().nullable().describe("Default: 512mb"), "ipcPayload": z.number().nullable().describe("Default: 100mb"), "stdout": z.number().nullable().describe("Default: 1mb"), "maxCost": z.union([z.number(), z.null()]).describe("Default: null"), "cwd": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __typecheck_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "typecheck", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "typecheck",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_typecheck, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "typecheck",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function typecheck threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "typecheck"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "typecheck",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "typecheck",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const typecheck = __AgencyFunction.create({
  name: "typecheck",
  module: "stdlib/agency.agency",
  fn: __typecheck_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "typecheck",
    description: `Type-check Agency source code.

  @param source - Agency source code as a string`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
const EffectsByExport = z.record(z.string(), z.array(z.string()));
async function __getEffects_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "getEffects", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getEffects",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_getEffects, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "getEffects",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getEffects threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getEffects"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getEffects",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getEffects",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getEffects = __AgencyFunction.create({
  name: "getEffects",
  module: "stdlib/agency.agency",
  fn: __getEffects_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "getEffects",
    description: `Map each exported node and function in the source to the list of
  interrupt effects it can raise, transitively. Bare \`interrupt(...)\`
  sites appear as the sentinel "unknown", so the envelope never
  silently under-reports. Use this to show or check what a program can
  do before running it.

  @param source - Agency source code as a string`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
const Feedback = z.object({ "error": z.boolean(), "feedback": z.string() });
async function __mergeFeedback_impl(a, b) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["a"] = a;
  __stack.args["b"] = b;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "mergeFeedback", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("a" in __overrides) {
      a = __overrides["a"];
      __stack.args["a"] = a;
    }
    if ("b" in __overrides) {
      b = __overrides["b"];
      __stack.args["b"] = b;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "mergeFeedback",
            args: {
              a,
              b
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => await isSuccess(__stack.args.a),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.aVal = __stack.args.a.value;
            });
            await runner2.ifElse(1, [
              {
                condition: async () => await isSuccess(__stack.args.b),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __stack.locals.bVal = __stack.args.b.value;
                  });
                  await runner3.step(1, async (runner4) => {
                    __functionCompleted = true;
                    runner4.halt(await success([...__stack.locals.aVal, ...__stack.locals.bVal]));
                    return;
                  });
                }
              }
            ], async (runner3) => {
              await runner3.step(2, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(__stack.args.b);
                return;
              });
            });
          }
        }
      ], async (runner2) => {
        await runner2.step(2, async (runner3) => {
          __functionCompleted = true;
          runner3.halt(__stack.args.a);
          return;
        });
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function mergeFeedback threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "mergeFeedback"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "mergeFeedback",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "mergeFeedback",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const mergeFeedback = __AgencyFunction.create({
  name: "mergeFeedback",
  module: "stdlib/agency.agency",
  fn: __mergeFeedback_impl,
  params: [{
    name: "a",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "b",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "mergeFeedback",
    description: `Merge two feedback Results by concatenating their success arrays or
  returning the first failure.

  @param a - First feedback Result
  @param b - Second feedback Result`,
    schema: z.object({ "a": z.union([z.object({ __type: z.literal("resultType"), success: z.literal(true), value: z.array(Feedback) }), z.object({ __type: z.literal("resultType"), success: z.literal(false), error: z.any() })]), "b": z.union([z.object({ __type: z.literal("resultType"), success: z.literal(true), value: z.array(Feedback) }), z.object({ __type: z.literal("resultType"), success: z.literal(false), error: z.any() })]) })
  },
  exported: true
}, __toolRegistry);
async function __parseFeedback_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "parseFeedback", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseFeedback",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.result = await __tryCall(async () => await __call(_parseAST, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "parseFeedback",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.result),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.err = __stack.locals.result.error;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await success([{
                "error": true,
                "feedback": `Parse error: ${__stack.locals.err}`
              }]));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await success([]));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseFeedback threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseFeedback"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseFeedback",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseFeedback",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseFeedback = __AgencyFunction.create({
  name: "parseFeedback",
  module: "stdlib/agency.agency",
  fn: __parseFeedback_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "parseFeedback",
    description: "No description provided.",
    schema: z.object({ "source": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __reportFeedback_impl(report) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["report"] = report;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "reportFeedback", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("report" in __overrides) {
      report = __overrides["report"];
      __stack.args["report"] = report;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "reportFeedback",
            args: {
              report
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.feedback = [];
      });
      await runner.loop(2, async () => __stack.args.report.errors, async (error, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          await __callMethod(__stack.locals.feedback, "push", {
            type: "positional",
            args: [{
              "error": true,
              "feedback": `Error: ${error.message}`
            }]
          });
        });
      });
      await runner.loop(3, async () => __stack.args.report.warnings, async (warning, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          await __callMethod(__stack.locals.feedback, "push", {
            type: "positional",
            args: [{
              "error": false,
              "feedback": `Warning: ${warning.message}`
            }]
          });
        });
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.feedback);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function reportFeedback threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "reportFeedback"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "reportFeedback",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "reportFeedback",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const reportFeedback = __AgencyFunction.create({
  name: "reportFeedback",
  module: "stdlib/agency.agency",
  fn: __reportFeedback_impl,
  params: [{
    name: "report",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "reportFeedback",
    description: "No description provided.",
    schema: z.object({ "report": TypeCheckReport })
  },
  exported: false
}, __toolRegistry);
async function __typecheckFeedback_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "typecheckFeedback", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "typecheckFeedback",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.result = await __tryCall(async () => await __call(_typecheck, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "typecheckFeedback",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.result),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.err = __stack.locals.result.error;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await success([{
                "error": true,
                "feedback": `Typecheck failed: ${__stack.locals.err}`
              }]));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await success(await __call(reportFeedback, {
          type: "positional",
          args: [__stack.locals.result.value]
        })));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function typecheckFeedback threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "typecheckFeedback"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "typecheckFeedback",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "typecheckFeedback",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const typecheckFeedback = __AgencyFunction.create({
  name: "typecheckFeedback",
  module: "stdlib/agency.agency",
  fn: __typecheckFeedback_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "typecheckFeedback",
    description: "No description provided.",
    schema: z.object({ "source": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __llmFeedback_impl(source, task) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __stack.args["task"] = task;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "llmFeedback", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "llmFeedback",
            args: {
              source,
              task
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.out = await success([]);
        if (hasInterrupts(__stack.locals.out)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.out);
          return;
        }
      });
      await runner.thread(2, "create", async () => ({ label: `review` }), async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __self.__removedTools = __self.__removedTools || [];
          __stack.locals.items = await runPrompt({
            prompt: `You are reviewing Agency-language code.
The code was written for this task:
<task>
${__stack.args.task}
</task>

<code>
${__stack.args.source}
</code>

Return a list of feedback items. Set error=true only if the code does
not accomplish the task. Keep feedback brief and concrete.`,
            messages: __threads().getOrCreateActive(),
            responseFormat: z.object({
              response: z.array(Feedback)
            }),
            clientConfig: {},
            maxToolCallRounds: 10,
            removedTools: __self.__removedTools,
            destructiveSink: __self,
            checkpointInfo: runner3.getCheckpointInfo()
          });
          if (hasInterrupts(__stack.locals.items)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.items);
            return;
          }
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.out = await success(__stack.locals.items);
          if (hasInterrupts(__stack.locals.out)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.out);
            return;
          }
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.out);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function llmFeedback threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "llmFeedback"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "llmFeedback",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "llmFeedback",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const llmFeedback = __AgencyFunction.create({
  name: "llmFeedback",
  module: "stdlib/agency.agency",
  fn: __llmFeedback_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "llmFeedback",
    description: "No description provided.",
    schema: z.object({ "source": z.string(), "task": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __review_impl(source, task = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __stack.args["task"] = task === __UNSET ? `` : task;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "review", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "review",
            args: {
              source,
              task
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.feedback = await success([]);
        if (hasInterrupts(__stack.locals.feedback)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.feedback);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.feedback = await __call(mergeFeedback, {
          type: "positional",
          args: [__stack.locals.feedback, await __call(parseFeedback, {
            type: "positional",
            args: [__stack.args.source]
          })]
        });
        if (hasInterrupts(__stack.locals.feedback)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.feedback);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.feedback = await __call(mergeFeedback, {
          type: "positional",
          args: [__stack.locals.feedback, await __call(typecheckFeedback, {
            type: "positional",
            args: [__stack.args.source]
          })]
        });
        if (hasInterrupts(__stack.locals.feedback)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.feedback);
          return;
        }
      });
      await runner.ifElse(4, [
        {
          condition: async () => !__eq(__stack.args.task, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.feedback = await __call(mergeFeedback, {
                type: "positional",
                args: [__stack.locals.feedback, await __call(llmFeedback, {
                  type: "positional",
                  args: [__stack.args.source, __stack.args.task]
                })]
              });
              if (hasInterrupts(__stack.locals.feedback)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.feedback);
                return;
              }
            });
          }
        }
      ]);
      await runner.ifElse(5, [
        {
          condition: async () => await isSuccess(__stack.locals.feedback),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.items = __stack.locals.feedback.value;
            });
            await runner2.ifElse(1, [
              {
                condition: async () => __eq(__stack.locals.items.length, 0),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __functionCompleted = true;
                    runner4.halt(await success([{
                      "error": false,
                      "feedback": `Code is valid with no errors or warnings.`
                    }]));
                    return;
                  });
                }
              }
            ]);
          }
        }
      ]);
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.feedback);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function review threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "review"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "review",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "review",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const review = __AgencyFunction.create({
  name: "review",
  module: "stdlib/agency.agency",
  fn: __review_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "task",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "review",
    description: `Review Agency source code. Always merges parse and typecheck findings;
  when a task description is given, an LLM pass also judges whether the
  code accomplishes the task.

  @param source - Agency source code as a string
  @param task - Optional description of what the code should do`,
    schema: z.object({ "source": z.string(), "task": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __renderSingleFeedback_impl(f) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["f"] = f;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "renderSingleFeedback", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("f" in __overrides) {
      f = __overrides["f"];
      __stack.args["f"] = f;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "renderSingleFeedback",
            args: {
              f
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.f.error,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(`Error: ${__stack.args.f.feedback}`);
              return;
            });
          }
        }
      ], async (runner2) => {
        await runner2.step(1, async (runner3) => {
          __functionCompleted = true;
          runner3.halt(`Feedback: ${__stack.args.f.feedback}`);
          return;
        });
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function renderSingleFeedback threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "renderSingleFeedback"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "renderSingleFeedback",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "renderSingleFeedback",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const renderSingleFeedback = __AgencyFunction.create({
  name: "renderSingleFeedback",
  module: "stdlib/agency.agency",
  fn: __renderSingleFeedback_impl,
  params: [{
    name: "f",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "renderSingleFeedback",
    description: "No description provided.",
    schema: z.object({ "f": Feedback })
  },
  exported: false
}, __toolRegistry);
async function __renderFeedback_impl(feedback) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["feedback"] = feedback;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "renderFeedback", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("feedback" in __overrides) {
      feedback = __overrides["feedback"];
      __stack.args["feedback"] = feedback;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "renderFeedback",
            args: {
              feedback
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => await isSuccess(__stack.args.feedback),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.val = __stack.args.feedback.value;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await __callMethod(await await __call(map, {
                type: "positional",
                args: [__stack.locals.val, renderSingleFeedback]
              }), "join", {
                type: "positional",
                args: [`

`]
              }));
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.args.feedback.error);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function renderFeedback threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "renderFeedback"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "renderFeedback",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "renderFeedback",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const renderFeedback = __AgencyFunction.create({
  name: "renderFeedback",
  module: "stdlib/agency.agency",
  fn: __renderFeedback_impl,
  params: [{
    name: "feedback",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "renderFeedback",
    description: `Render a feedback Result as human-readable text, one line per finding.

  @param feedback - The Result review() returned`,
    schema: z.object({ "feedback": z.union([z.object({ __type: z.literal("resultType"), success: z.literal(true), value: z.array(Feedback) }), z.object({ __type: z.literal("resultType"), success: z.literal(false), error: z.any() })]) })
  },
  exported: true
}, __toolRegistry);
async function __feedbackHasErrors_impl(feedback) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["feedback"] = feedback;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "feedbackHasErrors", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("feedback" in __overrides) {
      feedback = __overrides["feedback"];
      __stack.args["feedback"] = feedback;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "feedbackHasErrors",
            args: {
              feedback
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => await isSuccess(__stack.args.feedback),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.val = __stack.args.feedback.value;
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await __call(some, {
                type: "named",
                positionalArgs: [__stack.locals.val],
                namedArgs: {},
                blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/agency.agency", fn: async (f) => {
                  const __bsetup = setupFunction();
                  const __bstack = __bsetup.stack;
                  const __self2 = __bstack.locals;
                  const __bframe___block_1 = __bstack;
                  __bstack.args["f"] = f;
                  const runner4 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agency.agency", scopeName: "__block_1" });
                  try {
                    await runner4.step(0, async (runner5) => {
                      runner5.halt(__bstack.args.f.error);
                      return;
                    });
                    return runner4.halted ? runner4.haltResult : void 0;
                  } finally {
                    __bsetup.stateStack.pop();
                  }
                }, params: [{ name: "f", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
              }));
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(true);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function feedbackHasErrors threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "feedbackHasErrors"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "feedbackHasErrors",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "feedbackHasErrors",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const feedbackHasErrors = __AgencyFunction.create({
  name: "feedbackHasErrors",
  module: "stdlib/agency.agency",
  fn: __feedbackHasErrors_impl,
  params: [{
    name: "feedback",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "feedbackHasErrors",
    description: `True when any finding is an error, or when the feedback Result itself
  is a failure.

  @param feedback - The Result review() returned`,
    schema: z.object({ "feedback": z.union([z.object({ __type: z.literal("resultType"), success: z.literal(true), value: z.array(Feedback) }), z.object({ __type: z.literal("resultType"), success: z.literal(false), error: z.any() })]) })
  },
  exported: true
}, __toolRegistry);
async function __failOpenFeedback_impl(r) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["r"] = r;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "failOpenFeedback", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("r" in __overrides) {
      r = __overrides["r"];
      __stack.args["r"] = r;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "failOpenFeedback",
            args: {
              r
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_7 = __stack.args.r;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_7),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.items = __stack.locals.__scrutinee_7.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_5 = await success(__stack.locals.items);
              if (hasInterrupts(__stack.locals.__armval_5)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_5);
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(4, __stack.locals.__armval_5);
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_7),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals._ = __stack.locals.__scrutinee_7.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_6 = await success([]);
              if (hasInterrupts(__stack.locals.__armval_6)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_6);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(4, __stack.locals.__armval_6);
              return;
            });
          }
        }
      ], void 0, { matchId: 4 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_4));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function failOpenFeedback threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "failOpenFeedback"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "failOpenFeedback",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "failOpenFeedback",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const failOpenFeedback = __AgencyFunction.create({
  name: "failOpenFeedback",
  module: "stdlib/agency.agency",
  fn: __failOpenFeedback_impl,
  params: [{
    name: "r",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "failOpenFeedback",
    description: "No description provided.",
    schema: z.object({ "r": z.union([z.object({ __type: z.literal("resultType"), success: z.literal(true), value: z.array(Feedback) }), z.object({ __type: z.literal("resultType"), success: z.literal(false), error: z.any() })]) })
  },
  exported: true
}, __toolRegistry);
async function __syntaxHintFor_impl(errors) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["errors"] = errors;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "syntaxHintFor", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("errors" in __overrides) {
      errors = __overrides["errors"];
      __stack.args["errors"] = errors;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "syntaxHintFor",
            args: {
              errors
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => /for loop condition/.test(__stack.args.errors),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(`Reminder: Agency has no C-style for loop. Count with a while loop, or iterate with for (x in items).`);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(``);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function syntaxHintFor threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "syntaxHintFor"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "syntaxHintFor",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "syntaxHintFor",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const syntaxHintFor = __AgencyFunction.create({
  name: "syntaxHintFor",
  module: "stdlib/agency.agency",
  fn: __syntaxHintFor_impl,
  params: [{
    name: "errors",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "syntaxHintFor",
    description: "No description provided.",
    schema: z.object({ "errors": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __hasMainNode_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "hasMainNode", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "hasMainNode",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(/node\s+main\s*\(/.test(__stack.args.source));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function hasMainNode threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "hasMainNode"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "hasMainNode",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "hasMainNode",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const hasMainNode = __AgencyFunction.create({
  name: "hasMainNode",
  module: "stdlib/agency.agency",
  fn: __hasMainNode_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "hasMainNode",
    description: "No description provided.",
    schema: z.object({ "source": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __withSyntaxHint_impl(findings) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["findings"] = findings;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "withSyntaxHint", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("findings" in __overrides) {
      findings = __overrides["findings"];
      __stack.args["findings"] = findings;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "withSyntaxHint",
            args: {
              findings
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.hint = await __call(syntaxHintFor, {
          type: "positional",
          args: [__stack.args.findings]
        });
        if (hasInterrupts(__stack.locals.hint)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.hint);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => __eq(__stack.locals.hint, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.__ifbranch_10 = __stack.args.findings;
            });
            await runner2.step(1, async (runner3) => {
              runner3.exitMatch(8, __stack.locals.__ifbranch_10);
              return;
            });
          }
        }
      ], async (runner2) => {
        await runner2.step(2, async (runner3) => {
          __stack.locals.__ifbranch_9 = `${__stack.locals.hint}

${__stack.args.findings}`;
        });
        await runner2.step(3, async (runner3) => {
          runner3.exitMatch(8, __stack.locals.__ifbranch_9);
          return;
        });
      }, { matchId: 8 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_8));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function withSyntaxHint threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "withSyntaxHint"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "withSyntaxHint",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "withSyntaxHint",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const withSyntaxHint = __AgencyFunction.create({
  name: "withSyntaxHint",
  module: "stdlib/agency.agency",
  fn: __withSyntaxHint_impl,
  params: [{
    name: "findings",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "withSyntaxHint",
    description: "No description provided.",
    schema: z.object({ "findings": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __verifyInner_impl(task, criteria = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["criteria"] = criteria === __UNSET ? [] : criteria;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "verifyInner", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("criteria" in __overrides) {
      criteria = __overrides["criteria"];
      __stack.args["criteria"] = criteria;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "verifyInner",
            args: {
              task,
              criteria
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.items = [];
      });
      await runner.thread(2, "create", async () => ({ label: `verify` }), async (runner2) => {
        await runner2.step(0, async (runner3) => {
          const __funcResult = await __call(systemMessage, {
            type: "positional",
            args: [__readStatic(verifySysPrompt, "verifySysPrompt", "stdlib/agency.agency")]
          });
          if (hasInterrupts(__funcResult)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__funcResult);
            return;
          }
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.authoritativeCriteria = `

These domain-specific acceptance criteria are AUTHORITATIVE \u2014 check EACH one exactly as written, using the exact tool, flags, and input sub-sequence it names:
- ${await __callMethod(__stack.args.criteria, "join", {
            type: "positional",
            args: [`
- `]
          })}`;
        });
        await runner2.ifElse(2, [
          {
            condition: async () => __eq(__stack.args.criteria.length, 0),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.__ifbranch_13 = ``;
              });
              await runner3.step(1, async (runner4) => {
                runner4.exitMatch(11, __stack.locals.__ifbranch_13);
                return;
              });
            }
          }
        ], async (runner3) => {
          await runner3.step(2, async (runner4) => {
            __stack.locals.__ifbranch_12 = __stack.locals.authoritativeCriteria;
          });
          await runner3.step(3, async (runner4) => {
            runner4.exitMatch(11, __stack.locals.__ifbranch_12);
            return;
          });
        }, { matchId: 11 });
        await runner2.step(3, async (runner3) => {
          __stack.locals.criteriaBlock = __nn(__stack.locals.__matchval_11);
        });
        await runner2.step(4, async (runner3) => {
          __self.__removedTools = __self.__removedTools || [];
          __stack.locals.analysis = await runPrompt({
            prompt: `The task was:

${__stack.args.task}${__stack.locals.criteriaBlock}

Enumerate every explicit success criterion (including the authoritative ones above, if any), then for EACH one use \`exec\` to compute the artifact's actual value and compare it to the requirement (run any tool/command named as ground truth). Report a concrete pass/fail per criterion with the computed numbers. A criterion you did not actually compute counts as a failure.`,
            messages: __threads().getOrCreateActive(),
            clientConfig: {
              "tools": __readStatic(verifyTools, "verifyTools", "stdlib/agency.agency")
            },
            maxToolCallRounds: 10,
            removedTools: __self.__removedTools,
            destructiveSink: __self,
            checkpointInfo: runner3.getCheckpointInfo()
          });
          if (hasInterrupts(__stack.locals.analysis)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.analysis);
            return;
          }
        });
        await runner2.step(5, async (runner3) => {
          __self.__removedTools = __self.__removedTools || [];
          __stack.locals.parsed = await runPrompt({
            prompt: `Convert this analysis into Feedback items \u2014 one per concrete finding: error=true for an unmet criterion (name it), error=false for a satisfied one. Empty list if you cannot tell.

Analysis:
${__stack.locals.analysis}`,
            messages: __threads().getOrCreateActive(),
            responseFormat: z.object({
              response: z.array(Feedback)
            }),
            clientConfig: {},
            maxToolCallRounds: 10,
            removedTools: __self.__removedTools,
            destructiveSink: __self,
            checkpointInfo: runner3.getCheckpointInfo()
          });
          if (hasInterrupts(__stack.locals.parsed)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.parsed);
            return;
          }
        });
        await runner2.step(6, async (runner3) => {
          __stack.locals.items = __stack.locals.parsed;
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.items);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function verifyInner threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "verifyInner"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "verifyInner",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "verifyInner",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const verifyInner = __AgencyFunction.create({
  name: "verifyInner",
  module: "stdlib/agency.agency",
  fn: __verifyInner_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "criteria",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "verifyInner",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "criteria": z.array(z.string()).nullable().describe("Default: []") })
  },
  exported: false
}, __toolRegistry);
async function __verify_impl(task, criteria = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["criteria"] = criteria === __UNSET ? [] : criteria;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "verify", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("criteria" in __overrides) {
      criteria = __overrides["criteria"];
      __stack.args["criteria"] = criteria;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "verify",
            args: {
              task,
              criteria
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(failOpenFeedback, {
          type: "positional",
          args: [await __tryCall(async () => await __call(verifyInner, {
            type: "positional",
            args: [__stack.args.task, __stack.args.criteria]
          }), {
            checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
            functionName: "verify",
            args: __stack.args
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function verify threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "verify"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "verify",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "verify",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const verify = __AgencyFunction.create({
  name: "verify",
  module: "stdlib/agency.agency",
  fn: __verify_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "criteria",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "verify",
    description: `Reconstruct a task's success criteria, run the produced artifact against
  them, and return findings. \`error: true\` marks an unmet criterion (strict
  on the output contract); \`error: false\` a satisfied one. Fails open (empty
  success) if verification cannot run, so it never blocks.

  @param task - The original task description to verify against.
  @param criteria - Optional authoritative acceptance criteria (e.g. an expert
    checklist) that verify must check exactly, instead of only re-deriving its
    own from the task text.`,
    schema: z.object({ "task": z.string(), "criteria": z.array(z.string()).nullable().describe("Default: []") })
  },
  exported: true
}, __toolRegistry);
const GeneratedCode = z.object({ "code": z.string() });
const WriteFailure = z.object({ "source": z.string(), "errors": z.array(TypeCheckDiagnostic) });
async function __writeAgency_impl(task, context = __UNSET, maxAttempts = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["context"] = context === __UNSET ? `` : context;
  __stack.args["maxAttempts"] = maxAttempts === __UNSET ? 3 : maxAttempts;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "writeAgency", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("maxAttempts" in __overrides) {
      maxAttempts = __overrides["maxAttempts"];
      __stack.args["maxAttempts"] = maxAttempts;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "writeAgency",
            args: {
              task,
              context,
              maxAttempts
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.docsTool = await __call(docsSkill, {
          type: "positional",
          args: [`guide`]
        });
        if (hasInterrupts(__stack.locals.docsTool)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.docsTool);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = failure({
          "source": ``,
          "errors": []
        }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "writeAgency", args: __stack.args });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.thread(3, "create", async () => ({ label: `writeAgency` }), async (runner2) => {
        await runner2.step(0, async (runner3) => {
          const __funcResult = await __call(systemMessage, {
            type: "positional",
            args: [__readStatic(writeSysPrompt, "writeSysPrompt", "stdlib/agency.agency")]
          });
          if (hasInterrupts(__funcResult)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__funcResult);
            return;
          }
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.prompt = `Write an Agency program for this task:
<task>
${__stack.args.task}
</task>`;
        });
        await runner2.ifElse(2, [
          {
            condition: async () => !__eq(__stack.args.context, ``),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.prompt = __stack.locals.prompt + `
<context>
${__stack.args.context}
</context>`;
              });
            }
          }
        ]);
        await runner2.step(3, async (runner3) => {
          __stack.locals.attempt = 0;
        });
        await runner2.step(4, async (runner3) => {
          __stack.locals.done = false;
        });
        await runner2.whileLoop(5, async () => __stack.locals.attempt < __stack.args.maxAttempts && !__stack.locals.done, async (runner3) => {
          await runner3.step(0, async (runner4) => {
            __stack.locals.attempt = __stack.locals.attempt + 1;
          });
          await runner3.step(1, async (runner4) => {
            __self.__removedTools = __self.__removedTools || [];
            __stack.locals.generated = await runPrompt({
              prompt: __stack.locals.prompt,
              messages: __threads().getOrCreateActive(),
              responseFormat: z.object({
                response: GeneratedCode
              }),
              clientConfig: {
                "tools": [__stack.locals.docsTool]
              },
              maxToolCallRounds: 10,
              removedTools: __self.__removedTools,
              destructiveSink: __self,
              checkpointInfo: runner4.getCheckpointInfo()
            });
            if (hasInterrupts(__stack.locals.generated)) {
              await getRuntimeContext().ctx.pendingPromises.awaitAll();
              runner4.halt(__stack.locals.generated);
              return;
            }
          });
          await runner3.step(2, async (runner4) => {
            __stack.locals.source = __stack.locals.generated.code;
          });
          await runner3.step(3, async (runner4) => {
            __stack.locals.checked = await __tryCall(async () => await __call(_typecheck, {
              type: "positional",
              args: [__stack.locals.source]
            }), {
              checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
              functionName: "writeAgency",
              args: __stack.args
            });
            if (hasInterrupts(__stack.locals.checked)) {
              await getRuntimeContext().ctx.pendingPromises.awaitAll();
              runner4.halt(__stack.locals.checked);
              return;
            }
          });
          await runner3.ifElse(4, [
            {
              condition: async () => await isFailure(__stack.locals.checked),
              body: async (runner4) => {
                await runner4.step(0, async (runner5) => {
                  __stack.locals.parseErr = __stack.locals.checked.error;
                });
                await runner4.step(1, async (runner5) => {
                  __stack.locals.result = failure({
                    "source": __stack.locals.source,
                    "errors": []
                  }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "writeAgency", args: __stack.args });
                  if (hasInterrupts(__stack.locals.result)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__stack.locals.result);
                    return;
                  }
                });
                await runner4.step(2, async (runner5) => {
                  __stack.locals.findings = await __call(renderFeedback, {
                    type: "positional",
                    args: [await __call(parseFeedback, {
                      type: "positional",
                      args: [__stack.locals.source]
                    })]
                  });
                  if (hasInterrupts(__stack.locals.findings)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__stack.locals.findings);
                    return;
                  }
                });
                await runner4.ifElse(3, [
                  {
                    condition: async () => __eq(__stack.locals.findings, ``),
                    body: async (runner5) => {
                      await runner5.step(0, async (runner6) => {
                        __stack.locals.findings = `${__stack.locals.parseErr}`;
                      });
                    }
                  }
                ]);
                await runner4.step(4, async (runner5) => {
                  __stack.locals.prompt = `That code has problems:
${await __call(withSyntaxHint, {
                    type: "positional",
                    args: [__stack.locals.findings]
                  })}
Return a corrected complete program.`;
                });
              }
            },
            {
              condition: async () => __stack.locals.checked.value.errors.length > 0,
              body: async (runner4) => {
                await runner4.step(5, async (runner5) => {
                  __stack.locals.result = failure({
                    "source": __stack.locals.source,
                    "errors": __stack.locals.checked.value.errors
                  }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "writeAgency", args: __stack.args });
                  if (hasInterrupts(__stack.locals.result)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__stack.locals.result);
                    return;
                  }
                });
                await runner4.step(6, async (runner5) => {
                  __stack.locals.findings = await __call(renderFeedback, {
                    type: "positional",
                    args: [await success(await __call(reportFeedback, {
                      type: "positional",
                      args: [__stack.locals.checked.value]
                    }))]
                  });
                  if (hasInterrupts(__stack.locals.findings)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__stack.locals.findings);
                    return;
                  }
                });
                await runner4.step(7, async (runner5) => {
                  __stack.locals.prompt = `That code has problems:
${await __call(withSyntaxHint, {
                    type: "positional",
                    args: [__stack.locals.findings]
                  })}
Return a corrected complete program.`;
                });
              }
            }
          ], async (runner4) => {
            await runner4.step(8, async (runner5) => {
              __stack.locals.compiled = await __tryCall(async () => await __call(_compile, {
                type: "positional",
                args: [__stack.locals.source]
              }), {
                checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
                functionName: "writeAgency",
                args: __stack.args
              });
              if (hasInterrupts(__stack.locals.compiled)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner5.halt(__stack.locals.compiled);
                return;
              }
            });
            await runner4.ifElse(9, [
              {
                condition: async () => await isFailure(__stack.locals.compiled),
                body: async (runner5) => {
                  await runner5.step(0, async (runner6) => {
                    __stack.locals.compileErr = __stack.locals.compiled.error;
                  });
                  await runner5.step(1, async (runner6) => {
                    __stack.locals.result = failure({
                      "source": __stack.locals.source,
                      "errors": []
                    }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "writeAgency", args: __stack.args });
                    if (hasInterrupts(__stack.locals.result)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner6.halt(__stack.locals.result);
                      return;
                    }
                  });
                  await runner5.step(2, async (runner6) => {
                    __stack.locals.prompt = `That code failed to compile:
${await __call(withSyntaxHint, {
                      type: "positional",
                      args: [`${__stack.locals.compileErr}`]
                    })}
Return a corrected complete program.`;
                  });
                }
              },
              {
                condition: async () => !await __call(hasMainNode, {
                  type: "positional",
                  args: [__stack.locals.source]
                }),
                body: async (runner5) => {
                  await runner5.step(3, async (runner6) => {
                    __stack.locals.result = failure({
                      "source": __stack.locals.source,
                      "errors": []
                    }, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "writeAgency", args: __stack.args });
                    if (hasInterrupts(__stack.locals.result)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner6.halt(__stack.locals.result);
                      return;
                    }
                  });
                  await runner5.step(4, async (runner6) => {
                    __stack.locals.prompt = `The program compiles but has no \`node main\`. Every program MUST have a node named \`main\` as its entry point. Add one and return the complete program.`;
                  });
                }
              }
            ], async (runner5) => {
              await runner5.step(5, async (runner6) => {
                __stack.locals.result = await success(__stack.locals.source);
                if (hasInterrupts(__stack.locals.result)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner6.halt(__stack.locals.result);
                  return;
                }
              });
              await runner5.step(6, async (runner6) => {
                __stack.locals.done = true;
              });
            });
          });
        });
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function writeAgency threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "writeAgency"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "writeAgency",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "writeAgency",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const writeAgency = __AgencyFunction.create({
  name: "writeAgency",
  module: "stdlib/agency.agency",
  fn: __writeAgency_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxAttempts",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "writeAgency",
    description: `Generate Agency source code for a task description. Typechecks each
  attempt and feeds diagnostics back to the model, up to maxAttempts
  tries. Success holds source that compiles and typechecks; on retry
  exhaustion the failure holds { source, errors } for the last attempt.

  @param task - What the generated program should do
  @param context - Optional extra material (available data, examples)
  @param maxAttempts - Max generation attempts before giving up (default 3)`,
    schema: z.object({ "task": z.string(), "context": z.string().nullable().describe("Default: "), "maxAttempts": z.number().nullable().describe("Default: 3") })
  },
  exported: true
}, __toolRegistry);
const FilterImportsResult = z.object({ "source": z.string(), "filtered": z.boolean() });
async function __typecheckFile_impl(dir, filename) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __stack.args["filename"] = filename;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "typecheckFile", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "typecheckFile",
            args: {
              dir,
              filename
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::read", `Are you sure you want to read this file?`, {
            "dir": __stack.args.dir,
            "filename": __stack.args.filename
          }, "std::agency", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/agency.agency", scopeName: "typecheckFile", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_typecheckFile, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.filename]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "typecheckFile",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function typecheckFile threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "typecheckFile"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "typecheckFile",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "typecheckFile",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const typecheckFile = __AgencyFunction.create({
  name: "typecheckFile",
  module: "stdlib/agency.agency",
  fn: __typecheckFile_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "typecheckFile",
    description: `Type-check an Agency file on disk. The file is read from dir/filename,
  with relative imports inside it resolved against the file's directory.

  @param dir - The directory containing the file
  @param filename - The agency file to type-check`,
    schema: z.object({ "dir": z.string(), "filename": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
const AST = z.object({ "type": z.literal("agencyProgram"), "nodes": z.array(z.any()), "docComment": z.union([z.any(), z.null()]).optional().default(null) });
async function __parseAST_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "parseAST", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseAST",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_parseAST, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "parseAST",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseAST threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseAST"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseAST",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseAST",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseAST = __AgencyFunction.create({
  name: "parseAST",
  module: "stdlib/agency.agency",
  fn: __parseAST_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "parseAST",
    description: `Parse Agency source code into an abstract syntax tree.

  @param source - Agency source code as a string`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __writeAST_impl(ast, dir, filename, overwrite = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["ast"] = ast;
  __stack.args["dir"] = dir;
  __stack.args["filename"] = filename;
  __stack.args["overwrite"] = overwrite === __UNSET ? true : overwrite;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "writeAST", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("ast" in __overrides) {
      ast = __overrides["ast"];
      __stack.args["ast"] = ast;
    }
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("overwrite" in __overrides) {
      overwrite = __overrides["overwrite"];
      __stack.args["overwrite"] = overwrite;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "writeAST",
            args: {
              ast,
              dir,
              filename,
              overwrite
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::write", `Are you sure you want to write this file?`, {
            "dir": __stack.args.dir,
            "filename": __stack.args.filename,
            "overwrite": __stack.args.overwrite
          }, "std::agency", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/agency.agency", scopeName: "writeAST", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_writeAST, {
          type: "positional",
          args: [__stack.args.ast, __stack.args.dir, __stack.args.filename, __stack.args.overwrite]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "writeAST",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function writeAST threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "writeAST"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "writeAST",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "writeAST",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const writeAST = __AgencyFunction.create({
  name: "writeAST",
  module: "stdlib/agency.agency",
  fn: __writeAST_impl,
  params: [{
    name: "ast",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "overwrite",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "writeAST",
    description: `Format an AST as Agency source and write it to dir/filename. Absolute paths and .. segments cannot escape dir. Symlinks on existing files are followed and re-checked.

  @param ast - The AST to write (typically a parsed Agency AST)
  @param dir - The sandbox directory
  @param filename - The agency file to write, resolved relative to dir
  @param overwrite - If false, fail when the file already exists (default true)`,
    schema: z.object({ "ast": AST, "dir": z.string(), "filename": z.string(), "overwrite": z.boolean().nullable().describe("Default: true") })
  },
  exported: true
}, __toolRegistry);
async function __format_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "format", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "format",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_format, {
          type: "positional",
          args: [__stack.args.source]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "format",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function format threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "format"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "format",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "format",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const format = __AgencyFunction.create({
  name: "format",
  module: "stdlib/agency.agency",
  fn: __format_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "format",
    description: `Format Agency source code with the standard Agency formatter.

  @param source - Agency source code as a string`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __formatFile_impl(dir, filename) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir;
  __stack.args["filename"] = filename;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "formatFile", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "formatFile",
            args: {
              dir,
              filename
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::write", `Are you sure you want to format this file in place?`, {
            "dir": __stack.args.dir,
            "filename": __stack.args.filename
          }, "std::agency", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/agency.agency", scopeName: "formatFile", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_formatFile, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.filename]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "formatFile",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function formatFile threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "formatFile"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "formatFile",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "formatFile",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const formatFile = __AgencyFunction.create({
  name: "formatFile",
  module: "stdlib/agency.agency",
  fn: __formatFile_impl,
  params: [{
    name: "dir",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "formatFile",
    description: `Format an Agency file in place using the standard Agency formatter.

  @param dir - The directory containing the file
  @param filename - The agency file to format`,
    schema: z.object({ "dir": z.string(), "filename": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __walkAST_impl(ast, visitor) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["ast"] = ast;
  __stack.args["visitor"] = visitor;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "walkAST", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("ast" in __overrides) {
      ast = __overrides["ast"];
      __stack.args["ast"] = ast;
    }
    if ("visitor" in __overrides) {
      visitor = __overrides["visitor"];
      __stack.args["visitor"] = visitor;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "walkAST",
            args: {
              ast,
              visitor
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.result = await __call(_walkAST, {
          type: "positional",
          args: [__stack.args.ast]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
      });
      await runner.loop(2, async () => __stack.locals.result.visits, async (visit, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          const __funcResult = await __call(__stack.args.visitor, {
            type: "positional",
            args: [visit.node, visit.ancestors]
          });
          if (hasInterrupts(__funcResult)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__funcResult);
            return;
          }
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result.clone);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function walkAST threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "walkAST"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "walkAST",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "walkAST",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const walkAST = __AgencyFunction.create({
  name: "walkAST",
  module: "stdlib/agency.agency",
  fn: __walkAST_impl,
  params: [{
    name: "ast",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "visitor",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "walkAST",
    description: `Walk every node in a deep-cloned copy of the AST, invoking the visitor
  with each (node, ancestors) pair, and return the modified clone.
  The visitor may mutate nodes in place. This will not modify the original tree.
  The ancestors array lists every enclosing node from the root outward, excluding the node itself.

  @param ast - The AST to walk
  @param visitor - Called once per node as visitor(node, ancestors). Mutate node in place, return value is ignored.`,
    schema: z.object({ "ast": AST })
  },
  exported: true
}, __toolRegistry);
async function __getNodesOfType_impl(source, types) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __stack.args["types"] = types;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "getNodesOfType", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("types" in __overrides) {
      types = __overrides["types"];
      __stack.args["types"] = types;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getNodesOfType",
            args: {
              source,
              types
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_getNodesOfType, {
          type: "positional",
          args: [__stack.args.source, __stack.args.types]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "getNodesOfType",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getNodesOfType threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getNodesOfType"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getNodesOfType",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getNodesOfType",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getNodesOfType = __AgencyFunction.create({
  name: "getNodesOfType",
  module: "stdlib/agency.agency",
  fn: __getNodesOfType_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "types",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "getNodesOfType",
    description: `Parse Agency source code and return every AST node whose \`type\` field matches any of the provided types.

  @param source - Agency source code
  @param types - List of AST type strings to match (e.g. ["function", "graphNode"])`,
    schema: z.object({ "source": z.string(), "types": z.array(z.string()) })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __getImports_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "getImports", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getImports",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(getNodesOfType, {
          type: "positional",
          args: [__stack.args.source, [`importStatement`]]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getImports threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getImports"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getImports",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getImports",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getImports = __AgencyFunction.create({
  name: "getImports",
  module: "stdlib/agency.agency",
  fn: __getImports_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "getImports",
    description: `Return every import statement in the source (i.e. \`import { x } from "..."\`).

  @param source - Agency source code`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __getFunctions_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "getFunctions", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getFunctions",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(getNodesOfType, {
          type: "positional",
          args: [__stack.args.source, [`function`]]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getFunctions threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getFunctions"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getFunctions",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getFunctions",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getFunctions = __AgencyFunction.create({
  name: "getFunctions",
  module: "stdlib/agency.agency",
  fn: __getFunctions_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "getFunctions",
    description: `Return every function definition (\`def foo(...) { ... }\`) in the source.

  @param source - Agency source code`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __getGraphNodes_impl(source) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "getGraphNodes", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getGraphNodes",
            args: {
              source
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(getNodesOfType, {
          type: "positional",
          args: [__stack.args.source, [`graphNode`]]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getGraphNodes threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getGraphNodes"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getGraphNodes",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getGraphNodes",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getGraphNodes = __AgencyFunction.create({
  name: "getGraphNodes",
  module: "stdlib/agency.agency",
  fn: __getGraphNodes_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "getGraphNodes",
    description: `Return every graph node definition (\`node main() { ... }\`) in the source.

  @param source - Agency source code`,
    schema: z.object({ "source": z.string() })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __filterImports_impl(source, allowedPackages = __UNSET, excludedPackages = __UNSET, allowKinds = __UNSET, excludeKinds = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __stack.args["allowedPackages"] = allowedPackages === __UNSET ? [] : allowedPackages;
  __stack.args["excludedPackages"] = excludedPackages === __UNSET ? [] : excludedPackages;
  __stack.args["allowKinds"] = allowKinds === __UNSET ? [] : allowKinds;
  __stack.args["excludeKinds"] = excludeKinds === __UNSET ? [] : excludeKinds;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "filterImports", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("allowedPackages" in __overrides) {
      allowedPackages = __overrides["allowedPackages"];
      __stack.args["allowedPackages"] = allowedPackages;
    }
    if ("excludedPackages" in __overrides) {
      excludedPackages = __overrides["excludedPackages"];
      __stack.args["excludedPackages"] = excludedPackages;
    }
    if ("allowKinds" in __overrides) {
      allowKinds = __overrides["allowKinds"];
      __stack.args["allowKinds"] = allowKinds;
    }
    if ("excludeKinds" in __overrides) {
      excludeKinds = __overrides["excludeKinds"];
      __stack.args["excludeKinds"] = excludeKinds;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "filterImports",
            args: {
              source,
              allowedPackages,
              excludedPackages,
              allowKinds,
              excludeKinds
            },
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_filterImports, {
          type: "positional",
          args: [__stack.args.source, __stack.args.allowedPackages, __stack.args.excludedPackages, __stack.args.allowKinds, __stack.args.excludeKinds]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "filterImports",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function filterImports threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "filterImports"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "filterImports",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "filterImports",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const filterImports = __AgencyFunction.create({
  name: "filterImports",
  module: "stdlib/agency.agency",
  fn: __filterImports_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPackages",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "excludedPackages",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowKinds",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "excludeKinds",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "filterImports",
    description: `Filter imports in Agency source code according to the given policy.
  Returns the filtered source and a boolean indicating whether any imports were dropped.

  @param source - Agency source code
  @param allowedPackages - Glob patterns; matched imports are allowed (subject to excludes)
  @param excludedPackages - Glob patterns; matched imports are dropped
  @param allowKinds - Kind strings ("stdlib" | "pkg" | "local" | "node") to allow
  @param excludeKinds - Kind strings to drop`,
    schema: z.object({ "source": z.string(), "allowedPackages": z.array(z.string()).nullable().describe("Default: []"), "excludedPackages": z.array(z.string()).nullable().describe("Default: []"), "allowKinds": z.array(z.string()).nullable().describe("Default: []"), "excludeKinds": z.array(z.string()).nullable().describe("Default: []") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __getVersion_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency.agency", scopeName: "getVersion", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getVersion",
            args: {},
            moduleId: "stdlib/agency.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(VERSION);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getVersion threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getVersion"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getVersion",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getVersion",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getVersion = __AgencyFunction.create({
  name: "getVersion",
  module: "stdlib/agency.agency",
  fn: __getVersion_impl,
  params: [],
  toolDefinition: {
    name: "getVersion",
    description: `Get the current version of the Agency standard library.`,
    schema: z.object({})
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/agency.agency:compile": { "1": { "line": 93, "col": 2 } }, "stdlib/agency.agency:run": { "1": { "line": 135, "col": 2 }, "2": { "line": 136, "col": 2 }, "3": { "line": 144, "col": 2 }, "4": { "line": 164, "col": 2 }, "5": { "line": 165, "col": 14 }, "6": { "line": 165, "col": 2 }, "7": { "line": 166, "col": 2 }, "8": { "line": 184, "col": 2 }, "9": { "line": 200, "col": 2 }, "2.0": { "line": 137, "col": 4 }, "5.0": { "line": 165, "col": 38 }, "5.1": { "line": 165, "col": 38 }, "5.2": { "line": 165, "col": 51 }, "5.3": { "line": 165, "col": 51 }, "8.0": { "line": 184, "col": 2 }, "8.1.1": { "line": 189, "col": 6 }, "8.1": { "line": 185, "col": 4 } }, "stdlib/agency.agency:__block_0": { "7.0": { "line": 167, "col": 4 } }, "stdlib/agency.agency:runFile": { "1": { "line": 232, "col": 2 }, "2": { "line": 233, "col": 2 }, "3": { "line": 236, "col": 2 }, "2.0": { "line": 234, "col": 4 } }, "stdlib/agency.agency:checkRunCodeLimits": { "1": { "line": 256, "col": 2 }, "2": { "line": 262, "col": 2 }, "3": { "line": 270, "col": 2 }, "2.0.0": { "line": 264, "col": 6 }, "2.0": { "line": 263, "col": 4 }, "2.1.0": { "line": 267, "col": 6 }, "2.1": { "line": 266, "col": 4 } }, "stdlib/agency.agency:runCode": { "1": { "line": 315, "col": 2 }, "2": { "line": 316, "col": 2 }, "3": { "line": 319, "col": 2 }, "4": { "line": 320, "col": 2 }, "5": { "line": 323, "col": 2 }, "6": { "line": 338, "col": 2 }, "7": { "line": 341, "col": 2 }, "2.0": { "line": 317, "col": 4 }, "4.0": { "line": 320, "col": 2 }, "4.1": { "line": 321, "col": 4 }, "6.0": { "line": 338, "col": 2 }, "6.1": { "line": 339, "col": 4 } }, "stdlib/agency.agency:typecheck": { "1": { "line": 354, "col": 2 } }, "stdlib/agency.agency:getEffects": { "1": { "line": 370, "col": 2 } }, "stdlib/agency.agency:mergeFeedback": { "1": { "line": 392, "col": 2 }, "1.0": { "line": 392, "col": 2 }, "1.1.0": { "line": 393, "col": 4 }, "1.1.1": { "line": 394, "col": 6 }, "1.1.2": { "line": 396, "col": 6 }, "1.1": { "line": 393, "col": 4 }, "1.2": { "line": 399, "col": 4 } }, "stdlib/agency.agency:parseFeedback": { "1": { "line": 404, "col": 2 }, "2": { "line": 405, "col": 2 }, "3": { "line": 408, "col": 2 }, "2.0": { "line": 405, "col": 2 }, "2.1": { "line": 406, "col": 4 } }, "stdlib/agency.agency:reportFeedback": { "1": { "line": 414, "col": 2 }, "2": { "line": 415, "col": 2 }, "3": { "line": 418, "col": 2 }, "4": { "line": 421, "col": 2 }, "2.0": { "line": 416, "col": 4 }, "3.0": { "line": 419, "col": 4 } }, "stdlib/agency.agency:typecheckFeedback": { "1": { "line": 425, "col": 2 }, "2": { "line": 426, "col": 2 }, "3": { "line": 429, "col": 2 }, "2.0": { "line": 426, "col": 2 }, "2.1": { "line": 427, "col": 4 } }, "stdlib/agency.agency:llmFeedback": { "1": { "line": 433, "col": 2 }, "2": { "line": 434, "col": 2 }, "3": { "line": 449, "col": 2 }, "2.0": { "line": 435, "col": 4 }, "2.1": { "line": 447, "col": 4 } }, "stdlib/agency.agency:review": { "1": { "line": 461, "col": 2 }, "2": { "line": 462, "col": 2 }, "3": { "line": 463, "col": 2 }, "4": { "line": 464, "col": 2 }, "5": { "line": 467, "col": 2 }, "6": { "line": 472, "col": 2 }, "4.0": { "line": 465, "col": 4 }, "5.0": { "line": 467, "col": 2 }, "5.1.0": { "line": 469, "col": 6 }, "5.1": { "line": 468, "col": 4 } }, "stdlib/agency.agency:renderSingleFeedback": { "1": { "line": 476, "col": 2 }, "1.0": { "line": 477, "col": 4 }, "1.1": { "line": 479, "col": 4 } }, "stdlib/agency.agency:renderFeedback": { "1": { "line": 489, "col": 2 }, "2": { "line": 492, "col": 2 }, "1.0": { "line": 489, "col": 2 }, "1.1": { "line": 490, "col": 4 } }, "stdlib/agency.agency:feedbackHasErrors": { "1": { "line": 502, "col": 2 }, "3": { "line": 506, "col": 2 }, "1.0": { "line": 502, "col": 2 }, "1.1": { "line": 503, "col": 4 } }, "stdlib/agency.agency:__block_1": {}, "stdlib/agency.agency:failOpenFeedback": { "1": { "line": 513, "col": 9 }, "2": { "line": 513, "col": 9 }, "3": { "line": 513, "col": 2 }, "2.0": { "line": 513, "col": 9 }, "2.1": { "line": 514, "col": 22 }, "2.2": { "line": 514, "col": 22 }, "2.3": { "line": 513, "col": 9 }, "2.4": { "line": 515, "col": 18 }, "2.5": { "line": 515, "col": 18 } }, "stdlib/agency.agency:syntaxHintFor": { "1": { "line": 524, "col": 2 }, "2": { "line": 527, "col": 2 }, "1.0": { "line": 525, "col": 4 } }, "stdlib/agency.agency:hasMainNode": { "1": { "line": 533, "col": 2 } }, "stdlib/agency.agency:withSyntaxHint": { "1": { "line": 538, "col": 2 }, "2": { "line": 539, "col": 9 }, "3": { "line": 539, "col": 2 }, "2.0": { "line": 539, "col": 28 }, "2.1": { "line": 539, "col": 28 } }, "stdlib/agency.agency:verifyInner": { "1": { "line": 563, "col": 2 }, "2": { "line": 564, "col": 2 }, "3": { "line": 578, "col": 2 }, "2.0": { "line": 565, "col": 4 }, "2.1": { "line": 569, "col": 4 }, "2.2.2": { "line": 573, "col": 63 }, "2.2.3": { "line": 573, "col": 63 }, "2.2": { "line": 573, "col": 26 }, "2.3": { "line": 573, "col": 4 }, "2.4": { "line": 574, "col": 4 }, "2.5": { "line": 575, "col": 4 }, "2.6": { "line": 576, "col": 4 } }, "stdlib/agency.agency:verify": { "1": { "line": 593, "col": 2 } }, "stdlib/agency.agency:writeAgency": { "1": { "line": 680, "col": 2 }, "2": { "line": 681, "col": 2 }, "3": { "line": 682, "col": 2 }, "4": { "line": 725, "col": 2 }, "3.0": { "line": 683, "col": 4 }, "3.1": { "line": 684, "col": 4 }, "3.2.0": { "line": 686, "col": 6 }, "3.2": { "line": 685, "col": 4 }, "3.3": { "line": 688, "col": 4 }, "3.4": { "line": 689, "col": 4 }, "3.5.0": { "line": 691, "col": 6 }, "3.5.1": { "line": 692, "col": 6 }, "3.5.2": { "line": 693, "col": 6 }, "3.5.3": { "line": 694, "col": 6 }, "3.5.4.0": { "line": 695, "col": 6 }, "3.5.4.1": { "line": 696, "col": 8 }, "3.5.4.2": { "line": 701, "col": 8 }, "3.5.4.3.0": { "line": 703, "col": 10 }, "3.5.4.3": { "line": 702, "col": 8 }, "3.5.4.4": { "line": 705, "col": 8 }, "3.5.4.5": { "line": 707, "col": 8 }, "3.5.4.6": { "line": 708, "col": 8 }, "3.5.4.7": { "line": 709, "col": 8 }, "3.5.4.8": { "line": 711, "col": 8 }, "3.5.4.9.0": { "line": 712, "col": 8 }, "3.5.4.9.1": { "line": 713, "col": 10 }, "3.5.4.9.2": { "line": 714, "col": 10 }, "3.5.4.9.3": { "line": 716, "col": 10 }, "3.5.4.9.4": { "line": 717, "col": 10 }, "3.5.4.9.5": { "line": 719, "col": 10 }, "3.5.4.9.6": { "line": 720, "col": 10 }, "3.5.4.9": { "line": 712, "col": 8 }, "3.5.4": { "line": 695, "col": 6 }, "3.5": { "line": 690, "col": 4 } }, "stdlib/agency.agency:typecheckFile": { "1": { "line": 741, "col": 2 }, "2": { "line": 745, "col": 2 } }, "stdlib/agency.agency:parseAST": { "1": { "line": 765, "col": 2 } }, "stdlib/agency.agency:writeAST": { "1": { "line": 785, "col": 2 }, "2": { "line": 790, "col": 2 } }, "stdlib/agency.agency:format": { "1": { "line": 799, "col": 2 } }, "stdlib/agency.agency:formatFile": { "1": { "line": 811, "col": 2 }, "2": { "line": 815, "col": 2 } }, "stdlib/agency.agency:walkAST": { "1": { "line": 836, "col": 2 }, "2": { "line": 837, "col": 2 }, "3": { "line": 840, "col": 2 }, "2.0": { "line": 838, "col": 4 } }, "stdlib/agency.agency:getNodesOfType": { "1": { "line": 850, "col": 2 } }, "stdlib/agency.agency:getImports": { "1": { "line": 859, "col": 2 } }, "stdlib/agency.agency:getFunctions": { "1": { "line": 868, "col": 2 } }, "stdlib/agency.agency:getGraphNodes": { "1": { "line": 877, "col": 2 } }, "stdlib/agency.agency:filterImports": { "1": { "line": 915, "col": 2 } }, "stdlib/agency.agency:getVersion": { "1": { "line": 928, "col": 2 } } };
export {
  AST,
  CompiledProgram,
  EffectsByExport,
  Feedback,
  SourceLocation,
  TypeCheckDiagnostic,
  TypeCheckReport,
  WriteFailure,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  checkRunCodeLimits,
  compile,
  stdin_default as default,
  failOpenFeedback,
  feedbackHasErrors,
  filterImports,
  format,
  formatFile,
  getEffects,
  getFunctions,
  getGraphNodes,
  getImports,
  getNodesOfType,
  getVersion,
  hasInterrupts,
  hasMainNode,
  interrupt,
  isDebugger,
  isInterrupt,
  llmFeedback,
  mergeFeedback,
  parseAST,
  parseFeedback,
  reject,
  renderFeedback,
  renderSingleFeedback,
  reportFeedback,
  respondToInterrupts,
  review,
  rewindFrom,
  run,
  runCode,
  runFile,
  syntaxHintFor,
  typecheck,
  typecheckFeedback,
  typecheckFile,
  verify,
  verifyInner,
  walkAST,
  withSyntaxHint,
  writeAST,
  writeAgency
};
