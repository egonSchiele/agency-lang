import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  __registerGlobalsInit,
  __registerCallbacksInit,
  AgencyFunction as __AgencyFunction,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/capabilities.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/capabilities.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/capabilities.agency");
}
__registerGlobalsInit("stdlib/capabilities.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/capabilities.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const FileRead = z.union([z.literal("std::read"), z.literal("std::readBinary"), z.literal("std::ls"), z.literal("std::glob"), z.literal("std::grep")]);
const FileWrite = z.union([z.literal("std::write"), z.literal("std::writeBinary"), z.literal("std::edit"), z.literal("std::applyPatch"), z.literal("std::mkdir"), z.literal("std::move"), z.literal("std::copy"), z.literal("std::remove")]);
const FileSystem = z.union([FileRead, FileWrite]);
const Shell = z.union([z.literal("std::bash"), z.literal("std::exec"), z.literal("std::run")]);
const Network = z.union([z.literal("std::http::fetch"), z.literal("std::http::fetchJSON"), z.literal("std::http::fetchMarkdown"), z.literal("std::search"), z.literal("std::tavilySearch"), z.literal("std::weather"), z.literal("std::browserUse"), z.literal("std::wikipedia::article"), z.literal("std::wikipedia::search"), z.literal("std::wikipedia::summary"), z.literal("std::gdelt"), z.literal("std::fred"), z.literal("std::dbnomics"), z.literal("std::edgar"), z.literal("std::littlesis"), z.literal("std::yc"), z.literal("std::hackernews"), z.literal("std::wikidata"), z.literal("std::usaspending")]);
const DataFinance = z.union([z.literal("std::gdelt"), z.literal("std::fred"), z.literal("std::edgar"), z.literal("std::dbnomics")]);
const Messaging = z.union([z.literal("std::sendEmail"), z.literal("std::sendSms"), z.literal("std::sendIMessage")]);
const Secrets = z.union([z.literal("std::getSecret"), z.literal("std::setSecret"), z.literal("std::deleteSecret")]);
const Auth = z.union([z.literal("std::authorize"), z.literal("std::getAccessToken"), z.literal("std::revokeAuth")]);
const Calendar = z.union([z.literal("std::listEvents"), z.literal("std::createEvent"), z.literal("std::updateEvent"), z.literal("std::deleteEvent"), z.literal("std::authorizeCalendar")]);
const Memory = z.union([z.literal("std::memory::recall"), z.literal("std::memory::remember"), z.literal("std::memory::forget"), z.literal("std::memory::enableMemory"), z.literal("std::memory::disableMemory")]);
const NotesRead = z.union([z.literal("std::notes::read"), z.literal("std::notes::search"), z.literal("std::notes::list")]);
const NotesWrite = z.union([z.literal("std::notes::create"), z.literal("std::notes::append"), z.literal("std::notes::delete")]);
const Notes = z.union([NotesRead, NotesWrite]);
var stdin_default = graph;
const __sourceMap = {};
export {
  Auth,
  Calendar,
  DataFinance,
  FileRead,
  FileSystem,
  FileWrite,
  Memory,
  Messaging,
  Network,
  Notes,
  NotesRead,
  NotesWrite,
  Secrets,
  Shell,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  reject,
  respondToInterrupts,
  rewindFrom
};
