import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { map } from "agency-lang/stdlib/array.js";
import { fetch, fetchJSON, fetchMarkdown } from "agency-lang/stdlib/http.js";
import { docsSkill } from "agency-lang/stdlib/skills.js";
import { guard, systemMessage } from "agency-lang/stdlib/thread.js";
import { search as wikipediaSearch, summary as wikipediaSummary, article as wikipediaArticle } from "agency-lang/stdlib/wikipedia.js";
import { typecheck } from "agency-lang/stdlib/agency.js";
import { codingAgent } from "agency-lang/stdlib/agents/coding.js";
import { unwrapGuard } from "agency-lang/stdlib/agents/shared.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  runPrompt,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __tryCall,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __threads,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/agents/expert.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(map);
__registerTool(fetch);
__registerTool(fetchJSON);
__registerTool(fetchMarkdown);
__registerTool(docsSkill);
__registerTool(guard);
__registerTool(systemMessage);
__registerTool(wikipediaSearch);
__registerTool(wikipediaSummary);
__registerTool(wikipediaArticle);
__registerTool(typecheck);
__registerTool(codingAgent);
__registerTool(unwrapGuard);
let __staticInitPromise = null;
let docSkill = __UNINIT_STATIC;
let cliSkill = __UNINIT_STATIC;
let diagnosticsSkill = __UNINIT_STATIC;
let agencyTools = __UNINIT_STATIC;
let domainTools = __UNINIT_STATIC;
let agencySys = __UNINIT_STATIC;
let domainSys = __UNINIT_STATIC;
let classifySys = __UNINIT_STATIC;
let emptyGuidance = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    docSkill = __deepFreeze(await __call(docsSkill, {
      type: "positional",
      args: [`guide`]
    }));
    cliSkill = __deepFreeze(await __call(docsSkill, {
      type: "positional",
      args: [`cli`]
    }));
    diagnosticsSkill = __deepFreeze(await __call(docsSkill, {
      type: "positional",
      args: [`diagnostics`]
    }));
    agencyTools = __deepFreeze([__readStatic(docSkill, "docSkill", "stdlib/agents/expert.agency"), __readStatic(cliSkill, "cliSkill", "stdlib/agents/expert.agency"), __readStatic(diagnosticsSkill, "diagnosticsSkill", "stdlib/agents/expert.agency"), __readStatic(typecheck, "typecheck", "")]);
    domainTools = __deepFreeze([__readStatic(wikipediaSearch, "wikipediaSearch", ""), __readStatic(wikipediaSummary, "wikipediaSummary", ""), __readStatic(wikipediaArticle, "wikipediaArticle", ""), __readStatic(fetch, "fetch", ""), __readStatic(fetchJSON, "fetchJSON", ""), __readStatic(fetchMarkdown, "fetchMarkdown", "")]);
    agencySys = __deepFreeze(`You are an expert in the Agency programming language, advising a weaker coding agent that is about to attempt the task below.

Return the domain-specific knowledge it needs to get the task right:
- domain: "agency-lang".
- rules: the Agency conventions, syntax rules, and gotchas that apply to this task \u2014 the things a non-expert gets wrong. Be concrete and cite the guide.
- checklist: concrete acceptance criteria the finished code must satisfy (compiles/typechecks, uses the right construct, handles failures, etc). For EACH item, state HOW to verify it \u2014 the exact command to run (e.g. \`agency typecheck <file>\`) or the exact construct to look for. Prefer items checkable by running a command.
- ambiguity: if the task allows more than one valid reading, say so, and make the checklist require the work to satisfy the criteria under every reasonable reading, not just the first one.

The bundled docs (docSkill / cliSkill / diagnosticsSkill) are authoritative \u2014 consult them rather than guessing. If the task needs no special Agency knowledge, return empty rules and checklist.`);
    domainSys = __deepFreeze(`You are a domain expert advising a weaker coding agent that is about to attempt the task below and tends to miss domain-specific conventions.

Identify the technical domain, then return the knowledge it needs:
- domain: a short name for the field (e.g. "molecular biology / primer design", "ELF binaries").
- rules: the key conventions, constraints, and facts that apply \u2014 especially the ones a non-expert gets wrong. Be concrete: exact numeric ranges, formats, encodings, common pitfalls.
- checklist: concrete acceptance criteria the finished artifact MUST satisfy. For EACH item, state HOW to verify it \u2014 the exact command/tool/flags AND the exact input it applies to (which file, which sub-sequence, which bytes). When the task names a ground-truth tool, use it verbatim with its exact flags. Prefer items that can be checked by running a command over ones checked by eye. Be surgical about scope (e.g. "compute Tm on ONLY the annealing portion, not the whole primer").
- ambiguity: if a step allows more than one valid reading \u2014 an unclear boundary, an unstated convention, a value the task never pins down \u2014 call it out explicitly. When it affects a criterion, require the work to satisfy that criterion under EVERY reasonable reading, not just the first one. A checklist that silently assumes one reading is how a plausible-looking solution fails a hidden test.

Prefer the web_search tool to confirm specifics when unsure (wikipedia/fetch may be unavailable in sandboxed environments \u2014 if one fails, switch tools rather than retrying it). If the task has no special domain constraints, return empty rules and checklist.`);
    classifySys = __deepFreeze(`Classify the task below. Answer with domain = "agency" if it is about writing or debugging code in the Agency programming language itself (its syntax, types, stdlib, or CLI), or domain = "general" for any other technical domain. When unsure, answer "general".`);
    emptyGuidance = __deepFreeze({
      "domain": ``,
      "rules": [],
      "checklist": []
    });
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    docSkill,
    cliSkill,
    diagnosticsSkill,
    agencyTools,
    domainTools,
    agencySys,
    domainSys,
    classifySys,
    emptyGuidance
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/agents/expert.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/agents/expert.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/agents/expert.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/agents/expert.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const ExpertGuidance = z.object({ "domain": z.string(), "rules": z.array(z.string()), "checklist": z.array(z.string()) });
const DomainKind = z.object({ "domain": z.string() });
async function __classifyDomain_impl(question) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/expert.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["question"] = question;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/expert.agency", scopeName: "classifyDomain", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("question" in __overrides) {
      question = __overrides["question"];
      __stack.args["question"] = question;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "classifyDomain",
            args: {
              question
            },
            moduleId: "stdlib/agents/expert.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.kind = {
          "domain": `general`
        };
      });
      await runner.thread(2, "create", async () => ({ label: `classifyDomain`, session: `expert-classify` }), async (runner2) => {
        await runner2.step(0, async (runner3) => {
          const __funcResult = await __call(systemMessage, {
            type: "positional",
            args: [__readStatic(classifySys, "classifySys", "stdlib/agents/expert.agency")]
          });
          if (hasInterrupts(__funcResult)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__funcResult);
            return;
          }
        });
        await runner2.step(1, async (runner3) => {
          __self.__removedTools = __self.__removedTools || [];
          __stack.locals.k = await runPrompt({
            prompt: `Task:
${__stack.args.question}`,
            messages: __threads().getOrCreateActive(),
            responseFormat: z.object({
              response: DomainKind
            }),
            clientConfig: {},
            maxToolCallRounds: 10,
            removedTools: __self.__removedTools,
            destructiveSink: __self,
            checkpointInfo: runner3.getCheckpointInfo()
          });
          if (hasInterrupts(__stack.locals.k)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.k);
            return;
          }
        });
        await runner2.step(2, async (runner3) => {
          __stack.locals.kind = __stack.locals.k;
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.kind.domain);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function classifyDomain threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "classifyDomain"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "classifyDomain",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "classifyDomain",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const classifyDomain = __AgencyFunction.create({
  name: "classifyDomain",
  module: "stdlib/agents/expert.agency",
  fn: __classifyDomain_impl,
  params: [{
    name: "question",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "classifyDomain",
    description: "No description provided.",
    schema: z.object({ "question": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __agencyExpert_impl(question, expertModel = __UNSET, expertProvider = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/expert.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["question"] = question;
  __stack.args["expertModel"] = expertModel === __UNSET ? `` : expertModel;
  __stack.args["expertProvider"] = expertProvider === __UNSET ? `` : expertProvider;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/expert.agency", scopeName: "agencyExpert", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("question" in __overrides) {
      question = __overrides["question"];
      __stack.args["question"] = question;
    }
    if ("expertModel" in __overrides) {
      expertModel = __overrides["expertModel"];
      __stack.args["expertModel"] = expertModel;
    }
    if ("expertProvider" in __overrides) {
      expertProvider = __overrides["expertProvider"];
      __stack.args["expertProvider"] = expertProvider;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "agencyExpert",
            args: {
              question,
              expertModel,
              expertProvider
            },
            moduleId: "stdlib/agents/expert.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.guidance = {
          "domain": `agency-lang`,
          "rules": [],
          "checklist": []
        };
      });
      await runner.thread(2, "create", async () => ({ label: `agencyExpert`, session: `expert-agency` }), async (runner2) => {
        await runner2.step(0, async (runner3) => {
          const __funcResult = await __call(systemMessage, {
            type: "positional",
            args: [__readStatic(agencySys, "agencySys", "stdlib/agents/expert.agency")]
          });
          if (hasInterrupts(__funcResult)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__funcResult);
            return;
          }
        });
        await runner2.ifElse(1, [
          {
            condition: async () => __eq(__stack.args.expertModel, ``),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __self.__removedTools = __self.__removedTools || [];
                __stack.locals.g = await runPrompt({
                  prompt: `Task:
${__stack.args.question}`,
                  messages: __threads().getOrCreateActive(),
                  responseFormat: z.object({
                    response: ExpertGuidance
                  }),
                  clientConfig: {
                    "tools": __readStatic(agencyTools, "agencyTools", "stdlib/agents/expert.agency")
                  },
                  maxToolCallRounds: 10,
                  removedTools: __self.__removedTools,
                  destructiveSink: __self,
                  checkpointInfo: runner4.getCheckpointInfo()
                });
                if (hasInterrupts(__stack.locals.g)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__stack.locals.g);
                  return;
                }
              });
              await runner3.step(1, async (runner4) => {
                __stack.locals.guidance = __stack.locals.g;
              });
            }
          }
        ], async (runner3) => {
          await runner3.step(2, async (runner4) => {
            __self.__removedTools = __self.__removedTools || [];
            __stack.locals.g = await runPrompt({
              prompt: `Task:
${__stack.args.question}`,
              messages: __threads().getOrCreateActive(),
              responseFormat: z.object({
                response: ExpertGuidance
              }),
              clientConfig: {
                "tools": __readStatic(agencyTools, "agencyTools", "stdlib/agents/expert.agency"),
                "model": __stack.args.expertModel,
                "provider": __stack.args.expertProvider
              },
              maxToolCallRounds: 10,
              removedTools: __self.__removedTools,
              destructiveSink: __self,
              checkpointInfo: runner4.getCheckpointInfo()
            });
            if (hasInterrupts(__stack.locals.g)) {
              await getRuntimeContext().ctx.pendingPromises.awaitAll();
              runner4.halt(__stack.locals.g);
              return;
            }
          });
          await runner3.step(3, async (runner4) => {
            __stack.locals.guidance = __stack.locals.g;
          });
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.guidance);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function agencyExpert threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "agencyExpert"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "agencyExpert",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "agencyExpert",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const agencyExpert = __AgencyFunction.create({
  name: "agencyExpert",
  module: "stdlib/agents/expert.agency",
  fn: __agencyExpert_impl,
  params: [{
    name: "question",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "expertModel",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "expertProvider",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "agencyExpert",
    description: `Agency-language specialist: returns rules + a checklist grounded in the
  bundled docs. @param question - the task to advise on.
  @param expertModel - optional model override for the consult (empty = ambient).
  @param expertProvider - optional provider for expertModel (empty = auto-resolve).`,
    schema: z.object({ "question": z.string(), "expertModel": z.string().nullable().describe("Default: "), "expertProvider": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __domainExpert_impl(question, expertModel = __UNSET, expertProvider = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/expert.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["question"] = question;
  __stack.args["expertModel"] = expertModel === __UNSET ? `` : expertModel;
  __stack.args["expertProvider"] = expertProvider === __UNSET ? `` : expertProvider;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/expert.agency", scopeName: "domainExpert", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("question" in __overrides) {
      question = __overrides["question"];
      __stack.args["question"] = question;
    }
    if ("expertModel" in __overrides) {
      expertModel = __overrides["expertModel"];
      __stack.args["expertModel"] = expertModel;
    }
    if ("expertProvider" in __overrides) {
      expertProvider = __overrides["expertProvider"];
      __stack.args["expertProvider"] = expertProvider;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "domainExpert",
            args: {
              question,
              expertModel,
              expertProvider
            },
            moduleId: "stdlib/agents/expert.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.guidance = {
          "domain": ``,
          "rules": [],
          "checklist": []
        };
      });
      await runner.thread(2, "create", async () => ({ label: `domainExpert`, session: `expert-domain` }), async (runner2) => {
        await runner2.step(0, async (runner3) => {
          const __funcResult = await __call(systemMessage, {
            type: "positional",
            args: [__readStatic(domainSys, "domainSys", "stdlib/agents/expert.agency")]
          });
          if (hasInterrupts(__funcResult)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__funcResult);
            return;
          }
        });
        await runner2.ifElse(1, [
          {
            condition: async () => __eq(__stack.args.expertModel, ``),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __self.__removedTools = __self.__removedTools || [];
                __stack.locals.g = await runPrompt({
                  prompt: `Task:
${__stack.args.question}`,
                  messages: __threads().getOrCreateActive(),
                  responseFormat: z.object({
                    response: ExpertGuidance
                  }),
                  clientConfig: {
                    "tools": __readStatic(domainTools, "domainTools", "stdlib/agents/expert.agency"),
                    "hostedTools": [`web_search`]
                  },
                  maxToolCallRounds: 10,
                  removedTools: __self.__removedTools,
                  destructiveSink: __self,
                  checkpointInfo: runner4.getCheckpointInfo()
                });
                if (hasInterrupts(__stack.locals.g)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__stack.locals.g);
                  return;
                }
              });
              await runner3.step(1, async (runner4) => {
                __stack.locals.guidance = __stack.locals.g;
              });
            }
          }
        ], async (runner3) => {
          await runner3.step(2, async (runner4) => {
            __self.__removedTools = __self.__removedTools || [];
            __stack.locals.g = await runPrompt({
              prompt: `Task:
${__stack.args.question}`,
              messages: __threads().getOrCreateActive(),
              responseFormat: z.object({
                response: ExpertGuidance
              }),
              clientConfig: {
                "tools": __readStatic(domainTools, "domainTools", "stdlib/agents/expert.agency"),
                "hostedTools": [`web_search`],
                "model": __stack.args.expertModel,
                "provider": __stack.args.expertProvider
              },
              maxToolCallRounds: 10,
              removedTools: __self.__removedTools,
              destructiveSink: __self,
              checkpointInfo: runner4.getCheckpointInfo()
            });
            if (hasInterrupts(__stack.locals.g)) {
              await getRuntimeContext().ctx.pendingPromises.awaitAll();
              runner4.halt(__stack.locals.g);
              return;
            }
          });
          await runner3.step(3, async (runner4) => {
            __stack.locals.guidance = __stack.locals.g;
          });
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.guidance);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function domainExpert threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "domainExpert"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "domainExpert",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "domainExpert",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const domainExpert = __AgencyFunction.create({
  name: "domainExpert",
  module: "stdlib/agents/expert.agency",
  fn: __domainExpert_impl,
  params: [{
    name: "question",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "expertModel",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "expertProvider",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "domainExpert",
    description: `General-knowledge specialist: returns rules + a checklist, using web /
  Wikipedia lookups. @param question - the task to advise on.
  @param expertModel - optional model override for the consult (empty = ambient).
  @param expertProvider - optional provider for expertModel (empty = auto-resolve).`,
    schema: z.object({ "question": z.string(), "expertModel": z.string().nullable().describe("Default: "), "expertProvider": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __consultExpert_impl(question, expertModel = __UNSET, expertProvider = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/expert.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["question"] = question;
  __stack.args["expertModel"] = expertModel === __UNSET ? `` : expertModel;
  __stack.args["expertProvider"] = expertProvider === __UNSET ? `` : expertProvider;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/expert.agency", scopeName: "consultExpert", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("question" in __overrides) {
      question = __overrides["question"];
      __stack.args["question"] = question;
    }
    if ("expertModel" in __overrides) {
      expertModel = __overrides["expertModel"];
      __stack.args["expertModel"] = expertModel;
    }
    if ("expertProvider" in __overrides) {
      expertProvider = __overrides["expertProvider"];
      __stack.args["expertProvider"] = expertProvider;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "consultExpert",
            args: {
              question,
              expertModel,
              expertProvider
            },
            moduleId: "stdlib/agents/expert.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(await __call(classifyDomain, {
            type: "positional",
            args: [__stack.args.question]
          }), `agency`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.__ifbranch_3 = await __call(agencyExpert, {
                type: "positional",
                args: [__stack.args.question, __stack.args.expertModel, __stack.args.expertProvider]
              });
              if (hasInterrupts(__stack.locals.__ifbranch_3)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__ifbranch_3);
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__ifbranch_3);
              return;
            });
          }
        }
      ], async (runner2) => {
        await runner2.step(2, async (runner3) => {
          __stack.locals.__ifbranch_2 = await __call(domainExpert, {
            type: "positional",
            args: [__stack.args.question, __stack.args.expertModel, __stack.args.expertProvider]
          });
          if (hasInterrupts(__stack.locals.__ifbranch_2)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.__ifbranch_2);
            return;
          }
        });
        await runner2.step(3, async (runner3) => {
          runner3.exitMatch(1, __stack.locals.__ifbranch_2);
          return;
        });
      }, { matchId: 1 });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function consultExpert threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "consultExpert"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "consultExpert",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "consultExpert",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const consultExpert = __AgencyFunction.create({
  name: "consultExpert",
  module: "stdlib/agents/expert.agency",
  fn: __consultExpert_impl,
  params: [{
    name: "question",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "expertModel",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "expertProvider",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "consultExpert",
    description: `Route to the Agency-language or general-domain specialist automatically and
  return its guidance. @param question - the task to advise on.`,
    schema: z.object({ "question": z.string(), "expertModel": z.string().nullable().describe("Default: "), "expertProvider": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __consultOrEmpty_impl(task, expertModel = __UNSET, expertProvider = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/expert.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["expertModel"] = expertModel === __UNSET ? `` : expertModel;
  __stack.args["expertProvider"] = expertProvider === __UNSET ? `` : expertProvider;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/expert.agency", scopeName: "consultOrEmpty", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("expertModel" in __overrides) {
      expertModel = __overrides["expertModel"];
      __stack.args["expertModel"] = expertModel;
    }
    if ("expertProvider" in __overrides) {
      expertProvider = __overrides["expertProvider"];
      __stack.args["expertProvider"] = expertProvider;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "consultOrEmpty",
            args: {
              task,
              expertModel,
              expertProvider
            },
            moduleId: "stdlib/agents/expert.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_7 = await __tryCall(async () => await __call(consultExpert, {
          type: "positional",
          args: [__stack.args.task, __stack.args.expertModel, __stack.args.expertProvider]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "consultOrEmpty",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.__scrutinee_7)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.__scrutinee_7);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_7),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.g = __stack.locals.__scrutinee_7.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_5 = __stack.locals.g;
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(4, __stack.locals.__armval_5);
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_7),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals._ = __stack.locals.__scrutinee_7.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_6 = __readStatic(emptyGuidance, "emptyGuidance", "stdlib/agents/expert.agency");
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(4, __stack.locals.__armval_6);
              return;
            });
          }
        }
      ], void 0, { matchId: 4 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_4));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function consultOrEmpty threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "consultOrEmpty"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "consultOrEmpty",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "consultOrEmpty",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const consultOrEmpty = __AgencyFunction.create({
  name: "consultOrEmpty",
  module: "stdlib/agents/expert.agency",
  fn: __consultOrEmpty_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "expertModel",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "expertProvider",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "consultOrEmpty",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "expertModel": z.string().nullable().describe("Default: "), "expertProvider": z.string().nullable().describe("Default: ") })
  },
  exported: false
}, __toolRegistry);
async function __renderGuidance_impl(g) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/expert.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["g"] = g;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/expert.agency", scopeName: "renderGuidance", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("g" in __overrides) {
      g = __overrides["g"];
      __stack.args["g"] = g;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "renderGuidance",
            args: {
              g
            },
            moduleId: "stdlib/agents/expert.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.g.rules.length, 0) && __eq(__stack.args.g.checklist.length, 0),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(``);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __stack.locals.rules = await __callMethod(await await __call(map, {
          type: "named",
          positionalArgs: [__stack.args.g.rules],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/agents/expert.agency", fn: async (r) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["r"] = r;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/expert.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(`- ${__bstack.args.r}`);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "r", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }), "join", {
          type: "positional",
          args: [`
`]
        });
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.checks = await __callMethod(await await __call(map, {
          type: "named",
          positionalArgs: [__stack.args.g.checklist],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/agents/expert.agency", fn: async (c) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_1 = __bstack;
            __bstack.args["c"] = c;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/expert.agency", scopeName: "__block_1" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(`- ${__bstack.args.c}`);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "c", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }), "join", {
          type: "positional",
          args: [`
`]
        });
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`Domain expertise for this task (${__stack.args.g.domain}):

Key rules and conventions:
${__stack.locals.rules}

Acceptance checklist \u2014 your finished work MUST satisfy every item:
${__stack.locals.checks}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function renderGuidance threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "renderGuidance"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "renderGuidance",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "renderGuidance",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const renderGuidance = __AgencyFunction.create({
  name: "renderGuidance",
  module: "stdlib/agents/expert.agency",
  fn: __renderGuidance_impl,
  params: [{
    name: "g",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "renderGuidance",
    description: "No description provided.",
    schema: z.object({ "g": ExpertGuidance })
  },
  exported: false
}, __toolRegistry);
async function __expertAgent_impl(task, context = __UNSET, maxCost = __UNSET, maxTime = __UNSET, expertModel = __UNSET, expertProvider = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/expert.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["context"] = context === __UNSET ? `` : context;
  __stack.args["maxCost"] = maxCost === __UNSET ? 20 : maxCost;
  __stack.args["maxTime"] = maxTime === __UNSET ? 9e5 : maxTime;
  __stack.args["expertModel"] = expertModel === __UNSET ? `` : expertModel;
  __stack.args["expertProvider"] = expertProvider === __UNSET ? `` : expertProvider;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/expert.agency", scopeName: "expertAgent", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
    if ("maxTime" in __overrides) {
      maxTime = __overrides["maxTime"];
      __stack.args["maxTime"] = maxTime;
    }
    if ("expertModel" in __overrides) {
      expertModel = __overrides["expertModel"];
      __stack.args["expertModel"] = expertModel;
    }
    if ("expertProvider" in __overrides) {
      expertProvider = __overrides["expertProvider"];
      __stack.args["expertProvider"] = expertProvider;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "expertAgent",
            args: {
              task,
              context,
              maxCost,
              maxTime,
              expertModel,
              expertProvider
            },
            moduleId: "stdlib/agents/expert.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.captured = await __call(guard, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            cost: __stack.args.maxCost,
            time: __stack.args.maxTime
          },
          blockArg: __AgencyFunction.create({ name: "__block_2", module: "stdlib/agents/expert.agency", fn: async () => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_2 = __bstack;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/expert.agency", scopeName: "__block_2" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.guidance = await __call(consultOrEmpty, {
                  type: "positional",
                  args: [__stack.args.task, __stack.args.expertModel, __stack.args.expertProvider]
                });
                if (hasInterrupts(__bstack.locals.guidance)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__bstack.locals.guidance);
                  return;
                }
              });
              await runner3.step(1, async (runner4) => {
                __bstack.locals.solverContext = await __call(renderGuidance, {
                  type: "positional",
                  args: [__bstack.locals.guidance]
                });
                if (hasInterrupts(__bstack.locals.solverContext)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__bstack.locals.solverContext);
                  return;
                }
              });
              await runner3.ifElse(2, [
                {
                  condition: async () => !__eq(__stack.args.context, ``),
                  body: async (runner4) => {
                    await runner4.ifElse(0, [
                      {
                        condition: async () => __eq(__bstack.locals.solverContext, ``),
                        body: async (runner5) => {
                          await runner5.step(0, async (runner6) => {
                            __bstack.locals.__ifbranch_10 = __stack.args.context;
                          });
                          await runner5.step(1, async (runner6) => {
                            runner6.exitMatch(8, __bstack.locals.__ifbranch_10);
                            return;
                          });
                        }
                      }
                    ], async (runner5) => {
                      await runner5.step(2, async (runner6) => {
                        __bstack.locals.__ifbranch_9 = `${__bstack.locals.solverContext}

${__stack.args.context}`;
                      });
                      await runner5.step(3, async (runner6) => {
                        runner6.exitMatch(8, __bstack.locals.__ifbranch_9);
                        return;
                      });
                    }, { matchId: 8 });
                    await runner4.step(1, async (runner5) => {
                      __bstack.locals.solverContext = __nn(__stack.locals.__matchval_8);
                    });
                  }
                }
              ]);
              await runner3.step(3, async (runner4) => {
              });
              await runner3.step(4, async (runner4) => {
                runner4.halt(await __call(codingAgent, {
                  type: "named",
                  positionalArgs: [__stack.args.task],
                  namedArgs: {
                    context: __bstack.locals.solverContext,
                    criteria: __bstack.locals.guidance.checklist,
                    maxCost: __stack.args.maxCost,
                    maxTime: __stack.args.maxTime
                  }
                }));
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.captured)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.captured);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(unwrapGuard, {
          type: "positional",
          args: [__stack.locals.captured, `Expert`]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function expertAgent threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "expertAgent"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "expertAgent",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "expertAgent",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const expertAgent = __AgencyFunction.create({
  name: "expertAgent",
  module: "stdlib/agents/expert.agency",
  fn: __expertAgent_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxTime",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "expertModel",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "expertProvider",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "expertAgent",
    description: `Expert-guided coding agent. Consults a domain expert for the task's rules and
  acceptance criteria, then solves the task with that guidance in hand. A
  drop-in for plannerAgent: takes a task, returns a summary string; the real
  output is filesystem side effects.

  @param task - what to accomplish.
  @param context - optional extra material passed through to the solver.
  @param maxCost - hard spend cap for the whole run (default $20).
  @param maxTime - hard wall-clock cap for the whole run (default 15 minutes).
  @param expertModel - optional model for the expert consult only, not the
    solver (empty = the ambient model). Lets a caller put the one-shot expert
    consult on a stronger model while the solve loop stays on the default.
  @param expertProvider - optional provider for expertModel (empty = auto-resolve).`,
    schema: z.object({ "task": z.string(), "context": z.string().nullable().describe("Default: "), "maxCost": z.number().nullable().describe("Default: $20.00"), "maxTime": z.number().nullable().describe("Default: 15m"), "expertModel": z.string().nullable().describe("Default: "), "expertProvider": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/agents/expert.agency:classifyDomain": { "1": { "line": 84, "col": 2 }, "2": { "line": 85, "col": 2 }, "3": { "line": 91, "col": 2 }, "2.0": { "line": 86, "col": 4 }, "2.1": { "line": 88, "col": 4 }, "2.2": { "line": 89, "col": 4 } }, "stdlib/agents/expert.agency:agencyExpert": { "1": { "line": 99, "col": 2 }, "2": { "line": 100, "col": 2 }, "3": { "line": 112, "col": 2 }, "2.0": { "line": 101, "col": 4 }, "2.1.0": { "line": 105, "col": 6 }, "2.1.1": { "line": 106, "col": 6 }, "2.1.2": { "line": 108, "col": 6 }, "2.1.3": { "line": 109, "col": 6 }, "2.1": { "line": 104, "col": 4 } }, "stdlib/agents/expert.agency:domainExpert": { "1": { "line": 120, "col": 2 }, "2": { "line": 121, "col": 2 }, "3": { "line": 134, "col": 2 }, "2.0": { "line": 122, "col": 4 }, "2.1.0": { "line": 127, "col": 6 }, "2.1.1": { "line": 128, "col": 6 }, "2.1.2": { "line": 130, "col": 6 }, "2.1.3": { "line": 131, "col": 6 }, "2.1": { "line": 126, "col": 4 } }, "stdlib/agents/expert.agency:consultExpert": { "1": { "line": 140, "col": 9 }, "2": { "line": 140, "col": 2 }, "1.0": { "line": 140, "col": 54 }, "1.1": { "line": 140, "col": 54 }, "1.2": { "line": 140, "col": 111 }, "1.3": { "line": 140, "col": 111 } }, "stdlib/agents/expert.agency:consultOrEmpty": { "1": { "line": 150, "col": 9 }, "2": { "line": 150, "col": 9 }, "3": { "line": 150, "col": 2 }, "2.0": { "line": 150, "col": 9 }, "2.1": { "line": 151, "col": 18 }, "2.2": { "line": 151, "col": 18 }, "2.3": { "line": 150, "col": 9 }, "2.4": { "line": 152, "col": 18 }, "2.5": { "line": 152, "col": 18 } }, "stdlib/agents/expert.agency:renderGuidance": { "1": { "line": 160, "col": 2 }, "2": { "line": 163, "col": 2 }, "3": { "line": 164, "col": 2 }, "4": { "line": 165, "col": 2 }, "1.0": { "line": 161, "col": 4 } }, "stdlib/agents/expert.agency:__block_0": {}, "stdlib/agents/expert.agency:__block_1": {}, "stdlib/agents/expert.agency:expertAgent": { "1": { "line": 184, "col": 2 }, "2": { "line": 195, "col": 2 } }, "stdlib/agents/expert.agency:__block_2": { "1.0": { "line": 185, "col": 4 }, "1.1": { "line": 186, "col": 4 }, "1.2.0.0": { "line": 188, "col": 50 }, "1.2.0.1": { "line": 188, "col": 50 }, "1.2.0": { "line": 188, "col": 22 }, "1.2.1": { "line": 188, "col": 6 }, "1.2": { "line": 187, "col": 4 }, "1.4": { "line": 193, "col": 4 } } };
export {
  ExpertGuidance,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  agencyExpert,
  approve,
  classifyDomain,
  consultExpert,
  consultOrEmpty,
  stdin_default as default,
  domainExpert,
  expertAgent,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  reject,
  renderGuidance,
  respondToInterrupts,
  rewindFrom
};
