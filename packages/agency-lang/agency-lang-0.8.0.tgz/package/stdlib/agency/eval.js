import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { run, CompiledProgram } from "agency-lang/stdlib/agency.js";
import { _initEvalRun, _prepareInput, _finalizeInput, _finishEvalRun, _formatEvalRunFailure, _evalExtract, _evalJudge, _evalJudgeSuite, _optimize } from "agency-lang/stdlib-lib/agencyEval.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  __readStatic,
  __registerGlobalsInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __eq,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/agency/eval.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(run);
__registerTool(CompiledProgram);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/agency/eval.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/agency/eval.agency");
}
__registerGlobalsInit("stdlib/agency/eval.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
const Input = z.object({ "id": z.union([z.string(), z.null()]).optional().default(null), "goal": z.union([z.string(), z.null()]).optional().default(null), "args": z.record(z.string(), z.any()), "node": z.union([z.string(), z.null()]).optional().default(null), "working_dir": z.union([z.string(), z.null()]).optional().default(null), "metadata": z.union([z.record(z.string(), z.any()), z.null()]).optional().default(null) });
const EvalRunInputResult = z.object({ "inputId": z.string(), "status": z.union([z.literal("success"), z.literal("error")]), "evalRecordPath": z.string(), "statelogPath": z.string(), "workdirPath": z.string(), "errorMessage": z.union([z.string(), z.null()]).optional().default(null) });
const EvalRunResult = z.object({ "runId": z.string(), "runDir": z.string(), "agent": z.string(), "inputs": z.array(EvalRunInputResult), "okCount": z.number(), "errorCount": z.number() });
async function __evalRun_impl(compiled, inputs, node = __UNSET, runsDir = __UNSET, runId = __UNSET, continueOnError = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency/eval.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["compiled"] = compiled;
  __stack.args["inputs"] = inputs;
  __stack.args["node"] = node === __UNSET ? `main` : node;
  __stack.args["runsDir"] = runsDir === __UNSET ? `runs/` : runsDir;
  __stack.args["runId"] = runId === __UNSET ? `` : runId;
  __stack.args["continueOnError"] = continueOnError === __UNSET ? true : continueOnError;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency/eval.agency", scopeName: "evalRun", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("compiled" in __overrides) {
      compiled = __overrides["compiled"];
      __stack.args["compiled"] = compiled;
    }
    if ("inputs" in __overrides) {
      inputs = __overrides["inputs"];
      __stack.args["inputs"] = inputs;
    }
    if ("node" in __overrides) {
      node = __overrides["node"];
      __stack.args["node"] = node;
    }
    if ("runsDir" in __overrides) {
      runsDir = __overrides["runsDir"];
      __stack.args["runsDir"] = runsDir;
    }
    if ("runId" in __overrides) {
      runId = __overrides["runId"];
      __stack.args["runId"] = runId;
    }
    if ("continueOnError" in __overrides) {
      continueOnError = __overrides["continueOnError"];
      __stack.args["continueOnError"] = continueOnError;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "evalRun",
            args: {
              compiled,
              inputs,
              node,
              runsDir,
              runId,
              continueOnError
            },
            moduleId: "stdlib/agency/eval.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.state = await __call(_initEvalRun, {
          type: "positional",
          args: [__stack.args.compiled, __stack.args.inputs, __stack.args.node, __stack.args.runsDir, __stack.args.runId, __stack.args.continueOnError]
        });
        if (hasInterrupts(__stack.locals.state)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.state);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.results = [];
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.lastStatus = `success`;
      });
      await runner.loop(4, async () => __stack.locals.state.inputs, async (input2, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.prep = await __call(_prepareInput, {
            type: "positional",
            args: [__stack.locals.state, __readStatic(input2, "input", "")]
          });
          if (hasInterrupts(__stack.locals.prep)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.prep);
            return;
          }
        });
        await runner2.ifElse(1, [
          {
            condition: async () => __stack.locals.prep.ok,
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.prepared = __stack.locals.prep.prepared;
              });
              await runner3.step(1, async (runner4) => {
                __stack.locals.runResult = await __call(run, {
                  type: "named",
                  positionalArgs: [],
                  namedArgs: {
                    compiled: __stack.args.compiled,
                    node: __readStatic(input2, "input", "").node ?? __stack.args.node,
                    args: __readStatic(input2, "input", "").args,
                    logFile: __stack.locals.prepared.statelogPath,
                    cwd: __stack.locals.prepared.workdirPath
                  }
                });
                if (hasInterrupts(__stack.locals.runResult)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__stack.locals.runResult);
                  return;
                }
              });
              await runner3.step(2, async (runner4) => {
                __stack.locals.runError = ``;
              });
              await runner3.ifElse(3, [
                {
                  condition: async () => await isFailure(__stack.locals.runResult),
                  body: async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      __stack.locals.runError = await __call(_formatEvalRunFailure, {
                        type: "positional",
                        args: [__stack.locals.runResult]
                      });
                      if (hasInterrupts(__stack.locals.runError)) {
                        await getRuntimeContext().ctx.pendingPromises.awaitAll();
                        runner5.halt(__stack.locals.runError);
                        return;
                      }
                    });
                  }
                }
              ]);
              await runner3.step(4, async (runner4) => {
                __stack.locals.inputResult = await __call(_finalizeInput, {
                  type: "positional",
                  args: [__stack.locals.prepared, __stack.locals.runError]
                });
                if (hasInterrupts(__stack.locals.inputResult)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__stack.locals.inputResult);
                  return;
                }
              });
              await runner3.step(5, async (runner4) => {
                await __callMethod(__stack.locals.results, "push", {
                  type: "positional",
                  args: [__stack.locals.inputResult]
                });
              });
              await runner3.step(6, async (runner4) => {
                __stack.locals.lastStatus = __stack.locals.inputResult.status;
              });
            }
          }
        ], async (runner3) => {
          await runner3.step(7, async (runner4) => {
            await __callMethod(__stack.locals.results, "push", {
              type: "positional",
              args: [__stack.locals.prep.result]
            });
          });
          await runner3.step(8, async (runner4) => {
            __stack.locals.lastStatus = __stack.locals.prep.result.status;
          });
        });
        await runner2.ifElse(2, [
          {
            condition: async () => __eq(__stack.locals.lastStatus, `error`) && !__stack.args.continueOnError,
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                runner4.breakLoop();
                return;
              });
            }
          }
        ]);
      });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_finishEvalRun, {
          type: "positional",
          args: [__stack.locals.state, __stack.locals.results]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function evalRun threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "evalRun"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "evalRun",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "evalRun",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const evalRun = __AgencyFunction.create({
  name: "evalRun",
  module: "stdlib/agency/eval.agency",
  fn: __evalRun_impl,
  params: [{
    name: "compiled",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "inputs",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "node",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "runsDir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "runId",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "continueOnError",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "evalRun",
    description: `Run a compiled Agency program against a list of eval inputs sequentially, writing per-input statelog and eval artifacts under runsDir/runId, and return a summary of the run.

  @param compiled - Compiled program to evaluate
  @param inputs - Eval inputs to run sequentially
  @param node - Default node to invoke when an input does not specify one
  @param runsDir - Output directory for eval runs
  @param runId - Optional run id; generated when empty
  @param continueOnError - Continue remaining inputs after an input error`,
    schema: z.object({ "compiled": CompiledProgram, "inputs": z.array(Input), "node": z.string().nullable().describe("Default: main"), "runsDir": z.string().nullable().describe("Default: runs/"), "runId": z.string().nullable().describe("Default: "), "continueOnError": z.boolean().nullable().describe("Default: true") })
  },
  exported: true
}, __toolRegistry);
const EvalValue = z.object({ "value": z.any(), "threadId": z.union([z.string(), z.null()]).optional().default(null), "tMs": z.number(), "truncated": z.union([z.boolean(), z.null()]).optional().default(null) });
const EvalRecord = z.object({ "traceId": z.string(), "recordVersion": z.number(), "formatVersion": z.number(), "durationMs": z.number(), "source": z.string(), "evalValues": z.array(EvalValue), "evalOutputs": z.array(EvalValue), "threads": z.array(z.record(z.string(), z.any())), "events": z.array(z.record(z.string(), z.any())), "interrupts": z.array(z.record(z.string(), z.any())), "errors": z.array(z.record(z.string(), z.any())), "incomplete": z.array(z.record(z.string(), z.any())), "metrics": z.record(z.string(), z.any()), "warnings": z.array(z.string()) });
async function __evalExtract_impl(statelogPath) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency/eval.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["statelogPath"] = statelogPath;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency/eval.agency", scopeName: "evalExtract", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("statelogPath" in __overrides) {
      statelogPath = __overrides["statelogPath"];
      __stack.args["statelogPath"] = statelogPath;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "evalExtract",
            args: {
              statelogPath
            },
            moduleId: "stdlib/agency/eval.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_evalExtract, {
          type: "positional",
          args: [__stack.args.statelogPath]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function evalExtract threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "evalExtract"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "evalExtract",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "evalExtract",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const evalExtract = __AgencyFunction.create({
  name: "evalExtract",
  module: "stdlib/agency/eval.agency",
  fn: __evalExtract_impl,
  params: [{
    name: "statelogPath",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "evalExtract",
    description: `Extract a structured eval record from a statelog file. Returns the same record \`agency eval extract\` writes to disk, but directly, so eval pipelines composed in Agency can inspect or judge it without going through a temporary file.

  @param statelogPath - Path to a .statelog.jsonl file produced by an agent run (e.g. the file under \`runs/<run-id>/inputs/<input-id>/\` after an eval run)`,
    schema: z.object({ "statelogPath": z.string() })
  },
  exported: true
}, __toolRegistry);
const PairwiseVerdictInput = z.object({ "path": z.string(), "response": z.string(), "truncated": z.union([z.boolean(), z.null()]).optional().default(null) });
const PairwiseVerdict = z.object({ "verdictVersion": z.number(), "goal": z.string(), "inputs": z.array(PairwiseVerdictInput), "winner": z.string(), "confidence": z.number(), "reasoning": z.string(), "generatedAt": z.string() });
async function __evalJudge_impl(goal, recordPathA, recordPathB) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency/eval.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["goal"] = goal;
  __stack.args["recordPathA"] = recordPathA;
  __stack.args["recordPathB"] = recordPathB;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency/eval.agency", scopeName: "evalJudge", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("goal" in __overrides) {
      goal = __overrides["goal"];
      __stack.args["goal"] = goal;
    }
    if ("recordPathA" in __overrides) {
      recordPathA = __overrides["recordPathA"];
      __stack.args["recordPathA"] = recordPathA;
    }
    if ("recordPathB" in __overrides) {
      recordPathB = __overrides["recordPathB"];
      __stack.args["recordPathB"] = recordPathB;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "evalJudge",
            args: {
              goal,
              recordPathA,
              recordPathB
            },
            moduleId: "stdlib/agency/eval.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_evalJudge, {
          type: "positional",
          args: [__stack.args.goal, __stack.args.recordPathA, __stack.args.recordPathB]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function evalJudge threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "evalJudge"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "evalJudge",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "evalJudge",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const evalJudge = __AgencyFunction.create({
  name: "evalJudge",
  module: "stdlib/agency/eval.agency",
  fn: __evalJudge_impl,
  params: [{
    name: "goal",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "recordPathA",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "recordPathB",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "evalJudge",
    description: `Pairwise-judge two eval records against a goal. Returns a structured verdict naming the winner ("A", "B", or "tie"), the judge's confidence as an integer from 0 to 100, and the reasoning the judge produced. Both record paths must point at JSON files in the EvalRecord shape produced by extracting an eval record.

  @param goal - What the judge should grade against (typically a per-input goal from an eval suite)
  @param recordPathA - Path to the first eval record JSON file
  @param recordPathB - Path to the second eval record JSON file`,
    schema: z.object({ "goal": z.string(), "recordPathA": z.string(), "recordPathB": z.string() })
  },
  exported: true
}, __toolRegistry);
const JudgeAggregationPolicy = z.object({ "samples": z.number(), "confidenceThreshold": z.number(), "marginThreshold": z.number(), "positionBias": z.string() });
const VerdictSide = z.object({ "path": z.union([z.string(), z.null()]).optional().default(null), "status": z.string(), "response": z.union([z.string(), z.null()]).optional().default(null), "truncated": z.union([z.boolean(), z.null()]).optional().default(null), "errorMessage": z.union([z.string(), z.null()]).optional().default(null) });
const JudgeSample = z.object({ "winner": z.string(), "confidence": z.number(), "reasoning": z.string(), "order": z.string() });
const InputVerdict = z.object({ "inputId": z.string(), "goal": z.string(), "inputs": z.array(VerdictSide), "winner": z.string(), "confidence": z.number(), "reasoning": z.string(), "samples": z.array(JudgeSample), "generatedAt": z.string() });
const SuiteVerdict = z.object({ "verdictVersion": z.number(), "generatedAt": z.string(), "policy": JudgeAggregationPolicy, "winsA": z.number(), "winsB": z.number(), "ties": z.number(), "winner": z.string(), "perInput": z.array(InputVerdict) });
async function __evalJudgeSuite_impl(runA, runB, inputs, samples = __UNSET, confidenceThreshold = __UNSET, marginThreshold = __UNSET, positionBias = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency/eval.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["runA"] = runA;
  __stack.args["runB"] = runB;
  __stack.args["inputs"] = inputs;
  __stack.args["samples"] = samples === __UNSET ? 3 : samples;
  __stack.args["confidenceThreshold"] = confidenceThreshold === __UNSET ? 50 : confidenceThreshold;
  __stack.args["marginThreshold"] = marginThreshold === __UNSET ? 0 : marginThreshold;
  __stack.args["positionBias"] = positionBias === __UNSET ? `swap` : positionBias;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency/eval.agency", scopeName: "evalJudgeSuite", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("runA" in __overrides) {
      runA = __overrides["runA"];
      __stack.args["runA"] = runA;
    }
    if ("runB" in __overrides) {
      runB = __overrides["runB"];
      __stack.args["runB"] = runB;
    }
    if ("inputs" in __overrides) {
      inputs = __overrides["inputs"];
      __stack.args["inputs"] = inputs;
    }
    if ("samples" in __overrides) {
      samples = __overrides["samples"];
      __stack.args["samples"] = samples;
    }
    if ("confidenceThreshold" in __overrides) {
      confidenceThreshold = __overrides["confidenceThreshold"];
      __stack.args["confidenceThreshold"] = confidenceThreshold;
    }
    if ("marginThreshold" in __overrides) {
      marginThreshold = __overrides["marginThreshold"];
      __stack.args["marginThreshold"] = marginThreshold;
    }
    if ("positionBias" in __overrides) {
      positionBias = __overrides["positionBias"];
      __stack.args["positionBias"] = positionBias;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "evalJudgeSuite",
            args: {
              runA,
              runB,
              inputs,
              samples,
              confidenceThreshold,
              marginThreshold,
              positionBias
            },
            moduleId: "stdlib/agency/eval.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_evalJudgeSuite, {
          type: "positional",
          args: [__stack.args.runA, __stack.args.runB, __stack.args.inputs, __stack.args.samples, __stack.args.confidenceThreshold, __stack.args.marginThreshold, __stack.args.positionBias]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function evalJudgeSuite threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "evalJudgeSuite"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "evalJudgeSuite",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "evalJudgeSuite",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const evalJudgeSuite = __AgencyFunction.create({
  name: "evalJudgeSuite",
  module: "stdlib/agency/eval.agency",
  fn: __evalJudgeSuite_impl,
  params: [{
    name: "runA",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "runB",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "inputs",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "samples",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "confidenceThreshold",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "marginThreshold",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "positionBias",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "evalJudgeSuite",
    description: `Judge two eval run directories by input id and aggregate the results into a suite verdict. Missing or failed input records are handled deterministically without calling the LLM judge; successful inputs are judged pairwise.

  @param runA - Path to the first eval run directory
  @param runB - Path to the second eval run directory
  @param inputs - Input suite defining input ids and goals to compare
  @param samples - Judge samples per input
  @param confidenceThreshold - Minimum input confidence counted as a suite win
  @param marginThreshold - Suite win margin required to avoid an overall tie
  @param positionBias - Whether to swap A/B order across samples to cancel judge position bias`,
    schema: z.object({ "runA": z.string(), "runB": z.string(), "inputs": z.array(Input), "samples": z.number().nullable().describe("Default: 3"), "confidenceThreshold": z.number().nullable().describe("Default: 50"), "marginThreshold": z.number().nullable().describe("Default: 0"), "positionBias": z.union([z.literal("swap"), z.literal("none")]).nullable().describe("Default: swap") })
  },
  exported: true
}, __toolRegistry);
const OptimizeDecision = z.union([z.literal("baseline"), z.literal("accepted"), z.literal("rejected"), z.literal("validation-failed")]);
const OptimizeIterationResult = z.object({ "iter": z.number(), "decision": OptimizeDecision, "agentDir": z.union([z.string(), z.null()]).optional().default(null), "mutationPath": z.union([z.string(), z.null()]).optional().default(null), "evalRunDir": z.union([z.string(), z.null()]).optional().default(null), "verdictPath": z.union([z.string(), z.null()]).optional().default(null), "winsA": z.number(), "winsB": z.number(), "ties": z.number() });
const OptimizeResult = z.object({ "runId": z.string(), "runDir": z.string(), "championIter": z.union([z.number(), z.literal("baseline")]), "championFiles": z.record(z.string(), z.string()), "acceptedCount": z.number(), "rejectedCount": z.number(), "validationFailedCount": z.number(), "iterations": z.array(OptimizeIterationResult) });
async function __optimize_impl(config, entryFile, workingDir = __UNSET, inputs = __UNSET, goal = __UNSET, node = __UNSET, iterations = __UNSET, samples = __UNSET, confidenceThreshold = __UNSET, marginThreshold = __UNSET, runsDir = __UNSET, runId = __UNSET, mutatorModel = __UNSET, writeback = __UNSET, verbosity = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agency/eval.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["config"] = config;
  __stack.args["entryFile"] = entryFile;
  __stack.args["workingDir"] = workingDir === __UNSET ? `.` : workingDir;
  __stack.args["inputs"] = inputs === __UNSET ? [] : inputs;
  __stack.args["goal"] = goal === __UNSET ? `` : goal;
  __stack.args["node"] = node === __UNSET ? `main` : node;
  __stack.args["iterations"] = iterations === __UNSET ? 5 : iterations;
  __stack.args["samples"] = samples === __UNSET ? 3 : samples;
  __stack.args["confidenceThreshold"] = confidenceThreshold === __UNSET ? 50 : confidenceThreshold;
  __stack.args["marginThreshold"] = marginThreshold === __UNSET ? 0 : marginThreshold;
  __stack.args["runsDir"] = runsDir === __UNSET ? `runs/optimize` : runsDir;
  __stack.args["runId"] = runId === __UNSET ? `` : runId;
  __stack.args["mutatorModel"] = mutatorModel === __UNSET ? `` : mutatorModel;
  __stack.args["writeback"] = writeback === __UNSET ? false : writeback;
  __stack.args["verbosity"] = verbosity === __UNSET ? `silent` : verbosity;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agency/eval.agency", scopeName: "optimize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("config" in __overrides) {
      config = __overrides["config"];
      __stack.args["config"] = config;
    }
    if ("entryFile" in __overrides) {
      entryFile = __overrides["entryFile"];
      __stack.args["entryFile"] = entryFile;
    }
    if ("workingDir" in __overrides) {
      workingDir = __overrides["workingDir"];
      __stack.args["workingDir"] = workingDir;
    }
    if ("inputs" in __overrides) {
      inputs = __overrides["inputs"];
      __stack.args["inputs"] = inputs;
    }
    if ("goal" in __overrides) {
      goal = __overrides["goal"];
      __stack.args["goal"] = goal;
    }
    if ("node" in __overrides) {
      node = __overrides["node"];
      __stack.args["node"] = node;
    }
    if ("iterations" in __overrides) {
      iterations = __overrides["iterations"];
      __stack.args["iterations"] = iterations;
    }
    if ("samples" in __overrides) {
      samples = __overrides["samples"];
      __stack.args["samples"] = samples;
    }
    if ("confidenceThreshold" in __overrides) {
      confidenceThreshold = __overrides["confidenceThreshold"];
      __stack.args["confidenceThreshold"] = confidenceThreshold;
    }
    if ("marginThreshold" in __overrides) {
      marginThreshold = __overrides["marginThreshold"];
      __stack.args["marginThreshold"] = marginThreshold;
    }
    if ("runsDir" in __overrides) {
      runsDir = __overrides["runsDir"];
      __stack.args["runsDir"] = runsDir;
    }
    if ("runId" in __overrides) {
      runId = __overrides["runId"];
      __stack.args["runId"] = runId;
    }
    if ("mutatorModel" in __overrides) {
      mutatorModel = __overrides["mutatorModel"];
      __stack.args["mutatorModel"] = mutatorModel;
    }
    if ("writeback" in __overrides) {
      writeback = __overrides["writeback"];
      __stack.args["writeback"] = writeback;
    }
    if ("verbosity" in __overrides) {
      verbosity = __overrides["verbosity"];
      __stack.args["verbosity"] = verbosity;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "optimize",
            args: {
              config,
              entryFile,
              workingDir,
              inputs,
              goal,
              node,
              iterations,
              samples,
              confidenceThreshold,
              marginThreshold,
              runsDir,
              runId,
              mutatorModel,
              writeback,
              verbosity
            },
            moduleId: "stdlib/agency/eval.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_optimize, {
          type: "positional",
          args: [__stack.args.config, __stack.args.entryFile, __stack.args.workingDir, __stack.args.node, __stack.args.inputs, __stack.args.goal, __stack.args.iterations, __stack.args.samples, __stack.args.confidenceThreshold, __stack.args.marginThreshold, __stack.args.runsDir, __stack.args.runId, __stack.args.mutatorModel, __stack.args.writeback, __stack.args.verbosity]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function optimize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "optimize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "optimize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "optimize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const optimize = __AgencyFunction.create({
  name: "optimize",
  module: "stdlib/agency/eval.agency",
  fn: __optimize_impl,
  params: [{
    name: "config",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "entryFile",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "workingDir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "inputs",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "goal",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "node",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "iterations",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "samples",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "confidenceThreshold",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "marginThreshold",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "runsDir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "runId",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "mutatorModel",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "writeback",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "verbosity",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "optimize",
    description: `Optimize declarations marked with the \`optimize\` modifier in an Agency file. For example, \`optimize const prompt = "..."\` marks a string declaration the optimizer may mutate while evaluating candidates against eval inputs. Targets are discovered across the local Agency import tree of entryFile. Provide exactly one of inputs or goal: a goal desugars to a single no-argument input.

  @param config - Agency config to use for eval compilation and LLM calls
  @param entryFile - Agency file containing the eval entrypoint
  @param workingDir - Directory used to resolve a relative entryFile
  @param inputs - Eval inputs to run for each candidate (exclusive with goal)
  @param goal - Single optimization goal (exclusive with inputs)
  @param node - Node to evaluate while optimizing discovered declarations
  @param iterations - Maximum candidate iterations after the baseline
  @param samples - Judge samples per input
  @param confidenceThreshold - Minimum input confidence counted as a suite win
  @param marginThreshold - Suite win margin required to avoid an overall tie
  @param runsDir - Directory where optimization artifacts are written
  @param runId - Run id; generated by default
  @param mutatorModel - Optional model override for proposing mutations
  @param writeback - Write the champion file set back to the source files
  @param verbosity - Progress logging level`,
    schema: z.object({ "config": z.record(z.string(), z.any()), "entryFile": z.string(), "workingDir": z.string().nullable().describe("Default: ."), "inputs": z.array(Input).nullable().describe("Default: []"), "goal": z.string().nullable().describe("Default: "), "node": z.string().nullable().describe("Default: main"), "iterations": z.number().nullable().describe("Default: 5"), "samples": z.number().nullable().describe("Default: 3"), "confidenceThreshold": z.number().nullable().describe("Default: 50"), "marginThreshold": z.number().nullable().describe("Default: 0"), "runsDir": z.string().nullable().describe("Default: runs/optimize"), "runId": z.string().nullable().describe("Default: "), "mutatorModel": z.string().nullable().describe("Default: "), "writeback": z.boolean().nullable().describe("Default: false"), "verbosity": z.union([z.literal("silent"), z.literal("default")]).nullable().describe("Default: silent") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/agency/eval.agency:evalRun": { "1": { "line": 123, "col": 2 }, "2": { "line": 124, "col": 2 }, "3": { "line": 125, "col": 2 }, "4": { "line": 127, "col": 2 }, "5": { "line": 155, "col": 2 }, "4.0": { "line": 128, "col": 4 }, "4.1.0": { "line": 130, "col": 6 }, "4.1.1": { "line": 131, "col": 6 }, "4.1.2": { "line": 138, "col": 6 }, "4.1.3.0": { "line": 140, "col": 8 }, "4.1.3": { "line": 139, "col": 6 }, "4.1.4": { "line": 142, "col": 6 }, "4.1.5": { "line": 143, "col": 6 }, "4.1.6": { "line": 144, "col": 6 }, "4.1.7": { "line": 146, "col": 6 }, "4.1.8": { "line": 147, "col": 6 }, "4.1": { "line": 129, "col": 4 }, "4.2": { "line": 150, "col": 4 } }, "stdlib/agency/eval.agency:evalExtract": { "1": { "line": 197, "col": 2 } }, "stdlib/agency/eval.agency:evalJudge": { "1": { "line": 237, "col": 2 } }, "stdlib/agency/eval.agency:evalJudgeSuite": { "1": { "line": 304, "col": 2 } }, "stdlib/agency/eval.agency:optimize": { "1": { "line": 377, "col": 2 } } };
export {
  EvalRecord,
  EvalRunInputResult,
  EvalRunResult,
  EvalValue,
  Input,
  InputVerdict,
  JudgeAggregationPolicy,
  JudgeSample,
  OptimizeDecision,
  OptimizeIterationResult,
  OptimizeResult,
  PairwiseVerdict,
  PairwiseVerdictInput,
  SuiteVerdict,
  VerdictSide,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  stdin_default as default,
  evalExtract,
  evalJudge,
  evalJudgeSuite,
  evalRun,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  optimize,
  reject,
  respondToInterrupts,
  rewindFrom
};
