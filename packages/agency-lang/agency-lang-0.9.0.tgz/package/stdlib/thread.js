import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { _systemMessage, _userMessage, _assistantMessage, _imageAttachment, _fileAttachment, _attachToReply, _getCost, _getTokens, _getModelCosts, _threadIsNew } from "agency-lang/stdlib-lib/thread.js";
import { _installSlowInputImpl } from "agency-lang/stdlib-lib/builtins.js";
import { _listThreadsRaw, _getThread, _setThreadSummary, _currentThreadId } from "agency-lang/stdlib-lib/threads.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  runPrompt,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  success,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __tryCall,
  __eq,
  __validateType,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __threads,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/thread.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/thread.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/thread.agency");
}
__registerGlobalsInit("stdlib/thread.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/thread.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const AttachmentSource = z.union([z.object({ "kind": z.literal("path"), "path": z.string(), "mimeType": z.union([z.string(), z.null()]).optional().default(null) }), z.object({ "kind": z.literal("url"), "url": z.string(), "mimeType": z.union([z.string(), z.null()]).optional().default(null) }), z.object({ "kind": z.literal("base64"), "base64": z.string(), "mimeType": z.string() })]);
const Attachment = z.union([z.object({ "type": z.literal("image"), "source": AttachmentSource }), z.object({ "type": z.literal("file"), "source": AttachmentSource, "filename": z.union([z.string(), z.null()]).optional().default(null) })]);
async function __systemMessage_impl(msg, label = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["msg"] = msg;
  __stack.args["label"] = label === __UNSET ? `` : label;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "systemMessage", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("msg" in __overrides) {
      msg = __overrides["msg"];
      __stack.args["msg"] = msg;
    }
    if ("label" in __overrides) {
      label = __overrides["label"];
      __stack.args["label"] = label;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "systemMessage",
            args: {
              msg,
              label
            },
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __funcResult = await __call(_systemMessage, {
          type: "positional",
          args: [__stack.args.msg, __stack.args.label]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "systemMessage"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "systemMessage");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function systemMessage threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "systemMessage"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "systemMessage",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "systemMessage",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const systemMessage = __AgencyFunction.create({
  name: "systemMessage",
  module: "stdlib/thread.agency",
  fn: __systemMessage_impl,
  params: [{
    name: "msg",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "label",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "systemMessage",
    description: `Add a system message to the current thread's message history.
  The message becomes part of the conversation context for subsequent
  llm() calls.

  @param msg - The system message content
  @param label - Optional debug label shown in statelog. Never sent to the model.`,
    schema: z.object({ "msg": z.string(), "label": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __userMessage_impl(msg, label = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["msg"] = msg;
  __stack.args["label"] = label === __UNSET ? `` : label;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "userMessage", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("msg" in __overrides) {
      msg = __overrides["msg"];
      __stack.args["msg"] = msg;
    }
    if ("label" in __overrides) {
      label = __overrides["label"];
      __stack.args["label"] = label;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "userMessage",
            args: {
              msg,
              label
            },
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __funcResult = await __call(_userMessage, {
          type: "positional",
          args: [__stack.args.msg, __stack.args.label]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "userMessage"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "userMessage");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function userMessage threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "userMessage"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "userMessage",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "userMessage",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const userMessage = __AgencyFunction.create({
  name: "userMessage",
  module: "stdlib/thread.agency",
  fn: __userMessage_impl,
  params: [{
    name: "msg",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "label",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "userMessage",
    description: `Add a user message to the current thread's message history. Use this
  to seed the conversation with prior user context that wasn't actually
  typed by the user this turn.

  @param msg - The user message content: a string, or an array mixing text strings and attachments.
  @param label - Optional debug label shown in statelog. Never sent to the model.`,
    schema: z.object({ "msg": z.union([z.string(), z.array(z.union([z.string(), Attachment]))]), "label": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __image_impl(source, mimeType = __UNSET, base64 = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __stack.args["mimeType"] = mimeType === __UNSET ? `` : mimeType;
  __stack.args["base64"] = base64 === __UNSET ? false : base64;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "image", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("mimeType" in __overrides) {
      mimeType = __overrides["mimeType"];
      __stack.args["mimeType"] = mimeType;
    }
    if ("base64" in __overrides) {
      base64 = __overrides["base64"];
      __stack.args["base64"] = base64;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "image",
            args: {
              source,
              mimeType,
              base64
            },
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_imageAttachment, {
          type: "positional",
          args: [__stack.args.source, __stack.args.mimeType, __stack.args.base64]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "image");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function image threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "image"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "image",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "image",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const image = __AgencyFunction.create({
  name: "image",
  module: "stdlib/thread.agency",
  fn: __image_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "mimeType",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "base64",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "image",
    description: `Build an image attachment for a multimodal llm() call. The source is
  read, fetched, and MIME-inferred when the message is sent.

  @param source - A local path, an http(s) URL, a data: URI, or raw base64 (with base64: true)
  @param mimeType - Explicit MIME type; overrides inference. Required for raw base64.
  @param base64 - When true, treat \`source\` as raw base64 data.`,
    schema: z.object({ "source": z.string(), "mimeType": z.string().nullable().describe("Default: "), "base64": z.boolean().nullable().describe("Default: false") })
  },
  exported: true
}, __toolRegistry);
async function __file_impl(source, filename = __UNSET, mimeType = __UNSET, base64 = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["source"] = source;
  __stack.args["filename"] = filename === __UNSET ? `` : filename;
  __stack.args["mimeType"] = mimeType === __UNSET ? `` : mimeType;
  __stack.args["base64"] = base64 === __UNSET ? false : base64;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "file", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("mimeType" in __overrides) {
      mimeType = __overrides["mimeType"];
      __stack.args["mimeType"] = mimeType;
    }
    if ("base64" in __overrides) {
      base64 = __overrides["base64"];
      __stack.args["base64"] = base64;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "file",
            args: {
              source,
              filename,
              mimeType,
              base64
            },
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_fileAttachment, {
          type: "positional",
          args: [__stack.args.source, __stack.args.filename, __stack.args.mimeType, __stack.args.base64]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "file");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function file threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "file"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "file",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "file",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const file = __AgencyFunction.create({
  name: "file",
  module: "stdlib/thread.agency",
  fn: __file_impl,
  params: [{
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filename",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "mimeType",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "base64",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "file",
    description: `Build a file (e.g. PDF) attachment for a multimodal llm() call.

  @param source - A local path, an http(s) URL, a data: URI, or raw base64 (with base64: true)
  @param filename - Name shown to the model; defaults to the source basename.
  @param mimeType - Explicit MIME type; overrides inference. Required for raw base64.
  @param base64 - When true, treat \`source\` as raw base64 data.`,
    schema: z.object({ "source": z.string(), "filename": z.string().nullable().describe("Default: "), "mimeType": z.string().nullable().describe("Default: "), "base64": z.boolean().nullable().describe("Default: false") })
  },
  exported: true
}, __toolRegistry);
async function __attachToReply_impl(attachment) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["attachment"] = attachment;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "attachToReply", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("attachment" in __overrides) {
      attachment = __overrides["attachment"];
      __stack.args["attachment"] = attachment;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "attachToReply",
            args: {
              attachment
            },
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __funcResult = await __call(_attachToReply, {
          type: "positional",
          args: [__stack.args.attachment]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "attachToReply"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "attachToReply");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function attachToReply threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "attachToReply"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "attachToReply",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "attachToReply",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const attachToReply = __AgencyFunction.create({
  name: "attachToReply",
  module: "stdlib/thread.agency",
  fn: __attachToReply_impl,
  params: [{
    name: "attachment",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "attachToReply",
    description: `Queue an attachment to be shown to the model after the current tool
  call completes. Only meaningful while running as a tool inside an
  llm() call: the attachment follows the tool's text result as a user
  message the model can see. Prefer path-based sources. Outside a tool
  invocation the attachment is dropped.

  @param attachment - The attachment to show the model`,
    schema: z.object({ "attachment": Attachment })
  },
  exported: true
}, __toolRegistry);
async function __assistantMessage_impl(msg, label = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["msg"] = msg;
  __stack.args["label"] = label === __UNSET ? `` : label;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "assistantMessage", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("msg" in __overrides) {
      msg = __overrides["msg"];
      __stack.args["msg"] = msg;
    }
    if ("label" in __overrides) {
      label = __overrides["label"];
      __stack.args["label"] = label;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "assistantMessage",
            args: {
              msg,
              label
            },
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __funcResult = await __call(_assistantMessage, {
          type: "positional",
          args: [__stack.args.msg, __stack.args.label]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "assistantMessage"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "assistantMessage");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function assistantMessage threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "assistantMessage"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "assistantMessage",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "assistantMessage",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const assistantMessage = __AgencyFunction.create({
  name: "assistantMessage",
  module: "stdlib/thread.agency",
  fn: __assistantMessage_impl,
  params: [{
    name: "msg",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "label",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "assistantMessage",
    description: `Add an assistant message to the current thread's message history.
  Use this to inject prior assistant turns when reconstructing a
  conversation programmatically.

  @param msg - The assistant message content
  @param label - Optional debug label shown in statelog. Never sent to the model.`,
    schema: z.object({ "msg": z.string(), "label": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __getCost_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "getCost", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getCost",
            args: {},
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_getCost, {
          type: "positional",
          args: []
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "getCost");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getCost threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getCost"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getCost",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getCost",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getCost = __AgencyFunction.create({
  name: "getCost",
  module: "stdlib/thread.agency",
  fn: __getCost_impl,
  params: [],
  toolDefinition: {
    name: "getCost",
    description: `Return the cumulative cost in USD of all LLM calls contributing to the
  current execution branch.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __threadIsNew_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "threadIsNew", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "threadIsNew",
            args: {},
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_threadIsNew, {
          type: "positional",
          args: []
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "threadIsNew");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function threadIsNew threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "threadIsNew"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "threadIsNew",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "threadIsNew",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const threadIsNew = __AgencyFunction.create({
  name: "threadIsNew",
  module: "stdlib/thread.agency",
  fn: __threadIsNew_impl,
  params: [],
  toolDefinition: {
    name: "threadIsNew",
    description: `True when the current message thread has no messages yet. Use it inside a
  thread block to send a system prompt only on the first entry.`,
    schema: z.object({})
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __getTokens_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "getTokens", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getTokens",
            args: {},
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_getTokens, {
          type: "positional",
          args: []
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "getTokens");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getTokens threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getTokens"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getTokens",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getTokens",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getTokens = __AgencyFunction.create({
  name: "getTokens",
  module: "stdlib/thread.agency",
  fn: __getTokens_impl,
  params: [],
  toolDefinition: {
    name: "getTokens",
    description: `Return the cumulative token count for the current execution branch.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
const ModelCost = z.object({ "model": z.string(), "inputTokens": z.number(), "outputTokens": z.number(), "cost": z.number() });
async function __getModelCosts_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "getModelCosts", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getModelCosts",
            args: {},
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_getModelCosts, {
          type: "positional",
          args: []
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "getModelCosts");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getModelCosts threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getModelCosts"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getModelCosts",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getModelCosts",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getModelCosts = __AgencyFunction.create({
  name: "getModelCosts",
  module: "stdlib/thread.agency",
  fn: __getModelCosts_impl,
  params: [],
  toolDefinition: {
    name: "getModelCosts",
    description: `Return a per-model breakdown of cumulative LLM usage across the whole
  process, one entry per model that has been called, sorted by cost
  descending.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
const GuardFailureData = z.object({ "type": z.string(), "label": z.union([z.string(), z.null()]).optional().default(null), "maxCost": z.union([z.number(), z.null()]).optional().default(null), "actualCost": z.union([z.number(), z.null()]).optional().default(null), "maxTime": z.union([z.number(), z.null()]).optional().default(null), "actualTime": z.union([z.number(), z.null()]).optional().default(null) });
async function ___installSlowInput_impl(delayMs, answer) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["delayMs"] = delayMs;
  __stack.args["answer"] = answer;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "_installSlowInput", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("delayMs" in __overrides) {
      delayMs = __overrides["delayMs"];
      __stack.args["delayMs"] = delayMs;
    }
    if ("answer" in __overrides) {
      answer = __overrides["answer"];
      __stack.args["answer"] = answer;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_installSlowInput",
            args: {
              delayMs,
              answer
            },
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __funcResult = await __call(_installSlowInputImpl, {
          type: "positional",
          args: [__stack.args.delayMs, __stack.args.answer]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_installSlowInput"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_installSlowInput");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _installSlowInput threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_installSlowInput"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_installSlowInput",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_installSlowInput",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _installSlowInput = __AgencyFunction.create({
  name: "_installSlowInput",
  module: "stdlib/thread.agency",
  fn: ___installSlowInput_impl,
  params: [{
    name: "delayMs",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "answer",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_installSlowInput",
    description: `Test-only: make input() resolve with \`answer\` after \`delayMs\` milliseconds.

  @param delayMs - How long the simulated human takes to answer.
  @param answer - The answer input() resolves with.`,
    schema: z.object({ "delayMs": z.number(), "answer": z.string() })
  },
  exported: false
}, __toolRegistry);
const ThreadMessage = z.object({ "role": z.string(), "content": z.string() });
const ThreadInfo = z.object({ "id": z.string(), "label": z.union([z.string(), z.null()]).optional().default(null), "summary": z.union([z.string(), z.null()]).optional().default(null), "parentId": z.union([z.string(), z.null()]).optional().default(null), "threadType": z.string(), "messageCount": z.number(), "isActive": z.boolean() });
const SummaryResult = z.object({ "summary": z.string() });
async function __summarize_impl(messages) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["messages"] = messages;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "summarize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("messages" in __overrides) {
      messages = __overrides["messages"];
      __stack.args["messages"] = messages;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "summarize",
            args: {
              messages
            },
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.transcript = ``;
      });
      await runner.loop(3, async () => __stack.args.messages, async (m, _, runner2) => {
        await runner2.ifElse(0, [
          {
            condition: async () => !__eq(m.role, `system`) && !__eq(m.role, `developer`),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.transcript = __stack.locals.transcript + `[${m.role}] ${m.content}
`;
              });
            }
          }
        ]);
      });
      await runner.ifElse(4, [
        {
          condition: async () => __eq(__stack.locals.transcript, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(``);
              return;
            });
          }
        }
      ]);
      await runner.step(5, async (runner2) => {
        __stack.locals.summary = ``;
      });
      await runner.thread(6, "create", async () => ({ hidden: true }), async (runner2) => {
        await runner2.step(0, async (runner3) => {
        });
        await runner2.step(1, async (runner3) => {
          __self.__removedTools = __self.__removedTools || [];
          __stack.locals.result = await runPrompt({
            prompt: `Summarize this conversation in 1-2 sentences:
${__stack.locals.transcript}`,
            messages: __threads().getOrCreateActive(),
            responseFormat: z.object({
              response: SummaryResult
            }),
            clientConfig: {
              "maxTokens": 256
            },
            draftSchema: z.string(),
            maxToolCallRounds: 10,
            removedTools: __self.__removedTools,
            destructiveSink: __self,
            checkpointInfo: runner3.getCheckpointInfo()
          });
          if (hasInterrupts(__stack.locals.result)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.result);
            return;
          }
          __stack.locals.result = __validateType(__stack.locals.result, SummaryResult);
        });
        await runner2.ifElse(2, [
          {
            condition: async () => await isSuccess(__stack.locals.result),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.value = __stack.locals.result.value;
              });
              await runner3.step(1, async (runner4) => {
                __stack.locals.summary = __stack.locals.value.summary;
              });
            }
          }
        ]);
      });
      await runner.step(7, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.summary);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "summarize");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function summarize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "summarize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "summarize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "summarize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const summarize = __AgencyFunction.create({
  name: "summarize",
  module: "stdlib/thread.agency",
  fn: __summarize_impl,
  params: [{
    name: "messages",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "summarize",
    description: `One-shot LLM summarization used by the lazy summarize path.
  Wrapped in a \`thread {}\` block so the summarizer prompt runs on
  an isolated message history and doesn't pollute the agent's main
  conversation. Uses structured output so the returned text comes
  back on a known field instead of free-form completion text.

  @param messages - The thread's messages to summarize`,
    schema: z.object({ "messages": z.array(ThreadMessage) })
  },
  exported: false
}, __toolRegistry);
async function __summaryFor_impl(id, existing, messages) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["id"] = id;
  __stack.args["existing"] = existing;
  __stack.args["messages"] = messages;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "summaryFor", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("id" in __overrides) {
      id = __overrides["id"];
      __stack.args["id"] = id;
    }
    if ("existing" in __overrides) {
      existing = __overrides["existing"];
      __stack.args["existing"] = existing;
    }
    if ("messages" in __overrides) {
      messages = __overrides["messages"];
      __stack.args["messages"] = messages;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "summaryFor",
            args: {
              id,
              existing,
              messages
            },
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => !__eq(__stack.args.existing, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.args.existing);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __stack.locals.s = await __call(summarize, {
          type: "positional",
          args: [__stack.args.messages]
        });
        if (hasInterrupts(__stack.locals.s)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.s);
          return;
        }
        if (isAborted(__stack.locals.s)) {
          runner2.halt(__stack.locals.s.carryThrough(__stack, "summaryFor"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        const __funcResult = await __call(_setThreadSummary, {
          type: "positional",
          args: [__stack.args.id, __stack.locals.s]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "summaryFor"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.s);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "summaryFor");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function summaryFor threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "summaryFor"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "summaryFor",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "summaryFor",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const summaryFor = __AgencyFunction.create({
  name: "summaryFor",
  module: "stdlib/thread.agency",
  fn: __summaryFor_impl,
  params: [{
    name: "id",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "existing",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "messages",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "summaryFor",
    description: "No description provided.",
    schema: z.object({ "id": z.string(), "existing": z.union([z.string(), z.null()]), "messages": z.array(ThreadMessage) })
  },
  exported: false
}, __toolRegistry);
async function __listThreads_impl(lazySummarize = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["lazySummarize"] = lazySummarize === __UNSET ? true : lazySummarize;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "listThreads", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("lazySummarize" in __overrides) {
      lazySummarize = __overrides["lazySummarize"];
      __stack.args["lazySummarize"] = lazySummarize;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "listThreads",
            args: {
              lazySummarize
            },
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.raw = await __tryCall(async () => await __call(_listThreadsRaw, {
          type: "positional",
          args: []
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "listThreads",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.raw)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.raw);
          return;
        }
        if (isAborted(__stack.locals.raw)) {
          runner2.halt(__stack.locals.raw.carryThrough(__stack, "listThreads"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.raw),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.locals.raw);
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.out = [];
      });
      await runner.loop(4, async () => __stack.locals.raw.value, async (t, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.summary = null;
        });
        await runner2.ifElse(1, [
          {
            condition: async () => __stack.args.lazySummarize,
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
              });
              await runner3.ifElse(1, [
                {
                  condition: async () => t.isActive,
                  body: async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      __stack.locals.summary = t.summary;
                    });
                  }
                }
              ], async (runner4) => {
                await runner4.step(1, async (runner5) => {
                  __stack.locals.summary = await __call(summaryFor, {
                    type: "positional",
                    args: [t.id, t.summary, t.messages]
                  });
                  if (hasInterrupts(__stack.locals.summary)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__stack.locals.summary);
                    return;
                  }
                  if (isAborted(__stack.locals.summary)) {
                    runner5.halt(__stack.locals.summary.carryThrough(__stack, "listThreads"));
                    return;
                  }
                });
              });
            }
          }
        ], async (runner3) => {
          await runner3.step(2, async (runner4) => {
          });
          await runner3.ifElse(3, [
            {
              condition: async () => !__eq(t.summary, null),
              body: async (runner4) => {
                await runner4.step(0, async (runner5) => {
                  __stack.locals.summary = t.summary;
                });
              }
            },
            {
              condition: async () => !__eq(t.label, null),
              body: async (runner4) => {
                await runner4.step(1, async (runner5) => {
                  __stack.locals.summary = t.label;
                });
              }
            }
          ], async (runner4) => {
            await runner4.step(2, async (runner5) => {
              __stack.locals.summary = ``;
            });
          });
        });
        await runner2.step(2, async (runner3) => {
          await __callMethod(__stack.locals.out, "push", {
            type: "positional",
            args: [{
              "id": t.id,
              "label": t.label,
              "summary": __stack.locals.summary,
              "parentId": t.parentId,
              "threadType": t.threadType,
              "messageCount": t.messageCount,
              "isActive": t.isActive
            }]
          });
        });
      });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await success(__stack.locals.out));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "listThreads");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function listThreads threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "listThreads"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "listThreads",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "listThreads",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const listThreads = __AgencyFunction.create({
  name: "listThreads",
  module: "stdlib/thread.agency",
  fn: __listThreads_impl,
  params: [{
    name: "lazySummarize",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "listThreads",
    description: `Return every thread in the current run, including the active one, as a
  \`Result\`: success holds \`ThreadInfo[]\`, failure holds the error (e.g.
  called outside an Agency frame). Each closed thread carries a short
  summary; the active thread is not summarized.

  @param lazySummarize - When true (default), generate a summary
                         on-demand for any closed thread that lacks one.
                         When false, skip the LLM call and fall back to
                         the thread's label (or \`""\`).`,
    schema: z.object({ "lazySummarize": z.boolean().nullable().describe("Default: true") })
  },
  exported: true
}, __toolRegistry);
async function __currentThreadId_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "currentThreadId", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "currentThreadId",
            args: {},
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_currentThreadId, {
          type: "positional",
          args: []
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "currentThreadId");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function currentThreadId threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "currentThreadId"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "currentThreadId",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "currentThreadId",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const currentThreadId = __AgencyFunction.create({
  name: "currentThreadId",
  module: "stdlib/thread.agency",
  fn: __currentThreadId_impl,
  params: [],
  toolDefinition: {
    name: "currentThreadId",
    description: `Slug-form id of the active thread (e.g. "t3"), or \`""\` outside any
  runtime frame. Useful with \`thread(continue: id)\` when you want to
  capture a thread's id at the moment it was active so you can
  resume it later.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __getThread_impl(id, offset = __UNSET, limit = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/thread.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["id"] = id;
  __stack.args["offset"] = offset === __UNSET ? 0 : offset;
  __stack.args["limit"] = limit === __UNSET ? 50 : limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/thread.agency", scopeName: "getThread", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("id" in __overrides) {
      id = __overrides["id"];
      __stack.args["id"] = id;
    }
    if ("offset" in __overrides) {
      offset = __overrides["offset"];
      __stack.args["offset"] = offset;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getThread",
            args: {
              id,
              offset,
              limit
            },
            moduleId: "stdlib/thread.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_getThread, {
          type: "positional",
          args: [__stack.args.id, __stack.args.offset, __stack.args.limit]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "getThread",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "getThread");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getThread threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getThread"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getThread",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getThread",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getThread = __AgencyFunction.create({
  name: "getThread",
  module: "stdlib/thread.agency",
  fn: __getThread_impl,
  params: [{
    name: "id",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "offset",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "getThread",
    description: `Read a slice of a thread's messages. Returns success holding \`[]\`
  for an unknown id; returns failure when called outside an Agency
  frame.

  Pagination: \`offset\` is 0-indexed; \`limit\` defaults to 50. Pass
  larger explicit values for full-thread reads.

  Returns a \`Result\` \u2014 success holds \`ThreadMessage[]\`. See
  [error handling](https://agency-lang.com/guide/error-handling).

  @param id - Thread slug (e.g. "t1") from \`listThreads()\`
  @param offset - 0-indexed start of the message slice
  @param limit - Maximum number of messages to return`,
    schema: z.object({ "id": z.string(), "offset": z.number().nullable().describe("Default: 0"), "limit": z.number().nullable().describe("Default: 50") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/thread.agency:systemMessage": { "1": { "line": 71, "col": 2 } }, "stdlib/thread.agency:userMessage": { "1": { "line": 83, "col": 2 } }, "stdlib/thread.agency:image": { "1": { "line": 99, "col": 2 } }, "stdlib/thread.agency:file": { "1": { "line": 116, "col": 2 } }, "stdlib/thread.agency:attachToReply": { "1": { "line": 129, "col": 2 } }, "stdlib/thread.agency:assistantMessage": { "1": { "line": 141, "col": 2 } }, "stdlib/thread.agency:getCost": { "1": { "line": 154, "col": 2 } }, "stdlib/thread.agency:threadIsNew": { "1": { "line": 162, "col": 2 } }, "stdlib/thread.agency:getTokens": { "1": { "line": 169, "col": 2 } }, "stdlib/thread.agency:getModelCosts": { "1": { "line": 188, "col": 2 } }, "stdlib/thread.agency:_installSlowInput": { "1": { "line": 211, "col": 2 } }, "stdlib/thread.agency:summarize": { "2": { "line": 248, "col": 2 }, "3": { "line": 249, "col": 2 }, "4": { "line": 254, "col": 2 }, "5": { "line": 257, "col": 2 }, "6": { "line": 258, "col": 2 }, "7": { "line": 267, "col": 2 }, "3.0.0": { "line": 251, "col": 6 }, "3.0": { "line": 250, "col": 4 }, "4.0": { "line": 255, "col": 4 }, "6.1": { "line": 262, "col": 4 }, "6.2.0": { "line": 263, "col": 4 }, "6.2.1": { "line": 264, "col": 6 }, "6.2": { "line": 263, "col": 4 } }, "stdlib/thread.agency:summaryFor": { "1": { "line": 277, "col": 2 }, "2": { "line": 280, "col": 2 }, "3": { "line": 281, "col": 2 }, "4": { "line": 282, "col": 2 }, "1.0": { "line": 278, "col": 4 } }, "stdlib/thread.agency:listThreads": { "1": { "line": 303, "col": 2 }, "2": { "line": 304, "col": 2 }, "3": { "line": 307, "col": 2 }, "4": { "line": 308, "col": 2 }, "5": { "line": 341, "col": 2 }, "2.0": { "line": 305, "col": 4 }, "4.0": { "line": 309, "col": 4 }, "4.1.1.0": { "line": 315, "col": 8 }, "4.1.1.1": { "line": 317, "col": 8 }, "4.1.1": { "line": 314, "col": 6 }, "4.1.3.0": { "line": 324, "col": 8 }, "4.1.3.1": { "line": 326, "col": 8 }, "4.1.3.2": { "line": 328, "col": 8 }, "4.1.3": { "line": 323, "col": 6 }, "4.1": { "line": 310, "col": 4 }, "4.2": { "line": 331, "col": 4 } }, "stdlib/thread.agency:currentThreadId": { "1": { "line": 351, "col": 2 } }, "stdlib/thread.agency:getThread": { "1": { "line": 370, "col": 2 } } };
export {
  Attachment,
  AttachmentSource,
  GuardFailureData,
  ModelCost,
  ThreadInfo,
  ThreadMessage,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  _installSlowInput,
  approve,
  assistantMessage,
  attachToReply,
  currentThreadId,
  stdin_default as default,
  file,
  getCost,
  getModelCosts,
  getThread,
  getTokens,
  hasInterrupts,
  image,
  interrupt,
  isDebugger,
  isInterrupt,
  listThreads,
  reject,
  respondToInterrupts,
  rewindFrom,
  summarize,
  summaryFor,
  systemMessage,
  threadIsNew,
  userMessage
};
