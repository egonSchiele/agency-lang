import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, mapWithIndex, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { filter, map } from "agency-lang/stdlib/array.js";
import { entries } from "agency-lang/stdlib/object.js";
import { _termWidth } from "agency-lang/stdlib-lib/cli.js";
import { _isTTY } from "agency-lang/stdlib-lib/system.js";
import { _runLoop, _runReplLoop, _renderOnce, _readKey, _beginSubmit, _elapsedSeconds, _spinnerFrame, _nowMs, _triggerRender } from "agency-lang/stdlib-lib/ui.js";
import { _openChoicePrompt, _peekPendingChoiceRequest, _resolveChoice, _cancelChoice, _peekReplExitSignal, _promptsSelect, _promptsAutocomplete, _promptsText, _promptsConfirm } from "agency-lang/stdlib-lib/ui.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { color, nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/ui.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(filter);
__registerTool(map);
__registerTool(entries);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/ui.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/ui.agency");
  __ctx.globals.set("stdlib/ui.agency", "_PALETTE_ROWS", 5);
  __ctx.globals.set("stdlib/ui.agency", "_activeRepl", null);
  __ctx.globals.set("stdlib/ui.agency", "_CHOICE_ROWS", 15);
  __ctx.globals.set("stdlib/ui.agency", "_INPUT_MAX_ROWS", 6);
}
__registerGlobalsInit("stdlib/ui.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/ui.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const Element = z.object({ "type": z.string(), "style": z.union([z.any(), z.null()]).optional().default(null), "content": z.union([z.string(), z.null()]).optional().default(null), "children": z.union([z.array(z.any()), z.null()]).optional().default(null), "items": z.union([z.array(z.string()), z.null()]).optional().default(null), "selectedIndex": z.union([z.number(), z.null()]).optional().default(null), "value": z.union([z.string(), z.null()]).optional().default(null) });
const KeyEvent = z.object({ "key": z.string(), "shift": z.union([z.boolean(), z.null()]).optional().default(null), "ctrl": z.union([z.boolean(), z.null()]).optional().default(null), "text": z.union([z.string(), z.null()]).optional().default(null) });
const Builder = z.object({ "row": z.any(), "column": z.any(), "box": z.any(), "line": z.any(), "text": z.any(), "list": z.any(), "textInput": z.any() });
async function __text_impl(content) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["content"] = content;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "text", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("content" in __overrides) {
      content = __overrides["content"];
      __stack.args["content"] = content;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "text",
            args: {
              content
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `text`,
          "content": __stack.args.content
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "text");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function text threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "text"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "text",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "text",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const text = __AgencyFunction.create({
  name: "text",
  module: "stdlib/ui.agency",
  fn: __text_impl,
  params: [{
    name: "content",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "text",
    description: `Build a plain text element. It carries no layout sizing of its own,
  so nest it inside a container to position it.

  @param content - The text to render`,
    schema: z.object({ "content": z.string() })
  },
  exported: true
}, __toolRegistry);
async function ___setStyleIfSet_impl(style, key, value) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["style"] = style;
  __stack.args["key"] = key;
  __stack.args["value"] = value;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_setStyleIfSet", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("style" in __overrides) {
      style = __overrides["style"];
      __stack.args["style"] = style;
    }
    if ("key" in __overrides) {
      key = __overrides["key"];
      __stack.args["key"] = key;
    }
    if ("value" in __overrides) {
      value = __overrides["value"];
      __stack.args["value"] = value;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_setStyleIfSet",
            args: {
              style,
              key,
              value
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.value, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(void 0);
              return;
            });
          }
        }
      ]);
      await runner.ifElse(2, [
        {
          condition: async () => __eq(__stack.args.value, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(void 0);
              return;
            });
          }
        }
      ]);
      await runner.ifElse(3, [
        {
          condition: async () => __eq(__stack.args.value, false),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(void 0);
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __stack.args.style[__stack.args.key] = __stack.args.value;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_setStyleIfSet");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _setStyleIfSet threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_setStyleIfSet"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_setStyleIfSet",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_setStyleIfSet",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _setStyleIfSet = __AgencyFunction.create({
  name: "_setStyleIfSet",
  module: "stdlib/ui.agency",
  fn: ___setStyleIfSet_impl,
  params: [{
    name: "style",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "key",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "value",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "_setStyleIfSet",
    description: "No description provided.",
    schema: z.object({ "style": z.any(), "key": z.string(), "value": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __line_impl(content, flex = __UNSET, width = __UNSET, height = __UNSET, fg = __UNSET, bg = __UNSET, bold = __UNSET, fill = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["content"] = content;
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["fg"] = fg === __UNSET ? `` : fg;
  __stack.args["bg"] = bg === __UNSET ? `` : bg;
  __stack.args["bold"] = bold === __UNSET ? false : bold;
  __stack.args["fill"] = fill === __UNSET ? `` : fill;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "line", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("content" in __overrides) {
      content = __overrides["content"];
      __stack.args["content"] = content;
    }
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("fg" in __overrides) {
      fg = __overrides["fg"];
      __stack.args["fg"] = fg;
    }
    if ("bg" in __overrides) {
      bg = __overrides["bg"];
      __stack.args["bg"] = bg;
    }
    if ("bold" in __overrides) {
      bold = __overrides["bold"];
      __stack.args["bold"] = bold;
    }
    if ("fill" in __overrides) {
      fill = __overrides["fill"];
      __stack.args["fill"] = fill;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "line",
            args: {
              content,
              flex,
              width,
              height,
              fg,
              bg,
              bold,
              fill
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.h = 1;
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.height, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.h = __stack.args.height;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.style = {
          "height": __stack.locals.h
        };
      });
      await runner.step(4, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `flex`, __stack.args.flex]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "line"));
          return;
        }
      });
      await runner.step(5, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `width`, __stack.args.width]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "line"));
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `fg`, __stack.args.fg]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "line"));
          return;
        }
      });
      await runner.step(7, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `bg`, __stack.args.bg]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "line"));
          return;
        }
      });
      await runner.step(8, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `bold`, __stack.args.bold]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "line"));
          return;
        }
      });
      await runner.step(9, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `fill`, __stack.args.fill]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "line"));
          return;
        }
      });
      await runner.step(10, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `text`,
          "content": __stack.args.content,
          "style": __stack.locals.style
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "line");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function line threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "line"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "line",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "line",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const line = __AgencyFunction.create({
  name: "line",
  module: "stdlib/ui.agency",
  fn: __line_impl,
  params: [{
    name: "content",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bold",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fill",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "line",
    description: `Build a single-line text element (height 1) so it does not stretch
  vertically inside a container. Style and layout fields merge on top
  of that default.

  Set \`fill\` to a single character (e.g. \`"\u2500"\`) to repeat that
  character across the unused width, turning an empty-content line
  into a horizontal rule.

  @param content - The text to render
  @param flex - Flex grow factor; omit for natural width
  @param width - Fixed character width; omit for natural width
  @param height - Override the default height of 1
  @param fg - Foreground color (named or hex like "#fff")
  @param bg - Background color (named or hex like "#000")
  @param bold - Render the text bold
  @param fill - Character used to pad unused cells (default: space)`,
    schema: z.object({ "content": z.string(), "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "fg": z.string().nullable().describe("Default: "), "bg": z.string().nullable().describe("Default: "), "bold": z.boolean().nullable().describe("Default: false"), "fill": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __list_impl(items, selectedIndex = __UNSET, flex = __UNSET, width = __UNSET, height = __UNSET, border = __UNSET, borderColor = __UNSET, visible = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["items"] = items;
  __stack.args["selectedIndex"] = selectedIndex === __UNSET ? 0 : selectedIndex;
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["border"] = border === __UNSET ? false : border;
  __stack.args["borderColor"] = borderColor === __UNSET ? `` : borderColor;
  __stack.args["visible"] = visible === __UNSET ? true : visible;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "list", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("items" in __overrides) {
      items = __overrides["items"];
      __stack.args["items"] = items;
    }
    if ("selectedIndex" in __overrides) {
      selectedIndex = __overrides["selectedIndex"];
      __stack.args["selectedIndex"] = selectedIndex;
    }
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("border" in __overrides) {
      border = __overrides["border"];
      __stack.args["border"] = border;
    }
    if ("borderColor" in __overrides) {
      borderColor = __overrides["borderColor"];
      __stack.args["borderColor"] = borderColor;
    }
    if ("visible" in __overrides) {
      visible = __overrides["visible"];
      __stack.args["visible"] = visible;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "list",
            args: {
              items,
              selectedIndex,
              flex,
              width,
              height,
              border,
              borderColor,
              visible
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.style = {};
      });
      await runner.step(2, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `flex`, __stack.args.flex]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "list"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `width`, __stack.args.width]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "list"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `height`, __stack.args.height]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "list"));
          return;
        }
      });
      await runner.step(5, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `border`, __stack.args.border]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "list"));
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `borderColor`, __stack.args.borderColor]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "list"));
          return;
        }
      });
      await runner.ifElse(7, [
        {
          condition: async () => !__stack.args.visible,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.style.visible = false;
            });
          }
        }
      ]);
      await runner.step(8, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `list`,
          "style": __stack.locals.style,
          "items": __stack.args.items,
          "selectedIndex": __stack.args.selectedIndex
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "list");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function list threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "list"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "list",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "list",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const list = __AgencyFunction.create({
  name: "list",
  module: "stdlib/ui.agency",
  fn: __list_impl,
  params: [{
    name: "items",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "selectedIndex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "border",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "visible",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "list",
    description: `Build a scrollable selectable list. \`selectedIndex\` highlights one
  row, and the renderer clamps out-of-range values. When \`height\`
  is smaller than \`items.length\`, the list auto-scrolls so the
  selected row stays visible.

  @param items - The strings to display, one per row
  @param selectedIndex - 0-based row to highlight (default 0)
  @param flex - Flex grow factor when nested inside a column/row
  @param width - Fixed character width
  @param height - Fixed row count (otherwise uses available space)
  @param border - Draw a single-line border around the list
  @param borderColor - Color name or hex for the border
  @param visible - Set false to render the element as zero-height`,
    schema: z.object({ "items": z.array(z.string()), "selectedIndex": z.number().nullable().describe("Default: 0"), "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "border": z.boolean().nullable().describe("Default: false"), "borderColor": z.string().nullable().describe("Default: "), "visible": z.boolean().nullable().describe("Default: true") })
  },
  exported: true
}, __toolRegistry);
async function __textInput_impl(value = __UNSET, flex = __UNSET, width = __UNSET, height = __UNSET, fg = __UNSET, bg = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["value"] = value === __UNSET ? `` : value;
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["fg"] = fg === __UNSET ? `` : fg;
  __stack.args["bg"] = bg === __UNSET ? `` : bg;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "textInput", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("value" in __overrides) {
      value = __overrides["value"];
      __stack.args["value"] = value;
    }
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("fg" in __overrides) {
      fg = __overrides["fg"];
      __stack.args["fg"] = fg;
    }
    if ("bg" in __overrides) {
      bg = __overrides["bg"];
      __stack.args["bg"] = bg;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "textInput",
            args: {
              value,
              flex,
              width,
              height,
              fg,
              bg
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.style = {};
      });
      await runner.step(2, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `flex`, __stack.args.flex]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "textInput"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `width`, __stack.args.width]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "textInput"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `height`, __stack.args.height]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "textInput"));
          return;
        }
      });
      await runner.step(5, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `fg`, __stack.args.fg]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "textInput"));
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `bg`, __stack.args.bg]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "textInput"));
          return;
        }
      });
      await runner.step(7, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `textInput`,
          "style": __stack.locals.style,
          "value": __stack.args.value
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "textInput");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function textInput threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "textInput"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "textInput",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "textInput",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const textInput = __AgencyFunction.create({
  name: "textInput",
  module: "stdlib/ui.agency",
  fn: __textInput_impl,
  params: [{
    name: "value",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "textInput",
    description: `Build a single-line text input. The renderer displays \`value\` with
  a cursor. The caller owns key handling: append printable characters
  and process backspace / enter in the loop's key handler.

  @param value - Current contents of the buffer
  @param flex - Flex grow factor (typical: 1 inside a row)
  @param width - Fixed character width (omit to flex)
  @param height - Fixed row count (defaults to 1)
  @param fg - Foreground color (named or hex)
  @param bg - Background color (named or hex)`,
    schema: z.object({ "value": z.string().nullable().describe("Default: "), "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "fg": z.string().nullable().describe("Default: "), "bg": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function ___mkBoxStyle_impl(flexDirection, flex = __UNSET, width = __UNSET, height = __UNSET, padding = __UNSET, border = __UNSET, borderColor = __UNSET, label = __UNSET, bg = __UNSET, fg = __UNSET, visible = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["flexDirection"] = flexDirection;
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["padding"] = padding === __UNSET ? null : padding;
  __stack.args["border"] = border === __UNSET ? false : border;
  __stack.args["borderColor"] = borderColor === __UNSET ? `` : borderColor;
  __stack.args["label"] = label === __UNSET ? `` : label;
  __stack.args["bg"] = bg === __UNSET ? `` : bg;
  __stack.args["fg"] = fg === __UNSET ? `` : fg;
  __stack.args["visible"] = visible === __UNSET ? true : visible;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_mkBoxStyle", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("flexDirection" in __overrides) {
      flexDirection = __overrides["flexDirection"];
      __stack.args["flexDirection"] = flexDirection;
    }
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("padding" in __overrides) {
      padding = __overrides["padding"];
      __stack.args["padding"] = padding;
    }
    if ("border" in __overrides) {
      border = __overrides["border"];
      __stack.args["border"] = border;
    }
    if ("borderColor" in __overrides) {
      borderColor = __overrides["borderColor"];
      __stack.args["borderColor"] = borderColor;
    }
    if ("label" in __overrides) {
      label = __overrides["label"];
      __stack.args["label"] = label;
    }
    if ("bg" in __overrides) {
      bg = __overrides["bg"];
      __stack.args["bg"] = bg;
    }
    if ("fg" in __overrides) {
      fg = __overrides["fg"];
      __stack.args["fg"] = fg;
    }
    if ("visible" in __overrides) {
      visible = __overrides["visible"];
      __stack.args["visible"] = visible;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_mkBoxStyle",
            args: {
              flexDirection,
              flex,
              width,
              height,
              padding,
              border,
              borderColor,
              label,
              bg,
              fg,
              visible
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.style = {};
      });
      await runner.step(2, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `flexDirection`, __stack.args.flexDirection]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_mkBoxStyle"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `flex`, __stack.args.flex]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_mkBoxStyle"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `width`, __stack.args.width]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_mkBoxStyle"));
          return;
        }
      });
      await runner.step(5, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `height`, __stack.args.height]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_mkBoxStyle"));
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `padding`, __stack.args.padding]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_mkBoxStyle"));
          return;
        }
      });
      await runner.step(7, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `border`, __stack.args.border]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_mkBoxStyle"));
          return;
        }
      });
      await runner.step(8, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `borderColor`, __stack.args.borderColor]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_mkBoxStyle"));
          return;
        }
      });
      await runner.step(9, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `label`, __stack.args.label]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_mkBoxStyle"));
          return;
        }
      });
      await runner.step(10, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `bg`, __stack.args.bg]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_mkBoxStyle"));
          return;
        }
      });
      await runner.step(11, async (runner2) => {
        const __funcResult = await __call(_setStyleIfSet, {
          type: "positional",
          args: [__stack.locals.style, `fg`, __stack.args.fg]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_mkBoxStyle"));
          return;
        }
      });
      await runner.ifElse(12, [
        {
          condition: async () => !__stack.args.visible,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.style.visible = false;
            });
          }
        }
      ]);
      await runner.step(13, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.style);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_mkBoxStyle");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _mkBoxStyle threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_mkBoxStyle"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_mkBoxStyle",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_mkBoxStyle",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _mkBoxStyle = __AgencyFunction.create({
  name: "_mkBoxStyle",
  module: "stdlib/ui.agency",
  fn: ___mkBoxStyle_impl,
  params: [{
    name: "flexDirection",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "padding",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "border",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "label",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "visible",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_mkBoxStyle",
    description: "No description provided.",
    schema: z.object({ "flexDirection": z.string(), "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "padding": z.number().nullable().describe("Default: null"), "border": z.boolean().nullable().describe("Default: false"), "borderColor": z.string().nullable().describe("Default: "), "label": z.string().nullable().describe("Default: "), "bg": z.string().nullable().describe("Default: "), "fg": z.string().nullable().describe("Default: "), "visible": z.boolean().nullable().describe("Default: true") })
  },
  exported: false
}, __toolRegistry);
async function ___makeBuilder_impl(kids) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_makeBuilder", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_makeBuilder",
            args: {
              kids
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "row": await __callMethod(_addRow, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "column": await __callMethod(_addColumn, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "box": await __callMethod(_addBox, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "line": await __callMethod(_addLine, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "text": await __callMethod(_addText, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "list": await __callMethod(_addList, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          }),
          "textInput": await __callMethod(_addTextInput, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              kids: __stack.args.kids
            }
          })
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_makeBuilder");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _makeBuilder threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_makeBuilder"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_makeBuilder",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_makeBuilder",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _makeBuilder = __AgencyFunction.create({
  name: "_makeBuilder",
  module: "stdlib/ui.agency",
  fn: ___makeBuilder_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_makeBuilder",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()) })
  },
  exported: false
}, __toolRegistry);
async function __column_impl(flex = __UNSET, width = __UNSET, height = __UNSET, padding = __UNSET, border = __UNSET, borderColor = __UNSET, label = __UNSET, bg = __UNSET, fg = __UNSET, visible = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["padding"] = padding === __UNSET ? null : padding;
  __stack.args["border"] = border === __UNSET ? false : border;
  __stack.args["borderColor"] = borderColor === __UNSET ? `` : borderColor;
  __stack.args["label"] = label === __UNSET ? `` : label;
  __stack.args["bg"] = bg === __UNSET ? `` : bg;
  __stack.args["fg"] = fg === __UNSET ? `` : fg;
  __stack.args["visible"] = visible === __UNSET ? true : visible;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "column", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("padding" in __overrides) {
      padding = __overrides["padding"];
      __stack.args["padding"] = padding;
    }
    if ("border" in __overrides) {
      border = __overrides["border"];
      __stack.args["border"] = border;
    }
    if ("borderColor" in __overrides) {
      borderColor = __overrides["borderColor"];
      __stack.args["borderColor"] = borderColor;
    }
    if ("label" in __overrides) {
      label = __overrides["label"];
      __stack.args["label"] = label;
    }
    if ("bg" in __overrides) {
      bg = __overrides["bg"];
      __stack.args["bg"] = bg;
    }
    if ("fg" in __overrides) {
      fg = __overrides["fg"];
      __stack.args["fg"] = fg;
    }
    if ("visible" in __overrides) {
      visible = __overrides["visible"];
      __stack.args["visible"] = visible;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "column",
            args: {
              flex,
              width,
              height,
              padding,
              border,
              borderColor,
              label,
              bg,
              fg,
              visible,
              block
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.kids = [];
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.block, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(__stack.args.block, {
                type: "positional",
                args: [await __call(_makeBuilder, {
                  type: "positional",
                  args: [__stack.locals.kids]
                })]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "column"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `box`,
          "style": await __call(_mkBoxStyle, {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              flexDirection: `column`,
              flex: __stack.args.flex,
              width: __stack.args.width,
              height: __stack.args.height,
              padding: __stack.args.padding,
              border: __stack.args.border,
              borderColor: __stack.args.borderColor,
              label: __stack.args.label,
              bg: __stack.args.bg,
              fg: __stack.args.fg,
              visible: __stack.args.visible
            }
          }),
          "children": __stack.locals.kids
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "column");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function column threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "column"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "column",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "column",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const column = __AgencyFunction.create({
  name: "column",
  module: "stdlib/ui.agency",
  fn: __column_impl,
  params: [{
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "padding",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "border",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "label",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "visible",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "column",
    description: `Build a vertical container; children stack top-to-bottom. Pass a
  trailing \`as name { ... }\` block whose builder appends children in
  source order.

  @param flex - Flex grow factor when nested inside a parent
  @param width - Fixed character width
  @param height - Fixed row count
  @param padding - Inner padding (cells on all sides)
  @param border - Draw a single-line border
  @param borderColor - Color name or hex for the border
  @param label - Optional title rendered into the top border
  @param bg - Background color (named or hex)
  @param fg - Foreground color (named or hex)
  @param visible - Set false to render as zero-height
  @param block - Builder callback; appended children populate the column`,
    schema: z.object({ "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "padding": z.number().nullable().describe("Default: null"), "border": z.boolean().nullable().describe("Default: false"), "borderColor": z.string().nullable().describe("Default: "), "label": z.string().nullable().describe("Default: "), "bg": z.string().nullable().describe("Default: "), "fg": z.string().nullable().describe("Default: "), "visible": z.boolean().nullable().describe("Default: true") })
  },
  exported: true
}, __toolRegistry);
async function __row_impl(flex = __UNSET, width = __UNSET, height = __UNSET, padding = __UNSET, border = __UNSET, borderColor = __UNSET, label = __UNSET, bg = __UNSET, fg = __UNSET, visible = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["padding"] = padding === __UNSET ? null : padding;
  __stack.args["border"] = border === __UNSET ? false : border;
  __stack.args["borderColor"] = borderColor === __UNSET ? `` : borderColor;
  __stack.args["label"] = label === __UNSET ? `` : label;
  __stack.args["bg"] = bg === __UNSET ? `` : bg;
  __stack.args["fg"] = fg === __UNSET ? `` : fg;
  __stack.args["visible"] = visible === __UNSET ? true : visible;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "row", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("padding" in __overrides) {
      padding = __overrides["padding"];
      __stack.args["padding"] = padding;
    }
    if ("border" in __overrides) {
      border = __overrides["border"];
      __stack.args["border"] = border;
    }
    if ("borderColor" in __overrides) {
      borderColor = __overrides["borderColor"];
      __stack.args["borderColor"] = borderColor;
    }
    if ("label" in __overrides) {
      label = __overrides["label"];
      __stack.args["label"] = label;
    }
    if ("bg" in __overrides) {
      bg = __overrides["bg"];
      __stack.args["bg"] = bg;
    }
    if ("fg" in __overrides) {
      fg = __overrides["fg"];
      __stack.args["fg"] = fg;
    }
    if ("visible" in __overrides) {
      visible = __overrides["visible"];
      __stack.args["visible"] = visible;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "row",
            args: {
              flex,
              width,
              height,
              padding,
              border,
              borderColor,
              label,
              bg,
              fg,
              visible,
              block
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.kids = [];
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.block, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(__stack.args.block, {
                type: "positional",
                args: [await __call(_makeBuilder, {
                  type: "positional",
                  args: [__stack.locals.kids]
                })]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "row"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `box`,
          "style": await __call(_mkBoxStyle, {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              flexDirection: `row`,
              flex: __stack.args.flex,
              width: __stack.args.width,
              height: __stack.args.height,
              padding: __stack.args.padding,
              border: __stack.args.border,
              borderColor: __stack.args.borderColor,
              label: __stack.args.label,
              bg: __stack.args.bg,
              fg: __stack.args.fg,
              visible: __stack.args.visible
            }
          }),
          "children": __stack.locals.kids
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "row");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function row threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "row"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "row",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "row",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const row = __AgencyFunction.create({
  name: "row",
  module: "stdlib/ui.agency",
  fn: __row_impl,
  params: [{
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "padding",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "border",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "label",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "visible",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "row",
    description: `Build a horizontal container; children stack left-to-right. Pass a
  trailing \`as name { ... }\` block whose builder appends children in
  source order.

  @param flex - Flex grow factor when nested inside a parent
  @param width - Fixed character width
  @param height - Fixed row count
  @param padding - Inner padding (cells on all sides)
  @param border - Draw a single-line border
  @param borderColor - Color name or hex for the border
  @param label - Optional title rendered into the top border
  @param bg - Background color (named or hex)
  @param fg - Foreground color (named or hex)
  @param visible - Set false to render as zero-height
  @param block - Builder callback; appended children populate the row`,
    schema: z.object({ "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "padding": z.number().nullable().describe("Default: null"), "border": z.boolean().nullable().describe("Default: false"), "borderColor": z.string().nullable().describe("Default: "), "label": z.string().nullable().describe("Default: "), "bg": z.string().nullable().describe("Default: "), "fg": z.string().nullable().describe("Default: "), "visible": z.boolean().nullable().describe("Default: true") })
  },
  exported: true
}, __toolRegistry);
async function __box_impl(flex = __UNSET, width = __UNSET, height = __UNSET, padding = __UNSET, border = __UNSET, borderColor = __UNSET, label = __UNSET, bg = __UNSET, fg = __UNSET, visible = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["padding"] = padding === __UNSET ? null : padding;
  __stack.args["border"] = border === __UNSET ? false : border;
  __stack.args["borderColor"] = borderColor === __UNSET ? `` : borderColor;
  __stack.args["label"] = label === __UNSET ? `` : label;
  __stack.args["bg"] = bg === __UNSET ? `` : bg;
  __stack.args["fg"] = fg === __UNSET ? `` : fg;
  __stack.args["visible"] = visible === __UNSET ? true : visible;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "box", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("padding" in __overrides) {
      padding = __overrides["padding"];
      __stack.args["padding"] = padding;
    }
    if ("border" in __overrides) {
      border = __overrides["border"];
      __stack.args["border"] = border;
    }
    if ("borderColor" in __overrides) {
      borderColor = __overrides["borderColor"];
      __stack.args["borderColor"] = borderColor;
    }
    if ("label" in __overrides) {
      label = __overrides["label"];
      __stack.args["label"] = label;
    }
    if ("bg" in __overrides) {
      bg = __overrides["bg"];
      __stack.args["bg"] = bg;
    }
    if ("fg" in __overrides) {
      fg = __overrides["fg"];
      __stack.args["fg"] = fg;
    }
    if ("visible" in __overrides) {
      visible = __overrides["visible"];
      __stack.args["visible"] = visible;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "box",
            args: {
              flex,
              width,
              height,
              padding,
              border,
              borderColor,
              label,
              bg,
              fg,
              visible,
              block
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.kids = [];
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.args.block, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(__stack.args.block, {
                type: "positional",
                args: [await __call(_makeBuilder, {
                  type: "positional",
                  args: [__stack.locals.kids]
                })]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "box"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "type": `box`,
          "style": await __call(_mkBoxStyle, {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              flexDirection: ``,
              flex: __stack.args.flex,
              width: __stack.args.width,
              height: __stack.args.height,
              padding: __stack.args.padding,
              border: __stack.args.border,
              borderColor: __stack.args.borderColor,
              label: __stack.args.label,
              bg: __stack.args.bg,
              fg: __stack.args.fg,
              visible: __stack.args.visible
            }
          }),
          "children": __stack.locals.kids
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "box");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function box threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "box"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "box",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "box",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const box = __AgencyFunction.create({
  name: "box",
  module: "stdlib/ui.agency",
  fn: __box_impl,
  params: [{
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "padding",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "border",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "label",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "visible",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "box",
    description: `Build a direction-neutral container. Use it to apply styling
  (border, padding, background) without forcing a row/column layout,
  e.g. as a flex spacer (\`box(flex: 1) as _ {}\`).

  @param flex - Flex grow factor when nested inside a parent
  @param width - Fixed character width
  @param height - Fixed row count
  @param padding - Inner padding (cells on all sides)
  @param border - Draw a single-line border
  @param borderColor - Color name or hex for the border
  @param label - Optional title rendered into the top border
  @param bg - Background color (named or hex)
  @param fg - Foreground color (named or hex)
  @param visible - Set false to render as zero-height
  @param block - Builder callback; appended children populate the box`,
    schema: z.object({ "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "padding": z.number().nullable().describe("Default: null"), "border": z.boolean().nullable().describe("Default: false"), "borderColor": z.string().nullable().describe("Default: "), "label": z.string().nullable().describe("Default: "), "bg": z.string().nullable().describe("Default: "), "fg": z.string().nullable().describe("Default: "), "visible": z.boolean().nullable().describe("Default: true") })
  },
  exported: true
}, __toolRegistry);
async function ___addRow_impl(kids, flex = __UNSET, width = __UNSET, height = __UNSET, padding = __UNSET, border = __UNSET, borderColor = __UNSET, label = __UNSET, bg = __UNSET, fg = __UNSET, visible = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["padding"] = padding === __UNSET ? null : padding;
  __stack.args["border"] = border === __UNSET ? false : border;
  __stack.args["borderColor"] = borderColor === __UNSET ? `` : borderColor;
  __stack.args["label"] = label === __UNSET ? `` : label;
  __stack.args["bg"] = bg === __UNSET ? `` : bg;
  __stack.args["fg"] = fg === __UNSET ? `` : fg;
  __stack.args["visible"] = visible === __UNSET ? true : visible;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_addRow", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("padding" in __overrides) {
      padding = __overrides["padding"];
      __stack.args["padding"] = padding;
    }
    if ("border" in __overrides) {
      border = __overrides["border"];
      __stack.args["border"] = border;
    }
    if ("borderColor" in __overrides) {
      borderColor = __overrides["borderColor"];
      __stack.args["borderColor"] = borderColor;
    }
    if ("label" in __overrides) {
      label = __overrides["label"];
      __stack.args["label"] = label;
    }
    if ("bg" in __overrides) {
      bg = __overrides["bg"];
      __stack.args["bg"] = bg;
    }
    if ("fg" in __overrides) {
      fg = __overrides["fg"];
      __stack.args["fg"] = fg;
    }
    if ("visible" in __overrides) {
      visible = __overrides["visible"];
      __stack.args["visible"] = visible;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addRow",
            args: {
              kids,
              flex,
              width,
              height,
              padding,
              border,
              borderColor,
              label,
              bg,
              fg,
              visible,
              block
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.elem = await __call(row, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            flex: __stack.args.flex,
            width: __stack.args.width,
            height: __stack.args.height,
            padding: __stack.args.padding,
            border: __stack.args.border,
            borderColor: __stack.args.borderColor,
            label: __stack.args.label,
            bg: __stack.args.bg,
            fg: __stack.args.fg,
            visible: __stack.args.visible,
            block: __stack.args.block
          }
        });
        if (hasInterrupts(__stack.locals.elem)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.elem);
          return;
        }
        if (isAborted(__stack.locals.elem)) {
          runner2.halt(__stack.locals.elem.carryThrough(__stack, "_addRow"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.elem]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.elem);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addRow");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addRow threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addRow"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addRow",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addRow",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addRow = __AgencyFunction.create({
  name: "_addRow",
  module: "stdlib/ui.agency",
  fn: ___addRow_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "padding",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "border",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "label",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "visible",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addRow",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "padding": z.number().nullable().describe("Default: null"), "border": z.boolean().nullable().describe("Default: false"), "borderColor": z.string().nullable().describe("Default: "), "label": z.string().nullable().describe("Default: "), "bg": z.string().nullable().describe("Default: "), "fg": z.string().nullable().describe("Default: "), "visible": z.boolean().nullable().describe("Default: true") })
  },
  exported: false
}, __toolRegistry);
async function ___addColumn_impl(kids, flex = __UNSET, width = __UNSET, height = __UNSET, padding = __UNSET, border = __UNSET, borderColor = __UNSET, label = __UNSET, bg = __UNSET, fg = __UNSET, visible = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["padding"] = padding === __UNSET ? null : padding;
  __stack.args["border"] = border === __UNSET ? false : border;
  __stack.args["borderColor"] = borderColor === __UNSET ? `` : borderColor;
  __stack.args["label"] = label === __UNSET ? `` : label;
  __stack.args["bg"] = bg === __UNSET ? `` : bg;
  __stack.args["fg"] = fg === __UNSET ? `` : fg;
  __stack.args["visible"] = visible === __UNSET ? true : visible;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_addColumn", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("padding" in __overrides) {
      padding = __overrides["padding"];
      __stack.args["padding"] = padding;
    }
    if ("border" in __overrides) {
      border = __overrides["border"];
      __stack.args["border"] = border;
    }
    if ("borderColor" in __overrides) {
      borderColor = __overrides["borderColor"];
      __stack.args["borderColor"] = borderColor;
    }
    if ("label" in __overrides) {
      label = __overrides["label"];
      __stack.args["label"] = label;
    }
    if ("bg" in __overrides) {
      bg = __overrides["bg"];
      __stack.args["bg"] = bg;
    }
    if ("fg" in __overrides) {
      fg = __overrides["fg"];
      __stack.args["fg"] = fg;
    }
    if ("visible" in __overrides) {
      visible = __overrides["visible"];
      __stack.args["visible"] = visible;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addColumn",
            args: {
              kids,
              flex,
              width,
              height,
              padding,
              border,
              borderColor,
              label,
              bg,
              fg,
              visible,
              block
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.elem = await __call(column, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            flex: __stack.args.flex,
            width: __stack.args.width,
            height: __stack.args.height,
            padding: __stack.args.padding,
            border: __stack.args.border,
            borderColor: __stack.args.borderColor,
            label: __stack.args.label,
            bg: __stack.args.bg,
            fg: __stack.args.fg,
            visible: __stack.args.visible,
            block: __stack.args.block
          }
        });
        if (hasInterrupts(__stack.locals.elem)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.elem);
          return;
        }
        if (isAborted(__stack.locals.elem)) {
          runner2.halt(__stack.locals.elem.carryThrough(__stack, "_addColumn"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.elem]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.elem);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addColumn");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addColumn threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addColumn"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addColumn",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addColumn",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addColumn = __AgencyFunction.create({
  name: "_addColumn",
  module: "stdlib/ui.agency",
  fn: ___addColumn_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "padding",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "border",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "label",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "visible",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addColumn",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "padding": z.number().nullable().describe("Default: null"), "border": z.boolean().nullable().describe("Default: false"), "borderColor": z.string().nullable().describe("Default: "), "label": z.string().nullable().describe("Default: "), "bg": z.string().nullable().describe("Default: "), "fg": z.string().nullable().describe("Default: "), "visible": z.boolean().nullable().describe("Default: true") })
  },
  exported: false
}, __toolRegistry);
async function ___addBox_impl(kids, flex = __UNSET, width = __UNSET, height = __UNSET, padding = __UNSET, border = __UNSET, borderColor = __UNSET, label = __UNSET, bg = __UNSET, fg = __UNSET, visible = __UNSET, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["padding"] = padding === __UNSET ? null : padding;
  __stack.args["border"] = border === __UNSET ? false : border;
  __stack.args["borderColor"] = borderColor === __UNSET ? `` : borderColor;
  __stack.args["label"] = label === __UNSET ? `` : label;
  __stack.args["bg"] = bg === __UNSET ? `` : bg;
  __stack.args["fg"] = fg === __UNSET ? `` : fg;
  __stack.args["visible"] = visible === __UNSET ? true : visible;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_addBox", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("padding" in __overrides) {
      padding = __overrides["padding"];
      __stack.args["padding"] = padding;
    }
    if ("border" in __overrides) {
      border = __overrides["border"];
      __stack.args["border"] = border;
    }
    if ("borderColor" in __overrides) {
      borderColor = __overrides["borderColor"];
      __stack.args["borderColor"] = borderColor;
    }
    if ("label" in __overrides) {
      label = __overrides["label"];
      __stack.args["label"] = label;
    }
    if ("bg" in __overrides) {
      bg = __overrides["bg"];
      __stack.args["bg"] = bg;
    }
    if ("fg" in __overrides) {
      fg = __overrides["fg"];
      __stack.args["fg"] = fg;
    }
    if ("visible" in __overrides) {
      visible = __overrides["visible"];
      __stack.args["visible"] = visible;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addBox",
            args: {
              kids,
              flex,
              width,
              height,
              padding,
              border,
              borderColor,
              label,
              bg,
              fg,
              visible,
              block
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.elem = await __call(box, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            flex: __stack.args.flex,
            width: __stack.args.width,
            height: __stack.args.height,
            padding: __stack.args.padding,
            border: __stack.args.border,
            borderColor: __stack.args.borderColor,
            label: __stack.args.label,
            bg: __stack.args.bg,
            fg: __stack.args.fg,
            visible: __stack.args.visible,
            block: __stack.args.block
          }
        });
        if (hasInterrupts(__stack.locals.elem)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.elem);
          return;
        }
        if (isAborted(__stack.locals.elem)) {
          runner2.halt(__stack.locals.elem.carryThrough(__stack, "_addBox"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.elem]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.elem);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addBox");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addBox threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addBox"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addBox",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addBox",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addBox = __AgencyFunction.create({
  name: "_addBox",
  module: "stdlib/ui.agency",
  fn: ___addBox_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "padding",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "border",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "label",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "visible",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addBox",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "padding": z.number().nullable().describe("Default: null"), "border": z.boolean().nullable().describe("Default: false"), "borderColor": z.string().nullable().describe("Default: "), "label": z.string().nullable().describe("Default: "), "bg": z.string().nullable().describe("Default: "), "fg": z.string().nullable().describe("Default: "), "visible": z.boolean().nullable().describe("Default: true") })
  },
  exported: false
}, __toolRegistry);
async function ___addLine_impl(kids, content, flex = __UNSET, width = __UNSET, height = __UNSET, fg = __UNSET, bg = __UNSET, bold = __UNSET, fill = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["content"] = content;
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["fg"] = fg === __UNSET ? `` : fg;
  __stack.args["bg"] = bg === __UNSET ? `` : bg;
  __stack.args["bold"] = bold === __UNSET ? false : bold;
  __stack.args["fill"] = fill === __UNSET ? `` : fill;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_addLine", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("content" in __overrides) {
      content = __overrides["content"];
      __stack.args["content"] = content;
    }
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("fg" in __overrides) {
      fg = __overrides["fg"];
      __stack.args["fg"] = fg;
    }
    if ("bg" in __overrides) {
      bg = __overrides["bg"];
      __stack.args["bg"] = bg;
    }
    if ("bold" in __overrides) {
      bold = __overrides["bold"];
      __stack.args["bold"] = bold;
    }
    if ("fill" in __overrides) {
      fill = __overrides["fill"];
      __stack.args["fill"] = fill;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addLine",
            args: {
              kids,
              content,
              flex,
              width,
              height,
              fg,
              bg,
              bold,
              fill
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.elem = await __call(line, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            content: __stack.args.content,
            flex: __stack.args.flex,
            width: __stack.args.width,
            height: __stack.args.height,
            fg: __stack.args.fg,
            bg: __stack.args.bg,
            bold: __stack.args.bold,
            fill: __stack.args.fill
          }
        });
        if (hasInterrupts(__stack.locals.elem)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.elem);
          return;
        }
        if (isAborted(__stack.locals.elem)) {
          runner2.halt(__stack.locals.elem.carryThrough(__stack, "_addLine"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.elem]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.elem);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addLine");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addLine threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addLine"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addLine",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addLine",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addLine = __AgencyFunction.create({
  name: "_addLine",
  module: "stdlib/ui.agency",
  fn: ___addLine_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "content",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bold",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fill",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addLine",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "content": z.string(), "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "fg": z.string().nullable().describe("Default: "), "bg": z.string().nullable().describe("Default: "), "bold": z.boolean().nullable().describe("Default: false"), "fill": z.string().nullable().describe("Default: ") })
  },
  exported: false
}, __toolRegistry);
async function ___addText_impl(kids, content) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["content"] = content;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_addText", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("content" in __overrides) {
      content = __overrides["content"];
      __stack.args["content"] = content;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addText",
            args: {
              kids,
              content
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.elem = await __call(text, {
          type: "positional",
          args: [__stack.args.content]
        });
        if (hasInterrupts(__stack.locals.elem)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.elem);
          return;
        }
        if (isAborted(__stack.locals.elem)) {
          runner2.halt(__stack.locals.elem.carryThrough(__stack, "_addText"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.elem]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.elem);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addText");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addText threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addText"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addText",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addText",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addText = __AgencyFunction.create({
  name: "_addText",
  module: "stdlib/ui.agency",
  fn: ___addText_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "content",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addText",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "content": z.string() })
  },
  exported: false
}, __toolRegistry);
async function ___addList_impl(kids, items, selectedIndex = __UNSET, flex = __UNSET, width = __UNSET, height = __UNSET, border = __UNSET, borderColor = __UNSET, visible = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["items"] = items;
  __stack.args["selectedIndex"] = selectedIndex === __UNSET ? 0 : selectedIndex;
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["border"] = border === __UNSET ? false : border;
  __stack.args["borderColor"] = borderColor === __UNSET ? `` : borderColor;
  __stack.args["visible"] = visible === __UNSET ? true : visible;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_addList", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("items" in __overrides) {
      items = __overrides["items"];
      __stack.args["items"] = items;
    }
    if ("selectedIndex" in __overrides) {
      selectedIndex = __overrides["selectedIndex"];
      __stack.args["selectedIndex"] = selectedIndex;
    }
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("border" in __overrides) {
      border = __overrides["border"];
      __stack.args["border"] = border;
    }
    if ("borderColor" in __overrides) {
      borderColor = __overrides["borderColor"];
      __stack.args["borderColor"] = borderColor;
    }
    if ("visible" in __overrides) {
      visible = __overrides["visible"];
      __stack.args["visible"] = visible;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addList",
            args: {
              kids,
              items,
              selectedIndex,
              flex,
              width,
              height,
              border,
              borderColor,
              visible
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.elem = await __call(list, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            items: __stack.args.items,
            selectedIndex: __stack.args.selectedIndex,
            flex: __stack.args.flex,
            width: __stack.args.width,
            height: __stack.args.height,
            border: __stack.args.border,
            borderColor: __stack.args.borderColor,
            visible: __stack.args.visible
          }
        });
        if (hasInterrupts(__stack.locals.elem)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.elem);
          return;
        }
        if (isAborted(__stack.locals.elem)) {
          runner2.halt(__stack.locals.elem.carryThrough(__stack, "_addList"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.elem]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.elem);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addList");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addList threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addList"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addList",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addList",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addList = __AgencyFunction.create({
  name: "_addList",
  module: "stdlib/ui.agency",
  fn: ___addList_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "items",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "selectedIndex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "border",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "borderColor",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "visible",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addList",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "items": z.array(z.string()), "selectedIndex": z.number().nullable().describe("Default: 0"), "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "border": z.boolean().nullable().describe("Default: false"), "borderColor": z.string().nullable().describe("Default: "), "visible": z.boolean().nullable().describe("Default: true") })
  },
  exported: false
}, __toolRegistry);
async function ___addTextInput_impl(kids, value = __UNSET, flex = __UNSET, width = __UNSET, height = __UNSET, fg = __UNSET, bg = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["kids"] = kids;
  __stack.args["value"] = value === __UNSET ? `` : value;
  __stack.args["flex"] = flex === __UNSET ? null : flex;
  __stack.args["width"] = width === __UNSET ? null : width;
  __stack.args["height"] = height === __UNSET ? null : height;
  __stack.args["fg"] = fg === __UNSET ? `` : fg;
  __stack.args["bg"] = bg === __UNSET ? `` : bg;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_addTextInput", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("kids" in __overrides) {
      kids = __overrides["kids"];
      __stack.args["kids"] = kids;
    }
    if ("value" in __overrides) {
      value = __overrides["value"];
      __stack.args["value"] = value;
    }
    if ("flex" in __overrides) {
      flex = __overrides["flex"];
      __stack.args["flex"] = flex;
    }
    if ("width" in __overrides) {
      width = __overrides["width"];
      __stack.args["width"] = width;
    }
    if ("height" in __overrides) {
      height = __overrides["height"];
      __stack.args["height"] = height;
    }
    if ("fg" in __overrides) {
      fg = __overrides["fg"];
      __stack.args["fg"] = fg;
    }
    if ("bg" in __overrides) {
      bg = __overrides["bg"];
      __stack.args["bg"] = bg;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_addTextInput",
            args: {
              kids,
              value,
              flex,
              width,
              height,
              fg,
              bg
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.elem = await __call(textInput, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            value: __stack.args.value,
            flex: __stack.args.flex,
            width: __stack.args.width,
            height: __stack.args.height,
            fg: __stack.args.fg,
            bg: __stack.args.bg
          }
        });
        if (hasInterrupts(__stack.locals.elem)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.elem);
          return;
        }
        if (isAborted(__stack.locals.elem)) {
          runner2.halt(__stack.locals.elem.carryThrough(__stack, "_addTextInput"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        await __callMethod(__stack.args.kids, "push", {
          type: "positional",
          args: [__stack.locals.elem]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.elem);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_addTextInput");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _addTextInput threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_addTextInput"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_addTextInput",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_addTextInput",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _addTextInput = __AgencyFunction.create({
  name: "_addTextInput",
  module: "stdlib/ui.agency",
  fn: ___addTextInput_impl,
  params: [{
    name: "kids",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "value",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "flex",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "width",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "height",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "bg",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_addTextInput",
    description: "No description provided.",
    schema: z.object({ "kids": z.array(z.any()), "value": z.string().nullable().describe("Default: "), "flex": z.number().nullable().describe("Default: null"), "width": z.number().nullable().describe("Default: null"), "height": z.number().nullable().describe("Default: null"), "fg": z.string().nullable().describe("Default: "), "bg": z.string().nullable().describe("Default: ") })
  },
  exported: false
}, __toolRegistry);
async function __renderOnce_impl(tree) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["tree"] = tree;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "renderOnce", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("tree" in __overrides) {
      tree = __overrides["tree"];
      __stack.args["tree"] = tree;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "renderOnce",
            args: {
              tree
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __funcResult = await __call(_renderOnce, {
          type: "positional",
          args: [__stack.args.tree]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "renderOnce"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "renderOnce");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function renderOnce threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "renderOnce"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "renderOnce",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "renderOnce",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const renderOnce = __AgencyFunction.create({
  name: "renderOnce",
  module: "stdlib/ui.agency",
  fn: __renderOnce_impl,
  params: [{
    name: "tree",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "renderOnce",
    description: `Render a single Element tree to the screen and return immediately.
  Useful for static UI or first-paint scenarios.

  @param tree - The element tree to render`,
    schema: z.object({ "tree": Element })
  },
  exported: true
}, __toolRegistry);
async function __readKey_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "readKey", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "readKey",
            args: {},
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_readKey, {
          type: "positional",
          args: []
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "readKey");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function readKey threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "readKey"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "readKey",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "readKey",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const readKey = __AgencyFunction.create({
  name: "readKey",
  module: "stdlib/ui.agency",
  fn: __readKey_impl,
  params: [],
  toolDefinition: {
    name: "readKey",
    description: `Read one key from the terminal, blocking until a key is pressed.
  Returns a \`KeyEvent\` whose \`key\` field is either a named special key
  (\`"up"\`, \`"enter"\`, \`"escape"\`, ...) or a single printable character.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __runLoop_impl(initialState, render, handleKey, isDone, tickMs = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["initialState"] = initialState;
  __stack.args["render"] = render;
  __stack.args["handleKey"] = handleKey;
  __stack.args["isDone"] = isDone;
  __stack.args["tickMs"] = tickMs === __UNSET ? null : tickMs;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "runLoop", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("initialState" in __overrides) {
      initialState = __overrides["initialState"];
      __stack.args["initialState"] = initialState;
    }
    if ("render" in __overrides) {
      render = __overrides["render"];
      __stack.args["render"] = render;
    }
    if ("handleKey" in __overrides) {
      handleKey = __overrides["handleKey"];
      __stack.args["handleKey"] = handleKey;
    }
    if ("isDone" in __overrides) {
      isDone = __overrides["isDone"];
      __stack.args["isDone"] = isDone;
    }
    if ("tickMs" in __overrides) {
      tickMs = __overrides["tickMs"];
      __stack.args["tickMs"] = tickMs;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "runLoop",
            args: {
              initialState,
              render,
              handleKey,
              isDone,
              tickMs
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_runLoop, {
          type: "positional",
          args: [__stack.args.initialState, __stack.args.render, __stack.args.handleKey, __stack.args.isDone, __stack.args.tickMs]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "runLoop");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function runLoop threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "runLoop"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "runLoop",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "runLoop",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const runLoop = __AgencyFunction.create({
  name: "runLoop",
  module: "stdlib/ui.agency",
  fn: __runLoop_impl,
  params: [{
    name: "initialState",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "render",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "handleKey",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "isDone",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "tickMs",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "runLoop",
    description: `Elm/Ink-style state machine driver. Renders \`initialState\`, waits
  for each \`KeyEvent\`, runs \`handleKey\` to produce the next state,
  re-renders, exits when \`isDone\` returns true. Returns the final
  state.

  When \`tickMs\` is set, the loop also re-renders periodically even
  if no key is pressed. This is what makes a live status line tick.
  \`handleKey\` does NOT fire on ticks; only \`render\` does (so it can
  re-read any impure state your view depends on).

  @param initialState - The opening state record
  @param render - Pure (state) -> Element; re-runs every tick / key
  @param handleKey - Pure (state, key) -> state; runs on real keys only
  @param isDone - Pure (state) -> boolean; loop exits when true
  @param tickMs - Milliseconds between forced re-renders (omit for event-driven only)`,
    schema: z.object({ "initialState": z.any(), "render": z.any(), "handleKey": z.any(), "isDone": z.any(), "tickMs": z.number().nullable().describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
const ReplInputState = z.object({ "buffer": z.string(), "history": z.array(z.string()), "historyIdx": z.number(), "prompt": z.string(), "historyFile": z.string(), "historyMax": z.number() });
const ReplPaletteState = z.object({ "open": z.boolean(), "filter": z.string(), "cursor": z.number(), "commands": z.any() });
const ReplTranscriptState = z.object({ "messages": z.array(z.string()) });
const ReplSubmitState = z.object({ "busy": z.boolean(), "label": z.string(), "startedAtMs": z.number() });
const ReplConfigState = z.object({ "status": z.any(), "onSubmit": z.any() });
const ChoiceItem = z.object({ "key": z.string(), "label": z.string() });
const ReplChoiceState = z.object({ "title": z.string(), "body": z.string(), "items": z.array(ChoiceItem), "filter": z.string(), "cursor": z.number(), "allowFreeText": z.boolean() });
const ReplState = z.object({ "input": ReplInputState, "palette": ReplPaletteState, "transcript": ReplTranscriptState, "submit": ReplSubmitState, "config": ReplConfigState, "choice": z.union([ReplChoiceState, z.null()]).optional().default(null), "done": z.boolean() });
async function __pushMessage_impl(message) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["message"] = message;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "pushMessage", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("message" in __overrides) {
      message = __overrides["message"];
      __stack.args["message"] = message;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "pushMessage",
            args: {
              message
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__globals().get("stdlib/ui.agency", "_activeRepl"), null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(print, {
                type: "positional",
                args: [__stack.args.message]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "pushMessage"));
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(void 0);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        await __callMethod(__globals().get("stdlib/ui.agency", "_activeRepl").transcript.messages, "push", {
          type: "positional",
          args: [__stack.args.message]
        });
      });
      await runner.step(3, async (runner2) => {
        const __funcResult = await __call(_triggerRender, {
          type: "positional",
          args: []
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "pushMessage"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "pushMessage");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function pushMessage threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "pushMessage"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "pushMessage",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "pushMessage",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const pushMessage = __AgencyFunction.create({
  name: "pushMessage",
  module: "stdlib/ui.agency",
  fn: __pushMessage_impl,
  params: [{
    name: "message",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "pushMessage",
    description: `Append a message to the active REPL transcript. It renders on the
  next frame. The string may include style markup, which the
  transcript stores unchanged. When no REPL is active, the message
  prints normally instead.

  @param message - Styled or plain text to append to the transcript`,
    schema: z.object({ "message": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __clearMessages_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "clearMessages", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "clearMessages",
            args: {},
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__globals().get("stdlib/ui.agency", "_activeRepl"), null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(void 0);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
      });
      await runner.step(3, async (runner2) => {
        await __callMethod(__globals().get("stdlib/ui.agency", "_activeRepl").transcript.messages, "splice", {
          type: "positional",
          args: [0, __globals().get("stdlib/ui.agency", "_activeRepl").transcript.messages.length]
        });
      });
      await runner.step(4, async (runner2) => {
        const __funcResult = await __call(_triggerRender, {
          type: "positional",
          args: []
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "clearMessages"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "clearMessages");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function clearMessages threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "clearMessages"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "clearMessages",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "clearMessages",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const clearMessages = __AgencyFunction.create({
  name: "clearMessages",
  module: "stdlib/ui.agency",
  fn: __clearMessages_impl,
  params: [],
  toolDefinition: {
    name: "clearMessages",
    description: `Remove all messages from the active REPL transcript. Use it for an
  explicit "clear conversation" command. Silent no-op when no REPL is
  active.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __select_impl(message, items, allowFreeText = __UNSET, hint = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["message"] = message;
  __stack.args["items"] = items;
  __stack.args["allowFreeText"] = allowFreeText === __UNSET ? false : allowFreeText;
  __stack.args["hint"] = hint === __UNSET ? `` : hint;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "select", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("message" in __overrides) {
      message = __overrides["message"];
      __stack.args["message"] = message;
    }
    if ("items" in __overrides) {
      items = __overrides["items"];
      __stack.args["items"] = items;
    }
    if ("allowFreeText" in __overrides) {
      allowFreeText = __overrides["allowFreeText"];
      __stack.args["allowFreeText"] = allowFreeText;
    }
    if ("hint" in __overrides) {
      hint = __overrides["hint"];
      __stack.args["hint"] = hint;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "select",
            args: {
              message,
              items,
              allowFreeText,
              hint
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_promptsSelect, {
          type: "positional",
          args: [__stack.args.message, __stack.args.items, __stack.args.allowFreeText, __stack.args.hint]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "select");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function select threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "select"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "select",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "select",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const select = __AgencyFunction.create({
  name: "select",
  module: "stdlib/ui.agency",
  fn: __select_impl,
  params: [{
    name: "message",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "items",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowFreeText",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "hint",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "select",
    description: `Ask the user to pick from a list with arrow keys (no type-to-filter).
  Returns \`success(key)\` with the chosen item's \`key\`, or
  \`failure("cancelled")\` if the user pressed Ctrl+C / Escape. When
  \`allowFreeText\` is true, the list appends an extra "enter free text"
  row. Picking it prompts for text and returns that instead of a key.

  @param message - The question shown above the choices
  @param items - The {key, label} rows to choose from
  @param allowFreeText - Append a free-text entry row
  @param hint - Dim hint shown after the message`,
    schema: z.object({ "message": z.string(), "items": z.array(ChoiceItem), "allowFreeText": z.boolean().nullable().describe("Default: false"), "hint": z.string().nullable().describe("Default: ") })
  },
  exported: true
}, __toolRegistry);
async function __autocomplete_impl(message, items, allowFreeText = __UNSET, hint = __UNSET, cancelOnEscape = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["message"] = message;
  __stack.args["items"] = items;
  __stack.args["allowFreeText"] = allowFreeText === __UNSET ? false : allowFreeText;
  __stack.args["hint"] = hint === __UNSET ? `` : hint;
  __stack.args["cancelOnEscape"] = cancelOnEscape === __UNSET ? false : cancelOnEscape;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "autocomplete", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("message" in __overrides) {
      message = __overrides["message"];
      __stack.args["message"] = message;
    }
    if ("items" in __overrides) {
      items = __overrides["items"];
      __stack.args["items"] = items;
    }
    if ("allowFreeText" in __overrides) {
      allowFreeText = __overrides["allowFreeText"];
      __stack.args["allowFreeText"] = allowFreeText;
    }
    if ("hint" in __overrides) {
      hint = __overrides["hint"];
      __stack.args["hint"] = hint;
    }
    if ("cancelOnEscape" in __overrides) {
      cancelOnEscape = __overrides["cancelOnEscape"];
      __stack.args["cancelOnEscape"] = cancelOnEscape;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "autocomplete",
            args: {
              message,
              items,
              allowFreeText,
              hint,
              cancelOnEscape
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_promptsAutocomplete, {
          type: "positional",
          args: [__stack.args.message, __stack.args.items, __stack.args.allowFreeText, __stack.args.hint, __stack.args.cancelOnEscape]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "autocomplete");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function autocomplete threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "autocomplete"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "autocomplete",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "autocomplete",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const autocomplete = __AgencyFunction.create({
  name: "autocomplete",
  module: "stdlib/ui.agency",
  fn: __autocomplete_impl,
  params: [{
    name: "message",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "items",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowFreeText",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "hint",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cancelOnEscape",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "autocomplete",
    description: `Ask the user to pick from a list, filtering by typed text. Returns
  \`success(key)\` with the chosen item's \`key\`, or \`failure("cancelled")\`
  on Ctrl+C / Escape. The filter matches each item's \`key\` or \`label\`
  (substring, case-insensitive). When \`allowFreeText\` is true and the
  typed input matches no item, picking it returns the typed text
  verbatim instead of a key.

  @param message - The question shown above the choices
  @param items - The {key, label} rows to choose from
  @param allowFreeText - Return the typed input verbatim when no item matches
  @param hint - Dim hint shown after the message
  @param cancelOnEscape - When true, Escape raises a cancellation that
    unwinds the current run instead of returning \`failure("cancelled")\`.
    Use it where Escape should abort the whole request rather than re-ask`,
    schema: z.object({ "message": z.string(), "items": z.array(ChoiceItem), "allowFreeText": z.boolean().nullable().describe("Default: false"), "hint": z.string().nullable().describe("Default: "), "cancelOnEscape": z.boolean().nullable().describe("Default: false") })
  },
  exported: true
}, __toolRegistry);
async function __prompt_impl(message, initial = __UNSET, hint = __UNSET, validate = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["message"] = message;
  __stack.args["initial"] = initial === __UNSET ? `` : initial;
  __stack.args["hint"] = hint === __UNSET ? `` : hint;
  __stack.args["validate"] = validate === __UNSET ? null : validate;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "prompt", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("message" in __overrides) {
      message = __overrides["message"];
      __stack.args["message"] = message;
    }
    if ("initial" in __overrides) {
      initial = __overrides["initial"];
      __stack.args["initial"] = initial;
    }
    if ("hint" in __overrides) {
      hint = __overrides["hint"];
      __stack.args["hint"] = hint;
    }
    if ("validate" in __overrides) {
      validate = __overrides["validate"];
      __stack.args["validate"] = validate;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "prompt",
            args: {
              message,
              initial,
              hint,
              validate
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_promptsText, {
          type: "positional",
          args: [__stack.args.message, __stack.args.initial, __stack.args.hint, __stack.args.validate]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "prompt");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function prompt threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "prompt"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "prompt",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "prompt",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const prompt = __AgencyFunction.create({
  name: "prompt",
  module: "stdlib/ui.agency",
  fn: __prompt_impl,
  params: [{
    name: "message",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "initial",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "hint",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "validate",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "prompt",
    description: `Ask the user for a line of free-form text. Returns \`success(typed)\`
  or \`failure("cancelled")\`. The empty string is a legitimate value, so
  check the Result tag rather than truthiness. When \`validate\` is
  supplied, it runs on each submission: return \`true\` to accept, or an
  error string to reject and re-ask.

  @param message - The question shown to the user
  @param initial - Pre-filled value
  @param hint - Dim hint shown after the message
  @param validate - Optional \`(value) => true | "error message"\` validator`,
    schema: z.object({ "message": z.string(), "initial": z.string().nullable().describe("Default: "), "hint": z.string().nullable().describe("Default: "), "validate": z.any().nullable().describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
async function __confirm_impl(message, initial = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["message"] = message;
  __stack.args["initial"] = initial === __UNSET ? false : initial;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "confirm", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("message" in __overrides) {
      message = __overrides["message"];
      __stack.args["message"] = message;
    }
    if ("initial" in __overrides) {
      initial = __overrides["initial"];
      __stack.args["initial"] = initial;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "confirm",
            args: {
              message,
              initial
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_promptsConfirm, {
          type: "positional",
          args: [__stack.args.message, __stack.args.initial]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "confirm");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function confirm threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "confirm"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "confirm",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "confirm",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const confirm = __AgencyFunction.create({
  name: "confirm",
  module: "stdlib/ui.agency",
  fn: __confirm_impl,
  params: [{
    name: "message",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "initial",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "confirm",
    description: `Ask the user a yes/no question. Returns \`success(true)\`,
  \`success(false)\`, or \`failure("cancelled")\`. That is three outcomes,
  so check the Result tag rather than treating it as a boolean.

  @param message - The question shown to the user
  @param initial - Default position (false = "no")`,
    schema: z.object({ "message": z.string(), "initial": z.boolean().nullable().describe("Default: false") })
  },
  exported: true
}, __toolRegistry);
async function __indent_impl(str) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["str"] = str;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "indent", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("str" in __overrides) {
      str = __overrides["str"];
      __stack.args["str"] = str;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "indent",
            args: {
              str
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.str, ``) || __eq(__stack.args.str, null) || __eq(__stack.args.str, void 0),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(``);
              return;
            });
          }
        }
      ]);
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(typeof __stack.args.str, `string`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
            });
            await runner2.step(1, async (runner3) => {
              const __funcResult = await __call(print, {
                type: "positional",
                args: [`Warning: indent() expected a string but got`, typeof __stack.args.str, `- rendering without indentation`, await __callMethod(JSON, "stringify", {
                  type: "positional",
                  args: [__stack.args.str]
                })]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "indent"));
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await __callMethod(JSON, "stringify", {
                type: "positional",
                args: [__stack.args.str]
              }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.lines = await __callMethod(__stack.args.str, "split", {
          type: "positional",
          args: [`
`]
        });
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.res = await __call(map, {
          type: "named",
          positionalArgs: [__stack.locals.lines],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/ui.agency", fn: async (line2) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["line"] = line2;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/ui.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(`    ${__bstack.args.line}`);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_0");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "line", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.res)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.res);
          return;
        }
        if (isAborted(__stack.locals.res)) {
          runner2.halt(__stack.locals.res.carryThrough(__stack, "indent"));
          return;
        }
      });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(__stack.locals.res, "join", {
          type: "positional",
          args: [`
`]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "indent");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function indent threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "indent"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "indent",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "indent",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const indent = __AgencyFunction.create({
  name: "indent",
  module: "stdlib/ui.agency",
  fn: __indent_impl,
  params: [{
    name: "str",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "indent",
    description: "No description provided.",
    schema: z.object({ "str": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __chooseOption_impl(title, body, items, allowFreeText = __UNSET, allowCancel = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["title"] = title;
  __stack.args["body"] = body;
  __stack.args["items"] = items;
  __stack.args["allowFreeText"] = allowFreeText === __UNSET ? false : allowFreeText;
  __stack.args["allowCancel"] = allowCancel === __UNSET ? false : allowCancel;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "chooseOption", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("title" in __overrides) {
      title = __overrides["title"];
      __stack.args["title"] = title;
    }
    if ("body" in __overrides) {
      body = __overrides["body"];
      __stack.args["body"] = body;
    }
    if ("items" in __overrides) {
      items = __overrides["items"];
      __stack.args["items"] = items;
    }
    if ("allowFreeText" in __overrides) {
      allowFreeText = __overrides["allowFreeText"];
      __stack.args["allowFreeText"] = allowFreeText;
    }
    if ("allowCancel" in __overrides) {
      allowCancel = __overrides["allowCancel"];
      __stack.args["allowCancel"] = allowCancel;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "chooseOption",
            args: {
              title,
              body,
              items,
              allowFreeText,
              allowCancel
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => !__eq(__globals().get("stdlib/ui.agency", "_activeRepl"), null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await __call(_openChoicePrompt, {
                type: "positional",
                args: [{
                  "title": __stack.args.title,
                  "body": __stack.args.body,
                  "items": __stack.args.items,
                  "allowFreeText": __stack.args.allowFreeText
                }]
              }));
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
      });
      await runner.ifElse(3, [
        {
          condition: async () => !await __call(_isTTY, {
            type: "positional",
            args: []
          }),
          body: async (runner2) => {
            await runner2.ifElse(0, [
              {
                condition: async () => !__eq(__stack.args.title, ``),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    const __funcResult = await __call(print, {
                      type: "positional",
                      args: [__stack.args.title]
                    });
                    if (hasInterrupts(__funcResult)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner4.halt(__funcResult);
                      return;
                    }
                    if (isAborted(__funcResult)) {
                      runner4.halt(__funcResult.carryThrough(__stack, "chooseOption"));
                      return;
                    }
                  });
                }
              }
            ]);
            await runner2.ifElse(1, [
              {
                condition: async () => !__eq(__stack.args.body, ``),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    const __funcResult = await __call(print, {
                      type: "positional",
                      args: [__stack.args.body]
                    });
                    if (hasInterrupts(__funcResult)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner4.halt(__funcResult);
                      return;
                    }
                    if (isAborted(__funcResult)) {
                      runner4.halt(__funcResult.carryThrough(__stack, "chooseOption"));
                      return;
                    }
                  });
                }
              }
            ]);
            await runner2.step(2, async (runner3) => {
              __stack.locals.validKeys = await __call(map, {
                type: "positional",
                args: [__stack.args.items, _entryKey]
              });
              if (hasInterrupts(__stack.locals.validKeys)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.validKeys);
                return;
              }
              if (isAborted(__stack.locals.validKeys)) {
                runner3.halt(__stack.locals.validKeys.carryThrough(__stack, "chooseOption"));
                return;
              }
            });
            await runner2.whileLoop(3, async () => true, async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.answer = await __callMethod(await await __call(input, {
                  type: "positional",
                  args: [`> `]
                }), "trim", {
                  type: "positional",
                  args: []
                });
              });
              await runner3.ifElse(1, [
                {
                  condition: async () => await __callMethod(__stack.locals.validKeys, "includes", {
                    type: "positional",
                    args: [__stack.locals.answer]
                  }),
                  body: async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      __functionCompleted = true;
                      runner5.halt(__stack.locals.answer);
                      return;
                    });
                  }
                }
              ]);
              await runner3.ifElse(2, [
                {
                  condition: async () => __stack.args.allowFreeText && !__eq(__stack.locals.answer, ``),
                  body: async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      __functionCompleted = true;
                      runner5.halt(__stack.locals.answer);
                      return;
                    });
                  }
                }
              ]);
              await runner3.step(3, async (runner4) => {
                const __funcResult = await __call(print, {
                  type: "positional",
                  args: [`(answer required)`]
                });
                if (hasInterrupts(__funcResult)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__funcResult);
                  return;
                }
                if (isAborted(__funcResult)) {
                  runner4.halt(__funcResult.carryThrough(__stack, "chooseOption"));
                  return;
                }
              });
            });
            await runner2.step(4, async (runner3) => {
            });
            await runner2.step(5, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(``);
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
      });
      await runner.step(5, async (runner2) => {
        const __funcResult = await __call(print, {
          type: "positional",
          args: [`
`]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "chooseOption"));
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.rule = `\u2500`;
      });
      await runner.step(7, async (runner2) => {
        const __funcResult = await __call(print, {
          type: "positional",
          args: [await __callMethod(color, "cyan", {
            type: "positional",
            args: [await __callMethod(__stack.locals.rule, "repeat", {
              type: "positional",
              args: [await __call(_termWidth, {
                type: "positional",
                args: []
              })]
            })]
          })]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "chooseOption"));
          return;
        }
      });
      await runner.ifElse(8, [
        {
          condition: async () => !__eq(__stack.args.title, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(print, {
                type: "positional",
                args: [await __callMethod(color, "cyan", {
                  type: "positional",
                  args: [__stack.args.title]
                }), `
`]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "chooseOption"));
                return;
              }
            });
          }
        }
      ]);
      await runner.ifElse(9, [
        {
          condition: async () => !__eq(__stack.args.body, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(print, {
                type: "positional",
                args: [await __call(indent, {
                  type: "positional",
                  args: [__stack.args.body]
                })]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "chooseOption"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(10, async (runner2) => {
        const __funcResult = await __call(print, {
          type: "positional",
          args: [`
`]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "chooseOption"));
          return;
        }
      });
      await runner.step(11, async (runner2) => {
        __stack.locals.cancelHint = ``;
      });
      await runner.ifElse(12, [
        {
          condition: async () => __stack.args.allowCancel,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.cancelHint = `Esc to cancel`;
            });
          }
        }
      ]);
      await runner.whileLoop(13, async () => true, async (runner2) => {
        await runner2.step(0, async (runner3) => {
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.result = await __call(autocomplete, {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              message: `Do you want to continue?`,
              items: __stack.args.items,
              allowFreeText: __stack.args.allowFreeText,
              hint: __stack.locals.cancelHint,
              cancelOnEscape: __stack.args.allowCancel
            }
          });
          if (hasInterrupts(__stack.locals.result)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.result);
            return;
          }
          if (isAborted(__stack.locals.result)) {
            runner3.halt(__stack.locals.result.carryThrough(__stack, "chooseOption"));
            return;
          }
        });
        await runner2.ifElse(2, [
          {
            condition: async () => !await isFailure(__stack.locals.result),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __functionCompleted = true;
                runner4.halt(__stack.locals.result.value);
                return;
              });
            }
          }
        ]);
        await runner2.step(3, async (runner3) => {
        });
        await runner2.ifElse(4, [
          {
            condition: async () => !__eq(__stack.locals.result.error, `cancelled`),
            body: async (runner3) => {
              await runner3.step(0, async (runner4) => {
                throw new Error(__stack.locals.result.error);
              });
            }
          }
        ]);
        await runner2.step(5, async (runner3) => {
          const __funcResult = await __call(print, {
            type: "positional",
            args: [`(answer required)`]
          });
          if (hasInterrupts(__funcResult)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__funcResult);
            return;
          }
          if (isAborted(__funcResult)) {
            runner3.halt(__funcResult.carryThrough(__stack, "chooseOption"));
            return;
          }
        });
      });
      await runner.step(14, async (runner2) => {
      });
      await runner.step(15, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(``);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "chooseOption");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function chooseOption threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "chooseOption"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "chooseOption",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "chooseOption",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const chooseOption = __AgencyFunction.create({
  name: "chooseOption",
  module: "stdlib/ui.agency",
  fn: __chooseOption_impl,
  params: [{
    name: "title",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "body",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "items",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowFreeText",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowCancel",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "chooseOption",
    description: `Show a modal choice prompt and block until the user picks one. Returns
  the chosen item's \`key\`. The modal takes over key input until the user
  confirms (Enter) or cancels (Escape). Typing narrows the visible items
  by substring match on \`key\` or \`label\`. When \`allowFreeText\` is true
  and the typed text matches no item, it resolves with that text instead
  of re-prompting (empty input still re-prompts).

  @param title - Modal heading (e.g. "Approve interrupt: shell::exec")
  @param body - Multi-line context shown above the choices (or "")
  @param items - The set of {key, label} choices to pick from
  @param allowFreeText - Accept free-form text in addition to item keys
  @param allowCancel - When true, Escape cancels the whole request,
    raising a cancellation that unwinds the run, instead of re-prompting.
    The default of false enforces a "must answer" contract`,
    schema: z.object({ "title": z.string(), "body": z.string(), "items": z.array(ChoiceItem), "allowFreeText": z.boolean().nullable().describe("Default: false"), "allowCancel": z.boolean().nullable().describe("Default: false") })
  },
  exported: true
}, __toolRegistry);
async function ___entryKey_impl(entry) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["entry"] = entry;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_entryKey", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("entry" in __overrides) {
      entry = __overrides["entry"];
      __stack.args["entry"] = entry;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_entryKey",
            args: {
              entry
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.args.entry.key);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_entryKey");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _entryKey threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_entryKey"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_entryKey",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_entryKey",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _entryKey = __AgencyFunction.create({
  name: "_entryKey",
  module: "stdlib/ui.agency",
  fn: ___entryKey_impl,
  params: [{
    name: "entry",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "_entryKey",
    description: "No description provided.",
    schema: z.object({ "entry": z.any() })
  },
  exported: false
}, __toolRegistry);
async function ___filteredPaletteKeys_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_filteredPaletteKeys", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_filteredPaletteKeys",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.allCommandNames = await __call(map, {
          type: "positional",
          args: [await __call(entries, {
            type: "positional",
            args: [__stack.args.state.palette.commands]
          }), _entryKey]
        });
        if (hasInterrupts(__stack.locals.allCommandNames)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.allCommandNames);
          return;
        }
        if (isAborted(__stack.locals.allCommandNames)) {
          runner2.halt(__stack.locals.allCommandNames.carryThrough(__stack, "_filteredPaletteKeys"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => __eq(__stack.args.state.palette.filter, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.locals.allCommandNames);
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.filterText = await __callMethod(__stack.args.state.palette.filter, "toLowerCase", {
          type: "positional",
          args: []
        });
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(filter, {
          type: "positional",
          args: [__stack.locals.allCommandNames, await __callMethod(_matchesFilter, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              filterText: __stack.locals.filterText
            }
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_filteredPaletteKeys");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _filteredPaletteKeys threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_filteredPaletteKeys"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_filteredPaletteKeys",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_filteredPaletteKeys",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _filteredPaletteKeys = __AgencyFunction.create({
  name: "_filteredPaletteKeys",
  module: "stdlib/ui.agency",
  fn: ___filteredPaletteKeys_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_filteredPaletteKeys",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___matchesFilter_impl(name, filterText) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["name"] = name;
  __stack.args["filterText"] = filterText;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_matchesFilter", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
    if ("filterText" in __overrides) {
      filterText = __overrides["filterText"];
      __stack.args["filterText"] = filterText;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_matchesFilter",
            args: {
              name,
              filterText
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(await __callMethod(__stack.args.name, "toLowerCase", {
          type: "positional",
          args: []
        }), "includes", {
          type: "positional",
          args: [__stack.args.filterText]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_matchesFilter");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _matchesFilter threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_matchesFilter"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_matchesFilter",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_matchesFilter",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _matchesFilter = __AgencyFunction.create({
  name: "_matchesFilter",
  module: "stdlib/ui.agency",
  fn: ___matchesFilter_impl,
  params: [{
    name: "name",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "filterText",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_matchesFilter",
    description: "No description provided.",
    schema: z.object({ "name": z.string(), "filterText": z.string() })
  },
  exported: false
}, __toolRegistry);
async function ___busyLine_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_busyLine", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_busyLine",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => !__stack.args.state.submit.busy,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(``);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __stack.locals.nowMs = await __call(_nowMs, {
          type: "positional",
          args: []
        });
        if (hasInterrupts(__stack.locals.nowMs)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.nowMs);
          return;
        }
        if (isAborted(__stack.locals.nowMs)) {
          runner2.halt(__stack.locals.nowMs.carryThrough(__stack, "_busyLine"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.elapsedSeconds = await __call(_elapsedSeconds, {
          type: "positional",
          args: [__stack.args.state.submit.startedAtMs, __stack.locals.nowMs]
        });
        if (hasInterrupts(__stack.locals.elapsedSeconds)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.elapsedSeconds);
          return;
        }
        if (isAborted(__stack.locals.elapsedSeconds)) {
          runner2.halt(__stack.locals.elapsedSeconds.carryThrough(__stack, "_busyLine"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.spinnerFrame = await __call(_spinnerFrame, {
          type: "positional",
          args: [__stack.args.state.submit.startedAtMs, __stack.locals.nowMs]
        });
        if (hasInterrupts(__stack.locals.spinnerFrame)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.spinnerFrame);
          return;
        }
        if (isAborted(__stack.locals.spinnerFrame)) {
          runner2.halt(__stack.locals.spinnerFrame.carryThrough(__stack, "_busyLine"));
          return;
        }
      });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`{bright-yellow-fg}${__stack.locals.spinnerFrame}{/bright-yellow-fg} ${__stack.args.state.submit.label} ${__stack.locals.elapsedSeconds}s`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_busyLine");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _busyLine threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_busyLine"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_busyLine",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_busyLine",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _busyLine = __AgencyFunction.create({
  name: "_busyLine",
  module: "stdlib/ui.agency",
  fn: ___busyLine_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_busyLine",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___choiceProjection_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_choiceProjection", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_choiceProjection",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.choice = __stack.args.state.choice;
      });
      await runner.ifElse(3, [
        {
          condition: async () => __eq(__stack.locals.choice, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                "visible": false,
                "title": ``,
                "bodyLines": [],
                "itemLabels": [],
                "cursor": 0,
                "filterText": ``
              });
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __stack.locals.filteredItems = await __call(_filteredChoiceItems, {
          type: "positional",
          args: [__stack.locals.choice]
        });
        if (hasInterrupts(__stack.locals.filteredItems)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.filteredItems);
          return;
        }
        if (isAborted(__stack.locals.filteredItems)) {
          runner2.halt(__stack.locals.filteredItems.carryThrough(__stack, "_choiceProjection"));
          return;
        }
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.cursor = __stack.locals.choice.cursor;
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.maxCursor = __stack.locals.filteredItems.length - 1;
      });
      await runner.ifElse(7, [
        {
          condition: async () => __stack.locals.cursor > __stack.locals.maxCursor,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.cursor = __stack.locals.maxCursor;
            });
          }
        }
      ]);
      await runner.ifElse(8, [
        {
          condition: async () => __stack.locals.cursor < 0,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.cursor = 0;
            });
          }
        }
      ]);
      await runner.step(9, async (runner2) => {
      });
      await runner.step(10, async (runner2) => {
        __stack.locals.itemLabels = [];
      });
      await runner.loop(11, async () => __stack.locals.filteredItems, async (item, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.pad = ``;
        });
        await runner2.step(1, async (runner3) => {
          __stack.locals.n = item.key.length;
        });
        await runner2.whileLoop(2, async () => __stack.locals.n < 4, async (runner3) => {
          await runner3.step(0, async (runner4) => {
            __stack.locals.pad = __stack.locals.pad + ` `;
          });
          await runner3.step(1, async (runner4) => {
            __stack.locals.n = __stack.locals.n + 1;
          });
        });
        await runner2.step(3, async (runner3) => {
          await __callMethod(__stack.locals.itemLabels, "push", {
            type: "positional",
            args: [`${item.key}${__stack.locals.pad}${item.label}`]
          });
        });
      });
      await runner.step(12, async (runner2) => {
        __stack.locals.bodyLines = [];
      });
      await runner.ifElse(13, [
        {
          condition: async () => !__eq(__stack.locals.choice.body, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.bodyLines = await __callMethod(__stack.locals.choice.body, "split", {
                type: "positional",
                args: [`
`]
              });
            });
          }
        }
      ]);
      await runner.step(14, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "visible": true,
          "title": __stack.locals.choice.title,
          "bodyLines": __stack.locals.bodyLines,
          "itemLabels": __stack.locals.itemLabels,
          "cursor": __stack.locals.cursor,
          "filterText": __stack.locals.choice.filter
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_choiceProjection");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _choiceProjection threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_choiceProjection"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_choiceProjection",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_choiceProjection",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _choiceProjection = __AgencyFunction.create({
  name: "_choiceProjection",
  module: "stdlib/ui.agency",
  fn: ___choiceProjection_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_choiceProjection",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___replView_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_replView", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_replView",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.status = await __callMethod(__stack.args.state.config, "status", {
          type: "positional",
          args: []
        });
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.contextLine = __stack.locals.status.context ?? ``;
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.paletteKeys = await __call(_filteredPaletteKeys, {
          type: "positional",
          args: [__stack.args.state]
        });
        if (hasInterrupts(__stack.locals.paletteKeys)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.paletteKeys);
          return;
        }
        if (isAborted(__stack.locals.paletteKeys)) {
          runner2.halt(__stack.locals.paletteKeys.carryThrough(__stack, "_replView"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.paletteItems = [];
      });
      await runner.loop(5, async () => __stack.locals.paletteKeys, async (commandName, _, runner2) => {
        await runner2.step(0, async (runner3) => {
          __stack.locals.description = __nn(__stack.args.state.palette.commands[commandName]);
        });
        await runner2.step(1, async (runner3) => {
          await __callMethod(__stack.locals.paletteItems, "push", {
            type: "positional",
            args: [`${commandName}  - ${__stack.locals.description}`]
          });
        });
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.visibleMessages = __stack.args.state.transcript.messages;
      });
      await runner.ifElse(7, [
        {
          condition: async () => __stack.args.state.submit.busy,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.visibleMessages = [...__stack.locals.visibleMessages, await __call(_busyLine, {
                type: "positional",
                args: [__stack.args.state]
              })];
            });
          }
        }
      ]);
      await runner.step(8, async (runner2) => {
      });
      await runner.step(9, async (runner2) => {
        __stack.locals.followIndex = __stack.locals.visibleMessages.length;
      });
      await runner.step(10, async (runner2) => {
        __stack.locals.promptWidth = __stack.args.state.input.prompt.length;
      });
      await runner.step(11, async (runner2) => {
        __stack.locals.leftStatusWidth = __stack.locals.status.left.length;
      });
      await runner.step(12, async (runner2) => {
        __stack.locals.rightStatusWidth = __stack.locals.status.right.length;
      });
      await runner.step(13, async (runner2) => {
        __stack.locals.choiceView = await __call(_choiceProjection, {
          type: "positional",
          args: [__stack.args.state]
        });
        if (hasInterrupts(__stack.locals.choiceView)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.choiceView);
          return;
        }
        if (isAborted(__stack.locals.choiceView)) {
          runner2.halt(__stack.locals.choiceView.carryThrough(__stack, "_replView"));
          return;
        }
      });
      await runner.step(14, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(column, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            visible: true
          },
          blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/ui.agency", fn: async (mainCol) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_1 = __bstack;
            __bstack.args["mainCol"] = mainCol;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/ui.agency", scopeName: "__block_1" });
            try {
              await runner3.step(0, async (runner4) => {
                await __callMethod(__bstack.args.mainCol, "list", {
                  type: "named",
                  positionalArgs: [],
                  namedArgs: {
                    items: __stack.locals.visibleMessages,
                    selectedIndex: __stack.locals.followIndex,
                    flex: 1
                  }
                });
              });
              await runner3.step(1, async (runner4) => {
                await __callMethod(__bstack.args.mainCol, "column", {
                  type: "named",
                  positionalArgs: [],
                  namedArgs: {
                    visible: __stack.locals.choiceView.visible,
                    height: __globals().get("stdlib/ui.agency", "_CHOICE_ROWS"),
                    border: true,
                    borderColor: `yellow`,
                    label: __stack.locals.choiceView.title
                  },
                  blockArg: __AgencyFunction.create({ name: "__block_2", module: "stdlib/ui.agency", fn: async (choiceBox) => {
                    const __bsetup2 = setupFunction();
                    const __bstack2 = __bsetup2.stack;
                    const __self3 = __bstack2.locals;
                    const __bframe___block_2 = __bstack2;
                    __bstack2.args["choiceBox"] = choiceBox;
                    const runner5 = new Runner(__ctx, __bstack2, { state: __bstack2, moduleId: "stdlib/ui.agency", scopeName: "__block_2" });
                    try {
                      await runner5.loop(0, async () => __stack.locals.choiceView.bodyLines, async (bodyLine, _, runner6) => {
                        await runner6.step(0, async (runner7) => {
                          await __callMethod(__bstack2.args.choiceBox, "line", {
                            type: "positional",
                            args: [bodyLine]
                          });
                        });
                      });
                      await runner5.step(1, async (runner6) => {
                        await __callMethod(__bstack2.args.choiceBox, "line", {
                          type: "named",
                          positionalArgs: [`> ${__stack.locals.choiceView.filterText}`],
                          namedArgs: {
                            bold: true
                          }
                        });
                      });
                      await runner5.step(2, async (runner6) => {
                        await __callMethod(__bstack2.args.choiceBox, "list", {
                          type: "named",
                          positionalArgs: [],
                          namedArgs: {
                            items: __stack.locals.choiceView.itemLabels,
                            selectedIndex: __stack.locals.choiceView.cursor,
                            flex: 1
                          }
                        });
                      });
                      await runner5.step(3, async (runner6) => {
                        await __callMethod(__bstack2.args.choiceBox, "line", {
                          type: "named",
                          positionalArgs: [`\u2191\u2193 select \xB7 enter confirm \xB7 esc cancel`],
                          namedArgs: {
                            fg: `gray`
                          }
                        });
                      });
                      return runner5.halted ? runner5.haltResult : void 0;
                    } catch (__blockError) {
                      if (__blockError instanceof AgencyAbort) {
                        return AbortedResult.fromError(__blockError, __bstack2, "__block_2");
                      }
                      throw __blockError;
                    } finally {
                      __bsetup2.stateStack.pop();
                    }
                  }, params: [{ name: "choiceBox", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
                });
              });
              await runner3.step(2, async (runner4) => {
                await __callMethod(__bstack.args.mainCol, "list", {
                  type: "named",
                  positionalArgs: [],
                  namedArgs: {
                    items: __stack.locals.paletteItems,
                    selectedIndex: __stack.args.state.palette.cursor,
                    visible: __stack.args.state.palette.open,
                    height: __globals().get("stdlib/ui.agency", "_PALETTE_ROWS"),
                    border: true
                  }
                });
              });
              await runner3.step(3, async (runner4) => {
                await __callMethod(__bstack.args.mainCol, "line", {
                  type: "named",
                  positionalArgs: [``],
                  namedArgs: {
                    fill: `\u2500`,
                    fg: `gray`
                  }
                });
              });
              await runner3.step(4, async (runner4) => {
                __bstack.locals._bufferLines = await __callMethod(__stack.args.state.input.buffer, "split", {
                  type: "positional",
                  args: [`
`]
                });
              });
              await runner3.step(5, async (runner4) => {
                __bstack.locals.inputHeight = __bstack.locals._bufferLines.length;
              });
              await runner3.ifElse(6, [
                {
                  condition: async () => __bstack.locals.inputHeight < 1,
                  body: async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      __bstack.locals.inputHeight = 1;
                    });
                  }
                }
              ]);
              await runner3.ifElse(7, [
                {
                  condition: async () => __bstack.locals.inputHeight > __globals().get("stdlib/ui.agency", "_INPUT_MAX_ROWS"),
                  body: async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      __bstack.locals.inputHeight = __globals().get("stdlib/ui.agency", "_INPUT_MAX_ROWS");
                    });
                  }
                }
              ]);
              await runner3.step(8, async (runner4) => {
                await __callMethod(__bstack.args.mainCol, "row", {
                  type: "named",
                  positionalArgs: [],
                  namedArgs: {
                    height: __bstack.locals.inputHeight
                  },
                  blockArg: __AgencyFunction.create({ name: "__block_3", module: "stdlib/ui.agency", fn: async (inputRow) => {
                    const __bsetup2 = setupFunction();
                    const __bstack2 = __bsetup2.stack;
                    const __self3 = __bstack2.locals;
                    const __bframe___block_3 = __bstack2;
                    __bstack2.args["inputRow"] = inputRow;
                    const runner5 = new Runner(__ctx, __bstack2, { state: __bstack2, moduleId: "stdlib/ui.agency", scopeName: "__block_3" });
                    try {
                      await runner5.step(0, async (runner6) => {
                        await __callMethod(__bstack2.args.inputRow, "line", {
                          type: "named",
                          positionalArgs: [__stack.args.state.input.prompt],
                          namedArgs: {
                            width: __stack.locals.promptWidth
                          }
                        });
                      });
                      await runner5.step(1, async (runner6) => {
                        await __callMethod(__bstack2.args.inputRow, "textInput", {
                          type: "named",
                          positionalArgs: [],
                          namedArgs: {
                            value: __stack.args.state.input.buffer,
                            flex: 1
                          }
                        });
                      });
                      return runner5.halted ? runner5.haltResult : void 0;
                    } catch (__blockError) {
                      if (__blockError instanceof AgencyAbort) {
                        return AbortedResult.fromError(__blockError, __bstack2, "__block_3");
                      }
                      throw __blockError;
                    } finally {
                      __bsetup2.stateStack.pop();
                    }
                  }, params: [{ name: "inputRow", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
                });
              });
              await runner3.step(9, async (runner4) => {
                await __callMethod(__bstack.args.mainCol, "line", {
                  type: "named",
                  positionalArgs: [``],
                  namedArgs: {
                    fill: `\u2500`,
                    fg: `gray`
                  }
                });
              });
              await runner3.step(10, async (runner4) => {
                await __callMethod(__bstack.args.mainCol, "row", {
                  type: "named",
                  positionalArgs: [],
                  namedArgs: {
                    height: 1
                  },
                  blockArg: __AgencyFunction.create({ name: "__block_4", module: "stdlib/ui.agency", fn: async (statusLine) => {
                    const __bsetup2 = setupFunction();
                    const __bstack2 = __bsetup2.stack;
                    const __self3 = __bstack2.locals;
                    const __bframe___block_4 = __bstack2;
                    __bstack2.args["statusLine"] = statusLine;
                    const runner5 = new Runner(__ctx, __bstack2, { state: __bstack2, moduleId: "stdlib/ui.agency", scopeName: "__block_4" });
                    try {
                      await runner5.step(0, async (runner6) => {
                        await __callMethod(__bstack2.args.statusLine, "line", {
                          type: "named",
                          positionalArgs: [__stack.locals.status.left],
                          namedArgs: {
                            width: __stack.locals.leftStatusWidth
                          }
                        });
                      });
                      await runner5.step(1, async (runner6) => {
                        await __callMethod(__bstack2.args.statusLine, "box", {
                          type: "named",
                          positionalArgs: [],
                          namedArgs: {
                            flex: 1
                          },
                          blockArg: __AgencyFunction.create({ name: "__block_5", module: "stdlib/ui.agency", fn: async (_) => {
                            const __bsetup3 = setupFunction();
                            const __bstack3 = __bsetup3.stack;
                            const __self4 = __bstack3.locals;
                            const __bframe___block_5 = __bstack3;
                            __bstack3.args["_"] = _;
                            const runner7 = new Runner(__ctx, __bstack3, { state: __bstack3, moduleId: "stdlib/ui.agency", scopeName: "__block_5" });
                            try {
                              return runner7.halted ? runner7.haltResult : void 0;
                            } catch (__blockError) {
                              if (__blockError instanceof AgencyAbort) {
                                return AbortedResult.fromError(__blockError, __bstack3, "__block_5");
                              }
                              throw __blockError;
                            } finally {
                              __bsetup3.stateStack.pop();
                            }
                          }, params: [{ name: "_", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
                        });
                      });
                      await runner5.step(2, async (runner6) => {
                        await __callMethod(__bstack2.args.statusLine, "line", {
                          type: "named",
                          positionalArgs: [__stack.locals.status.right],
                          namedArgs: {
                            width: __stack.locals.rightStatusWidth
                          }
                        });
                      });
                      return runner5.halted ? runner5.haltResult : void 0;
                    } catch (__blockError) {
                      if (__blockError instanceof AgencyAbort) {
                        return AbortedResult.fromError(__blockError, __bstack2, "__block_4");
                      }
                      throw __blockError;
                    } finally {
                      __bsetup2.stateStack.pop();
                    }
                  }, params: [{ name: "statusLine", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
                });
              });
              await runner3.step(11, async (runner4) => {
                await __callMethod(__bstack.args.mainCol, "line", {
                  type: "named",
                  positionalArgs: [__stack.locals.contextLine],
                  namedArgs: {
                    fg: `gray`
                  }
                });
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_1");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "mainCol", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_replView");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _replView threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_replView"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_replView",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_replView",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _replView = __AgencyFunction.create({
  name: "_replView",
  module: "stdlib/ui.agency",
  fn: ___replView_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_replView",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___submitPrompt_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_submitPrompt", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_submitPrompt",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.submittedPrompt = __stack.args.state.input.buffer;
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.nextHistory = __stack.args.state.input.history;
      });
      await runner.ifElse(3, [
        {
          condition: async () => !__eq(__stack.locals.submittedPrompt, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.nextHistory = [...__stack.args.state.input.history, __stack.locals.submittedPrompt];
            });
            await runner2.ifElse(1, [
              {
                condition: async () => __stack.locals.nextHistory.length > __stack.args.state.input.historyMax,
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __stack.locals.nextHistory = __stack.locals.nextHistory.slice(__stack.locals.nextHistory.length - __stack.args.state.input.historyMax);
                  });
                }
              }
            ]);
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __stack.locals.nextState = {
          ...__stack.args.state,
          "input": {
            ...__stack.args.state.input,
            "buffer": ``,
            "history": __stack.locals.nextHistory,
            "historyIdx": __stack.locals.nextHistory.length
          },
          "submit": {
            ...__stack.args.state.submit,
            "busy": true,
            "label": `Thinking`,
            "startedAtMs": await __call(_nowMs, {
              type: "positional",
              args: []
            })
          }
        };
      });
      await runner.step(5, async (runner2) => {
        const __funcResult = await __call(_beginSubmit, {
          type: "positional",
          args: [__stack.locals.nextState, __stack.locals.submittedPrompt, __stack.args.state.config.onSubmit]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "_submitPrompt"));
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.nextState);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_submitPrompt");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _submitPrompt threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_submitPrompt"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_submitPrompt",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_submitPrompt",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _submitPrompt = __AgencyFunction.create({
  name: "_submitPrompt",
  module: "stdlib/ui.agency",
  fn: ___submitPrompt_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_submitPrompt",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___recallPreviousHistory_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_recallPreviousHistory", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_recallPreviousHistory",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.nextHistoryIndex = __stack.args.state.input.historyIdx - 1;
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          ...__stack.args.state,
          "input": {
            ...__stack.args.state.input,
            "historyIdx": __stack.locals.nextHistoryIndex,
            "buffer": __nn(__stack.args.state.input.history[__stack.locals.nextHistoryIndex])
          }
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_recallPreviousHistory");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _recallPreviousHistory threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_recallPreviousHistory"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_recallPreviousHistory",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_recallPreviousHistory",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _recallPreviousHistory = __AgencyFunction.create({
  name: "_recallPreviousHistory",
  module: "stdlib/ui.agency",
  fn: ___recallPreviousHistory_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_recallPreviousHistory",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___recallNextHistory_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_recallNextHistory", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_recallNextHistory",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.nextHistoryIndex = __stack.args.state.input.historyIdx + 1;
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.nextBuffer = ``;
      });
      await runner.ifElse(3, [
        {
          condition: async () => __stack.locals.nextHistoryIndex < __stack.args.state.input.history.length,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.nextBuffer = __nn(__stack.args.state.input.history[__stack.locals.nextHistoryIndex]);
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          ...__stack.args.state,
          "input": {
            ...__stack.args.state.input,
            "historyIdx": __stack.locals.nextHistoryIndex,
            "buffer": __stack.locals.nextBuffer
          }
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_recallNextHistory");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _recallNextHistory threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_recallNextHistory"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_recallNextHistory",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_recallNextHistory",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _recallNextHistory = __AgencyFunction.create({
  name: "_recallNextHistory",
  module: "stdlib/ui.agency",
  fn: ___recallNextHistory_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_recallNextHistory",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___closePalette_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_closePalette", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_closePalette",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          ...__stack.args.state,
          "palette": {
            ...__stack.args.state.palette,
            "open": false,
            "filter": ``,
            "cursor": 0
          }
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_closePalette");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _closePalette threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_closePalette"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_closePalette",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_closePalette",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _closePalette = __AgencyFunction.create({
  name: "_closePalette",
  module: "stdlib/ui.agency",
  fn: ___closePalette_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_closePalette",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___selectPaletteCommand_impl(state, paletteKeys) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["paletteKeys"] = paletteKeys;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_selectPaletteCommand", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("paletteKeys" in __overrides) {
      paletteKeys = __overrides["paletteKeys"];
      __stack.args["paletteKeys"] = paletteKeys;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_selectPaletteCommand",
            args: {
              state,
              paletteKeys
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.paletteKeys.length, 0),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await __call(_closePalette, {
                type: "positional",
                args: [__stack.args.state]
              }));
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          ...__stack.args.state,
          "input": {
            ...__stack.args.state.input,
            "buffer": __nn(__stack.args.paletteKeys[__stack.args.state.palette.cursor])
          },
          "palette": {
            ...__stack.args.state.palette,
            "open": false,
            "filter": ``,
            "cursor": 0
          }
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_selectPaletteCommand");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _selectPaletteCommand threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_selectPaletteCommand"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_selectPaletteCommand",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_selectPaletteCommand",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _selectPaletteCommand = __AgencyFunction.create({
  name: "_selectPaletteCommand",
  module: "stdlib/ui.agency",
  fn: ___selectPaletteCommand_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "paletteKeys",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_selectPaletteCommand",
    description: "No description provided.",
    schema: z.object({ "state": ReplState, "paletteKeys": z.array(z.string()) })
  },
  exported: false
}, __toolRegistry);
async function ___movePaletteCursor_impl(state, paletteKeys, delta) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["paletteKeys"] = paletteKeys;
  __stack.args["delta"] = delta;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_movePaletteCursor", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("paletteKeys" in __overrides) {
      paletteKeys = __overrides["paletteKeys"];
      __stack.args["paletteKeys"] = paletteKeys;
    }
    if ("delta" in __overrides) {
      delta = __overrides["delta"];
      __stack.args["delta"] = delta;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_movePaletteCursor",
            args: {
              state,
              paletteKeys,
              delta
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.nextCursor = __stack.args.state.palette.cursor + __stack.args.delta;
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.maxCursor = __stack.args.paletteKeys.length - 1;
      });
      await runner.ifElse(3, [
        {
          condition: async () => __stack.locals.nextCursor > __stack.locals.maxCursor,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.nextCursor = __stack.locals.maxCursor;
            });
          }
        }
      ]);
      await runner.ifElse(4, [
        {
          condition: async () => __stack.locals.nextCursor < 0,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.nextCursor = 0;
            });
          }
        }
      ]);
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          ...__stack.args.state,
          "palette": {
            ...__stack.args.state.palette,
            "cursor": __stack.locals.nextCursor
          }
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_movePaletteCursor");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _movePaletteCursor threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_movePaletteCursor"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_movePaletteCursor",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_movePaletteCursor",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _movePaletteCursor = __AgencyFunction.create({
  name: "_movePaletteCursor",
  module: "stdlib/ui.agency",
  fn: ___movePaletteCursor_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "paletteKeys",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "delta",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_movePaletteCursor",
    description: "No description provided.",
    schema: z.object({ "state": ReplState, "paletteKeys": z.array(z.string()), "delta": z.number() })
  },
  exported: false
}, __toolRegistry);
async function ___removePaletteFilterCharacter_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_removePaletteFilterCharacter", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_removePaletteFilterCharacter",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          ...__stack.args.state,
          "palette": {
            ...__stack.args.state.palette,
            "filter": __stack.args.state.palette.filter.slice(0, __stack.args.state.palette.filter.length - 1),
            "cursor": 0
          }
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_removePaletteFilterCharacter");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _removePaletteFilterCharacter threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_removePaletteFilterCharacter"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_removePaletteFilterCharacter",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_removePaletteFilterCharacter",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _removePaletteFilterCharacter = __AgencyFunction.create({
  name: "_removePaletteFilterCharacter",
  module: "stdlib/ui.agency",
  fn: ___removePaletteFilterCharacter_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_removePaletteFilterCharacter",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___appendPaletteFilterCharacter_impl(state, character) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["character"] = character;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_appendPaletteFilterCharacter", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("character" in __overrides) {
      character = __overrides["character"];
      __stack.args["character"] = character;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_appendPaletteFilterCharacter",
            args: {
              state,
              character
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          ...__stack.args.state,
          "palette": {
            ...__stack.args.state.palette,
            "filter": __stack.args.state.palette.filter + __stack.args.character,
            "cursor": 0
          }
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_appendPaletteFilterCharacter");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _appendPaletteFilterCharacter threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_appendPaletteFilterCharacter"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_appendPaletteFilterCharacter",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_appendPaletteFilterCharacter",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _appendPaletteFilterCharacter = __AgencyFunction.create({
  name: "_appendPaletteFilterCharacter",
  module: "stdlib/ui.agency",
  fn: ___appendPaletteFilterCharacter_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "character",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_appendPaletteFilterCharacter",
    description: "No description provided.",
    schema: z.object({ "state": ReplState, "character": z.string() })
  },
  exported: false
}, __toolRegistry);
async function ___replReducePaletteOpen_impl(state, keyEvent) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["keyEvent"] = keyEvent;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_replReducePaletteOpen", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("keyEvent" in __overrides) {
      keyEvent = __overrides["keyEvent"];
      __stack.args["keyEvent"] = keyEvent;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_replReducePaletteOpen",
            args: {
              state,
              keyEvent
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.paletteKeys = await __call(_filteredPaletteKeys, {
          type: "positional",
          args: [__stack.args.state]
        });
        if (hasInterrupts(__stack.locals.paletteKeys)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.paletteKeys);
          return;
        }
        if (isAborted(__stack.locals.paletteKeys)) {
          runner2.halt(__stack.locals.paletteKeys.carryThrough(__stack, "_replReducePaletteOpen"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.__scrutinee_11 = __stack.args.keyEvent;
      });
      await runner.ifElse(3, [
        {
          condition: async () => __eq(__stack.locals.__scrutinee_11.key, `escape`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.__armval_2 = await __call(_closePalette, {
                type: "positional",
                args: [__stack.args.state]
              });
              if (hasInterrupts(__stack.locals.__armval_2)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_2);
                return;
              }
              if (isAborted(__stack.locals.__armval_2)) {
                runner3.halt(__stack.locals.__armval_2.carryThrough(__stack, "_replReducePaletteOpen"));
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_2);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_11.key, `up`),
          body: async (runner2) => {
            await runner2.step(2, async (runner3) => {
              __stack.locals.__armval_3 = await __call(_movePaletteCursor, {
                type: "positional",
                args: [__stack.args.state, __stack.locals.paletteKeys, -1]
              });
              if (hasInterrupts(__stack.locals.__armval_3)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_3);
                return;
              }
              if (isAborted(__stack.locals.__armval_3)) {
                runner3.halt(__stack.locals.__armval_3.carryThrough(__stack, "_replReducePaletteOpen"));
                return;
              }
            });
            await runner2.step(3, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_3);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_11.key, `down`),
          body: async (runner2) => {
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_4 = await __call(_movePaletteCursor, {
                type: "positional",
                args: [__stack.args.state, __stack.locals.paletteKeys, 1]
              });
              if (hasInterrupts(__stack.locals.__armval_4)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_4);
                return;
              }
              if (isAborted(__stack.locals.__armval_4)) {
                runner3.halt(__stack.locals.__armval_4.carryThrough(__stack, "_replReducePaletteOpen"));
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_4);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_11.key, `enter`),
          body: async (runner2) => {
            await runner2.step(6, async (runner3) => {
              __stack.locals.__armval_5 = await __call(_selectPaletteCommand, {
                type: "positional",
                args: [__stack.args.state, __stack.locals.paletteKeys]
              });
              if (hasInterrupts(__stack.locals.__armval_5)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_5);
                return;
              }
              if (isAborted(__stack.locals.__armval_5)) {
                runner3.halt(__stack.locals.__armval_5.carryThrough(__stack, "_replReducePaletteOpen"));
                return;
              }
            });
            await runner2.step(7, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_5);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_11.key, `tab`),
          body: async (runner2) => {
            await runner2.step(8, async (runner3) => {
              __stack.locals.__armval_6 = await __call(_selectPaletteCommand, {
                type: "positional",
                args: [__stack.args.state, __stack.locals.paletteKeys]
              });
              if (hasInterrupts(__stack.locals.__armval_6)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_6);
                return;
              }
              if (isAborted(__stack.locals.__armval_6)) {
                runner3.halt(__stack.locals.__armval_6.carryThrough(__stack, "_replReducePaletteOpen"));
                return;
              }
            });
            await runner2.step(9, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_6);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_11.key, `backspace`) && __eq(__stack.args.state.palette.filter, ``),
          body: async (runner2) => {
            await runner2.step(10, async (runner3) => {
              __stack.locals.__armval_7 = await __call(_closePalette, {
                type: "positional",
                args: [__stack.args.state]
              });
              if (hasInterrupts(__stack.locals.__armval_7)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_7);
                return;
              }
              if (isAborted(__stack.locals.__armval_7)) {
                runner3.halt(__stack.locals.__armval_7.carryThrough(__stack, "_replReducePaletteOpen"));
                return;
              }
            });
            await runner2.step(11, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_7);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_11.key, `backspace`),
          body: async (runner2) => {
            await runner2.step(12, async (runner3) => {
              __stack.locals.__armval_8 = await __call(_removePaletteFilterCharacter, {
                type: "positional",
                args: [__stack.args.state]
              });
              if (hasInterrupts(__stack.locals.__armval_8)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_8);
                return;
              }
              if (isAborted(__stack.locals.__armval_8)) {
                runner3.halt(__stack.locals.__armval_8.carryThrough(__stack, "_replReducePaletteOpen"));
                return;
              }
            });
            await runner2.step(13, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_8);
              return;
            });
          }
        },
        {
          condition: async () => true,
          body: async (runner2) => {
            await runner2.step(14, async (runner3) => {
              __stack.locals.key = __stack.locals.__scrutinee_11.key;
            });
            await runner2.ifElse(15, [
              {
                condition: async () => __eq(__stack.locals.key.length, 1),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __stack.locals.__armval_9 = await __call(_appendPaletteFilterCharacter, {
                      type: "positional",
                      args: [__stack.args.state, __stack.locals.key]
                    });
                    if (hasInterrupts(__stack.locals.__armval_9)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner4.halt(__stack.locals.__armval_9);
                      return;
                    }
                    if (isAborted(__stack.locals.__armval_9)) {
                      runner4.halt(__stack.locals.__armval_9.carryThrough(__stack, "_replReducePaletteOpen"));
                      return;
                    }
                  });
                  await runner3.step(1, async (runner4) => {
                    runner4.exitMatch(1, __stack.locals.__armval_9);
                    return;
                  });
                }
              },
              {
                condition: async () => true,
                body: async (runner3) => {
                  await runner3.step(2, async (runner4) => {
                    __stack.locals.__armval_10 = __stack.args.state;
                  });
                  await runner3.step(3, async (runner4) => {
                    runner4.exitMatch(1, __stack.locals.__armval_10);
                    return;
                  });
                }
              }
            ]);
          }
        },
        {
          condition: async () => true,
          body: async (runner2) => {
            await runner2.step(16, async (runner3) => {
              __stack.locals.__armval_10 = __stack.args.state;
            });
            await runner2.step(17, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_10);
              return;
            });
          }
        }
      ], void 0, { matchId: 1 });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_replReducePaletteOpen");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _replReducePaletteOpen threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_replReducePaletteOpen"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_replReducePaletteOpen",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_replReducePaletteOpen",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _replReducePaletteOpen = __AgencyFunction.create({
  name: "_replReducePaletteOpen",
  module: "stdlib/ui.agency",
  fn: ___replReducePaletteOpen_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "keyEvent",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_replReducePaletteOpen",
    description: "No description provided.",
    schema: z.object({ "state": ReplState, "keyEvent": KeyEvent })
  },
  exported: false
}, __toolRegistry);
async function ___appendInputCharacter_impl(state, character) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["character"] = character;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_appendInputCharacter", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("character" in __overrides) {
      character = __overrides["character"];
      __stack.args["character"] = character;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_appendInputCharacter",
            args: {
              state,
              character
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          ...__stack.args.state,
          "input": {
            ...__stack.args.state.input,
            "buffer": __stack.args.state.input.buffer + __stack.args.character
          }
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_appendInputCharacter");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _appendInputCharacter threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_appendInputCharacter"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_appendInputCharacter",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_appendInputCharacter",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _appendInputCharacter = __AgencyFunction.create({
  name: "_appendInputCharacter",
  module: "stdlib/ui.agency",
  fn: ___appendInputCharacter_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "character",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_appendInputCharacter",
    description: "No description provided.",
    schema: z.object({ "state": ReplState, "character": z.string() })
  },
  exported: false
}, __toolRegistry);
async function ___pasteText_impl(keyEvent) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["keyEvent"] = keyEvent;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_pasteText", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("keyEvent" in __overrides) {
      keyEvent = __overrides["keyEvent"];
      __stack.args["keyEvent"] = keyEvent;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_pasteText",
            args: {
              keyEvent
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.keyEvent.text, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(``);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.args.keyEvent.text);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_pasteText");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _pasteText threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_pasteText"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_pasteText",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_pasteText",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _pasteText = __AgencyFunction.create({
  name: "_pasteText",
  module: "stdlib/ui.agency",
  fn: ___pasteText_impl,
  params: [{
    name: "keyEvent",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "_pasteText",
    description: "No description provided.",
    schema: z.object({ "keyEvent": z.any() })
  },
  exported: false
}, __toolRegistry);
async function ___appendPaste_impl(state, pasted) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["pasted"] = pasted;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_appendPaste", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("pasted" in __overrides) {
      pasted = __overrides["pasted"];
      __stack.args["pasted"] = pasted;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_appendPaste",
            args: {
              state,
              pasted
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.normalized = await __callMethod(__stack.args.pasted, "replaceAll", {
          type: "positional",
          args: [`\r
`, `
`]
        });
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.normalized = await __callMethod(__stack.locals.normalized, "replaceAll", {
          type: "positional",
          args: [`\r`, `
`]
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          ...__stack.args.state,
          "input": {
            ...__stack.args.state.input,
            "buffer": __stack.args.state.input.buffer + __stack.locals.normalized
          }
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_appendPaste");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _appendPaste threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_appendPaste"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_appendPaste",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_appendPaste",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _appendPaste = __AgencyFunction.create({
  name: "_appendPaste",
  module: "stdlib/ui.agency",
  fn: ___appendPaste_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "pasted",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_appendPaste",
    description: "No description provided.",
    schema: z.object({ "state": ReplState, "pasted": z.string() })
  },
  exported: false
}, __toolRegistry);
async function ___clearInputBuffer_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_clearInputBuffer", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_clearInputBuffer",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          ...__stack.args.state,
          "input": {
            ...__stack.args.state.input,
            "buffer": ``
          }
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_clearInputBuffer");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _clearInputBuffer threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_clearInputBuffer"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_clearInputBuffer",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_clearInputBuffer",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _clearInputBuffer = __AgencyFunction.create({
  name: "_clearInputBuffer",
  module: "stdlib/ui.agency",
  fn: ___clearInputBuffer_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_clearInputBuffer",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___removeInputCharacter_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_removeInputCharacter", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_removeInputCharacter",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          ...__stack.args.state,
          "input": {
            ...__stack.args.state.input,
            "buffer": __stack.args.state.input.buffer.slice(0, __stack.args.state.input.buffer.length - 1)
          }
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_removeInputCharacter");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _removeInputCharacter threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_removeInputCharacter"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_removeInputCharacter",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_removeInputCharacter",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _removeInputCharacter = __AgencyFunction.create({
  name: "_removeInputCharacter",
  module: "stdlib/ui.agency",
  fn: ___removeInputCharacter_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_removeInputCharacter",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___openPalette_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_openPalette", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_openPalette",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          ...__stack.args.state,
          "palette": {
            ...__stack.args.state.palette,
            "open": true,
            "filter": ``,
            "cursor": 0
          }
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_openPalette");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _openPalette threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_openPalette"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_openPalette",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_openPalette",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _openPalette = __AgencyFunction.create({
  name: "_openPalette",
  module: "stdlib/ui.agency",
  fn: ___openPalette_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_openPalette",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___filteredChoiceItems_impl(choice) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["choice"] = choice;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_filteredChoiceItems", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("choice" in __overrides) {
      choice = __overrides["choice"];
      __stack.args["choice"] = choice;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_filteredChoiceItems",
            args: {
              choice
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.choice.filter, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.args.choice.items);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __stack.locals.needle = await __callMethod(__stack.args.choice.filter, "toLowerCase", {
          type: "positional",
          args: []
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(filter, {
          type: "positional",
          args: [__stack.args.choice.items, await __callMethod(_matchesChoiceFilter, "partial", {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              needle: __stack.locals.needle
            }
          })]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_filteredChoiceItems");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _filteredChoiceItems threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_filteredChoiceItems"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_filteredChoiceItems",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_filteredChoiceItems",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _filteredChoiceItems = __AgencyFunction.create({
  name: "_filteredChoiceItems",
  module: "stdlib/ui.agency",
  fn: ___filteredChoiceItems_impl,
  params: [{
    name: "choice",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_filteredChoiceItems",
    description: "No description provided.",
    schema: z.object({ "choice": ReplChoiceState })
  },
  exported: false
}, __toolRegistry);
async function ___matchesChoiceFilter_impl(item, needle) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["item"] = item;
  __stack.args["needle"] = needle;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_matchesChoiceFilter", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("item" in __overrides) {
      item = __overrides["item"];
      __stack.args["item"] = item;
    }
    if ("needle" in __overrides) {
      needle = __overrides["needle"];
      __stack.args["needle"] = needle;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_matchesChoiceFilter",
            args: {
              item,
              needle
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(await __callMethod(__stack.args.item.label, "toLowerCase", {
          type: "positional",
          args: []
        }), "includes", {
          type: "positional",
          args: [__stack.args.needle]
        }) || await __callMethod(await __callMethod(__stack.args.item.key, "toLowerCase", {
          type: "positional",
          args: []
        }), "includes", {
          type: "positional",
          args: [__stack.args.needle]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_matchesChoiceFilter");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _matchesChoiceFilter threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_matchesChoiceFilter"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_matchesChoiceFilter",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_matchesChoiceFilter",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _matchesChoiceFilter = __AgencyFunction.create({
  name: "_matchesChoiceFilter",
  module: "stdlib/ui.agency",
  fn: ___matchesChoiceFilter_impl,
  params: [{
    name: "item",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "needle",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_matchesChoiceFilter",
    description: "No description provided.",
    schema: z.object({ "item": ChoiceItem, "needle": z.string() })
  },
  exported: false
}, __toolRegistry);
async function ___replReduceChoice_impl(state, keyEvent) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["keyEvent"] = keyEvent;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_replReduceChoice", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("keyEvent" in __overrides) {
      keyEvent = __overrides["keyEvent"];
      __stack.args["keyEvent"] = keyEvent;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_replReduceChoice",
            args: {
              state,
              keyEvent
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.choice = __stack.args.state.choice;
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.visibleItems = await __call(_filteredChoiceItems, {
          type: "positional",
          args: [__stack.locals.choice]
        });
        if (hasInterrupts(__stack.locals.visibleItems)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.visibleItems);
          return;
        }
        if (isAborted(__stack.locals.visibleItems)) {
          runner2.halt(__stack.locals.visibleItems.carryThrough(__stack, "_replReduceChoice"));
          return;
        }
      });
      await runner.ifElse(4, [
        {
          condition: async () => __eq(__stack.args.keyEvent.key, `escape`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(_cancelChoice, {
                type: "positional",
                args: [`user cancelled`]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "_replReduceChoice"));
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                ...__stack.args.state,
                "choice": null
              });
              return;
            });
          }
        }
      ]);
      await runner.ifElse(5, [
        {
          condition: async () => __eq(__stack.args.keyEvent.key, `enter`),
          body: async (runner2) => {
            await runner2.ifElse(0, [
              {
                condition: async () => __eq(__stack.locals.visibleItems.length, 0),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                  });
                  await runner3.ifElse(1, [
                    {
                      condition: async () => __stack.locals.choice.allowFreeText && !__eq(__stack.locals.choice.filter, ``),
                      body: async (runner4) => {
                        await runner4.step(0, async (runner5) => {
                          const __funcResult = await __call(_resolveChoice, {
                            type: "positional",
                            args: [__stack.locals.choice.filter]
                          });
                          if (hasInterrupts(__funcResult)) {
                            await getRuntimeContext().ctx.pendingPromises.awaitAll();
                            runner5.halt(__funcResult);
                            return;
                          }
                          if (isAborted(__funcResult)) {
                            runner5.halt(__funcResult.carryThrough(__stack, "_replReduceChoice"));
                            return;
                          }
                        });
                        await runner4.step(1, async (runner5) => {
                          __functionCompleted = true;
                          runner5.halt({
                            ...__stack.args.state,
                            "choice": null
                          });
                          return;
                        });
                      }
                    }
                  ]);
                  await runner3.step(2, async (runner4) => {
                    __functionCompleted = true;
                    runner4.halt(__stack.args.state);
                    return;
                  });
                }
              }
            ]);
            await runner2.step(1, async (runner3) => {
              __stack.locals.cursor = __stack.locals.choice.cursor;
            });
            await runner2.ifElse(2, [
              {
                condition: async () => __stack.locals.cursor >= __stack.locals.visibleItems.length,
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __stack.locals.cursor = __stack.locals.visibleItems.length - 1;
                  });
                }
              }
            ]);
            await runner2.step(3, async (runner3) => {
              const __funcResult = await __call(_resolveChoice, {
                type: "positional",
                args: [__stack.locals.visibleItems[__stack.locals.cursor].key]
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "_replReduceChoice"));
                return;
              }
            });
            await runner2.step(4, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                ...__stack.args.state,
                "choice": null
              });
              return;
            });
          }
        }
      ]);
      await runner.ifElse(6, [
        {
          condition: async () => __eq(__stack.args.keyEvent.key, `up`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.cursor = __stack.locals.choice.cursor - 1;
            });
            await runner2.ifElse(1, [
              {
                condition: async () => __stack.locals.cursor < 0,
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __stack.locals.cursor = 0;
                  });
                }
              }
            ]);
            await runner2.step(2, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                ...__stack.args.state,
                "choice": {
                  ...__stack.locals.choice,
                  "cursor": __stack.locals.cursor
                }
              });
              return;
            });
          }
        }
      ]);
      await runner.ifElse(7, [
        {
          condition: async () => __eq(__stack.args.keyEvent.key, `down`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.cursor = __stack.locals.choice.cursor + 1;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.maxCursor = __stack.locals.visibleItems.length - 1;
            });
            await runner2.ifElse(2, [
              {
                condition: async () => __stack.locals.cursor > __stack.locals.maxCursor,
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __stack.locals.cursor = __stack.locals.maxCursor;
                  });
                }
              }
            ]);
            await runner2.ifElse(3, [
              {
                condition: async () => __stack.locals.cursor < 0,
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __stack.locals.cursor = 0;
                  });
                }
              }
            ]);
            await runner2.step(4, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                ...__stack.args.state,
                "choice": {
                  ...__stack.locals.choice,
                  "cursor": __stack.locals.cursor
                }
              });
              return;
            });
          }
        }
      ]);
      await runner.ifElse(8, [
        {
          condition: async () => __eq(__stack.args.keyEvent.key, `backspace`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.currentFilter = __stack.locals.choice.filter;
            });
            await runner2.ifElse(1, [
              {
                condition: async () => __eq(__stack.locals.currentFilter, ``),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __functionCompleted = true;
                    runner4.halt(__stack.args.state);
                    return;
                  });
                }
              }
            ]);
            await runner2.step(2, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                ...__stack.args.state,
                "choice": {
                  ...__stack.locals.choice,
                  "filter": __stack.locals.currentFilter.slice(0, __stack.locals.currentFilter.length - 1),
                  "cursor": 0
                }
              });
              return;
            });
          }
        }
      ]);
      await runner.ifElse(9, [
        {
          condition: async () => __eq(__stack.args.keyEvent.key.length, 1),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                ...__stack.args.state,
                "choice": {
                  ...__stack.locals.choice,
                  "filter": __stack.locals.choice.filter + __stack.args.keyEvent.key,
                  "cursor": 0
                }
              });
              return;
            });
          }
        }
      ]);
      await runner.step(10, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.args.state);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_replReduceChoice");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _replReduceChoice threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_replReduceChoice"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_replReduceChoice",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_replReduceChoice",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _replReduceChoice = __AgencyFunction.create({
  name: "_replReduceChoice",
  module: "stdlib/ui.agency",
  fn: ___replReduceChoice_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "keyEvent",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_replReduceChoice",
    description: "No description provided.",
    schema: z.object({ "state": ReplState, "keyEvent": KeyEvent })
  },
  exported: false
}, __toolRegistry);
async function ___syncChoiceFromBridge_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_syncChoiceFromBridge", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_syncChoiceFromBridge",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.tsRequest = await __call(_peekPendingChoiceRequest, {
          type: "positional",
          args: []
        });
        if (hasInterrupts(__stack.locals.tsRequest)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.tsRequest);
          return;
        }
        if (isAborted(__stack.locals.tsRequest)) {
          runner2.halt(__stack.locals.tsRequest.carryThrough(__stack, "_syncChoiceFromBridge"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.locals.tsRequest, null) && __eq(__stack.args.state.choice, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                ...__stack.args.state,
                "choice": {
                  "title": __stack.locals.tsRequest.title,
                  "body": __stack.locals.tsRequest.body,
                  "items": __stack.locals.tsRequest.items,
                  "allowFreeText": __eq(__stack.locals.tsRequest.allowFreeText, true),
                  "filter": ``,
                  "cursor": 0
                }
              });
              return;
            });
          }
        }
      ]);
      await runner.ifElse(3, [
        {
          condition: async () => __eq(__stack.locals.tsRequest, null) && !__eq(__stack.args.state.choice, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt({
                ...__stack.args.state,
                "choice": null
              });
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.args.state);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_syncChoiceFromBridge");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _syncChoiceFromBridge threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_syncChoiceFromBridge"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_syncChoiceFromBridge",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_syncChoiceFromBridge",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _syncChoiceFromBridge = __AgencyFunction.create({
  name: "_syncChoiceFromBridge",
  module: "stdlib/ui.agency",
  fn: ___syncChoiceFromBridge_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_syncChoiceFromBridge",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function ___replReduce_impl(replState, keyEvent) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["replState"] = replState;
  __stack.args["keyEvent"] = keyEvent;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_replReduce", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("replState" in __overrides) {
      replState = __overrides["replState"];
      __stack.args["replState"] = replState;
    }
    if ("keyEvent" in __overrides) {
      keyEvent = __overrides["keyEvent"];
      __stack.args["keyEvent"] = keyEvent;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_replReduce",
            args: {
              replState,
              keyEvent
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.state = await __call(_syncChoiceFromBridge, {
          type: "positional",
          args: [__stack.args.replState]
        });
        if (hasInterrupts(__stack.locals.state)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.state);
          return;
        }
        if (isAborted(__stack.locals.state)) {
          runner2.halt(__stack.locals.state.carryThrough(__stack, "_replReduce"));
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.locals.state.choice, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await __call(_replReduceChoice, {
                type: "positional",
                args: [__stack.locals.state, __stack.args.keyEvent]
              }));
              return;
            });
          }
        }
      ]);
      await runner.ifElse(3, [
        {
          condition: async () => __stack.locals.state.palette.open,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(await __call(_replReducePaletteOpen, {
                type: "positional",
                args: [__stack.locals.state, __stack.args.keyEvent]
              }));
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __stack.locals.__scrutinee_25 = __stack.args.keyEvent;
      });
      await runner.ifElse(5, [
        {
          condition: async () => __eq(__stack.locals.__scrutinee_25.ctrl, true) && __eq(__stack.locals.__scrutinee_25.key, `c`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.__armval_13 = {
                ...__stack.locals.state,
                "done": true
              };
            });
            await runner2.step(1, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_13);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_25.ctrl, true) && __eq(__stack.locals.__scrutinee_25.key, `u`),
          body: async (runner2) => {
            await runner2.step(2, async (runner3) => {
              __stack.locals.__armval_14 = await __call(_clearInputBuffer, {
                type: "positional",
                args: [__stack.locals.state]
              });
              if (hasInterrupts(__stack.locals.__armval_14)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_14);
                return;
              }
              if (isAborted(__stack.locals.__armval_14)) {
                runner3.halt(__stack.locals.__armval_14.carryThrough(__stack, "_replReduce"));
                return;
              }
            });
            await runner2.step(3, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_14);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_25.key, `paste`),
          body: async (runner2) => {
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_15 = await __call(_appendPaste, {
                type: "positional",
                args: [__stack.locals.state, await __call(_pasteText, {
                  type: "positional",
                  args: [__stack.args.keyEvent]
                })]
              });
              if (hasInterrupts(__stack.locals.__armval_15)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_15);
                return;
              }
              if (isAborted(__stack.locals.__armval_15)) {
                runner3.halt(__stack.locals.__armval_15.carryThrough(__stack, "_replReduce"));
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_15);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_25.key, `/`) && __eq(__stack.locals.state.input.buffer, ``),
          body: async (runner2) => {
            await runner2.step(6, async (runner3) => {
              __stack.locals.__armval_16 = await __call(_openPalette, {
                type: "positional",
                args: [__stack.locals.state]
              });
              if (hasInterrupts(__stack.locals.__armval_16)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_16);
                return;
              }
              if (isAborted(__stack.locals.__armval_16)) {
                runner3.halt(__stack.locals.__armval_16.carryThrough(__stack, "_replReduce"));
                return;
              }
            });
            await runner2.step(7, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_16);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_25.key, `up`) && __stack.locals.state.input.historyIdx > 0,
          body: async (runner2) => {
            await runner2.step(8, async (runner3) => {
              __stack.locals.__armval_17 = await __call(_recallPreviousHistory, {
                type: "positional",
                args: [__stack.locals.state]
              });
              if (hasInterrupts(__stack.locals.__armval_17)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_17);
                return;
              }
              if (isAborted(__stack.locals.__armval_17)) {
                runner3.halt(__stack.locals.__armval_17.carryThrough(__stack, "_replReduce"));
                return;
              }
            });
            await runner2.step(9, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_17);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_25.key, `down`) && __stack.locals.state.input.historyIdx < __stack.locals.state.input.history.length,
          body: async (runner2) => {
            await runner2.step(10, async (runner3) => {
              __stack.locals.__armval_18 = await __call(_recallNextHistory, {
                type: "positional",
                args: [__stack.locals.state]
              });
              if (hasInterrupts(__stack.locals.__armval_18)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_18);
                return;
              }
              if (isAborted(__stack.locals.__armval_18)) {
                runner3.halt(__stack.locals.__armval_18.carryThrough(__stack, "_replReduce"));
                return;
              }
            });
            await runner2.step(11, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_18);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_25.key, `backspace`) && !__eq(__stack.locals.state.input.buffer, ``),
          body: async (runner2) => {
            await runner2.step(12, async (runner3) => {
              __stack.locals.__armval_19 = await __call(_removeInputCharacter, {
                type: "positional",
                args: [__stack.locals.state]
              });
              if (hasInterrupts(__stack.locals.__armval_19)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_19);
                return;
              }
              if (isAborted(__stack.locals.__armval_19)) {
                runner3.halt(__stack.locals.__armval_19.carryThrough(__stack, "_replReduce"));
                return;
              }
            });
            await runner2.step(13, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_19);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_25.key, `enter`) && __eq(__stack.locals.__scrutinee_25.shift, true),
          body: async (runner2) => {
            await runner2.step(14, async (runner3) => {
              __stack.locals.__armval_20 = await __call(_appendInputCharacter, {
                type: "positional",
                args: [__stack.locals.state, `
`]
              });
              if (hasInterrupts(__stack.locals.__armval_20)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_20);
                return;
              }
              if (isAborted(__stack.locals.__armval_20)) {
                runner3.halt(__stack.locals.__armval_20.carryThrough(__stack, "_replReduce"));
                return;
              }
            });
            await runner2.step(15, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_20);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_25.key, `enter`) && __eq(__stack.locals.state.input.buffer, ``),
          body: async (runner2) => {
            await runner2.step(16, async (runner3) => {
              __stack.locals.__armval_21 = __stack.locals.state;
            });
            await runner2.step(17, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_21);
              return;
            });
          }
        },
        {
          condition: async () => __eq(__stack.locals.__scrutinee_25.key, `enter`),
          body: async (runner2) => {
            await runner2.step(18, async (runner3) => {
              __stack.locals.__armval_22 = await __call(_submitPrompt, {
                type: "positional",
                args: [__stack.locals.state]
              });
              if (hasInterrupts(__stack.locals.__armval_22)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_22);
                return;
              }
              if (isAborted(__stack.locals.__armval_22)) {
                runner3.halt(__stack.locals.__armval_22.carryThrough(__stack, "_replReduce"));
                return;
              }
            });
            await runner2.step(19, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_22);
              return;
            });
          }
        },
        {
          condition: async () => true,
          body: async (runner2) => {
            await runner2.step(20, async (runner3) => {
              __stack.locals.key = __stack.locals.__scrutinee_25.key;
            });
            await runner2.ifElse(21, [
              {
                condition: async () => __eq(__stack.locals.key.length, 1),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    __stack.locals.__armval_23 = await __call(_appendInputCharacter, {
                      type: "positional",
                      args: [__stack.locals.state, __stack.locals.key]
                    });
                    if (hasInterrupts(__stack.locals.__armval_23)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner4.halt(__stack.locals.__armval_23);
                      return;
                    }
                    if (isAborted(__stack.locals.__armval_23)) {
                      runner4.halt(__stack.locals.__armval_23.carryThrough(__stack, "_replReduce"));
                      return;
                    }
                  });
                  await runner3.step(1, async (runner4) => {
                    runner4.exitMatch(12, __stack.locals.__armval_23);
                    return;
                  });
                }
              },
              {
                condition: async () => true,
                body: async (runner3) => {
                  await runner3.step(2, async (runner4) => {
                    __stack.locals.__armval_24 = __stack.locals.state;
                  });
                  await runner3.step(3, async (runner4) => {
                    runner4.exitMatch(12, __stack.locals.__armval_24);
                    return;
                  });
                }
              }
            ]);
          }
        },
        {
          condition: async () => true,
          body: async (runner2) => {
            await runner2.step(22, async (runner3) => {
              __stack.locals.__armval_24 = __stack.locals.state;
            });
            await runner2.step(23, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_24);
              return;
            });
          }
        }
      ], void 0, { matchId: 12 });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_12));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_replReduce");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _replReduce threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_replReduce"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_replReduce",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_replReduce",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _replReduce = __AgencyFunction.create({
  name: "_replReduce",
  module: "stdlib/ui.agency",
  fn: ___replReduce_impl,
  params: [{
    name: "replState",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "keyEvent",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_replReduce",
    description: "No description provided.",
    schema: z.object({ "replState": ReplState, "keyEvent": KeyEvent })
  },
  exported: false
}, __toolRegistry);
async function ___replIsDone_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "_replIsDone", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "_replIsDone",
            args: {
              state
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.ifElse(2, [
        {
          condition: async () => await __call(_peekReplExitSignal, {
            type: "positional",
            args: []
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(true);
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.args.state.done);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "_replIsDone");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function _replIsDone threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "_replIsDone"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "_replIsDone",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "_replIsDone",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const _replIsDone = __AgencyFunction.create({
  name: "_replIsDone",
  module: "stdlib/ui.agency",
  fn: ___replIsDone_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "_replIsDone",
    description: "No description provided.",
    schema: z.object({ "state": ReplState })
  },
  exported: false
}, __toolRegistry);
async function __repl_impl(status, onSubmit, prompt2 = __UNSET, historyFile = __UNSET, historyMax = __UNSET, paletteCommands = __UNSET, tickMs = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/ui.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["status"] = status;
  __stack.args["onSubmit"] = onSubmit;
  __stack.args["prompt"] = prompt2 === __UNSET ? `> ` : prompt2;
  __stack.args["historyFile"] = historyFile === __UNSET ? `` : historyFile;
  __stack.args["historyMax"] = historyMax === __UNSET ? 1e3 : historyMax;
  __stack.args["paletteCommands"] = paletteCommands === __UNSET ? null : paletteCommands;
  __stack.args["tickMs"] = tickMs === __UNSET ? null : tickMs;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/ui.agency", scopeName: "repl", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("status" in __overrides) {
      status = __overrides["status"];
      __stack.args["status"] = status;
    }
    if ("onSubmit" in __overrides) {
      onSubmit = __overrides["onSubmit"];
      __stack.args["onSubmit"] = onSubmit;
    }
    if ("prompt" in __overrides) {
      prompt2 = __overrides["prompt"];
      __stack.args["prompt"] = prompt2;
    }
    if ("historyFile" in __overrides) {
      historyFile = __overrides["historyFile"];
      __stack.args["historyFile"] = historyFile;
    }
    if ("historyMax" in __overrides) {
      historyMax = __overrides["historyMax"];
      __stack.args["historyMax"] = historyMax;
    }
    if ("paletteCommands" in __overrides) {
      paletteCommands = __overrides["paletteCommands"];
      __stack.args["paletteCommands"] = paletteCommands;
    }
    if ("tickMs" in __overrides) {
      tickMs = __overrides["tickMs"];
      __stack.args["tickMs"] = tickMs;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "repl",
            args: {
              status,
              onSubmit,
              prompt: prompt2,
              historyFile,
              historyMax,
              paletteCommands,
              tickMs
            },
            moduleId: "stdlib/ui.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.paletteCommandMap = __stack.args.paletteCommands;
      });
      await runner.ifElse(2, [
        {
          condition: async () => __eq(__stack.locals.paletteCommandMap, null),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.paletteCommandMap = {};
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.initial = {
          "input": {
            "buffer": ``,
            "history": [],
            "historyIdx": 0,
            "prompt": __stack.args.prompt,
            "historyFile": __stack.args.historyFile,
            "historyMax": __stack.args.historyMax
          },
          "palette": {
            "open": false,
            "filter": ``,
            "cursor": 0,
            "commands": __stack.locals.paletteCommandMap
          },
          "transcript": {
            "messages": []
          },
          "submit": {
            "busy": false,
            "label": ``,
            "startedAtMs": 0
          },
          "config": {
            "status": __stack.args.status,
            "onSubmit": __stack.args.onSubmit
          },
          "choice": null,
          "done": false
        };
      });
      await runner.step(4, async (runner2) => {
        __globals().set("stdlib/ui.agency", "_activeRepl", __stack.locals.initial);
      });
      await runner.step(5, async (runner2) => {
        const __funcResult = await __call(_runReplLoop, {
          type: "positional",
          args: [__stack.locals.initial, _replView, _replReduce, _replIsDone, __stack.args.tickMs, __stack.locals.initial.transcript.messages]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "repl"));
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        __globals().set("stdlib/ui.agency", "_activeRepl", null);
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "repl");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function repl threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "repl"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "repl",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "repl",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const repl = __AgencyFunction.create({
  name: "repl",
  module: "stdlib/ui.agency",
  fn: __repl_impl,
  params: [{
    name: "status",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "onSubmit",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "prompt",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "historyFile",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "historyMax",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "paletteCommands",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "tickMs",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "repl",
    description: `Drop-in REPL widget for interactive CLI agents. Bundles a scrollable
  output area, a live status line, a slash-command palette (triggered
  by \`/\`), and an input line with history navigation. It owns the full
  terminal (alt-screen) and one transcript buffer. Submitted prompts,
  appended messages, and string replies from \`onSubmit\` all show up in
  that buffer. Returning false from \`onSubmit\` exits. While it is
  active, the transcript captures any console / stdout / stderr writes
  from code running underneath, instead of losing them behind the
  alt-screen.

  @param status - Re-evaluated every render; populates the status line
  @param onSubmit - Called with the submitted line; return a string to append or false to exit
  @param prompt - String shown before the input buffer (default "> ")
  @param historyFile - Reserved for future use (history persistence is v2)
  @param historyMax - Trim oldest history entries beyond this count
  @param paletteCommands - Map of /cmd -> description, iterated in order
  @param tickMs - Render cadence in ms; null (default) is event-driven`,
    schema: z.object({ "status": z.any(), "onSubmit": z.any(), "prompt": z.string().nullable().describe("Default: > "), "historyFile": z.string().nullable().describe("Default: "), "historyMax": z.number().nullable().describe("Default: 1000"), "paletteCommands": z.any().nullable().describe("Default: null"), "tickMs": z.number().nullable().describe("Default: null") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/ui.agency:text": { "1": { "line": 134, "col": 2 } }, "stdlib/ui.agency:_setStyleIfSet": { "1": { "line": 147, "col": 2 }, "2": { "line": 150, "col": 2 }, "3": { "line": 153, "col": 2 }, "4": { "line": 156, "col": 2 }, "1.0": { "line": 148, "col": 4 }, "2.0": { "line": 151, "col": 4 }, "3.0": { "line": 154, "col": 4 } }, "stdlib/ui.agency:line": { "1": { "line": 194, "col": 2 }, "2": { "line": 195, "col": 2 }, "3": { "line": 198, "col": 2 }, "4": { "line": 201, "col": 2 }, "5": { "line": 202, "col": 2 }, "6": { "line": 203, "col": 2 }, "7": { "line": 204, "col": 2 }, "8": { "line": 205, "col": 2 }, "9": { "line": 206, "col": 2 }, "10": { "line": 207, "col": 2 }, "2.0": { "line": 196, "col": 4 } }, "stdlib/ui.agency:list": { "1": { "line": 246, "col": 2 }, "2": { "line": 247, "col": 2 }, "3": { "line": 248, "col": 2 }, "4": { "line": 249, "col": 2 }, "5": { "line": 250, "col": 2 }, "6": { "line": 251, "col": 2 }, "7": { "line": 252, "col": 2 }, "8": { "line": 255, "col": 2 }, "7.0": { "line": 253, "col": 4 } }, "stdlib/ui.agency:textInput": { "1": { "line": 290, "col": 2 }, "2": { "line": 291, "col": 2 }, "3": { "line": 292, "col": 2 }, "4": { "line": 293, "col": 2 }, "5": { "line": 294, "col": 2 }, "6": { "line": 295, "col": 2 }, "7": { "line": 296, "col": 2 } }, "stdlib/ui.agency:_mkBoxStyle": { "1": { "line": 326, "col": 2 }, "2": { "line": 327, "col": 2 }, "3": { "line": 328, "col": 2 }, "4": { "line": 329, "col": 2 }, "5": { "line": 330, "col": 2 }, "6": { "line": 331, "col": 2 }, "7": { "line": 332, "col": 2 }, "8": { "line": 333, "col": 2 }, "9": { "line": 334, "col": 2 }, "10": { "line": 335, "col": 2 }, "11": { "line": 336, "col": 2 }, "12": { "line": 337, "col": 2 }, "13": { "line": 340, "col": 2 }, "12.0": { "line": 338, "col": 4 } }, "stdlib/ui.agency:_makeBuilder": { "1": { "line": 344, "col": 2 } }, "stdlib/ui.agency:column": { "1": { "line": 392, "col": 2 }, "2": { "line": 395, "col": 2 }, "3": { "line": 398, "col": 2 }, "2.0": { "line": 396, "col": 4 } }, "stdlib/ui.agency:row": { "1": { "line": 451, "col": 2 }, "2": { "line": 452, "col": 2 }, "3": { "line": 455, "col": 2 }, "2.0": { "line": 453, "col": 4 } }, "stdlib/ui.agency:box": { "1": { "line": 508, "col": 2 }, "2": { "line": 509, "col": 2 }, "3": { "line": 512, "col": 2 }, "2.0": { "line": 510, "col": 4 } }, "stdlib/ui.agency:_addRow": { "1": { "line": 547, "col": 2 }, "2": { "line": 560, "col": 2 }, "3": { "line": 561, "col": 2 } }, "stdlib/ui.agency:_addColumn": { "1": { "line": 578, "col": 2 }, "2": { "line": 591, "col": 2 }, "3": { "line": 592, "col": 2 } }, "stdlib/ui.agency:_addBox": { "1": { "line": 609, "col": 2 }, "2": { "line": 622, "col": 2 }, "3": { "line": 623, "col": 2 } }, "stdlib/ui.agency:_addLine": { "1": { "line": 637, "col": 2 }, "2": { "line": 647, "col": 2 }, "3": { "line": 648, "col": 2 } }, "stdlib/ui.agency:_addText": { "1": { "line": 652, "col": 2 }, "2": { "line": 653, "col": 2 }, "3": { "line": 654, "col": 2 } }, "stdlib/ui.agency:_addList": { "1": { "line": 668, "col": 2 }, "2": { "line": 678, "col": 2 }, "3": { "line": 679, "col": 2 } }, "stdlib/ui.agency:_addTextInput": { "1": { "line": 691, "col": 2 }, "2": { "line": 699, "col": 2 }, "3": { "line": 700, "col": 2 } }, "stdlib/ui.agency:renderOnce": { "1": { "line": 717, "col": 2 } }, "stdlib/ui.agency:readKey": { "1": { "line": 731, "col": 2 } }, "stdlib/ui.agency:runLoop": { "1": { "line": 775, "col": 2 } }, "stdlib/ui.agency:pushMessage": { "1": { "line": 878, "col": 2 }, "2": { "line": 882, "col": 2 }, "3": { "line": 885, "col": 2 }, "1.0": { "line": 879, "col": 4 }, "1.1": { "line": 880, "col": 4 } }, "stdlib/ui.agency:clearMessages": { "1": { "line": 894, "col": 2 }, "3": { "line": 901, "col": 2 }, "4": { "line": 902, "col": 2 }, "1.0": { "line": 895, "col": 4 } }, "stdlib/ui.agency:select": { "1": { "line": 928, "col": 2 } }, "stdlib/ui.agency:autocomplete": { "1": { "line": 957, "col": 2 } }, "stdlib/ui.agency:prompt": { "1": { "line": 986, "col": 2 } }, "stdlib/ui.agency:confirm": { "1": { "line": 1001, "col": 2 } }, "stdlib/ui.agency:indent": { "1": { "line": 1005, "col": 2 }, "2": { "line": 1008, "col": 2 }, "3": { "line": 1021, "col": 2 }, "4": { "line": 1022, "col": 2 }, "5": { "line": 1023, "col": 2 }, "1.0": { "line": 1006, "col": 4 }, "2.1": { "line": 1013, "col": 4 }, "2.2": { "line": 1019, "col": 4 } }, "stdlib/ui.agency:__block_0": {}, "stdlib/ui.agency:chooseOption": { "1": { "line": 1055, "col": 2 }, "3": { "line": 1070, "col": 2 }, "5": { "line": 1098, "col": 2 }, "6": { "line": 1106, "col": 2 }, "7": { "line": 1107, "col": 2 }, "8": { "line": 1108, "col": 2 }, "9": { "line": 1111, "col": 2 }, "10": { "line": 1114, "col": 2 }, "11": { "line": 1115, "col": 2 }, "12": { "line": 1116, "col": 2 }, "13": { "line": 1119, "col": 2 }, "15": { "line": 1144, "col": 2 }, "1.0": { "line": 1056, "col": 4 }, "3.0.0": { "line": 1072, "col": 6 }, "3.0": { "line": 1071, "col": 4 }, "3.1.0": { "line": 1075, "col": 6 }, "3.1": { "line": 1074, "col": 4 }, "3.2": { "line": 1077, "col": 4 }, "3.3.0": { "line": 1079, "col": 6 }, "3.3.1.0": { "line": 1081, "col": 8 }, "3.3.1": { "line": 1080, "col": 6 }, "3.3.2.0": { "line": 1084, "col": 8 }, "3.3.2": { "line": 1083, "col": 6 }, "3.3.3": { "line": 1086, "col": 6 }, "3.3": { "line": 1078, "col": 4 }, "3.5": { "line": 1089, "col": 4 }, "8.0": { "line": 1109, "col": 4 }, "9.0": { "line": 1112, "col": 4 }, "12.0": { "line": 1117, "col": 4 }, "13.1": { "line": 1123, "col": 4 }, "13.2.0": { "line": 1131, "col": 6 }, "13.2": { "line": 1130, "col": 4 }, "13.4.0": { "line": 1139, "col": 6 }, "13.4": { "line": 1138, "col": 4 }, "13.5": { "line": 1141, "col": 4 } }, "stdlib/ui.agency:_entryKey": { "1": { "line": 1148, "col": 2 } }, "stdlib/ui.agency:_filteredPaletteKeys": { "1": { "line": 1158, "col": 2 }, "2": { "line": 1159, "col": 2 }, "3": { "line": 1162, "col": 2 }, "4": { "line": 1163, "col": 2 }, "2.0": { "line": 1160, "col": 4 } }, "stdlib/ui.agency:_matchesFilter": { "1": { "line": 1167, "col": 2 } }, "stdlib/ui.agency:_busyLine": { "1": { "line": 1171, "col": 2 }, "2": { "line": 1174, "col": 2 }, "3": { "line": 1175, "col": 2 }, "4": { "line": 1176, "col": 2 }, "5": { "line": 1177, "col": 2 }, "1.0": { "line": 1172, "col": 4 } }, "stdlib/ui.agency:_choiceProjection": { "2": { "line": 1210, "col": 2 }, "3": { "line": 1211, "col": 2 }, "4": { "line": 1221, "col": 2 }, "5": { "line": 1222, "col": 2 }, "6": { "line": 1223, "col": 2 }, "7": { "line": 1224, "col": 2 }, "8": { "line": 1227, "col": 2 }, "10": { "line": 1233, "col": 2 }, "11": { "line": 1234, "col": 2 }, "12": { "line": 1243, "col": 2 }, "13": { "line": 1244, "col": 2 }, "14": { "line": 1247, "col": 2 }, "3.0": { "line": 1212, "col": 4 }, "7.0": { "line": 1225, "col": 4 }, "8.0": { "line": 1228, "col": 4 }, "11.0": { "line": 1235, "col": 4 }, "11.1": { "line": 1236, "col": 4 }, "11.2.0": { "line": 1238, "col": 6 }, "11.2.1": { "line": 1239, "col": 6 }, "11.2": { "line": 1237, "col": 4 }, "11.3": { "line": 1241, "col": 4 }, "13.0": { "line": 1245, "col": 4 } }, "stdlib/ui.agency:_replView": { "1": { "line": 1258, "col": 2 }, "2": { "line": 1261, "col": 2 }, "3": { "line": 1262, "col": 2 }, "4": { "line": 1263, "col": 2 }, "5": { "line": 1264, "col": 2 }, "6": { "line": 1269, "col": 2 }, "7": { "line": 1270, "col": 2 }, "9": { "line": 1277, "col": 2 }, "10": { "line": 1278, "col": 2 }, "11": { "line": 1279, "col": 2 }, "12": { "line": 1280, "col": 2 }, "13": { "line": 1282, "col": 2 }, "14": { "line": 1287, "col": 2 }, "5.0": { "line": 1265, "col": 4 }, "5.1": { "line": 1266, "col": 4 }, "7.0": { "line": 1271, "col": 4 } }, "stdlib/ui.agency:__block_1": { "14.0": { "line": 1288, "col": 4 }, "14.1": { "line": 1293, "col": 4 }, "14.2": { "line": 1311, "col": 4 }, "14.3": { "line": 1324, "col": 4 }, "14.4": { "line": 1335, "col": 4 }, "14.5": { "line": 1336, "col": 4 }, "14.6.0": { "line": 1338, "col": 6 }, "14.6": { "line": 1337, "col": 4 }, "14.7.0": { "line": 1341, "col": 6 }, "14.7": { "line": 1340, "col": 4 }, "14.8": { "line": 1343, "col": 4 }, "14.9": { "line": 1347, "col": 4 }, "14.10": { "line": 1348, "col": 4 }, "14.11": { "line": 1355, "col": 4 } }, "stdlib/ui.agency:__block_2": { "14.1.0.0": { "line": 1301, "col": 8 }, "14.1.0": { "line": 1300, "col": 6 }, "14.1.1": { "line": 1303, "col": 6 }, "14.1.2": { "line": 1304, "col": 6 }, "14.1.3": { "line": 1309, "col": 6 } }, "stdlib/ui.agency:__block_3": { "14.8.0": { "line": 1344, "col": 6 }, "14.8.1": { "line": 1345, "col": 6 } }, "stdlib/ui.agency:__block_4": { "14.10.0": { "line": 1349, "col": 6 }, "14.10.1": { "line": 1350, "col": 6 }, "14.10.2": { "line": 1353, "col": 6 } }, "stdlib/ui.agency:__block_5": {}, "stdlib/ui.agency:_submitPrompt": { "1": { "line": 1360, "col": 2 }, "2": { "line": 1361, "col": 2 }, "3": { "line": 1362, "col": 2 }, "4": { "line": 1368, "col": 2 }, "5": { "line": 1383, "col": 2 }, "6": { "line": 1384, "col": 2 }, "3.0": { "line": 1363, "col": 4 }, "3.1.0": { "line": 1365, "col": 6 }, "3.1": { "line": 1364, "col": 4 } }, "stdlib/ui.agency:_recallPreviousHistory": { "1": { "line": 1388, "col": 2 }, "2": { "line": 1389, "col": 2 } }, "stdlib/ui.agency:_recallNextHistory": { "1": { "line": 1400, "col": 2 }, "2": { "line": 1401, "col": 2 }, "3": { "line": 1402, "col": 2 }, "4": { "line": 1405, "col": 2 }, "3.0": { "line": 1403, "col": 4 } }, "stdlib/ui.agency:_closePalette": { "1": { "line": 1416, "col": 2 } }, "stdlib/ui.agency:_selectPaletteCommand": { "1": { "line": 1428, "col": 2 }, "2": { "line": 1431, "col": 2 }, "1.0": { "line": 1429, "col": 4 } }, "stdlib/ui.agency:_movePaletteCursor": { "1": { "line": 1451, "col": 2 }, "2": { "line": 1452, "col": 2 }, "3": { "line": 1453, "col": 2 }, "4": { "line": 1456, "col": 2 }, "5": { "line": 1459, "col": 2 }, "3.0": { "line": 1454, "col": 4 }, "4.0": { "line": 1457, "col": 4 } }, "stdlib/ui.agency:_removePaletteFilterCharacter": { "1": { "line": 1469, "col": 2 } }, "stdlib/ui.agency:_appendPaletteFilterCharacter": { "1": { "line": 1483, "col": 2 } }, "stdlib/ui.agency:_replReducePaletteOpen": { "1": { "line": 1494, "col": 2 }, "2": { "line": 1495, "col": 9 }, "3": { "line": 1495, "col": 9 }, "4": { "line": 1495, "col": 2 }, "3.0": { "line": 1496, "col": 25 }, "3.1": { "line": 1496, "col": 25 }, "3.2": { "line": 1497, "col": 21 }, "3.3": { "line": 1497, "col": 21 }, "3.4": { "line": 1498, "col": 23 }, "3.5": { "line": 1498, "col": 23 }, "3.6": { "line": 1499, "col": 24 }, "3.7": { "line": 1499, "col": 24 }, "3.8": { "line": 1500, "col": 22 }, "3.9": { "line": 1500, "col": 22 }, "3.10": { "line": 1501, "col": 60 }, "3.11": { "line": 1501, "col": 60 }, "3.12": { "line": 1502, "col": 28 }, "3.13": { "line": 1502, "col": 28 }, "3.14": { "line": 1495, "col": 9 }, "3.15.0": { "line": 1503, "col": 36 }, "3.15.1": { "line": 1503, "col": 36 }, "3.15.2": { "line": 1504, "col": 9 }, "3.15.3": { "line": 1504, "col": 9 }, "3.15": { "line": 1495, "col": 9 }, "3.16": { "line": 1504, "col": 9 }, "3.17": { "line": 1504, "col": 9 } }, "stdlib/ui.agency:_appendInputCharacter": { "1": { "line": 1509, "col": 2 } }, "stdlib/ui.agency:_pasteText": { "1": { "line": 1526, "col": 2 }, "2": { "line": 1529, "col": 2 }, "1.0": { "line": 1527, "col": 4 } }, "stdlib/ui.agency:_appendPaste": { "1": { "line": 1538, "col": 2 }, "2": { "line": 1539, "col": 2 }, "3": { "line": 1540, "col": 2 } }, "stdlib/ui.agency:_clearInputBuffer": { "1": { "line": 1554, "col": 2 } }, "stdlib/ui.agency:_removeInputCharacter": { "1": { "line": 1564, "col": 2 } }, "stdlib/ui.agency:_openPalette": { "1": { "line": 1574, "col": 2 } }, "stdlib/ui.agency:_filteredChoiceItems": { "1": { "line": 1588, "col": 2 }, "2": { "line": 1591, "col": 2 }, "3": { "line": 1592, "col": 2 }, "1.0": { "line": 1589, "col": 4 } }, "stdlib/ui.agency:_matchesChoiceFilter": { "1": { "line": 1596, "col": 2 } }, "stdlib/ui.agency:_replReduceChoice": { "2": { "line": 1612, "col": 2 }, "3": { "line": 1613, "col": 2 }, "4": { "line": 1614, "col": 2 }, "5": { "line": 1621, "col": 2 }, "6": { "line": 1647, "col": 2 }, "7": { "line": 1660, "col": 2 }, "8": { "line": 1677, "col": 2 }, "9": { "line": 1691, "col": 2 }, "10": { "line": 1701, "col": 2 }, "4.0": { "line": 1615, "col": 4 }, "4.1": { "line": 1616, "col": 4 }, "5.0.1.0": { "line": 1629, "col": 8 }, "5.0.1.1": { "line": 1630, "col": 8 }, "5.0.1": { "line": 1628, "col": 6 }, "5.0.2": { "line": 1635, "col": 6 }, "5.0": { "line": 1622, "col": 4 }, "5.1": { "line": 1637, "col": 4 }, "5.2.0": { "line": 1639, "col": 6 }, "5.2": { "line": 1638, "col": 4 }, "5.3": { "line": 1641, "col": 4 }, "5.4": { "line": 1642, "col": 4 }, "6.0": { "line": 1648, "col": 4 }, "6.1.0": { "line": 1650, "col": 6 }, "6.1": { "line": 1649, "col": 4 }, "6.2": { "line": 1652, "col": 4 }, "7.0": { "line": 1661, "col": 4 }, "7.1": { "line": 1662, "col": 4 }, "7.2.0": { "line": 1664, "col": 6 }, "7.2": { "line": 1663, "col": 4 }, "7.3.0": { "line": 1667, "col": 6 }, "7.3": { "line": 1666, "col": 4 }, "7.4": { "line": 1669, "col": 4 }, "8.0": { "line": 1678, "col": 4 }, "8.1.0": { "line": 1680, "col": 6 }, "8.1": { "line": 1679, "col": 4 }, "8.2": { "line": 1682, "col": 4 }, "9.0": { "line": 1692, "col": 4 } }, "stdlib/ui.agency:_syncChoiceFromBridge": { "1": { "line": 1712, "col": 2 }, "2": { "line": 1713, "col": 2 }, "3": { "line": 1726, "col": 2 }, "4": { "line": 1732, "col": 2 }, "2.0": { "line": 1714, "col": 4 }, "3.0": { "line": 1727, "col": 4 } }, "stdlib/ui.agency:_replReduce": { "1": { "line": 1736, "col": 2 }, "2": { "line": 1741, "col": 2 }, "3": { "line": 1744, "col": 2 }, "4": { "line": 1748, "col": 9 }, "5": { "line": 1748, "col": 9 }, "6": { "line": 1748, "col": 2 }, "2.0": { "line": 1742, "col": 4 }, "3.0": { "line": 1745, "col": 4 }, "5.2": { "line": 1753, "col": 32 }, "5.3": { "line": 1753, "col": 32 }, "5.4": { "line": 1757, "col": 24 }, "5.5": { "line": 1757, "col": 24 }, "5.6": { "line": 1758, "col": 50 }, "5.7": { "line": 1758, "col": 50 }, "5.8": { "line": 1759, "col": 53 }, "5.9": { "line": 1759, "col": 53 }, "5.10": { "line": 1760, "col": 80 }, "5.11": { "line": 1760, "col": 80 }, "5.12": { "line": 1761, "col": 58 }, "5.13": { "line": 1761, "col": 58 }, "5.14": { "line": 1765, "col": 37 }, "5.15": { "line": 1765, "col": 37 }, "5.16": { "line": 1768, "col": 54 }, "5.17": { "line": 1768, "col": 54 }, "5.18": { "line": 1769, "col": 24 }, "5.19": { "line": 1769, "col": 24 }, "5.20": { "line": 1748, "col": 9 }, "5.21.0": { "line": 1770, "col": 36 }, "5.21.1": { "line": 1770, "col": 36 }, "5.21.2": { "line": 1771, "col": 9 }, "5.21.3": { "line": 1771, "col": 9 }, "5.21": { "line": 1748, "col": 9 }, "5.22": { "line": 1771, "col": 9 }, "5.23": { "line": 1771, "col": 9 } }, "stdlib/ui.agency:_replIsDone": { "2": { "line": 1780, "col": 2 }, "3": { "line": 1783, "col": 2 }, "2.0": { "line": 1781, "col": 4 } }, "stdlib/ui.agency:repl": { "1": { "line": 1819, "col": 2 }, "2": { "line": 1820, "col": 2 }, "3": { "line": 1823, "col": 2 }, "4": { "line": 1853, "col": 2 }, "5": { "line": 1863, "col": 2 }, "6": { "line": 1871, "col": 2 }, "2.0": { "line": 1821, "col": 4 } } };
export {
  Builder,
  ChoiceItem,
  Element,
  KeyEvent,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  _addBox,
  _addColumn,
  _addLine,
  _addList,
  _addRow,
  _addText,
  _addTextInput,
  _appendInputCharacter,
  _appendPaletteFilterCharacter,
  _appendPaste,
  _busyLine,
  _choiceProjection,
  _clearInputBuffer,
  _closePalette,
  _entryKey,
  _filteredChoiceItems,
  _filteredPaletteKeys,
  _makeBuilder,
  _matchesChoiceFilter,
  _matchesFilter,
  _mkBoxStyle,
  _movePaletteCursor,
  _openPalette,
  _pasteText,
  _recallNextHistory,
  _recallPreviousHistory,
  _removeInputCharacter,
  _removePaletteFilterCharacter,
  _replIsDone,
  _replReduce,
  _replReduceChoice,
  _replReducePaletteOpen,
  _replView,
  _selectPaletteCommand,
  _setStyleIfSet,
  _submitPrompt,
  _syncChoiceFromBridge,
  approve,
  autocomplete,
  box,
  chooseOption,
  clearMessages,
  column,
  confirm,
  stdin_default as default,
  hasInterrupts,
  indent,
  interrupt,
  isDebugger,
  isInterrupt,
  line,
  list,
  prompt,
  pushMessage,
  readKey,
  reject,
  renderOnce,
  repl,
  respondToInterrupts,
  rewindFrom,
  row,
  runLoop,
  select,
  text,
  textInput
};
