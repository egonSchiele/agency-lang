import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { search as webSearch } from "agency-lang/stdlib/web/search.js";
import { fetch, fetchMarkdown } from "agency-lang/stdlib/http.js";
import { search as wikiSearch } from "agency-lang/stdlib/wikipedia.js";
import { systemMessage, guard } from "agency-lang/stdlib/thread.js";
import { feedbackHasErrors, renderFeedback, Feedback } from "agency-lang/stdlib/agency.js";
import { env } from "agency-lang/stdlib/system.js";
import { withContext, unwrapGuard } from "agency-lang/stdlib/agents/shared.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  runPrompt,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  success,
  failure,
  isFailure,
  stampFailureBoundary,
  __eq,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __threads,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/agents/research.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(webSearch);
__registerTool(fetch);
__registerTool(fetchMarkdown);
__registerTool(wikiSearch);
__registerTool(systemMessage);
__registerTool(guard);
__registerTool(feedbackHasErrors);
__registerTool(renderFeedback);
__registerTool(Feedback);
__registerTool(env);
__registerTool(withContext);
__registerTool(unwrapGuard);
let __staticInitPromise = null;
let researchSysPrompt = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    researchSysPrompt = __deepFreeze(`You are a research analyst. Answer the task using your source tools.

- Ground every factual claim in a source and cite it.
- If your tools cannot retrieve the needed information, say so plainly. NEVER fabricate sources or facts.`);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    researchSysPrompt
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/agents/research.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/agents/research.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/agents/research.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/agents/research.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
async function __buildResearchTools_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/research.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/research.agency", scopeName: "buildResearchTools", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildResearchTools",
            args: {},
            moduleId: "stdlib/agents/research.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.tools = [__readStatic(wikiSearch, "wikiSearch", ""), __readStatic(fetchMarkdown, "fetchMarkdown", ""), __readStatic(fetch, "fetch", ""), await __callMethod(__readStatic(read, "read", ""), "partial", {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            useAgentCwd: true
          }
        })];
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.braveKey = await __call(env, {
          type: "positional",
          args: [`BRAVE_API_KEY`]
        });
        if (hasInterrupts(__stack.locals.braveKey)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.braveKey);
          return;
        }
      });
      await runner.ifElse(3, [
        {
          condition: async () => !__eq(__stack.locals.braveKey, null) && !__eq(__stack.locals.braveKey, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              await __callMethod(__stack.locals.tools, "push", {
                type: "positional",
                args: [__readStatic(webSearch, "webSearch", "")]
              });
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.tools);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildResearchTools threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildResearchTools"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildResearchTools",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildResearchTools",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildResearchTools = __AgencyFunction.create({
  name: "buildResearchTools",
  module: "stdlib/agents/research.agency",
  fn: __buildResearchTools_impl,
  params: [],
  toolDefinition: {
    name: "buildResearchTools",
    description: "No description provided.",
    schema: z.object({})
  },
  exported: false
}, __toolRegistry);
async function __researchAgent_impl(task, context = __UNSET, maxAttempts = __UNSET, maxCost = __UNSET, maxTime = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/research.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["context"] = context === __UNSET ? `` : context;
  __stack.args["maxAttempts"] = maxAttempts === __UNSET ? 2 : maxAttempts;
  __stack.args["maxCost"] = maxCost === __UNSET ? 50 : maxCost;
  __stack.args["maxTime"] = maxTime === __UNSET ? 18e5 : maxTime;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/research.agency", scopeName: "researchAgent", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("maxAttempts" in __overrides) {
      maxAttempts = __overrides["maxAttempts"];
      __stack.args["maxAttempts"] = maxAttempts;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
    if ("maxTime" in __overrides) {
      maxTime = __overrides["maxTime"];
      __stack.args["maxTime"] = maxTime;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "researchAgent",
            args: {
              task,
              context,
              maxAttempts,
              maxCost,
              maxTime
            },
            moduleId: "stdlib/agents/research.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.researchTools = await __call(buildResearchTools, {
          type: "positional",
          args: []
        });
        if (hasInterrupts(__stack.locals.researchTools)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.researchTools);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.captured = await __call(guard, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            cost: __stack.args.maxCost,
            time: __stack.args.maxTime
          },
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/agents/research.agency", fn: async () => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/research.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.answer = ``;
              });
              await runner3.step(1, async (runner4) => {
                __bstack.locals.msg = await __call(withContext, {
                  type: "positional",
                  args: [__stack.args.task, __stack.args.context]
                });
                if (hasInterrupts(__bstack.locals.msg)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__bstack.locals.msg);
                  return;
                }
              });
              await runner3.thread(2, "create", async () => ({ label: `researchAgent` }), async (runner4) => {
                await runner4.step(0, async (runner5) => {
                  const __funcResult = await __call(systemMessage, {
                    type: "positional",
                    args: [__readStatic(researchSysPrompt, "researchSysPrompt", "stdlib/agents/research.agency")]
                  });
                  if (hasInterrupts(__funcResult)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__funcResult);
                    return;
                  }
                });
                await runner4.step(1, async (runner5) => {
                  __bstack.locals.done = false;
                });
                await runner4.step(2, async (runner5) => {
                  __bstack.locals.attemptsLeft = __stack.args.maxAttempts;
                });
                await runner4.whileLoop(3, async () => !__bstack.locals.done && __bstack.locals.attemptsLeft > 0, async (runner5) => {
                  await runner5.step(0, async (runner6) => {
                    __self2.__removedTools = __self2.__removedTools || [];
                    __bstack.locals.answer = await runPrompt({
                      prompt: __bstack.locals.msg,
                      messages: __threads().getOrCreateActive(),
                      clientConfig: {
                        "tools": __stack.locals.researchTools
                      },
                      maxToolCallRounds: 10,
                      removedTools: __self2.__removedTools,
                      destructiveSink: __self2,
                      checkpointInfo: runner6.getCheckpointInfo()
                    });
                    if (hasInterrupts(__bstack.locals.answer)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner6.halt(__bstack.locals.answer);
                      return;
                    }
                  });
                  await runner5.step(1, async (runner6) => {
                    __self2.__removedTools = __self2.__removedTools || [];
                    __bstack.locals.items = await runPrompt({
                      prompt: `Judge the answer against the task. For each finding, return a Feedback item: error=true if a claim is ungrounded or uncited or the task is not fully answered (name it), error=false for a well-supported point.

Task: ${__stack.args.task}

Answer:
${__bstack.locals.answer}`,
                      messages: __threads().getOrCreateActive(),
                      responseFormat: z.object({
                        response: z.array(Feedback)
                      }),
                      clientConfig: {},
                      maxToolCallRounds: 10,
                      removedTools: __self2.__removedTools,
                      destructiveSink: __self2,
                      checkpointInfo: runner6.getCheckpointInfo()
                    });
                    if (hasInterrupts(__bstack.locals.items)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner6.halt(__bstack.locals.items);
                      return;
                    }
                  });
                  await runner5.step(2, async (runner6) => {
                    __bstack.locals.fb = await success(__bstack.locals.items);
                    if (hasInterrupts(__bstack.locals.fb)) {
                      await getRuntimeContext().ctx.pendingPromises.awaitAll();
                      runner6.halt(__bstack.locals.fb);
                      return;
                    }
                  });
                  await runner5.ifElse(3, [
                    {
                      condition: async () => await __call(feedbackHasErrors, {
                        type: "positional",
                        args: [__bstack.locals.fb]
                      }),
                      body: async (runner6) => {
                        await runner6.step(0, async (runner7) => {
                          __bstack.locals.msg = `Your answer has gaps:

${await __call(renderFeedback, {
                            type: "positional",
                            args: [__bstack.locals.fb]
                          })}

Retrieve more and fix them.`;
                        });
                        await runner6.step(1, async (runner7) => {
                          __bstack.locals.attemptsLeft = __bstack.locals.attemptsLeft - 1;
                        });
                      }
                    }
                  ], async (runner6) => {
                    await runner6.step(2, async (runner7) => {
                      __bstack.locals.done = true;
                    });
                  });
                });
              });
              await runner3.step(3, async (runner4) => {
                runner4.halt(__bstack.locals.answer);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.captured)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.captured);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(unwrapGuard, {
          type: "positional",
          args: [__stack.locals.captured, `Research`]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function researchAgent threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "researchAgent"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "researchAgent",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "researchAgent",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const researchAgent = __AgencyFunction.create({
  name: "researchAgent",
  module: "stdlib/agents/research.agency",
  fn: __researchAgent_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxAttempts",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxTime",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "researchAgent",
    description: `Research agent: gathers from web and Wikipedia sources and synthesizes a
  cited answer, checked for grounding and completeness.

  @param task - The research question.
  @param context - Optional extra material.
  @param maxAttempts - Max answer-and-fix attempts before returning (default 2).
  @param maxCost - Hard spend cap for the whole run (default $50).
  @param maxTime - Hard wall-clock cap for the whole run (default 30 minutes).`,
    schema: z.object({ "task": z.string(), "context": z.string().nullable().describe("Default: "), "maxAttempts": z.number().nullable().describe("Default: 2"), "maxCost": z.number().nullable().describe("Default: $50.00"), "maxTime": z.number().nullable().describe("Default: 30m") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/agents/research.agency:buildResearchTools": { "1": { "line": 21, "col": 2 }, "2": { "line": 22, "col": 2 }, "3": { "line": 23, "col": 2 }, "4": { "line": 26, "col": 2 }, "3.0": { "line": 24, "col": 4 } }, "stdlib/agents/research.agency:researchAgent": { "1": { "line": 40, "col": 2 }, "2": { "line": 41, "col": 2 }, "3": { "line": 62, "col": 2 } }, "stdlib/agents/research.agency:__block_0": { "2.0": { "line": 42, "col": 4 }, "2.1": { "line": 43, "col": 4 }, "2.2.0": { "line": 45, "col": 6 }, "2.2.1": { "line": 46, "col": 6 }, "2.2.2": { "line": 47, "col": 6 }, "2.2.3.0": { "line": 49, "col": 8 }, "2.2.3.1": { "line": 50, "col": 8 }, "2.2.3.2": { "line": 51, "col": 8 }, "2.2.3.3.0": { "line": 53, "col": 10 }, "2.2.3.3.1": { "line": 54, "col": 10 }, "2.2.3.3.2": { "line": 56, "col": 10 }, "2.2.3.3": { "line": 52, "col": 8 }, "2.2.3": { "line": 48, "col": 6 }, "2.2": { "line": 44, "col": 4 }, "2.3": { "line": 60, "col": 4 } } };
export {
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  buildResearchTools,
  stdin_default as default,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  reject,
  researchAgent,
  respondToInterrupts,
  rewindFrom
};
