import { print, printJSON, input, sleep, read, write, writeBinary, readBinary, range, callback, map, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy } from "agency-lang/stdlib/index.js";
import { writeAgency, runCode, getEffects, verify, feedbackHasErrors, renderFeedback, EffectsByExport } from "agency-lang/stdlib/agency.js";
import { codingAgent } from "agency-lang/stdlib/agents/coding.js";
import { withContext, unwrapGuard } from "agency-lang/stdlib/agents/shared.js";
import { guard } from "agency-lang/stdlib/thread.js";
import { getAgentCwd } from "agency-lang/stdlib/index.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  runPrompt,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __tryCall,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __callMethod,
  __threads,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const getDirname = () => __dirname;
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/agents/planner.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals, registerTopLevelCallbacks: __registerTopLevelCallbacks, moduleDir: __dirname });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(writeAgency);
__registerTool(runCode);
__registerTool(getEffects);
__registerTool(verify);
__registerTool(feedbackHasErrors);
__registerTool(renderFeedback);
__registerTool(EffectsByExport);
__registerTool(codingAgent);
__registerTool(withContext);
__registerTool(unwrapGuard);
__registerTool(guard);
__registerTool(getAgentCwd);
let __staticInitPromise = null;
let importableSurface = __UNINIT_STATIC;
let planExample = __UNINIT_STATIC;
let PLANNER_MAX_ATTEMPTS = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    importableSurface = __deepFreeze(`You may import and compose these building blocks (all standard library, so they run in the sandbox):
- import { codingAgent } from "std::agents/coding"      general coding: read/write/edit/run files and shell
- import { researchAgent } from "std::agents/research"  gather from web and Wikipedia and synthesize
- import { agencyCodingAgent } from "std::agents/agency" write and run Agency code
- import { plannerAgent } from "std::agents/planner"    decompose a genuinely complex sub-task into its own planned agent
- direct tools from std::shell, std::fs, std::http, and the rest of the standard library

Prefer to DO THE WORK directly: call codingAgent (or researchAgent, or direct tools) to actually create files, run commands, and produce the deliverable. Use plannerAgent ONLY for a sub-task that is itself large and multi-step; never call plannerAgent for a concrete, single-step piece of work, and never just re-plan without doing anything.`);
    planExample = __deepFreeze(`EXAMPLE, compose a worker in a node main:
import { codingAgent } from "std::agents/coding"
node main(): string {
  return codingAgent("clone the repo, install deps, and run the test suite")
}`);
    PLANNER_MAX_ATTEMPTS = __deepFreeze(2);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    importableSurface,
    planExample,
    PLANNER_MAX_ATTEMPTS
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/agents/planner.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/agents/planner.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/agents/planner.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
}
__registerGlobalsInit("stdlib/agents/planner.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
  __ctx.topLevelCallbacks = [];
}
__functionRefReviver.registry = __toolRegistry;
async function __planCodePrompt_impl(task, planText) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["planText"] = planText;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "planCodePrompt", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("planText" in __overrides) {
      planText = __overrides["planText"];
      __stack.args["planText"] = planText;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "planCodePrompt",
            args: {
              task,
              planText
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`Write a complete Agency program (a node main) that carries out this plan, composing the building blocks below.

Task:
${__stack.args.task}

Plan:
${__stack.args.planText}

${__readStatic(importableSurface, "importableSurface", "stdlib/agents/planner.agency")}

${__readStatic(planExample, "planExample", "stdlib/agents/planner.agency")}

Return only the complete program.`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function planCodePrompt threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "planCodePrompt"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "planCodePrompt",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "planCodePrompt",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const planCodePrompt = __AgencyFunction.create({
  name: "planCodePrompt",
  module: "stdlib/agents/planner.agency",
  fn: __planCodePrompt_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "planText",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "planCodePrompt",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "planText": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __renderEffectLines_impl(byExport) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["byExport"] = byExport;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "renderEffectLines", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("byExport" in __overrides) {
      byExport = __overrides["byExport"];
      __stack.args["byExport"] = byExport;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "renderEffectLines",
            args: {
              byExport
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.lines = [];
      });
      await runner.loop(2, async () => __stack.args.byExport, async (name, effs, runner2) => {
        await runner2.step(0, async (runner3) => {
          await __callMethod(__stack.locals.lines, "push", {
            type: "positional",
            args: [`${name}: ${await __callMethod(effs, "join", {
              type: "positional",
              args: [`, `]
            })}`]
          });
        });
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __callMethod(__stack.locals.lines, "join", {
          type: "positional",
          args: [`
`]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function renderEffectLines threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "renderEffectLines"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "renderEffectLines",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "renderEffectLines",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const renderEffectLines = __AgencyFunction.create({
  name: "renderEffectLines",
  module: "stdlib/agents/planner.agency",
  fn: __renderEffectLines_impl,
  params: [{
    name: "byExport",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "renderEffectLines",
    description: "No description provided.",
    schema: z.object({ "byExport": z.record(z.string(), z.array(z.string())) })
  },
  exported: false
}, __toolRegistry);
async function __renderEffects_impl(effects) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["effects"] = effects;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "renderEffects", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("effects" in __overrides) {
      effects = __overrides["effects"];
      __stack.args["effects"] = effects;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "renderEffects",
            args: {
              effects
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_4 = __stack.args.effects;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_4),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals._ = __stack.locals.__scrutinee_4.error;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_2 = `(capabilities could not be computed)`;
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_2);
              return;
            });
          }
        },
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_4),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.byExport = __stack.locals.__scrutinee_4.value;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_3 = await __call(renderEffectLines, {
                type: "positional",
                args: [__stack.locals.byExport]
              });
              if (hasInterrupts(__stack.locals.__armval_3)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_3);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_3);
              return;
            });
          }
        }
      ], void 0, { matchId: 1 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function renderEffects threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "renderEffects"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "renderEffects",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "renderEffects",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const renderEffects = __AgencyFunction.create({
  name: "renderEffects",
  module: "stdlib/agents/planner.agency",
  fn: __renderEffects_impl,
  params: [{
    name: "effects",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "renderEffects",
    description: "No description provided.",
    schema: z.object({ "effects": z.union([z.object({ __type: z.literal("resultType"), success: z.literal(true), value: EffectsByExport }), z.object({ __type: z.literal("resultType"), success: z.literal(false), error: z.any() })]) })
  },
  exported: true
}, __toolRegistry);
async function __requestApproval_impl(plan, source, effects) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["plan"] = plan;
  __stack.args["source"] = source;
  __stack.args["effects"] = effects;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "requestApproval", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("plan" in __overrides) {
      plan = __overrides["plan"];
      __stack.args["plan"] = plan;
    }
    if ("source" in __overrides) {
      source = __overrides["source"];
      __stack.args["source"] = source;
    }
    if ("effects" in __overrides) {
      effects = __overrides["effects"];
      __stack.args["effects"] = effects;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "requestApproval",
            args: {
              plan,
              source,
              effects
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::agents::planApprove", `Approve this plan before running it?`, {
            "plan": __stack.args.plan,
            "source": __stack.args.source,
            "effects": __stack.args.effects
          }, "std::agents/planner", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/agents/planner.agency", scopeName: "requestApproval", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function requestApproval threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "requestApproval"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "requestApproval",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "requestApproval",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const requestApproval = __AgencyFunction.create({
  name: "requestApproval",
  module: "stdlib/agents/planner.agency",
  fn: __requestApproval_impl,
  params: [{
    name: "plan",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "source",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "effects",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "requestApproval",
    description: "No description provided.",
    schema: z.object({ "plan": z.string(), "source": z.string(), "effects": z.string() })
  },
  exported: false
}, __toolRegistry);
const PlanState = z.object({ "summary": z.string(), "done": z.boolean(), "extra": z.string() });
async function __rejectedState_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "rejectedState", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "rejectedState",
            args: {
              state
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "summary": `Plan rejected; nothing was run.`,
          "done": true,
          "extra": __stack.args.state.extra
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function rejectedState threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "rejectedState"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "rejectedState",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "rejectedState",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const rejectedState = __AgencyFunction.create({
  name: "rejectedState",
  module: "stdlib/agents/planner.agency",
  fn: __rejectedState_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "rejectedState",
    description: "No description provided.",
    schema: z.object({ "state": PlanState })
  },
  exported: false
}, __toolRegistry);
async function __completedState_impl(state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "completedState", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "completedState",
            args: {
              state
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "summary": `Plan completed and verified.`,
          "done": true,
          "extra": __stack.args.state.extra
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function completedState threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "completedState"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "completedState",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "completedState",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const completedState = __AgencyFunction.create({
  name: "completedState",
  module: "stdlib/agents/planner.agency",
  fn: __completedState_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "completedState",
    description: "No description provided.",
    schema: z.object({ "state": PlanState })
  },
  exported: false
}, __toolRegistry);
async function __regenState_impl(state, gaps) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["state"] = state;
  __stack.args["gaps"] = gaps;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "regenState", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
    if ("gaps" in __overrides) {
      gaps = __overrides["gaps"];
      __stack.args["gaps"] = gaps;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "regenState",
            args: {
              state,
              gaps
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "summary": __stack.args.state.summary,
          "done": false,
          "extra": `${__stack.args.state.extra}

A prior attempt had problems; fix them:
${__stack.args.gaps}`
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function regenState threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "regenState"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "regenState",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "regenState",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const regenState = __AgencyFunction.create({
  name: "regenState",
  module: "stdlib/agents/planner.agency",
  fn: __regenState_impl,
  params: [{
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "gaps",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "regenState",
    description: "No description provided.",
    schema: z.object({ "state": PlanState, "gaps": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __fallbackState_impl(task, state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "fallbackState", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "fallbackState",
            args: {
              task,
              state
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "summary": await __call(codingAgent, {
            type: "positional",
            args: [__stack.args.task]
          }),
          "done": true,
          "extra": __stack.args.state.extra
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function fallbackState threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "fallbackState"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "fallbackState",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "fallbackState",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const fallbackState = __AgencyFunction.create({
  name: "fallbackState",
  module: "stdlib/agents/planner.agency",
  fn: __fallbackState_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "fallbackState",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "state": PlanState })
  },
  exported: false
}, __toolRegistry);
async function __judgeAfterRun_impl(task, state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "judgeAfterRun", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "judgeAfterRun",
            args: {
              task,
              state
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.fb = await __call(verify, {
          type: "positional",
          args: [__stack.args.task]
        });
        if (hasInterrupts(__stack.locals.fb)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.fb);
          return;
        }
      });
      await runner.ifElse(2, [
        {
          condition: async () => await __call(feedbackHasErrors, {
            type: "positional",
            args: [__stack.locals.fb]
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.__ifbranch_7 = await __call(regenState, {
                type: "positional",
                args: [__stack.args.state, await __call(renderFeedback, {
                  type: "positional",
                  args: [__stack.locals.fb]
                })]
              });
              if (hasInterrupts(__stack.locals.__ifbranch_7)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__ifbranch_7);
                return;
              }
            });
            await runner2.step(1, async (runner3) => {
              runner3.exitMatch(5, __stack.locals.__ifbranch_7);
              return;
            });
          }
        }
      ], async (runner2) => {
        await runner2.step(2, async (runner3) => {
          __stack.locals.__ifbranch_6 = await __call(completedState, {
            type: "positional",
            args: [__stack.args.state]
          });
          if (hasInterrupts(__stack.locals.__ifbranch_6)) {
            await getRuntimeContext().ctx.pendingPromises.awaitAll();
            runner3.halt(__stack.locals.__ifbranch_6);
            return;
          }
        });
        await runner2.step(3, async (runner3) => {
          runner3.exitMatch(5, __stack.locals.__ifbranch_6);
          return;
        });
      }, { matchId: 5 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_5));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function judgeAfterRun threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "judgeAfterRun"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "judgeAfterRun",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "judgeAfterRun",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const judgeAfterRun = __AgencyFunction.create({
  name: "judgeAfterRun",
  module: "stdlib/agents/planner.agency",
  fn: __judgeAfterRun_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "judgeAfterRun",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "state": PlanState })
  },
  exported: false
}, __toolRegistry);
async function __afterRun_impl(task, src, state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["src"] = src;
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "afterRun", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("src" in __overrides) {
      src = __overrides["src"];
      __stack.args["src"] = src;
    }
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "afterRun",
            args: {
              task,
              src,
              state
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.__scrutinee_11 = await __call(runCode, {
          type: "named",
          positionalArgs: [__stack.args.src],
          namedArgs: {
            cwd: await __call(getAgentCwd, {
              type: "positional",
              args: []
            })
          }
        });
        if (hasInterrupts(__stack.locals.__scrutinee_11)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.__scrutinee_11);
          return;
        }
      });
      await runner.ifElse(3, [
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_11),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_11.error;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_9 = await __call(regenState, {
                type: "positional",
                args: [__stack.args.state, `The generated agent failed to run: ${__stack.locals.err}`]
              });
              if (hasInterrupts(__stack.locals.__armval_9)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_9);
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(8, __stack.locals.__armval_9);
              return;
            });
          }
        },
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_11),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals._ = __stack.locals.__scrutinee_11.value;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_10 = await __call(judgeAfterRun, {
                type: "positional",
                args: [__stack.args.task, __stack.args.state]
              });
              if (hasInterrupts(__stack.locals.__armval_10)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_10);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(8, __stack.locals.__armval_10);
              return;
            });
          }
        }
      ], void 0, { matchId: 8 });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_8));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function afterRun threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "afterRun"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "afterRun",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "afterRun",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const afterRun = __AgencyFunction.create({
  name: "afterRun",
  module: "stdlib/agents/planner.agency",
  fn: __afterRun_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "src",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "afterRun",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "src": z.string(), "state": PlanState })
  },
  exported: false
}, __toolRegistry);
async function __runApproved_impl(task, plan, src, state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["plan"] = plan;
  __stack.args["src"] = src;
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "runApproved", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("plan" in __overrides) {
      plan = __overrides["plan"];
      __stack.args["plan"] = plan;
    }
    if ("src" in __overrides) {
      src = __overrides["src"];
      __stack.args["src"] = src;
    }
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "runApproved",
            args: {
              task,
              plan,
              src,
              state
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.eff = await __call(getEffects, {
          type: "positional",
          args: [__stack.args.src]
        });
        if (hasInterrupts(__stack.locals.eff)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.eff);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.gate = await __tryCall(async () => await __call(requestApproval, {
          type: "positional",
          args: [__stack.args.plan, __stack.args.src, await __call(renderEffects, {
            type: "positional",
            args: [__stack.locals.eff]
          })]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "runApproved",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.gate)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.gate);
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.__scrutinee_15 = __stack.locals.gate;
      });
      await runner.ifElse(4, [
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_15),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals._ = __stack.locals.__scrutinee_15.error;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_13 = await __call(rejectedState, {
                type: "positional",
                args: [__stack.args.state]
              });
              if (hasInterrupts(__stack.locals.__armval_13)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_13);
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_13);
              return;
            });
          }
        },
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_15),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals._ = __stack.locals.__scrutinee_15.value;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_14 = await __call(afterRun, {
                type: "positional",
                args: [__stack.args.task, __stack.args.src, __stack.args.state]
              });
              if (hasInterrupts(__stack.locals.__armval_14)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_14);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(12, __stack.locals.__armval_14);
              return;
            });
          }
        }
      ], void 0, { matchId: 12 });
      await runner.step(5, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_12));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function runApproved threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "runApproved"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "runApproved",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "runApproved",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const runApproved = __AgencyFunction.create({
  name: "runApproved",
  module: "stdlib/agents/planner.agency",
  fn: __runApproved_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "plan",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "src",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "runApproved",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "plan": z.string(), "src": z.string(), "state": PlanState })
  },
  exported: true
}, __toolRegistry);
async function __planStep_impl(task, planText, state) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["planText"] = planText;
  __stack.args["state"] = state;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "planStep", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("planText" in __overrides) {
      planText = __overrides["planText"];
      __stack.args["planText"] = planText;
    }
    if ("state" in __overrides) {
      state = __overrides["state"];
      __stack.args["state"] = state;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "planStep",
            args: {
              task,
              planText,
              state
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.gen = await __call(writeAgency, {
          type: "positional",
          args: [await __call(planCodePrompt, {
            type: "positional",
            args: [__stack.args.task, __stack.args.planText]
          }), __stack.args.state.extra]
        });
        if (hasInterrupts(__stack.locals.gen)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.gen);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.__scrutinee_19 = __stack.locals.gen;
      });
      await runner.ifElse(3, [
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_19),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals._ = __stack.locals.__scrutinee_19.error;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_17 = await __call(fallbackState, {
                type: "positional",
                args: [__stack.args.task, __stack.args.state]
              });
              if (hasInterrupts(__stack.locals.__armval_17)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_17);
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(16, __stack.locals.__armval_17);
              return;
            });
          }
        },
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_19),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.src = __stack.locals.__scrutinee_19.value;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_18 = await __call(runApproved, {
                type: "positional",
                args: [__stack.args.task, __stack.args.planText, __stack.locals.src, __stack.args.state]
              });
              if (hasInterrupts(__stack.locals.__armval_18)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_18);
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(16, __stack.locals.__armval_18);
              return;
            });
          }
        }
      ], void 0, { matchId: 16 });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_16));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function planStep threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "planStep"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "planStep",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "planStep",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const planStep = __AgencyFunction.create({
  name: "planStep",
  module: "stdlib/agents/planner.agency",
  fn: __planStep_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "planText",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "state",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "planStep",
    description: "No description provided.",
    schema: z.object({ "task": z.string(), "planText": z.string(), "state": PlanState })
  },
  exported: false
}, __toolRegistry);
async function __plannerAgent_impl(task, context = __UNSET, plan = __UNSET, maxCost = __UNSET, maxTime = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/agents/planner.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["task"] = task;
  __stack.args["context"] = context === __UNSET ? `` : context;
  __stack.args["plan"] = plan === __UNSET ? `` : plan;
  __stack.args["maxCost"] = maxCost === __UNSET ? 100 : maxCost;
  __stack.args["maxTime"] = maxTime === __UNSET ? 36e5 : maxTime;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/agents/planner.agency", scopeName: "plannerAgent", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("task" in __overrides) {
      task = __overrides["task"];
      __stack.args["task"] = task;
    }
    if ("context" in __overrides) {
      context = __overrides["context"];
      __stack.args["context"] = context;
    }
    if ("plan" in __overrides) {
      plan = __overrides["plan"];
      __stack.args["plan"] = plan;
    }
    if ("maxCost" in __overrides) {
      maxCost = __overrides["maxCost"];
      __stack.args["maxCost"] = maxCost;
    }
    if ("maxTime" in __overrides) {
      maxTime = __overrides["maxTime"];
      __stack.args["maxTime"] = maxTime;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "plannerAgent",
            args: {
              task,
              context,
              plan,
              maxCost,
              maxTime
            },
            moduleId: "stdlib/agents/planner.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.captured = await __call(guard, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            cost: __stack.args.maxCost,
            time: __stack.args.maxTime
          },
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/agents/planner.agency", fn: async () => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/agents/planner.agency", scopeName: "__block_0" });
            try {
              await runner3.ifElse(0, [
                {
                  condition: async () => __eq(__stack.args.plan, ``),
                  body: async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      __self2.__removedTools = __self2.__removedTools || [];
                      __bstack.locals.__ifbranch_22 = await runPrompt({
                        prompt: `Analyse this task and outline the steps:
${await __call(withContext, {
                          type: "positional",
                          args: [__stack.args.task, __stack.args.context]
                        })}`,
                        messages: __threads().getOrCreateActive(),
                        clientConfig: {},
                        maxToolCallRounds: 10,
                        removedTools: __self2.__removedTools,
                        destructiveSink: __self2,
                        checkpointInfo: runner5.getCheckpointInfo()
                      });
                      if (hasInterrupts(__bstack.locals.__ifbranch_22)) {
                        await getRuntimeContext().ctx.pendingPromises.awaitAll();
                        runner5.halt(__bstack.locals.__ifbranch_22);
                        return;
                      }
                    });
                    await runner4.step(1, async (runner5) => {
                      runner5.exitMatch(20, __bstack.locals.__ifbranch_22);
                      return;
                    });
                  }
                }
              ], async (runner4) => {
                await runner4.step(2, async (runner5) => {
                  __bstack.locals.__ifbranch_21 = __stack.args.plan;
                });
                await runner4.step(3, async (runner5) => {
                  runner5.exitMatch(20, __bstack.locals.__ifbranch_21);
                  return;
                });
              }, { matchId: 20 });
              await runner3.step(1, async (runner4) => {
                __bstack.locals.planText = __nn(__stack.locals.__matchval_20);
              });
              await runner3.step(2, async (runner4) => {
                __bstack.locals.state = {
                  "summary": ``,
                  "done": false,
                  "extra": await __call(withContext, {
                    type: "positional",
                    args: [__stack.args.task, __stack.args.context]
                  })
                };
              });
              await runner3.step(3, async (runner4) => {
                __bstack.locals.attemptsLeft = __readStatic(PLANNER_MAX_ATTEMPTS, "PLANNER_MAX_ATTEMPTS", "stdlib/agents/planner.agency");
              });
              await runner3.whileLoop(4, async () => !__bstack.locals.state.done && __bstack.locals.attemptsLeft > 0, async (runner4) => {
                await runner4.step(0, async (runner5) => {
                  __bstack.locals.state = await __call(planStep, {
                    type: "positional",
                    args: [__stack.args.task, __bstack.locals.planText, __bstack.locals.state]
                  });
                  if (hasInterrupts(__bstack.locals.state)) {
                    await getRuntimeContext().ctx.pendingPromises.awaitAll();
                    runner5.halt(__bstack.locals.state);
                    return;
                  }
                });
                await runner4.step(1, async (runner5) => {
                  __bstack.locals.attemptsLeft = __bstack.locals.attemptsLeft - 1;
                });
              });
              await runner3.step(5, async (runner4) => {
                runner4.halt(__bstack.locals.state.summary);
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.captured)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.captured);
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(unwrapGuard, {
          type: "positional",
          args: [__stack.locals.captured, `Planner`]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      throw __error;
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function plannerAgent threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "plannerAgent"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "plannerAgent",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "plannerAgent",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const plannerAgent = __AgencyFunction.create({
  name: "plannerAgent",
  module: "stdlib/agents/planner.agency",
  fn: __plannerAgent_impl,
  params: [{
    name: "task",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "context",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "plan",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxCost",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxTime",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "plannerAgent",
    description: `Plan-as-code: draft (or use a seed) plan, generate an agent that solves the
  task, show the plan/source/effects for approval, run it in a sandboxed
  subprocess, and verify. Falls back to codingAgent on generation failure or
  repeated verification gaps. Recursion (a generated agent calling plannerAgent)
  is bounded by the runtime's subprocess maxDepth and by maxCost/maxTime.

  @param task - what to accomplish.
  @param context - optional extra material.
  @param plan - optional seed plan; when non-empty the analysis step is skipped.
  @param maxCost - hard spend cap for the whole tree (default $100).
  @param maxTime - hard wall-clock cap (default 60 minutes).`,
    schema: z.object({ "task": z.string(), "context": z.string().nullable().describe("Default: "), "plan": z.string().nullable().describe("Default: "), "maxCost": z.number().nullable().describe("Default: $100.00"), "maxTime": z.number().nullable().describe("Default: 60m") })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/agents/planner.agency:planCodePrompt": { "1": { "line": 41, "col": 2 } }, "stdlib/agents/planner.agency:renderEffectLines": { "1": { "line": 59, "col": 2 }, "2": { "line": 60, "col": 2 }, "3": { "line": 63, "col": 2 }, "2.0": { "line": 61, "col": 4 } }, "stdlib/agents/planner.agency:renderEffects": { "1": { "line": 69, "col": 9 }, "2": { "line": 69, "col": 9 }, "3": { "line": 69, "col": 2 }, "2.0": { "line": 69, "col": 9 }, "2.3": { "line": 69, "col": 9 }, "2.4": { "line": 71, "col": 25 }, "2.5": { "line": 71, "col": 25 } }, "stdlib/agents/planner.agency:requestApproval": { "1": { "line": 81, "col": 2 } }, "stdlib/agents/planner.agency:rejectedState": { "1": { "line": 99, "col": 2 } }, "stdlib/agents/planner.agency:completedState": { "1": { "line": 103, "col": 2 } }, "stdlib/agents/planner.agency:regenState": { "1": { "line": 107, "col": 2 } }, "stdlib/agents/planner.agency:fallbackState": { "1": { "line": 111, "col": 2 } }, "stdlib/agents/planner.agency:judgeAfterRun": { "1": { "line": 115, "col": 2 }, "2": { "line": 116, "col": 9 }, "3": { "line": 116, "col": 2 }, "2.0": { "line": 116, "col": 39 }, "2.1": { "line": 116, "col": 39 }, "2.2": { "line": 116, "col": 82 }, "2.3": { "line": 116, "col": 82 } }, "stdlib/agents/planner.agency:afterRun": { "2": { "line": 124, "col": 9 }, "3": { "line": 124, "col": 9 }, "4": { "line": 124, "col": 2 }, "3.0": { "line": 124, "col": 9 }, "3.1": { "line": 125, "col": 20 }, "3.2": { "line": 125, "col": 20 }, "3.3": { "line": 124, "col": 9 }, "3.4": { "line": 126, "col": 18 }, "3.5": { "line": 126, "col": 18 } }, "stdlib/agents/planner.agency:runApproved": { "1": { "line": 133, "col": 2 }, "2": { "line": 136, "col": 2 }, "3": { "line": 137, "col": 9 }, "4": { "line": 137, "col": 9 }, "5": { "line": 137, "col": 2 }, "4.0": { "line": 137, "col": 9 }, "4.1": { "line": 138, "col": 18 }, "4.2": { "line": 138, "col": 18 }, "4.3": { "line": 137, "col": 9 }, "4.4": { "line": 139, "col": 18 }, "4.5": { "line": 139, "col": 18 } }, "stdlib/agents/planner.agency:planStep": { "1": { "line": 144, "col": 2 }, "2": { "line": 145, "col": 9 }, "3": { "line": 145, "col": 9 }, "4": { "line": 145, "col": 2 }, "3.0": { "line": 145, "col": 9 }, "3.1": { "line": 146, "col": 18 }, "3.2": { "line": 146, "col": 18 }, "3.3": { "line": 145, "col": 9 }, "3.4": { "line": 147, "col": 20 }, "3.5": { "line": 147, "col": 20 } }, "stdlib/agents/planner.agency:plannerAgent": { "1": { "line": 165, "col": 2 }, "2": { "line": 175, "col": 2 } }, "stdlib/agents/planner.agency:__block_0": { "1.0.0": { "line": 166, "col": 40 }, "1.0.1": { "line": 166, "col": 40 }, "1.0.2": { "line": 166, "col": 124 }, "1.0.3": { "line": 166, "col": 124 }, "1.0": { "line": 166, "col": 21 }, "1.1": { "line": 166, "col": 4 }, "1.2": { "line": 167, "col": 4 }, "1.3": { "line": 168, "col": 4 }, "1.4.0": { "line": 170, "col": 6 }, "1.4.1": { "line": 171, "col": 6 }, "1.4": { "line": 169, "col": 4 }, "1.5": { "line": 173, "col": 4 } } };
export {
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  afterRun,
  approve,
  completedState,
  stdin_default as default,
  fallbackState,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  judgeAfterRun,
  planCodePrompt,
  planStep,
  plannerAgent,
  regenState,
  reject,
  rejectedState,
  renderEffectLines,
  renderEffects,
  requestApproval,
  respondToInterrupts,
  rewindFrom,
  runApproved
};
