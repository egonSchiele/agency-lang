import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { applyAgentCwd } from "agency-lang/stdlib/index.js";
import { isAbsolute } from "agency-lang/stdlib/path.js";
import { _ls, _grep, _glob, _stat, _exists, _which, _exec, _bash } from "agency-lang/stdlib-lib/shell.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isFailure,
  stampFailureBoundary,
  __tryCall,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/shell.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(applyAgentCwd);
__registerTool(isAbsolute);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/shell.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/shell.agency");
}
__registerGlobalsInit("stdlib/shell.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/shell.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const ExecResult = z.object({ "stdout": z.string(), "stderr": z.string(), "exitCode": z.number() });
async function __exec_impl(command, args = __UNSET, cwd = __UNSET, timeout = __UNSET, stdin = __UNSET, allowedExecutables = __UNSET, blockedCommands = __UNSET, allowedPaths = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/shell.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["command"] = command;
  __stack.args["args"] = args === __UNSET ? [] : args;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __stack.args["timeout"] = timeout === __UNSET ? 0 : timeout;
  __stack.args["stdin"] = stdin === __UNSET ? `` : stdin;
  __stack.args["allowedExecutables"] = allowedExecutables === __UNSET ? [] : allowedExecutables;
  __stack.args["blockedCommands"] = blockedCommands === __UNSET ? [] : blockedCommands;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/shell.agency", scopeName: "exec", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("command" in __overrides) {
      command = __overrides["command"];
      __stack.args["command"] = command;
    }
    if ("args" in __overrides) {
      args = __overrides["args"];
      __stack.args["args"] = args;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
    if ("timeout" in __overrides) {
      timeout = __overrides["timeout"];
      __stack.args["timeout"] = timeout;
    }
    if ("stdin" in __overrides) {
      stdin = __overrides["stdin"];
      __stack.args["stdin"] = stdin;
    }
    if ("allowedExecutables" in __overrides) {
      allowedExecutables = __overrides["allowedExecutables"];
      __stack.args["allowedExecutables"] = allowedExecutables;
    }
    if ("blockedCommands" in __overrides) {
      blockedCommands = __overrides["blockedCommands"];
      __stack.args["blockedCommands"] = blockedCommands;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "exec",
            args: {
              command,
              args,
              cwd,
              timeout,
              stdin,
              allowedExecutables,
              blockedCommands,
              allowedPaths,
              useAgentCwd
            },
            moduleId: "stdlib/shell.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.cwd = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.cwd]
              });
              if (hasInterrupts(__stack.args.cwd)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.cwd);
                return;
              }
              if (isAborted(__stack.args.cwd)) {
                runner3.halt(__stack.args.cwd.carryThrough(__stack, "exec"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.subcommand = ``;
      });
      await runner.ifElse(4, [
        {
          condition: async () => __stack.args.args.length > 0,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.subcommand = __nn(__stack.args.args[0]);
            });
          }
        }
      ]);
      await runner.step(5, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_5);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::exec", `Are you sure you want to run this command?`, {
            "command": __stack.args.command,
            "args": __stack.args.args,
            "subcommand": __stack.locals.subcommand,
            "cwd": __stack.args.cwd,
            "timeout": __stack.args.timeout,
            "stdin": __stack.args.stdin
          }, "std::shell", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_5 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/shell.agency", scopeName: "exec", stepPath: "5" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_exec, {
          type: "positional",
          args: [__stack.args.command, __stack.args.args, __stack.args.cwd, __stack.args.timeout, __stack.args.stdin, {
            "allowedExecutables": __stack.args.allowedExecutables,
            "blockedCommands": __stack.args.blockedCommands,
            "allowedPaths": __stack.args.allowedPaths
          }]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "exec");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function exec threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "exec"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "exec",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "exec",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const exec = __AgencyFunction.create({
  name: "exec",
  module: "stdlib/shell.agency",
  fn: __exec_impl,
  params: [{
    name: "command",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "args",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "timeout",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "stdin",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedExecutables",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "blockedCommands",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "exec",
    description: `Run an executable directly with an array of arguments, bypassing the shell, and return its stdout, stderr, and exit code. Arguments are passed straight to the process without shell interpretation, which prevents command injection. Prefer this whenever you have a known command and structured arguments.

  @param command - The executable to run
  @param args - Arguments to pass
  @param cwd - Working directory for the command
  @param timeout - Time limit in milliseconds (e.g. 30s)
  @param stdin - Input to feed to the command
  @param allowedExecutables - Only allow running these executables (allow-list)
  @param blockedCommands - Block running these executables
  @param allowedPaths - Only allow cwd values under these path prefixes
  @param useAgentCwd - When true, a relative or empty cwd is resolved against the agent working directory if one is set; an absolute cwd is left unchanged`,
    schema: z.object({ "command": z.string(), "args": z.array(z.string()).nullable().describe("Default: []"), "cwd": z.string().nullable().describe("Default: "), "timeout": z.number().nullable().describe("Default: 0"), "stdin": z.string().nullable().describe("Default: "), "allowedExecutables": z.array(z.string()).nullable().describe("Default: []"), "blockedCommands": z.array(z.string()).nullable().describe("Default: []"), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true
}, __toolRegistry);
async function __bash_impl(command, cwd = __UNSET, timeout = __UNSET, stdin = __UNSET, blockedCommands = __UNSET, allowedPaths = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/shell.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["command"] = command;
  __stack.args["cwd"] = cwd === __UNSET ? `` : cwd;
  __stack.args["timeout"] = timeout === __UNSET ? 0 : timeout;
  __stack.args["stdin"] = stdin === __UNSET ? `` : stdin;
  __stack.args["blockedCommands"] = blockedCommands === __UNSET ? [] : blockedCommands;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/shell.agency", scopeName: "bash", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("command" in __overrides) {
      command = __overrides["command"];
      __stack.args["command"] = command;
    }
    if ("cwd" in __overrides) {
      cwd = __overrides["cwd"];
      __stack.args["cwd"] = cwd;
    }
    if ("timeout" in __overrides) {
      timeout = __overrides["timeout"];
      __stack.args["timeout"] = timeout;
    }
    if ("stdin" in __overrides) {
      stdin = __overrides["stdin"];
      __stack.args["stdin"] = stdin;
    }
    if ("blockedCommands" in __overrides) {
      blockedCommands = __overrides["blockedCommands"];
      __stack.args["blockedCommands"] = blockedCommands;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "bash",
            args: {
              command,
              cwd,
              timeout,
              stdin,
              blockedCommands,
              allowedPaths,
              useAgentCwd
            },
            moduleId: "stdlib/shell.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.cwd = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.cwd]
              });
              if (hasInterrupts(__stack.args.cwd)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.cwd);
                return;
              }
              if (isAborted(__stack.args.cwd)) {
                runner3.halt(__stack.args.cwd.carryThrough(__stack, "bash"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::bash", `Are you sure you want to run this shell command?`, {
            "command": __stack.args.command,
            "cwd": __stack.args.cwd,
            "timeout": __stack.args.timeout,
            "stdin": __stack.args.stdin
          }, "std::shell", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/shell.agency", scopeName: "bash", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_bash, {
          type: "positional",
          args: [__stack.args.command, __stack.args.cwd, __stack.args.timeout, __stack.args.stdin, {
            "blockedCommands": __stack.args.blockedCommands,
            "allowedPaths": __stack.args.allowedPaths
          }]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "bash");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function bash threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "bash"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "bash",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "bash",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const bash = __AgencyFunction.create({
  name: "bash",
  module: "stdlib/shell.agency",
  fn: __bash_impl,
  params: [{
    name: "command",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "cwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "timeout",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "stdin",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "blockedCommands",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "bash",
    description: `Run a shell command string via sh -c and return its stdout, stderr, and exit code. The shell interprets the string, so pipes, redirects, and globbing work. Interpolated values are also subject to shell interpretation, so prefer running an executable directly with structured arguments when passing untrusted or dynamic values.

  @param command - The shell command to run
  @param cwd - Working directory for the command
  @param timeout - Time limit in milliseconds (e.g. 30s)
  @param stdin - Input to feed to the command
  @param blockedCommands - Block commands that start with these strings
  @param allowedPaths - Only allow cwd values under these path prefixes
  @param useAgentCwd - When true, a relative or empty cwd is resolved against the agent working directory if one is set; an absolute cwd is left unchanged`,
    schema: z.object({ "command": z.string(), "cwd": z.string().nullable().describe("Default: "), "timeout": z.number().nullable().describe("Default: 0"), "stdin": z.string().nullable().describe("Default: "), "blockedCommands": z.array(z.string()).nullable().describe("Default: []"), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true
}, __toolRegistry);
const LsEntry = z.object({ "name": z.string(), "path": z.string(), "type": z.union([z.literal("file"), z.literal("dir"), z.literal("symlink"), z.literal("other")]), "size": z.number() });
async function __ls_impl(dir = __UNSET, recursive = __UNSET, maxResults = __UNSET, allowedPaths = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/shell.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["dir"] = dir === __UNSET ? `.` : dir;
  __stack.args["recursive"] = recursive === __UNSET ? false : recursive;
  __stack.args["maxResults"] = maxResults === __UNSET ? 1e3 : maxResults;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/shell.agency", scopeName: "ls", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("recursive" in __overrides) {
      recursive = __overrides["recursive"];
      __stack.args["recursive"] = recursive;
    }
    if ("maxResults" in __overrides) {
      maxResults = __overrides["maxResults"];
      __stack.args["maxResults"] = maxResults;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "ls",
            args: {
              dir,
              recursive,
              maxResults,
              allowedPaths,
              useAgentCwd
            },
            moduleId: "stdlib/shell.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.dir = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dir]
              });
              if (hasInterrupts(__stack.args.dir)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dir);
                return;
              }
              if (isAborted(__stack.args.dir)) {
                runner3.halt(__stack.args.dir.carryThrough(__stack, "ls"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::ls", `Are you sure you want to list this directory?`, {
            "dir": __stack.args.dir,
            "recursive": __stack.args.recursive,
            "maxResults": __stack.args.maxResults
          }, "std::shell", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/shell.agency", scopeName: "ls", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_ls, {
          type: "positional",
          args: [__stack.args.dir, __stack.args.recursive, __stack.args.allowedPaths, __stack.args.maxResults]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "ls",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "ls");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function ls threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "ls"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "ls",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "ls",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const ls = __AgencyFunction.create({
  name: "ls",
  module: "stdlib/shell.agency",
  fn: __ls_impl,
  params: [{
    name: "dir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "recursive",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxResults",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "ls",
    description: `List entries in a directory. Each entry has name, path, type ("file", "dir", "symlink", or "other"), and size. Set recursive to true to walk subdirectories. Fails if the directory cannot be read.

  A recursive listing skips heavyweight dirs (node_modules, .git, dist, build, .next, .cache) and stops at maxResults. A non-recursive listing still shows those dirs. If entries look truncated, narrow dir or raise maxResults.

  @param dir - The directory to list
  @param recursive - Whether to walk subdirectories
  @param maxResults - Maximum number of entries to return
  @param allowedPaths - Only allow listing directories under these prefixes
  @param useAgentCwd - When true, resolve a relative dir against the agent working directory if one is set`,
    schema: z.object({ "dir": z.string().nullable().describe("Default: ."), "recursive": z.boolean().nullable().describe("Default: false"), "maxResults": z.number().nullable().describe("Default: 1000"), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
const GrepMatch = z.object({ "file": z.string(), "line": z.number(), "text": z.string() });
async function __grep_impl(pattern, dir = __UNSET, flags = __UNSET, maxResults = __UNSET, allowedPaths = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/shell.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["pattern"] = pattern;
  __stack.args["dir"] = dir === __UNSET ? `.` : dir;
  __stack.args["flags"] = flags === __UNSET ? `` : flags;
  __stack.args["maxResults"] = maxResults === __UNSET ? 200 : maxResults;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/shell.agency", scopeName: "grep", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("pattern" in __overrides) {
      pattern = __overrides["pattern"];
      __stack.args["pattern"] = pattern;
    }
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("flags" in __overrides) {
      flags = __overrides["flags"];
      __stack.args["flags"] = flags;
    }
    if ("maxResults" in __overrides) {
      maxResults = __overrides["maxResults"];
      __stack.args["maxResults"] = maxResults;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "grep",
            args: {
              pattern,
              dir,
              flags,
              maxResults,
              allowedPaths,
              useAgentCwd
            },
            moduleId: "stdlib/shell.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.dir = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dir]
              });
              if (hasInterrupts(__stack.args.dir)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dir);
                return;
              }
              if (isAborted(__stack.args.dir)) {
                runner3.halt(__stack.args.dir.carryThrough(__stack, "grep"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::grep", `Are you sure you want to search files with grep?`, {
            "pattern": __stack.args.pattern,
            "dir": __stack.args.dir,
            "flags": __stack.args.flags,
            "maxResults": __stack.args.maxResults
          }, "std::shell", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/shell.agency", scopeName: "grep", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_grep, {
          type: "positional",
          args: [__stack.args.pattern, __stack.args.dir, __stack.args.flags, __stack.args.maxResults, __stack.args.allowedPaths]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "grep",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "grep");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function grep threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "grep"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "grep",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "grep",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const grep = __AgencyFunction.create({
  name: "grep",
  module: "stdlib/shell.agency",
  fn: __grep_impl,
  params: [{
    name: "pattern",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "flags",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxResults",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "grep",
    description: `Search for a regex pattern in files under a directory. Returns matches with file path, line number, and matched line. Skips node_modules, .git, dist, build. Fails if the pattern is not a valid regex or the directory cannot be read.

  Returned file values are relative to dir. Returns at most maxResults matches; if matches look truncated, narrow dir or refine the pattern.

  @param pattern - The regex pattern to search for
  @param dir - The directory to search in
  @param flags - Regex flags
  @param maxResults - Maximum number of results to return
  @param allowedPaths - Only allow searching under these path prefixes
  @param useAgentCwd - When true, resolve a relative dir against the agent working directory if one is set`,
    schema: z.object({ "pattern": z.string(), "dir": z.string().nullable().describe("Default: ."), "flags": z.string().nullable().describe("Default: "), "maxResults": z.number().nullable().describe("Default: 200"), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
async function __glob_impl(pattern, dir = __UNSET, maxResults = __UNSET, allowedPaths = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/shell.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["pattern"] = pattern;
  __stack.args["dir"] = dir === __UNSET ? `.` : dir;
  __stack.args["maxResults"] = maxResults === __UNSET ? 500 : maxResults;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/shell.agency", scopeName: "glob", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("pattern" in __overrides) {
      pattern = __overrides["pattern"];
      __stack.args["pattern"] = pattern;
    }
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("maxResults" in __overrides) {
      maxResults = __overrides["maxResults"];
      __stack.args["maxResults"] = maxResults;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "glob",
            args: {
              pattern,
              dir,
              maxResults,
              allowedPaths,
              useAgentCwd
            },
            moduleId: "stdlib/shell.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.dir = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dir]
              });
              if (hasInterrupts(__stack.args.dir)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dir);
                return;
              }
              if (isAborted(__stack.args.dir)) {
                runner3.halt(__stack.args.dir.carryThrough(__stack, "glob"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_2);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::glob", `Are you sure you want to glob files?`, {
            "pattern": __stack.args.pattern,
            "dir": __stack.args.dir,
            "maxResults": __stack.args.maxResults
          }, "std::shell", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_2 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/shell.agency", scopeName: "glob", stepPath: "2" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __tryCall(async () => await __call(_glob, {
          type: "positional",
          args: [__stack.args.pattern, __stack.args.dir, __stack.args.maxResults, __stack.args.allowedPaths]
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "glob",
          args: __stack.args
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "glob");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function glob threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "glob"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "glob",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "glob",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const glob = __AgencyFunction.create({
  name: "glob",
  module: "stdlib/shell.agency",
  fn: __glob_impl,
  params: [{
    name: "pattern",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "maxResults",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "glob",
    description: `Find files whose paths match a glob pattern (e.g. "src/**/*.ts"). Fails if the pattern is not valid glob syntax or the directory cannot be read.

  @param pattern - The glob pattern to match
  @param dir - The directory to search in
  @param maxResults - Maximum number of results to return
  @param allowedPaths - Only allow searching under these path prefixes
  @param useAgentCwd - When true, resolve a relative dir against the agent working directory if one is set`,
    schema: z.object({ "pattern": z.string(), "dir": z.string().nullable().describe("Default: ."), "maxResults": z.number().nullable().describe("Default: 500"), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true,
  markers: {
    idempotent: true
  }
}, __toolRegistry);
const StatInfo = z.object({ "exists": z.boolean(), "type": z.union([z.literal("file"), z.literal("dir"), z.literal("symlink"), z.literal("other"), z.literal("missing")]), "size": z.number(), "modifiedMs": z.number() });
async function __stat_impl(filename, dir = __UNSET, allowedPaths = __UNSET, useAgentCwd = __UNSET, followSymlinks = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/shell.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["filename"] = filename;
  __stack.args["dir"] = dir === __UNSET ? `` : dir;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __stack.args["followSymlinks"] = followSymlinks === __UNSET ? false : followSymlinks;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/shell.agency", scopeName: "stat", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
    if ("followSymlinks" in __overrides) {
      followSymlinks = __overrides["followSymlinks"];
      __stack.args["followSymlinks"] = followSymlinks;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "stat",
            args: {
              filename,
              dir,
              allowedPaths,
              useAgentCwd,
              followSymlinks
            },
            moduleId: "stdlib/shell.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd && !await __call(isAbsolute, {
            type: "positional",
            args: [__stack.args.filename]
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.dir = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dir]
              });
              if (hasInterrupts(__stack.args.dir)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dir);
                return;
              }
              if (isAborted(__stack.args.dir)) {
                runner3.halt(__stack.args.dir.carryThrough(__stack, "stat"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_stat, {
          type: "positional",
          args: [__stack.args.filename, __stack.args.dir, __stack.args.allowedPaths, __stack.args.followSymlinks]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "stat");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function stat threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "stat"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "stat",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "stat",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const stat = __AgencyFunction.create({
  name: "stat",
  module: "stdlib/shell.agency",
  fn: __stat_impl,
  params: [{
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "followSymlinks",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "stat",
    description: `Return metadata about a filesystem entry: whether it exists, its type ("file", "dir", "symlink", "other", or "missing" if absent), size in bytes, and mtime in ms.

  @param filename - The path to stat
  @param dir - Directory to resolve a relative filename against; filename cannot escape it. When empty, filename resolves against the process cwd and absolute paths are accepted
  @param allowedPaths - Only allow paths under these prefixes
  @param useAgentCwd - When true, resolve a relative filename against the agent working directory if one is set; absolute filenames are unaffected
  @param followSymlinks - When true, report the symlink target's type and size (a broken link reports "missing"); when false, report the link itself with type "symlink"`,
    schema: z.object({ "filename": z.string(), "dir": z.string().nullable().describe("Default: "), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "useAgentCwd": z.boolean().nullable().describe("Default: false"), "followSymlinks": z.boolean().nullable().describe("Default: false") })
  },
  exported: true
}, __toolRegistry);
async function __exists_impl(filename, dir = __UNSET, allowedPaths = __UNSET, useAgentCwd = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/shell.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["filename"] = filename;
  __stack.args["dir"] = dir === __UNSET ? `` : dir;
  __stack.args["allowedPaths"] = allowedPaths === __UNSET ? [] : allowedPaths;
  __stack.args["useAgentCwd"] = useAgentCwd === __UNSET ? false : useAgentCwd;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/shell.agency", scopeName: "exists", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("filename" in __overrides) {
      filename = __overrides["filename"];
      __stack.args["filename"] = filename;
    }
    if ("dir" in __overrides) {
      dir = __overrides["dir"];
      __stack.args["dir"] = dir;
    }
    if ("allowedPaths" in __overrides) {
      allowedPaths = __overrides["allowedPaths"];
      __stack.args["allowedPaths"] = allowedPaths;
    }
    if ("useAgentCwd" in __overrides) {
      useAgentCwd = __overrides["useAgentCwd"];
      __stack.args["useAgentCwd"] = useAgentCwd;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "exists",
            args: {
              filename,
              dir,
              allowedPaths,
              useAgentCwd
            },
            moduleId: "stdlib/shell.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __stack.args.useAgentCwd && !await __call(isAbsolute, {
            type: "positional",
            args: [__stack.args.filename]
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.args.dir = await __call(applyAgentCwd, {
                type: "positional",
                args: [__stack.args.dir]
              });
              if (hasInterrupts(__stack.args.dir)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.args.dir);
                return;
              }
              if (isAborted(__stack.args.dir)) {
                runner3.halt(__stack.args.dir.carryThrough(__stack, "exists"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_exists, {
          type: "positional",
          args: [__stack.args.filename, __stack.args.dir, __stack.args.allowedPaths]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "exists");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function exists threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "exists"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "exists",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "exists",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const exists = __AgencyFunction.create({
  name: "exists",
  module: "stdlib/shell.agency",
  fn: __exists_impl,
  params: [{
    name: "filename",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "dir",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "allowedPaths",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "useAgentCwd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "exists",
    description: `Return true if a file or directory exists at the given path. Probing a path outside allowedPaths raises an error rather than silently returning false.

  @param filename - The path to check
  @param dir - Directory to resolve a relative filename against; filename cannot escape it. When empty, filename resolves against the process cwd and absolute paths are accepted
  @param allowedPaths - Only allow paths under these prefixes
  @param useAgentCwd - When true, resolve a relative filename against the agent working directory if one is set; absolute filenames are unaffected`,
    schema: z.object({ "filename": z.string(), "dir": z.string().nullable().describe("Default: "), "allowedPaths": z.array(z.string()).nullable().describe("Default: []"), "useAgentCwd": z.boolean().nullable().describe("Default: false") })
  },
  exported: true
}, __toolRegistry);
async function __which_impl(command) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/shell.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["command"] = command;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/shell.agency", scopeName: "which", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("command" in __overrides) {
      command = __overrides["command"];
      __stack.args["command"] = command;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "which",
            args: {
              command
            },
            moduleId: "stdlib/shell.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_which, {
          type: "positional",
          args: [__stack.args.command]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "which");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function which threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "which"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "which",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "which",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const which = __AgencyFunction.create({
  name: "which",
  module: "stdlib/shell.agency",
  fn: __which_impl,
  params: [{
    name: "command",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "which",
    description: `Locate an executable in PATH and return its absolute path, or an empty string if not found. On Windows, also tries PATHEXT extensions.

  @param command - The executable to find`,
    schema: z.object({ "command": z.string() })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/shell.agency:exec": { "1": { "line": 92, "col": 2 }, "3": { "line": 100, "col": 2 }, "4": { "line": 101, "col": 2 }, "5": { "line": 104, "col": 2 }, "6": { "line": 113, "col": 2 }, "1.0": { "line": 93, "col": 4 }, "4.0": { "line": 102, "col": 4 } }, "stdlib/shell.agency:bash": { "1": { "line": 152, "col": 2 }, "2": { "line": 155, "col": 2 }, "3": { "line": 162, "col": 2 }, "1.0": { "line": 153, "col": 4 } }, "stdlib/shell.agency:ls": { "1": { "line": 199, "col": 2 }, "2": { "line": 202, "col": 2 }, "3": { "line": 208, "col": 2 }, "1.0": { "line": 200, "col": 4 } }, "stdlib/shell.agency:grep": { "1": { "line": 237, "col": 2 }, "2": { "line": 240, "col": 2 }, "3": { "line": 247, "col": 2 }, "1.0": { "line": 238, "col": 4 } }, "stdlib/shell.agency:glob": { "1": { "line": 266, "col": 2 }, "2": { "line": 269, "col": 2 }, "3": { "line": 275, "col": 2 }, "1.0": { "line": 267, "col": 4 } }, "stdlib/shell.agency:stat": { "1": { "line": 301, "col": 2 }, "2": { "line": 304, "col": 2 }, "1.0": { "line": 302, "col": 4 } }, "stdlib/shell.agency:exists": { "1": { "line": 321, "col": 2 }, "2": { "line": 324, "col": 2 }, "1.0": { "line": 322, "col": 4 } }, "stdlib/shell.agency:which": { "1": { "line": 333, "col": 2 } } };
export {
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  bash,
  stdin_default as default,
  exec,
  exists,
  glob,
  grep,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  ls,
  reject,
  respondToInterrupts,
  rewindFrom,
  stat,
  which
};
