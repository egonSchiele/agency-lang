import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { fetchJSON } from "agency-lang/stdlib/http.js";
import { env } from "agency-lang/stdlib/system.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  success,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/data/finance/fred.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(fetchJSON);
__registerTool(env);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/data/finance/fred.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/data/finance/fred.agency");
  __ctx.globals.set("stdlib/data/finance/fred.agency", "FRED_BASE", `https://api.stlouisfed.org/fred/`);
  __ctx.globals.set("stdlib/data/finance/fred.agency", "FRED_DOMAINS", [`api.stlouisfed.org`]);
}
__registerGlobalsInit("stdlib/data/finance/fred.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/data/finance/fred.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const FredObservation = z.object({ "date": z.string(), "value": z.union([z.number(), z.null()]).optional().default(null) });
const FredSeries = z.object({ "seriesId": z.string(), "units": z.string(), "observations": z.array(FredObservation) });
const FredSeriesInfo = z.object({ "id": z.string(), "title": z.string(), "units": z.string(), "frequency": z.string(), "observationStart": z.string(), "observationEnd": z.string(), "notes": z.string() });
const FredUnits = z.union([z.literal("lin"), z.literal("chg"), z.literal("ch1"), z.literal("pch"), z.literal("pc1"), z.literal("pca"), z.literal("cch"), z.literal("cca"), z.literal("log")]);
const FredFrequency = z.union([z.literal("d"), z.literal("w"), z.literal("bw"), z.literal("m"), z.literal("q"), z.literal("sa"), z.literal("a"), z.literal("wef"), z.literal("weth"), z.literal("wetu"), z.literal("wew"), z.literal("wetdt"), z.literal("wem"), z.literal("wesun")]);
async function __appendParam_impl(path2, key, value) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/fred.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["path"] = path2;
  __stack.args["key"] = key;
  __stack.args["value"] = value;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/fred.agency", scopeName: "appendParam", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("path" in __overrides) {
      path2 = __overrides["path"];
      __stack.args["path"] = path2;
    }
    if ("key" in __overrides) {
      key = __overrides["key"];
      __stack.args["key"] = key;
    }
    if ("value" in __overrides) {
      value = __overrides["value"];
      __stack.args["value"] = value;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "appendParam",
            args: {
              path: path2,
              key,
              value
            },
            moduleId: "stdlib/data/finance/fred.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.value, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.args.path);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`${__stack.args.path}&${__stack.args.key}=${await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.value]
        })}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "appendParam");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function appendParam threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "appendParam"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "appendParam",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "appendParam",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const appendParam = __AgencyFunction.create({
  name: "appendParam",
  module: "stdlib/data/finance/fred.agency",
  fn: __appendParam_impl,
  params: [{
    name: "path",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "key",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "value",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "appendParam",
    description: "No description provided.",
    schema: z.object({ "path": z.string(), "key": z.string(), "value": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildFredObservationsPath_impl(seriesId, apiKey, observationStart, observationEnd, frequency, units, limit) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/fred.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["seriesId"] = seriesId;
  __stack.args["apiKey"] = apiKey;
  __stack.args["observationStart"] = observationStart;
  __stack.args["observationEnd"] = observationEnd;
  __stack.args["frequency"] = frequency;
  __stack.args["units"] = units;
  __stack.args["limit"] = limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/fred.agency", scopeName: "buildFredObservationsPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("seriesId" in __overrides) {
      seriesId = __overrides["seriesId"];
      __stack.args["seriesId"] = seriesId;
    }
    if ("apiKey" in __overrides) {
      apiKey = __overrides["apiKey"];
      __stack.args["apiKey"] = apiKey;
    }
    if ("observationStart" in __overrides) {
      observationStart = __overrides["observationStart"];
      __stack.args["observationStart"] = observationStart;
    }
    if ("observationEnd" in __overrides) {
      observationEnd = __overrides["observationEnd"];
      __stack.args["observationEnd"] = observationEnd;
    }
    if ("frequency" in __overrides) {
      frequency = __overrides["frequency"];
      __stack.args["frequency"] = frequency;
    }
    if ("units" in __overrides) {
      units = __overrides["units"];
      __stack.args["units"] = units;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildFredObservationsPath",
            args: {
              seriesId,
              apiKey,
              observationStart,
              observationEnd,
              frequency,
              units,
              limit
            },
            moduleId: "stdlib/data/finance/fred.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.path = `series/observations?series_id=${await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.seriesId]
        })}&api_key=${await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.apiKey]
        })}&file_type=json`;
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.path = await __call(appendParam, {
          type: "positional",
          args: [__stack.locals.path, `observation_start`, __stack.args.observationStart]
        });
        if (hasInterrupts(__stack.locals.path)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.path);
          return;
        }
        if (isAborted(__stack.locals.path)) {
          runner2.halt(__stack.locals.path.carryThrough(__stack, "buildFredObservationsPath"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.path = await __call(appendParam, {
          type: "positional",
          args: [__stack.locals.path, `observation_end`, __stack.args.observationEnd]
        });
        if (hasInterrupts(__stack.locals.path)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.path);
          return;
        }
        if (isAborted(__stack.locals.path)) {
          runner2.halt(__stack.locals.path.carryThrough(__stack, "buildFredObservationsPath"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.path = await __call(appendParam, {
          type: "positional",
          args: [__stack.locals.path, `frequency`, __stack.args.frequency]
        });
        if (hasInterrupts(__stack.locals.path)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.path);
          return;
        }
        if (isAborted(__stack.locals.path)) {
          runner2.halt(__stack.locals.path.carryThrough(__stack, "buildFredObservationsPath"));
          return;
        }
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.path = await __call(appendParam, {
          type: "positional",
          args: [__stack.locals.path, `units`, __stack.args.units]
        });
        if (hasInterrupts(__stack.locals.path)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.path);
          return;
        }
        if (isAborted(__stack.locals.path)) {
          runner2.halt(__stack.locals.path.carryThrough(__stack, "buildFredObservationsPath"));
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.limitStr = ``;
      });
      await runner.ifElse(7, [
        {
          condition: async () => __stack.args.limit > 0,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.limitStr = `${__stack.args.limit}`;
            });
          }
        }
      ]);
      await runner.step(8, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(appendParam, {
          type: "positional",
          args: [__stack.locals.path, `limit`, __stack.locals.limitStr]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildFredObservationsPath");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildFredObservationsPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildFredObservationsPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildFredObservationsPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildFredObservationsPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildFredObservationsPath = __AgencyFunction.create({
  name: "buildFredObservationsPath",
  module: "stdlib/data/finance/fred.agency",
  fn: __buildFredObservationsPath_impl,
  params: [{
    name: "seriesId",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "apiKey",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "observationStart",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "observationEnd",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "frequency",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "units",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildFredObservationsPath",
    description: "No description provided.",
    schema: z.object({ "seriesId": z.string(), "apiKey": z.string(), "observationStart": z.string(), "observationEnd": z.string(), "frequency": z.string(), "units": z.string(), "limit": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __buildFredSeriesPath_impl(seriesId, apiKey) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/fred.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["seriesId"] = seriesId;
  __stack.args["apiKey"] = apiKey;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/fred.agency", scopeName: "buildFredSeriesPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("seriesId" in __overrides) {
      seriesId = __overrides["seriesId"];
      __stack.args["seriesId"] = seriesId;
    }
    if ("apiKey" in __overrides) {
      apiKey = __overrides["apiKey"];
      __stack.args["apiKey"] = apiKey;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildFredSeriesPath",
            args: {
              seriesId,
              apiKey
            },
            moduleId: "stdlib/data/finance/fred.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`series?series_id=${await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.seriesId]
        })}&api_key=${await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.apiKey]
        })}&file_type=json`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildFredSeriesPath");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildFredSeriesPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildFredSeriesPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildFredSeriesPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildFredSeriesPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildFredSeriesPath = __AgencyFunction.create({
  name: "buildFredSeriesPath",
  module: "stdlib/data/finance/fred.agency",
  fn: __buildFredSeriesPath_impl,
  params: [{
    name: "seriesId",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "apiKey",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildFredSeriesPath",
    description: "No description provided.",
    schema: z.object({ "seriesId": z.string(), "apiKey": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __toFredValue_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/fred.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/fred.agency", scopeName: "toFredValue", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "toFredValue",
            args: {
              raw
            },
            moduleId: "stdlib/data/finance/fred.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => __eq(__stack.args.raw, `.`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(null);
              return;
            });
          }
        }
      ]);
      await runner.step(2, async (runner2) => {
        __stack.locals.n = await __call(Number, {
          type: "positional",
          args: [__stack.args.raw]
        });
        if (hasInterrupts(__stack.locals.n)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.n);
          return;
        }
        if (isAborted(__stack.locals.n)) {
          runner2.halt(__stack.locals.n.carryThrough(__stack, "toFredValue"));
          return;
        }
      });
      await runner.ifElse(3, [
        {
          condition: async () => await __call(isNaN, {
            type: "positional",
            args: [__stack.locals.n]
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(null);
              return;
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.n);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "toFredValue");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function toFredValue threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "toFredValue"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "toFredValue",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "toFredValue",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const toFredValue = __AgencyFunction.create({
  name: "toFredValue",
  module: "stdlib/data/finance/fred.agency",
  fn: __toFredValue_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "toFredValue",
    description: "No description provided.",
    schema: z.object({ "raw": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __parseFredObservations_impl(seriesId, raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/fred.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["seriesId"] = seriesId;
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/fred.agency", scopeName: "parseFredObservations", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("seriesId" in __overrides) {
      seriesId = __overrides["seriesId"];
      __stack.args["seriesId"] = seriesId;
    }
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseFredObservations",
            args: {
              seriesId,
              raw
            },
            moduleId: "stdlib/data/finance/fred.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.rawObs = __stack.locals.r.observations ?? [];
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.observations = await __call(map, {
          type: "named",
          positionalArgs: [__stack.locals.rawObs],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/data/finance/fred.agency", fn: async (obs) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["obs"] = obs;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/finance/fred.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt({
                  "date": __bstack.args.obs.date ?? ``,
                  "value": await __call(toFredValue, {
                    type: "positional",
                    args: [__bstack.args.obs.value ?? `.`]
                  })
                });
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_0");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "obs", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        });
        if (hasInterrupts(__stack.locals.observations)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.observations);
          return;
        }
        if (isAborted(__stack.locals.observations)) {
          runner2.halt(__stack.locals.observations.carryThrough(__stack, "parseFredObservations"));
          return;
        }
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "seriesId": __stack.args.seriesId,
          "units": __stack.locals.r.units ?? ``,
          "observations": __stack.locals.observations
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseFredObservations");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseFredObservations threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseFredObservations"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseFredObservations",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseFredObservations",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseFredObservations = __AgencyFunction.create({
  name: "parseFredObservations",
  module: "stdlib/data/finance/fred.agency",
  fn: __parseFredObservations_impl,
  params: [{
    name: "seriesId",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseFredObservations",
    description: "No description provided.",
    schema: z.object({ "seriesId": z.string(), "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __parseFredInfo_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/fred.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/fred.agency", scopeName: "parseFredInfo", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseFredInfo",
            args: {
              raw
            },
            moduleId: "stdlib/data/finance/fred.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.list = __stack.locals.r.seriess ?? [];
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.info = __nn(__stack.locals.list[0]) ?? {};
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "id": __stack.locals.info.id ?? ``,
          "title": __stack.locals.info.title ?? ``,
          "units": __stack.locals.info.units ?? ``,
          "frequency": __stack.locals.info.frequency ?? ``,
          "observationStart": __stack.locals.info.observation_start ?? ``,
          "observationEnd": __stack.locals.info.observation_end ?? ``,
          "notes": __stack.locals.info.notes ?? ``
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseFredInfo");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseFredInfo threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseFredInfo"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseFredInfo",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseFredInfo",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseFredInfo = __AgencyFunction.create({
  name: "parseFredInfo",
  module: "stdlib/data/finance/fred.agency",
  fn: __parseFredInfo_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseFredInfo",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __fredObservationsFinalize_impl(seriesId, fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/fred.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["seriesId"] = seriesId;
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/fred.agency", scopeName: "fredObservationsFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("seriesId" in __overrides) {
      seriesId = __overrides["seriesId"];
      __stack.args["seriesId"] = seriesId;
    }
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "fredObservationsFinalize",
            args: {
              seriesId,
              fetchResult
            },
            moduleId: "stdlib/data/finance/fred.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_3 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_3),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_3.value;
            });
            await runner2.ifElse(1, [
              {
                condition: async () => __eq(__stack.locals.body.observations ?? null, null),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    runner4.exitMatch(1, failure(`FRED returned no observations for '${__stack.args.seriesId}' (check the series id)`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "fredObservationsFinalize", args: __stack.args }));
                    return;
                  });
                }
              }
            ]);
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(1, await success(await __call(parseFredObservations, {
                type: "positional",
                args: [__stack.args.seriesId, __stack.locals.body]
              })));
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_3),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_3.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_2 = failure(`FRED request failed: ${__stack.locals.err}`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "fredObservationsFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_2)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_2);
                return;
              }
              if (isAborted(__stack.locals.__armval_2)) {
                runner3.halt(__stack.locals.__armval_2.carryThrough(__stack, "fredObservationsFinalize"));
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_2);
              return;
            });
          }
        }
      ], void 0, { matchId: 1 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "fredObservationsFinalize");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function fredObservationsFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "fredObservationsFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "fredObservationsFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "fredObservationsFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const fredObservationsFinalize = __AgencyFunction.create({
  name: "fredObservationsFinalize",
  module: "stdlib/data/finance/fred.agency",
  fn: __fredObservationsFinalize_impl,
  params: [{
    name: "seriesId",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "fredObservationsFinalize",
    description: "No description provided.",
    schema: z.object({ "seriesId": z.string(), "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __fredInfoFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/fred.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/fred.agency", scopeName: "fredInfoFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "fredInfoFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/finance/fred.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_6 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_6),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_6.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.list = __stack.locals.body.seriess ?? [];
            });
            await runner2.ifElse(2, [
              {
                condition: async () => __eq(__stack.locals.list.length, 0),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    runner4.exitMatch(4, failure(`FRED returned no series metadata (check the series id)`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "fredInfoFinalize", args: __stack.args }));
                    return;
                  });
                }
              }
            ]);
            await runner2.step(3, async (runner3) => {
              runner3.exitMatch(4, await success(await __call(parseFredInfo, {
                type: "positional",
                args: [__stack.locals.body]
              })));
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_6),
          body: async (runner2) => {
            await runner2.step(4, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_6.error;
            });
            await runner2.step(5, async (runner3) => {
              __stack.locals.__armval_5 = failure(`FRED request failed: ${__stack.locals.err}`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "fredInfoFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_5)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_5);
                return;
              }
              if (isAborted(__stack.locals.__armval_5)) {
                runner3.halt(__stack.locals.__armval_5.carryThrough(__stack, "fredInfoFinalize"));
                return;
              }
            });
            await runner2.step(6, async (runner3) => {
              runner3.exitMatch(4, __stack.locals.__armval_5);
              return;
            });
          }
        }
      ], void 0, { matchId: 4 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_4));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "fredInfoFinalize");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function fredInfoFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "fredInfoFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "fredInfoFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "fredInfoFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const fredInfoFinalize = __AgencyFunction.create({
  name: "fredInfoFinalize",
  module: "stdlib/data/finance/fred.agency",
  fn: __fredInfoFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "fredInfoFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __fredSeries_impl(seriesId, observationStart = __UNSET, observationEnd = __UNSET, frequency = __UNSET, units = __UNSET, limit = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/fred.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["seriesId"] = seriesId;
  __stack.args["observationStart"] = observationStart === __UNSET ? `` : observationStart;
  __stack.args["observationEnd"] = observationEnd === __UNSET ? `` : observationEnd;
  __stack.args["frequency"] = frequency === __UNSET ? null : frequency;
  __stack.args["units"] = units === __UNSET ? null : units;
  __stack.args["limit"] = limit === __UNSET ? 0 : limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/fred.agency", scopeName: "fredSeries", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("seriesId" in __overrides) {
      seriesId = __overrides["seriesId"];
      __stack.args["seriesId"] = seriesId;
    }
    if ("observationStart" in __overrides) {
      observationStart = __overrides["observationStart"];
      __stack.args["observationStart"] = observationStart;
    }
    if ("observationEnd" in __overrides) {
      observationEnd = __overrides["observationEnd"];
      __stack.args["observationEnd"] = observationEnd;
    }
    if ("frequency" in __overrides) {
      frequency = __overrides["frequency"];
      __stack.args["frequency"] = frequency;
    }
    if ("units" in __overrides) {
      units = __overrides["units"];
      __stack.args["units"] = units;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "fredSeries",
            args: {
              seriesId,
              observationStart,
              observationEnd,
              frequency,
              units,
              limit
            },
            moduleId: "stdlib/data/finance/fred.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.apiKey = await __call(env, {
          type: "positional",
          args: [`FRED_API_KEY`]
        }) ?? ``;
      });
      await runner.ifElse(2, [
        {
          condition: async () => __eq(__stack.locals.apiKey, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(`FRED_API_KEY is not set. Get a free key at https://fred.stlouisfed.org/docs/api/api_key.html`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "fredSeries", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_3);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::fred", `Fetch this FRED series?`, {
            "seriesId": __stack.args.seriesId
          }, "std::data/finance/fred", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_3 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/finance/fred.agency", scopeName: "fredSeries", stepPath: "3" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.path = await __call(buildFredObservationsPath, {
          type: "positional",
          args: [__stack.args.seriesId, __stack.locals.apiKey, __stack.args.observationStart, __stack.args.observationEnd, __stack.args.frequency ?? ``, __stack.args.units ?? ``, __stack.args.limit]
        });
        if (hasInterrupts(__stack.locals.path)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.path);
          return;
        }
        if (isAborted(__stack.locals.path)) {
          runner2.halt(__stack.locals.path.carryThrough(__stack, "fredSeries"));
          return;
        }
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.result = await __call(fetchJSON, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            baseUrl: __globals().get("stdlib/data/finance/fred.agency", "FRED_BASE"),
            path: __stack.locals.path,
            allowedDomains: __globals().get("stdlib/data/finance/fred.agency", "FRED_DOMAINS")
          }
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "fredSeries"));
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(fredObservationsFinalize, {
          type: "positional",
          args: [__stack.args.seriesId, __stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "fredSeries");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function fredSeries threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "fredSeries"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "fredSeries",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "fredSeries",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const fredSeries = __AgencyFunction.create({
  name: "fredSeries",
  module: "stdlib/data/finance/fred.agency",
  fn: __fredSeries_impl,
  params: [{
    name: "seriesId",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "observationStart",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "observationEnd",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "frequency",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "units",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "fredSeries",
    description: `Fetch a U.S. macroeconomic time-series from FRED by its series id (e.g. "UNRATE" for the
  unemployment rate, "CPIAUCSL" for CPI, "FEDFUNDS" for the fed funds rate). Returns the
  series and a list of { date, value } observations, ordered oldest-first (value is null when
  missing). For the most recent data, set observationStart rather than relying on limit
  (limit caps from the oldest observation). Requires the FRED_API_KEY environment variable.

  @param seriesId - FRED series id, e.g. "UNRATE"
  @param observationStart - Optional earliest date, "YYYY-MM-DD" (empty for no bound)
  @param observationEnd - Optional latest date, "YYYY-MM-DD" (empty for no bound)
  @param frequency - Optional frequency aggregation code, e.g. "m", "q", "a" (null for native)
  @param units - Optional units transform code, e.g. "pch" for percent change (null for "lin")
  @param limit - Optional max observations from the oldest, 0 means no limit`,
    schema: z.object({ "seriesId": z.string(), "observationStart": z.string().nullable().describe("Default: "), "observationEnd": z.string().nullable().describe("Default: "), "frequency": z.union([FredFrequency, z.null()]).describe("Default: null"), "units": z.union([FredUnits, z.null()]).describe("Default: null"), "limit": z.number().nullable().describe("Default: 0") })
  },
  exported: true
}, __toolRegistry);
async function __fredSeriesInfo_impl(seriesId) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/finance/fred.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["seriesId"] = seriesId;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/finance/fred.agency", scopeName: "fredSeriesInfo", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("seriesId" in __overrides) {
      seriesId = __overrides["seriesId"];
      __stack.args["seriesId"] = seriesId;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "fredSeriesInfo",
            args: {
              seriesId
            },
            moduleId: "stdlib/data/finance/fred.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.apiKey = await __call(env, {
          type: "positional",
          args: [`FRED_API_KEY`]
        }) ?? ``;
      });
      await runner.ifElse(2, [
        {
          condition: async () => __eq(__stack.locals.apiKey, ``),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(failure(`FRED_API_KEY is not set. Get a free key at https://fred.stlouisfed.org/docs/api/api_key.html`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "fredSeriesInfo", args: __stack.args }));
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_3);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::fred", `Fetch this FRED series metadata?`, {
            "seriesId": __stack.args.seriesId
          }, "std::data/finance/fred", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_3 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/finance/fred.agency", scopeName: "fredSeriesInfo", stepPath: "3" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.path = await __call(buildFredSeriesPath, {
          type: "positional",
          args: [__stack.args.seriesId, __stack.locals.apiKey]
        });
        if (hasInterrupts(__stack.locals.path)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.path);
          return;
        }
        if (isAborted(__stack.locals.path)) {
          runner2.halt(__stack.locals.path.carryThrough(__stack, "fredSeriesInfo"));
          return;
        }
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.result = await __call(fetchJSON, {
          type: "named",
          positionalArgs: [],
          namedArgs: {
            baseUrl: __globals().get("stdlib/data/finance/fred.agency", "FRED_BASE"),
            path: __stack.locals.path,
            allowedDomains: __globals().get("stdlib/data/finance/fred.agency", "FRED_DOMAINS")
          }
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "fredSeriesInfo"));
          return;
        }
      });
      await runner.step(6, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(fredInfoFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "fredSeriesInfo");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function fredSeriesInfo threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "fredSeriesInfo"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "fredSeriesInfo",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "fredSeriesInfo",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const fredSeriesInfo = __AgencyFunction.create({
  name: "fredSeriesInfo",
  module: "stdlib/data/finance/fred.agency",
  fn: __fredSeriesInfo_impl,
  params: [{
    name: "seriesId",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "fredSeriesInfo",
    description: `Fetch metadata about a FRED series by its id: its human title, display units, frequency, and
  the date range it covers. Requires the FRED_API_KEY environment variable.

  @param seriesId - FRED series id, e.g. "UNRATE"`,
    schema: z.object({ "seriesId": z.string() })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/data/finance/fred.agency:appendParam": { "1": { "line": 83, "col": 2 }, "2": { "line": 86, "col": 2 }, "1.0": { "line": 84, "col": 4 } }, "stdlib/data/finance/fred.agency:buildFredObservationsPath": { "1": { "line": 91, "col": 2 }, "2": { "line": 92, "col": 2 }, "3": { "line": 93, "col": 2 }, "4": { "line": 94, "col": 2 }, "5": { "line": 95, "col": 2 }, "6": { "line": 96, "col": 2 }, "7": { "line": 97, "col": 2 }, "8": { "line": 100, "col": 2 }, "7.0": { "line": 98, "col": 4 } }, "stdlib/data/finance/fred.agency:buildFredSeriesPath": { "1": { "line": 105, "col": 2 } }, "stdlib/data/finance/fred.agency:toFredValue": { "1": { "line": 110, "col": 2 }, "2": { "line": 113, "col": 2 }, "3": { "line": 114, "col": 2 }, "4": { "line": 117, "col": 2 }, "1.0": { "line": 111, "col": 4 }, "3.0": { "line": 115, "col": 4 } }, "stdlib/data/finance/fred.agency:parseFredObservations": { "1": { "line": 122, "col": 2 }, "2": { "line": 123, "col": 2 }, "3": { "line": 124, "col": 2 }, "4": { "line": 127, "col": 2 } }, "stdlib/data/finance/fred.agency:__block_0": { "3.0": { "line": 125, "col": 4 } }, "stdlib/data/finance/fred.agency:parseFredInfo": { "1": { "line": 132, "col": 2 }, "2": { "line": 133, "col": 2 }, "3": { "line": 134, "col": 2 }, "4": { "line": 135, "col": 2 } }, "stdlib/data/finance/fred.agency:fredObservationsFinalize": { "1": { "line": 148, "col": 9 }, "2": { "line": 148, "col": 9 }, "3": { "line": 148, "col": 2 }, "2.0": { "line": 148, "col": 9 }, "2.1.0": { "line": 151, "col": 8 }, "2.1": { "line": 150, "col": 6 }, "2.2": { "line": 153, "col": 6 }, "2.3": { "line": 148, "col": 9 }, "2.4": { "line": 155, "col": 20 }, "2.5": { "line": 155, "col": 20 } }, "stdlib/data/finance/fred.agency:fredInfoFinalize": { "1": { "line": 161, "col": 9 }, "2": { "line": 161, "col": 9 }, "3": { "line": 161, "col": 2 }, "2.0": { "line": 161, "col": 9 }, "2.1": { "line": 163, "col": 6 }, "2.2.0": { "line": 165, "col": 8 }, "2.2": { "line": 164, "col": 6 }, "2.3": { "line": 167, "col": 6 }, "2.4": { "line": 161, "col": 9 }, "2.5": { "line": 169, "col": 20 }, "2.6": { "line": 169, "col": 20 } }, "stdlib/data/finance/fred.agency:fredSeries": { "1": { "line": 188, "col": 2 }, "2": { "line": 189, "col": 2 }, "3": { "line": 192, "col": 2 }, "4": { "line": 193, "col": 2 }, "5": { "line": 196, "col": 2 }, "6": { "line": 197, "col": 2 }, "2.0": { "line": 190, "col": 4 } }, "stdlib/data/finance/fred.agency:fredSeriesInfo": { "1": { "line": 207, "col": 2 }, "2": { "line": 208, "col": 2 }, "3": { "line": 211, "col": 2 }, "4": { "line": 212, "col": 2 }, "5": { "line": 213, "col": 2 }, "6": { "line": 214, "col": 2 }, "2.0": { "line": 209, "col": 4 } } };
export {
  FredFrequency,
  FredObservation,
  FredSeries,
  FredSeriesInfo,
  FredUnits,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  appendParam,
  approve,
  buildFredObservationsPath,
  buildFredSeriesPath,
  stdin_default as default,
  fredInfoFinalize,
  fredObservationsFinalize,
  fredSeries,
  fredSeriesInfo,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  parseFredInfo,
  parseFredObservations,
  reject,
  respondToInterrupts,
  rewindFrom,
  toFredValue
};
