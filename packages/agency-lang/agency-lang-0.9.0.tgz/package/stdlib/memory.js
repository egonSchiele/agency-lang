import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { _setMemoryId, _getMemoryId, _shouldRunMemory, _buildExtractionPrompt, _applyExtractionResult, _buildForgetPrompt, _applyForgetResult, _recall, _enableMemory, _disableMemory, _pushMemoryFrame, _popMemoryFrame } from "agency-lang/stdlib-lib/memory.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  runPrompt,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  __registerGlobalsInit,
  __registerCallbacksInit,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __tryCall,
  __validateType,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __threads,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/memory.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/memory.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/memory.agency");
}
__registerGlobalsInit("stdlib/memory.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/memory.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const ExtractionResult = z.object({ "entities": z.array(z.object({ "name": z.string(), "type": z.string(), "observations": z.array(z.string()) })), "relations": z.array(z.object({ "from": z.string(), "to": z.string(), "type": z.string() })), "expirations": z.array(z.object({ "entityName": z.string(), "observationContent": z.string() })) });
const ForgetResult = z.object({ "observations": z.array(z.object({ "entityName": z.string(), "observationContent": z.string() })), "relations": z.array(z.object({ "fromName": z.string(), "toName": z.string(), "type": z.string() })) });
const MemoryConfig = z.object({ "dir": z.string(), "model": z.union([z.string(), z.null()]).optional().default(null), "autoExtract": z.union([z.object({ "interval": z.union([z.number(), z.null()]).optional().default(null) }), z.null()]).optional().default(null), "compaction": z.union([z.object({ "trigger": z.union([z.literal("token"), z.literal("messages"), z.null()]).optional().default(null), "threshold": z.union([z.number(), z.null()]).optional().default(null) }), z.null()]).optional().default(null), "embeddings": z.union([z.object({ "model": z.union([z.string(), z.null()]).optional().default(null), "provider": z.union([z.string(), z.null()]).optional().default(null) }), z.null()]).optional().default(null) });
async function __isMemoryActive_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/memory.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/memory.agency", scopeName: "isMemoryActive", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "isMemoryActive",
            args: {},
            moduleId: "stdlib/memory.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_shouldRunMemory, {
          type: "positional",
          args: []
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "isMemoryActive");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function isMemoryActive threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "isMemoryActive"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "isMemoryActive",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "isMemoryActive",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const isMemoryActive = __AgencyFunction.create({
  name: "isMemoryActive",
  module: "stdlib/memory.agency",
  fn: __isMemoryActive_impl,
  params: [],
  toolDefinition: {
    name: "isMemoryActive",
    description: `Return \`true\` when memory is on for the current branch and reads and
  writes will reach a real store. Returns \`false\` when memory was never
  enabled, was turned off, or the call is outside any runtime frame.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __setMemoryId_impl(id) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/memory.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["id"] = id;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/memory.agency", scopeName: "setMemoryId", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("id" in __overrides) {
      id = __overrides["id"];
      __stack.args["id"] = id;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "setMemoryId",
            args: {
              id
            },
            moduleId: "stdlib/memory.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __funcResult = await __call(_setMemoryId, {
          type: "positional",
          args: [__stack.args.id]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "setMemoryId"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "setMemoryId");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function setMemoryId threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "setMemoryId"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "setMemoryId",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "setMemoryId",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const setMemoryId = __AgencyFunction.create({
  name: "setMemoryId",
  module: "stdlib/memory.agency",
  fn: __setMemoryId_impl,
  params: [{
    name: "id",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "setMemoryId",
    description: `Set the memory scope for this agent run, so reads and writes target a
  specific user, thread, or workspace. Call before other memory
  operations. The scope defaults to "default" if never set. Memory must
  be enabled for this to have any effect.

  @param id - A unique identifier for the memory scope (e.g. user ID)`,
    schema: z.object({ "id": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __getMemoryId_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/memory.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/memory.agency", scopeName: "getMemoryId", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "getMemoryId",
            args: {},
            moduleId: "stdlib/memory.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_getMemoryId, {
          type: "positional",
          args: []
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "getMemoryId");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function getMemoryId threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "getMemoryId"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "getMemoryId",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "getMemoryId",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const getMemoryId = __AgencyFunction.create({
  name: "getMemoryId",
  module: "stdlib/memory.agency",
  fn: __getMemoryId_impl,
  params: [],
  toolDefinition: {
    name: "getMemoryId",
    description: `Return the current memory scope id, or "default" if it was never set
  or memory is not active.

  @returns The active memory scope id`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __enableMemory_impl(config) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/memory.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["config"] = config;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/memory.agency", scopeName: "enableMemory", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("config" in __overrides) {
      config = __overrides["config"];
      __stack.args["config"] = config;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "enableMemory",
            args: {
              config
            },
            moduleId: "stdlib/memory.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::memory::enableMemory", `Are you sure you want to enable memory at this directory?`, {
            "dir": __stack.args.config.dir
          }, "std::memory", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/memory.agency", scopeName: "enableMemory", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        const __funcResult = await __call(_enableMemory, {
          type: "positional",
          args: [__stack.args.config]
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "enableMemory"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "enableMemory");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function enableMemory threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "enableMemory"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "enableMemory",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "enableMemory",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const enableMemory = __AgencyFunction.create({
  name: "enableMemory",
  module: "stdlib/memory.agency",
  fn: __enableMemory_impl,
  params: [{
    name: "config",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "enableMemory",
    description: `Turn memory on for the current execution branch using \`config\`. The
  directory in \`config.dir\` is created if missing. Enabling a directory
  that is already active is a no-op.

  @param config - Memory configuration with \`dir\` required`,
    schema: z.object({ "config": MemoryConfig })
  },
  exported: true
}, __toolRegistry);
async function __disableMemory_impl() {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/memory.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/memory.agency", scopeName: "disableMemory", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "disableMemory",
            args: {},
            moduleId: "stdlib/memory.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::memory::disableMemory", `Are you sure you want to disable memory (pop the top memory frame)?`, {}, "std::memory", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/memory.agency", scopeName: "disableMemory", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        const __funcResult = await __call(_disableMemory, {
          type: "positional",
          args: []
        });
        if (hasInterrupts(__funcResult)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__funcResult);
          return;
        }
        if (isAborted(__funcResult)) {
          runner2.halt(__funcResult.carryThrough(__stack, "disableMemory"));
          return;
        }
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "disableMemory");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function disableMemory threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "disableMemory"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "disableMemory",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "disableMemory",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const disableMemory = __AgencyFunction.create({
  name: "disableMemory",
  module: "stdlib/memory.agency",
  fn: __disableMemory_impl,
  params: [],
  toolDefinition: {
    name: "disableMemory",
    description: `Turn off memory for the current branch by removing the most recently
  enabled memory configuration.`,
    schema: z.object({})
  },
  exported: true
}, __toolRegistry);
async function __memory_impl(config, block = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/memory.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["config"] = config;
  __stack.args["block"] = block === __UNSET ? null : block;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/memory.agency", scopeName: "memory", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("config" in __overrides) {
      config = __overrides["config"];
      __stack.args["config"] = config;
    }
    if ("block" in __overrides) {
      block = __overrides["block"];
      __stack.args["block"] = block;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "memory",
            args: {
              config,
              block
            },
            moduleId: "stdlib/memory.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.pushed = await __call(_pushMemoryFrame, {
          type: "positional",
          args: [__stack.args.config]
        });
        if (hasInterrupts(__stack.locals.pushed)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.pushed);
          return;
        }
        if (isAborted(__stack.locals.pushed)) {
          runner2.halt(__stack.locals.pushed.carryThrough(__stack, "memory"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __tryCall(async () => await __call(block, {
          type: "positional",
          args: []
        }), {
          checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
          functionName: "memory",
          args: __stack.args
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "memory"));
          return;
        }
      });
      await runner.ifElse(3, [
        {
          condition: async () => __stack.locals.pushed,
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __funcResult = await __call(_popMemoryFrame, {
                type: "positional",
                args: []
              });
              if (hasInterrupts(__funcResult)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__funcResult);
                return;
              }
              if (isAborted(__funcResult)) {
                runner3.halt(__funcResult.carryThrough(__stack, "memory"));
                return;
              }
            });
          }
        }
      ]);
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__stack.locals.result);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "memory");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function memory threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "memory"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "memory",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "memory",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const memory = __AgencyFunction.create({
  name: "memory",
  module: "stdlib/memory.agency",
  fn: __memory_impl,
  params: [{
    name: "config",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "block",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: true,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "memory",
    description: `Run \`block\` with \`config\` as the active memory configuration, then
  restore the previous configuration when the block returns or fails.
  Returns a \`Result\`: success holds the block's return value, failure
  holds an error raised inside the block.

  Example:
  const r = memory({ dir: "./mem-user-a" }) as {
  remember("alice's favorite color is blue")
  }

  @param config - Memory configuration with \`dir\` required
  @param block - The code to run with the configuration active`,
    schema: z.object({ "config": MemoryConfig })
  },
  exported: true
}, __toolRegistry);
async function __remember_impl(content) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/memory.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["content"] = content;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/memory.agency", scopeName: "remember", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("content" in __overrides) {
      content = __overrides["content"];
      __stack.args["content"] = content;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "remember",
            args: {
              content
            },
            moduleId: "stdlib/memory.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => await __call(_shouldRunMemory, {
            type: "positional",
            args: []
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1_0);
              if (__response) {
                if (__response.type === "approve") {
                } else if (__response.type === "reject") {
                  runner3.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
                  return;
                }
              } else {
                const __handlerResult = await interruptWithHandlers("std::memory::remember", `Are you sure you want to extract and persist facts to memory?`, {
                  "contentLength": __stack.args.content.length
                }, "std::memory", __ctx, __stateStack());
                if (isRejected(__handlerResult)) {
                  runner3.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
                  return;
                }
                if (!isApproved(__handlerResult)) {
                  __self.__interruptId_1_0 = __handlerResult[0].interruptId;
                  const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/memory.agency", scopeName: "remember", stepPath: "1.0" });
                  __handlerResult[0].checkpointId = __checkpointId;
                  __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
                  runner3.halt(__handlerResult);
                  return;
                }
              }
            });
            await runner2.step(1, async (runner3) => {
              __self.__destructiveRan = true;
            });
            await runner2.thread(2, "create", async () => ({}), async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.prompt = await __call(_buildExtractionPrompt, {
                  type: "positional",
                  args: [__stack.args.content]
                });
                if (hasInterrupts(__stack.locals.prompt)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__stack.locals.prompt);
                  return;
                }
                if (isAborted(__stack.locals.prompt)) {
                  runner4.halt(__stack.locals.prompt.carryThrough(__stack, "remember"));
                  return;
                }
              });
              await runner3.step(1, async (runner4) => {
                __self.__removedTools = __self.__removedTools || [];
                __stack.locals.result = await runPrompt({
                  prompt: __stack.locals.prompt,
                  messages: __threads().getOrCreateActive(),
                  responseFormat: z.object({
                    response: ExtractionResult
                  }),
                  clientConfig: {},
                  maxToolCallRounds: 10,
                  removedTools: __self.__removedTools,
                  destructiveSink: __self,
                  checkpointInfo: runner4.getCheckpointInfo()
                });
                if (hasInterrupts(__stack.locals.result)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__stack.locals.result);
                  return;
                }
                __stack.locals.result = __validateType(__stack.locals.result, ExtractionResult);
              });
              await runner3.ifElse(2, [
                {
                  condition: async () => await isSuccess(__stack.locals.result),
                  body: async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      __stack.locals.extraction = __stack.locals.result.value;
                    });
                    await runner4.step(1, async (runner5) => {
                      const __funcResult = await __call(_applyExtractionResult, {
                        type: "positional",
                        args: [__stack.locals.extraction]
                      });
                      if (hasInterrupts(__funcResult)) {
                        await getRuntimeContext().ctx.pendingPromises.awaitAll();
                        runner5.halt(__funcResult);
                        return;
                      }
                      if (isAborted(__funcResult)) {
                        runner5.halt(__funcResult.carryThrough(__stack, "remember"));
                        return;
                      }
                    });
                  }
                }
              ], async (runner4) => {
                await runner4.step(2, async (runner5) => {
                  __functionCompleted = true;
                  runner5.halt(__stack.locals.result);
                  return;
                });
              });
            });
          }
        }
      ]);
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "remember");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function remember threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "remember"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "remember",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "remember",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const remember = __AgencyFunction.create({
  name: "remember",
  module: "stdlib/memory.agency",
  fn: __remember_impl,
  params: [{
    name: "content",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "remember",
    description: `Extract structured facts (entities, observations, and relations) from
  the given text and store them in the knowledge graph.

  @param content - Natural language text containing facts to remember`,
    schema: z.object({ "content": z.string() })
  },
  exported: true,
  markers: {
    destructive: true
  }
}, __toolRegistry);
async function __recall_impl(query) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/memory.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["query"] = query;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/memory.agency", scopeName: "recall", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("query" in __overrides) {
      query = __overrides["query"];
      __stack.args["query"] = query;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "recall",
            args: {
              query
            },
            moduleId: "stdlib/memory.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::memory::recall", `Are you sure you want to recall memories based on this query?`, {
            "query": __stack.args.query
          }, "std::memory", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/memory.agency", scopeName: "recall", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(_recall, {
          type: "positional",
          args: [__stack.args.query]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "recall");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function recall threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "recall"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "recall",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "recall",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const recall = __AgencyFunction.create({
  name: "recall",
  module: "stdlib/memory.agency",
  fn: __recall_impl,
  params: [{
    name: "query",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "recall",
    description: `Retrieve relevant facts from the knowledge graph as a formatted
  string. Combines structured lookup, embedding similarity, and
  LLM-powered retrieval. Returns up to 10 entities ranked by match
  quality.

  Returns an empty string if memory is not configured or nothing matches.

  @param query - A natural language query describing what to recall`,
    schema: z.object({ "query": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __forget_impl(query) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/memory.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["query"] = query;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/memory.agency", scopeName: "forget", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("query" in __overrides) {
      query = __overrides["query"];
      __stack.args["query"] = query;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "forget",
            args: {
              query
            },
            moduleId: "stdlib/memory.agency"
          }
        });
      });
      await runner.ifElse(1, [
        {
          condition: async () => await __call(_shouldRunMemory, {
            type: "positional",
            args: []
          }),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1_0);
              if (__response) {
                if (__response.type === "approve") {
                } else if (__response.type === "reject") {
                  runner3.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
                  return;
                }
              } else {
                const __handlerResult = await interruptWithHandlers("std::memory::forget", `Are you sure you want to soft-delete facts matching this query from memory?`, {
                  "query": __stack.args.query
                }, "std::memory", __ctx, __stateStack());
                if (isRejected(__handlerResult)) {
                  runner3.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
                  return;
                }
                if (!isApproved(__handlerResult)) {
                  __self.__interruptId_1_0 = __handlerResult[0].interruptId;
                  const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/memory.agency", scopeName: "forget", stepPath: "1.0" });
                  __handlerResult[0].checkpointId = __checkpointId;
                  __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
                  runner3.halt(__handlerResult);
                  return;
                }
              }
            });
            await runner2.thread(1, "create", async () => ({}), async (runner3) => {
              await runner3.step(0, async (runner4) => {
                __stack.locals.prompt = await __call(_buildForgetPrompt, {
                  type: "positional",
                  args: [__stack.args.query]
                });
                if (hasInterrupts(__stack.locals.prompt)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__stack.locals.prompt);
                  return;
                }
                if (isAborted(__stack.locals.prompt)) {
                  runner4.halt(__stack.locals.prompt.carryThrough(__stack, "forget"));
                  return;
                }
              });
              await runner3.step(1, async (runner4) => {
                __self.__removedTools = __self.__removedTools || [];
                __stack.locals.result = await runPrompt({
                  prompt: __stack.locals.prompt,
                  messages: __threads().getOrCreateActive(),
                  responseFormat: z.object({
                    response: ForgetResult
                  }),
                  clientConfig: {},
                  maxToolCallRounds: 10,
                  removedTools: __self.__removedTools,
                  destructiveSink: __self,
                  checkpointInfo: runner4.getCheckpointInfo()
                });
                if (hasInterrupts(__stack.locals.result)) {
                  await getRuntimeContext().ctx.pendingPromises.awaitAll();
                  runner4.halt(__stack.locals.result);
                  return;
                }
                __stack.locals.result = __validateType(__stack.locals.result, ForgetResult);
              });
              await runner3.ifElse(2, [
                {
                  condition: async () => await isSuccess(__stack.locals.result),
                  body: async (runner4) => {
                    await runner4.step(0, async (runner5) => {
                      __stack.locals.forgetPlan = __stack.locals.result.value;
                    });
                    await runner4.step(1, async (runner5) => {
                      const __funcResult = await __call(_applyForgetResult, {
                        type: "positional",
                        args: [__stack.locals.forgetPlan]
                      });
                      if (hasInterrupts(__funcResult)) {
                        await getRuntimeContext().ctx.pendingPromises.awaitAll();
                        runner5.halt(__funcResult);
                        return;
                      }
                      if (isAborted(__funcResult)) {
                        runner5.halt(__funcResult.carryThrough(__stack, "forget"));
                        return;
                      }
                    });
                  }
                }
              ], async (runner4) => {
                await runner4.step(2, async (runner5) => {
                  __functionCompleted = true;
                  runner5.halt(__stack.locals.result);
                  return;
                });
              });
            });
          }
        }
      ]);
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "forget");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function forget threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "forget"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "forget",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "forget",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const forget = __AgencyFunction.create({
  name: "forget",
  module: "stdlib/memory.agency",
  fn: __forget_impl,
  params: [{
    name: "query",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "forget",
    description: `Soft-delete facts matching the query from the knowledge graph. Data is
  not erased. Affected observations are marked with a validTo timestamp,
  preserving the audit trail.

  @param query - A natural language description of what to forget`,
    schema: z.object({ "query": z.string() })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/memory.agency:isMemoryActive": { "1": { "line": 85, "col": 2 } }, "stdlib/memory.agency:setMemoryId": { "1": { "line": 102, "col": 2 } }, "stdlib/memory.agency:getMemoryId": { "1": { "line": 112, "col": 2 } }, "stdlib/memory.agency:enableMemory": { "1": { "line": 137, "col": 2 }, "2": { "line": 141, "col": 2 } }, "stdlib/memory.agency:disableMemory": { "1": { "line": 155, "col": 2 }, "2": { "line": 157, "col": 2 } }, "stdlib/memory.agency:memory": { "1": { "line": 175, "col": 2 }, "2": { "line": 176, "col": 2 }, "3": { "line": 177, "col": 2 }, "4": { "line": 180, "col": 2 }, "3.0": { "line": 178, "col": 4 } }, "stdlib/memory.agency:remember": { "1": { "line": 190, "col": 2 }, "1.0": { "line": 191, "col": 4 }, "1.2.0": { "line": 197, "col": 8 }, "1.2.1": { "line": 202, "col": 8 }, "1.2.2.0": { "line": 203, "col": 8 }, "1.2.2.1": { "line": 204, "col": 10 }, "1.2.2.2": { "line": 206, "col": 10 }, "1.2.2": { "line": 203, "col": 8 }, "1.2": { "line": 196, "col": 6 } }, "stdlib/memory.agency:recall": { "1": { "line": 224, "col": 2 }, "2": { "line": 228, "col": 2 } }, "stdlib/memory.agency:forget": { "1": { "line": 239, "col": 2 }, "1.0": { "line": 240, "col": 4 }, "1.1.0": { "line": 245, "col": 6 }, "1.1.1": { "line": 248, "col": 6 }, "1.1.2.0": { "line": 249, "col": 6 }, "1.1.2.1": { "line": 250, "col": 8 }, "1.1.2.2": { "line": 252, "col": 8 }, "1.1.2": { "line": 249, "col": 6 }, "1.1": { "line": 244, "col": 4 } } };
export {
  MemoryConfig,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  stdin_default as default,
  disableMemory,
  enableMemory,
  forget,
  getMemoryId,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  isMemoryActive,
  memory,
  recall,
  reject,
  remember,
  respondToInterrupts,
  rewindFrom,
  setMemoryId
};
