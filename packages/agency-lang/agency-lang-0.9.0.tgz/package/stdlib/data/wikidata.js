import { print, printJSON, input, sleep, saveDraft, _guard, _pairsOf, read, write, writeBinary, readBinary, range, callback, map, mapWithIndex, filter, exclude, find, findIndex, reduce, flatMap, every, some, count, sortBy, unique, groupBy, flatten } from "agency-lang/stdlib/index.js";
import { fetchJSON } from "agency-lang/stdlib/http.js";
import { env } from "agency-lang/stdlib/system.js";
import { mapValues, values } from "agency-lang/stdlib/object.js";
import { fileURLToPath } from "url";
import __process from "process";
import { readFileSync } from "fs";
import { z } from "agency-lang/zod";
import { nanoid } from "agency-lang";
import path from "path";
import {
  RuntimeContext,
  Runner,
  setupFunction,
  callHook,
  checkpoint as __checkpoint_impl,
  getCheckpoint as __getCheckpoint_impl,
  restore as __restore_impl,
  _run as __runtime_run_impl,
  interrupt,
  isInterrupt,
  hasInterrupts,
  isDebugger,
  isRejected,
  isApproved,
  interruptWithHandlers,
  respondToInterrupts as _respondToInterrupts,
  rewindFrom as _rewindFrom,
  runExportedFunction as _runExportedFunction,
  RestoreSignal,
  AgencyAbort,
  AbortedResult,
  isAborted,
  deepFreeze as __deepFreeze,
  __UNINIT_STATIC,
  __readStatic,
  __registerStaticInit,
  __registerGlobalsInit,
  __registerCallbacksInit,
  success,
  failure,
  isSuccess,
  isFailure,
  stampFailureBoundary,
  __eq,
  __nn,
  AgencyFunction as __AgencyFunction,
  UNSET as __UNSET,
  __call,
  __stateStack,
  __globals,
  getRuntimeContext,
  agencyStore,
  functionRefReviver as __functionRefReviver,
  DeterministicClient as __DeterministicClient,
  installFetchMock as __installFetchMock,
  createLogger as __createLogger
} from "agency-lang/runtime";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __cwd = __process.cwd();
const __globalCtx = new RuntimeContext({
  statelogConfig: {
    host: "https://statelog.adit.io",
    apiKey: __process.env["STATELOG_API_KEY"] || "",
    projectId: "agency-lang",
    debugMode: false,
    observability: true,
    logFile: "log.jsonl"
  },
  smoltalkDefaults: {
    apiKey: {
      openAi: __process.env["OPENAI_API_KEY"] || "",
      google: __process.env["GEMINI_API_KEY"] || "",
      anthropic: __process.env["ANTHROPIC_API_KEY"] || "",
      openRouter: __process.env["OPENROUTER_API_KEY"] || "",
      deepInfra: __process.env["DEEPINFRA_API_KEY"] || "",
      liteLlm: __process.env["LITELLM_API_KEY"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_API_KEY"] || ""
    },
    baseUrl: {
      liteLlm: __process.env["LITELLM_BASE_URL"] || "",
      openAiCompat: __process.env["OPENAI_COMPAT_BASE_URL"] || ""
    },
    model: "gpt-4o-mini",
    logLevel: "warn",
    statelog: {
      host: "https://statelog.adit.io",
      projectId: "smoltalk",
      apiKey: __process.env["STATELOG_SMOLTALK_API_KEY"] || "",
      traceId: nanoid()
    }
  },
  dirname: __dirname,
  logLevel: "info",
  traceConfig: {
    program: "stdlib/data/wikidata.agency"
  }
});
const graph = __globalCtx.graph;
function approve(value) {
  return { type: "approve", value };
}
function reject(value) {
  return { type: "reject", value };
}
function propagate() {
  return { type: "propagate" };
}
function pass() {
  return { type: "pass" };
}
const respondToInterrupts = (interrupts, responses, opts) => _respondToInterrupts({ ctx: __globalCtx, interrupts, responses, overrides: opts?.overrides, metadata: opts?.metadata });
const rewindFrom = (checkpoint2, overrides, opts) => _rewindFrom({ ctx: __globalCtx, checkpoint: checkpoint2, overrides, metadata: opts?.metadata });
const __invokeFunction = (fn, namedArgs) => _runExportedFunction({ ctx: __globalCtx, fn, namedArgs, initializeGlobals: __initializeGlobals });
const __setDebugger = (dbg) => {
  __globalCtx.debuggerState = dbg;
};
const __setTraceFile = (filePath) => {
  __globalCtx.traceConfig.traceFile = filePath;
};
const __setLLMClient = (client) => {
  __globalCtx.setLLMClient(client);
};
const __getCheckpoints = () => __globalCtx.checkpoints;
if (__process.env.AGENCY_LLM_MOCKS) {
  __globalCtx.setLLMClient(
    new __DeterministicClient(JSON.parse(__process.env.AGENCY_LLM_MOCKS))
  );
}
if (__process.env.AGENCY_FETCH_MOCKS_FILE) {
  __installFetchMock(JSON.parse(readFileSync(__process.env.AGENCY_FETCH_MOCKS_FILE, "utf-8")));
}
const __toolRegistry = __functionRefReviver.registry ??= {};
function __registerTool(value, _aliasName) {
  if (__AgencyFunction.isAgencyFunction(value)) {
    __toolRegistry[`${value.module}:${value.name}`] = value;
  }
}
const checkpoint = __AgencyFunction.create({ name: "checkpoint", module: "__runtime", fn: __checkpoint_impl, params: [], toolDefinition: null }, __toolRegistry);
const getCheckpoint = __AgencyFunction.create({ name: "getCheckpoint", module: "__runtime", fn: __getCheckpoint_impl, params: [{ name: "checkpointId", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const restore = __AgencyFunction.create({ name: "restore", module: "__runtime", fn: __restore_impl, params: [{ name: "checkpointIdOrCheckpoint", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "options", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
const _run = __AgencyFunction.create({ name: "_run", module: "__runtime", fn: __runtime_run_impl, params: [{ name: "compiled", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "node", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "args", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "wallClock", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "memory", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "ipcPayload", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "stdout", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "configOverrides", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "cwd", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "maxDepth", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry);
function setLLMClient(client) {
  __globalCtx.setLLMClient(client);
}
function registerTools(tools) {
  for (const tool of tools) {
    if (__AgencyFunction.isAgencyFunction(tool)) {
      __toolRegistry[`${tool.module}:${tool.name}`] = tool;
    }
  }
}
__registerTool(print);
__registerTool(printJSON);
__registerTool(input);
__registerTool(sleep);
__registerTool(saveDraft);
__registerTool(_guard);
__registerTool(_pairsOf);
__registerTool(read);
__registerTool(write);
__registerTool(writeBinary);
__registerTool(readBinary);
__registerTool(range);
__registerTool(callback);
__registerTool(map);
__registerTool(mapWithIndex);
__registerTool(filter);
__registerTool(exclude);
__registerTool(find);
__registerTool(findIndex);
__registerTool(reduce);
__registerTool(flatMap);
__registerTool(every);
__registerTool(some);
__registerTool(count);
__registerTool(sortBy);
__registerTool(unique);
__registerTool(groupBy);
__registerTool(flatten);
__registerTool(fetchJSON);
__registerTool(env);
__registerTool(mapValues);
__registerTool(values);
let __staticInitPromise = null;
let WD_BASE = __UNINIT_STATIC;
let WD_DOMAINS = __UNINIT_STATIC;
let WDQS_BASE = __UNINIT_STATIC;
let WDQS_DOMAINS = __UNINIT_STATIC;
async function __initializeStatic(__ctx) {
  if (__staticInitPromise) {
    return __staticInitPromise;
  }
  __staticInitPromise = (async () => {
    WD_BASE = __deepFreeze(`https://www.wikidata.org`);
    WD_DOMAINS = __deepFreeze([`www.wikidata.org`]);
    WDQS_BASE = __deepFreeze(`https://query.wikidata.org`);
    WDQS_DOMAINS = __deepFreeze([`query.wikidata.org`]);
  })();
  return __staticInitPromise;
}
function __getStaticVars() {
  return {
    WD_BASE,
    WD_DOMAINS,
    WDQS_BASE,
    WDQS_DOMAINS
  };
}
__globalCtx.getStaticVars = __getStaticVars;
__registerStaticInit("stdlib/data/wikidata.agency", __initializeStatic);
async function __initializeGlobals(__ctx) {
  if (__ctx.globals.isInitialized("stdlib/data/wikidata.agency")) {
    return;
  }
  __ctx.globals.markInitialized("stdlib/data/wikidata.agency");
  await __initializeStatic(__ctx);
  await __ctx.writeStaticStateToTrace(__globalCtx.getStaticVars());
  __ctx.globals.set("stdlib/data/wikidata.agency", "wikidataUserAgent", await __call(env, {
    type: "positional",
    args: [`WIKIDATA_USER_AGENT`]
  }) ?? `agency-lang (https://agency-lang.com)`);
  __ctx.globals.set("stdlib/data/wikidata.agency", "WD_HEADERS", {
    "User-Agent": __globals().get("stdlib/data/wikidata.agency", "wikidataUserAgent")
  });
}
__registerGlobalsInit("stdlib/data/wikidata.agency", __initializeGlobals);
async function __registerTopLevelCallbacks(__ctx) {
}
__registerCallbacksInit("stdlib/data/wikidata.agency", __registerTopLevelCallbacks);
__functionRefReviver.registry = __toolRegistry;
const Entity = z.object({ "id": z.string(), "label": z.string(), "description": z.string(), "url": z.string() });
const EntityDetail = z.object({ "id": z.string(), "label": z.string(), "description": z.string(), "aliases": z.array(z.string()), "claims": z.record(z.string(), z.array(z.string())) });
async function __buildSearchPath_impl(name, limit) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["name"] = name;
  __stack.args["limit"] = limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "buildSearchPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildSearchPath",
            args: {
              name,
              limit
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.q = await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.name]
        });
        if (hasInterrupts(__stack.locals.q)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.q);
          return;
        }
        if (isAborted(__stack.locals.q)) {
          runner2.halt(__stack.locals.q.carryThrough(__stack, "buildSearchPath"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/w/api.php?action=wbsearchentities&search=${__stack.locals.q}&language=en&format=json&limit=${__stack.args.limit}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildSearchPath");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildSearchPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildSearchPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildSearchPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildSearchPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildSearchPath = __AgencyFunction.create({
  name: "buildSearchPath",
  module: "stdlib/data/wikidata.agency",
  fn: __buildSearchPath_impl,
  params: [{
    name: "name",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildSearchPath",
    description: "No description provided.",
    schema: z.object({ "name": z.string(), "limit": z.number() })
  },
  exported: false
}, __toolRegistry);
async function __buildEntityPath_impl(qid) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["qid"] = qid;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "buildEntityPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("qid" in __overrides) {
      qid = __overrides["qid"];
      __stack.args["qid"] = qid;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildEntityPath",
            args: {
              qid
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/wiki/Special:EntityData/${await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.qid]
        })}.json`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildEntityPath");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildEntityPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildEntityPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildEntityPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildEntityPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildEntityPath = __AgencyFunction.create({
  name: "buildEntityPath",
  module: "stdlib/data/wikidata.agency",
  fn: __buildEntityPath_impl,
  params: [{
    name: "qid",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildEntityPath",
    description: "No description provided.",
    schema: z.object({ "qid": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __buildQueryPath_impl(sparql) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["sparql"] = sparql;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "buildQueryPath", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("sparql" in __overrides) {
      sparql = __overrides["sparql"];
      __stack.args["sparql"] = sparql;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "buildQueryPath",
            args: {
              sparql
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.q = await __call(encodeURIComponent, {
          type: "positional",
          args: [__stack.args.sparql]
        });
        if (hasInterrupts(__stack.locals.q)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.q);
          return;
        }
        if (isAborted(__stack.locals.q)) {
          runner2.halt(__stack.locals.q.carryThrough(__stack, "buildQueryPath"));
          return;
        }
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`/sparql?query=${__stack.locals.q}&format=json`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "buildQueryPath");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function buildQueryPath threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "buildQueryPath"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "buildQueryPath",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "buildQueryPath",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const buildQueryPath = __AgencyFunction.create({
  name: "buildQueryPath",
  module: "stdlib/data/wikidata.agency",
  fn: __buildQueryPath_impl,
  params: [{
    name: "sparql",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "buildQueryPath",
    description: "No description provided.",
    schema: z.object({ "sparql": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __parseSearch_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "parseSearch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseSearch",
            args: {
              raw
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.results = __stack.locals.r.search ?? [];
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(map, {
          type: "named",
          positionalArgs: [__stack.locals.results],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_0", module: "stdlib/data/wikidata.agency", fn: async (s) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_0 = __bstack;
            __bstack.args["s"] = s;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/wikidata.agency", scopeName: "__block_0" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.e = __bstack.args.s ?? {};
              });
              await runner3.step(1, async (runner4) => {
                runner4.halt({
                  "id": __bstack.locals.e.id ?? ``,
                  "label": __bstack.locals.e.label ?? ``,
                  "description": __bstack.locals.e.description ?? ``,
                  "url": __bstack.locals.e.concepturi ?? ``
                });
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_0");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "s", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseSearch");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseSearch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseSearch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseSearch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseSearch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseSearch = __AgencyFunction.create({
  name: "parseSearch",
  module: "stdlib/data/wikidata.agency",
  fn: __parseSearch_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseSearch",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __parseClaimValue_impl(mainsnak) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["mainsnak"] = mainsnak;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "parseClaimValue", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("mainsnak" in __overrides) {
      mainsnak = __overrides["mainsnak"];
      __stack.args["mainsnak"] = mainsnak;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseClaimValue",
            args: {
              mainsnak
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.snak = __stack.args.mainsnak ?? {};
      });
      await runner.ifElse(2, [
        {
          condition: async () => !__eq(__stack.locals.snak.snaktype ?? ``, `value`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(``);
              return;
            });
          }
        }
      ]);
      await runner.step(3, async (runner2) => {
        __stack.locals.dv = __stack.locals.snak.datavalue ?? {};
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.t = __stack.locals.dv.type ?? ``;
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.v = __stack.locals.dv.value ?? null;
      });
      await runner.ifElse(6, [
        {
          condition: async () => __eq(__stack.locals.t, `wikibase-entityid`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.locals.v.id ?? ``);
              return;
            });
          }
        }
      ]);
      await runner.ifElse(7, [
        {
          condition: async () => __eq(__stack.locals.t, `string`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.locals.v ?? ``);
              return;
            });
          }
        }
      ]);
      await runner.ifElse(8, [
        {
          condition: async () => __eq(__stack.locals.t, `monolingualtext`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.locals.v.text ?? ``);
              return;
            });
          }
        }
      ]);
      await runner.ifElse(9, [
        {
          condition: async () => __eq(__stack.locals.t, `time`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.locals.v.time ?? ``);
              return;
            });
          }
        }
      ]);
      await runner.ifElse(10, [
        {
          condition: async () => __eq(__stack.locals.t, `quantity`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(__stack.locals.v.amount ?? ``);
              return;
            });
          }
        }
      ]);
      await runner.ifElse(11, [
        {
          condition: async () => __eq(__stack.locals.t, `globecoordinate`),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __functionCompleted = true;
              runner3.halt(`${__stack.locals.v.latitude ?? 0},${__stack.locals.v.longitude ?? 0}`);
              return;
            });
          }
        }
      ]);
      await runner.step(12, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(``);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseClaimValue");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseClaimValue threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseClaimValue"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseClaimValue",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseClaimValue",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseClaimValue = __AgencyFunction.create({
  name: "parseClaimValue",
  module: "stdlib/data/wikidata.agency",
  fn: __parseClaimValue_impl,
  params: [{
    name: "mainsnak",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseClaimValue",
    description: "No description provided.",
    schema: z.object({ "mainsnak": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __parseClaimList_impl(statements) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["statements"] = statements;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "parseClaimList", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("statements" in __overrides) {
      statements = __overrides["statements"];
      __stack.args["statements"] = statements;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseClaimList",
            args: {
              statements
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.arr = __stack.args.statements ?? [];
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(map, {
          type: "named",
          positionalArgs: [__stack.locals.arr],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_1", module: "stdlib/data/wikidata.agency", fn: async (s) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_1 = __bstack;
            __bstack.args["s"] = s;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/wikidata.agency", scopeName: "__block_1" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.st = __bstack.args.s ?? {};
              });
              await runner3.step(1, async (runner4) => {
                runner4.halt(await __call(parseClaimValue, {
                  type: "positional",
                  args: [__bstack.locals.st.mainsnak ?? {}]
                }));
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_1");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "s", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseClaimList");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseClaimList threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseClaimList"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseClaimList",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseClaimList",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseClaimList = __AgencyFunction.create({
  name: "parseClaimList",
  module: "stdlib/data/wikidata.agency",
  fn: __parseClaimList_impl,
  params: [{
    name: "statements",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseClaimList",
    description: "No description provided.",
    schema: z.object({ "statements": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __parseClaims_impl(claims) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["claims"] = claims;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "parseClaims", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("claims" in __overrides) {
      claims = __overrides["claims"];
      __stack.args["claims"] = claims;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseClaims",
            args: {
              claims
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.c = __stack.args.claims ?? {};
      });
      await runner.step(2, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(mapValues, {
          type: "named",
          positionalArgs: [__stack.locals.c],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_2", module: "stdlib/data/wikidata.agency", fn: async (statements, pid) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_2 = __bstack;
            __bstack.args["statements"] = statements;
            __bstack.args["pid"] = pid;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/wikidata.agency", scopeName: "__block_2" });
            try {
              await runner3.step(0, async (runner4) => {
                runner4.halt(await __call(parseClaimList, {
                  type: "positional",
                  args: [__bstack.args.statements]
                }));
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_2");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "statements", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "pid", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseClaims");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseClaims threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseClaims"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseClaims",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseClaims",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseClaims = __AgencyFunction.create({
  name: "parseClaims",
  module: "stdlib/data/wikidata.agency",
  fn: __parseClaims_impl,
  params: [{
    name: "claims",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseClaims",
    description: "No description provided.",
    schema: z.object({ "claims": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __parseEntity_impl(raw, qid) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __stack.args["qid"] = qid;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "parseEntity", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
    if ("qid" in __overrides) {
      qid = __overrides["qid"];
      __stack.args["qid"] = qid;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseEntity",
            args: {
              raw,
              qid
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.ents = await __call(values, {
          type: "positional",
          args: [__stack.locals.r.entities ?? {}]
        });
        if (hasInterrupts(__stack.locals.ents)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.ents);
          return;
        }
        if (isAborted(__stack.locals.ents)) {
          runner2.halt(__stack.locals.ents.carryThrough(__stack, "parseEntity"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.ent = __nn(__stack.locals.ents[0]) ?? {};
      });
      await runner.step(4, async (runner2) => {
        __stack.locals.labels = __stack.locals.ent.labels ?? {};
      });
      await runner.step(5, async (runner2) => {
        __stack.locals.descriptions = __stack.locals.ent.descriptions ?? {};
      });
      await runner.step(6, async (runner2) => {
        __stack.locals.aliasesObj = __stack.locals.ent.aliases ?? {};
      });
      await runner.step(7, async (runner2) => {
        __stack.locals.enLabel = __stack.locals.labels.en ?? {};
      });
      await runner.step(8, async (runner2) => {
        __stack.locals.enDesc = __stack.locals.descriptions.en ?? {};
      });
      await runner.step(9, async (runner2) => {
        __stack.locals.enAliases = __stack.locals.aliasesObj.en ?? [];
      });
      await runner.step(10, async (runner2) => {
        __functionCompleted = true;
        runner2.halt({
          "id": __stack.locals.ent.id ?? __stack.args.qid,
          "label": __stack.locals.enLabel.value ?? ``,
          "description": __stack.locals.enDesc.value ?? ``,
          "aliases": await __call(map, {
            type: "named",
            positionalArgs: [__stack.locals.enAliases],
            namedArgs: {},
            blockArg: __AgencyFunction.create({ name: "__block_3", module: "stdlib/data/wikidata.agency", fn: async (a) => {
              const __bsetup = setupFunction();
              const __bstack = __bsetup.stack;
              const __self2 = __bstack.locals;
              const __bframe___block_3 = __bstack;
              __bstack.args["a"] = a;
              const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/wikidata.agency", scopeName: "__block_3" });
              try {
                await runner3.step(0, async (runner4) => {
                  __bstack.locals.al = __bstack.args.a ?? {};
                });
                await runner3.step(1, async (runner4) => {
                  runner4.halt(__bstack.locals.al.value ?? ``);
                  return;
                });
                return runner3.halted ? runner3.haltResult : void 0;
              } catch (__blockError) {
                if (__blockError instanceof AgencyAbort) {
                  return AbortedResult.fromError(__blockError, __bstack, "__block_3");
                }
                throw __blockError;
              } finally {
                __bsetup.stateStack.pop();
              }
            }, params: [{ name: "a", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
          }),
          "claims": await __call(parseClaims, {
            type: "positional",
            args: [__stack.locals.ent.claims ?? {}]
          })
        });
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseEntity");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseEntity threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseEntity"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseEntity",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseEntity",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseEntity = __AgencyFunction.create({
  name: "parseEntity",
  module: "stdlib/data/wikidata.agency",
  fn: __parseEntity_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "qid",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "parseEntity",
    description: "No description provided.",
    schema: z.object({ "raw": z.any(), "qid": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __parseBindings_impl(raw) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["raw"] = raw;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "parseBindings", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("raw" in __overrides) {
      raw = __overrides["raw"];
      __stack.args["raw"] = raw;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "parseBindings",
            args: {
              raw
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.r = __stack.args.raw ?? {};
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.res = __stack.locals.r.results ?? {};
      });
      await runner.step(3, async (runner2) => {
        __stack.locals.bindings = __stack.locals.res.bindings ?? [];
      });
      await runner.step(4, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(map, {
          type: "named",
          positionalArgs: [__stack.locals.bindings],
          namedArgs: {},
          blockArg: __AgencyFunction.create({ name: "__block_4", module: "stdlib/data/wikidata.agency", fn: async (b) => {
            const __bsetup = setupFunction();
            const __bstack = __bsetup.stack;
            const __self2 = __bstack.locals;
            const __bframe___block_4 = __bstack;
            __bstack.args["b"] = b;
            const runner3 = new Runner(__ctx, __bstack, { state: __bstack, moduleId: "stdlib/data/wikidata.agency", scopeName: "__block_4" });
            try {
              await runner3.step(0, async (runner4) => {
                __bstack.locals.binding = __bstack.args.b ?? {};
              });
              await runner3.step(1, async (runner4) => {
                runner4.halt(await __call(mapValues, {
                  type: "named",
                  positionalArgs: [__bstack.locals.binding],
                  namedArgs: {},
                  blockArg: __AgencyFunction.create({ name: "__block_5", module: "stdlib/data/wikidata.agency", fn: async (cell, varName) => {
                    const __bsetup2 = setupFunction();
                    const __bstack2 = __bsetup2.stack;
                    const __self3 = __bstack2.locals;
                    const __bframe___block_5 = __bstack2;
                    __bstack2.args["cell"] = cell;
                    __bstack2.args["varName"] = varName;
                    const runner5 = new Runner(__ctx, __bstack2, { state: __bstack2, moduleId: "stdlib/data/wikidata.agency", scopeName: "__block_5" });
                    try {
                      await runner5.step(0, async (runner6) => {
                        __bstack2.locals.c = __bstack2.args.cell ?? {};
                      });
                      await runner5.step(1, async (runner6) => {
                        runner6.halt(__bstack2.locals.c.value ?? ``);
                        return;
                      });
                      return runner5.halted ? runner5.haltResult : void 0;
                    } catch (__blockError) {
                      if (__blockError instanceof AgencyAbort) {
                        return AbortedResult.fromError(__blockError, __bstack2, "__block_5");
                      }
                      throw __blockError;
                    } finally {
                      __bsetup2.stateStack.pop();
                    }
                  }, params: [{ name: "cell", hasDefault: false, defaultValue: void 0, variadic: false }, { name: "varName", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
                }));
                return;
              });
              return runner3.halted ? runner3.haltResult : void 0;
            } catch (__blockError) {
              if (__blockError instanceof AgencyAbort) {
                return AbortedResult.fromError(__blockError, __bstack, "__block_4");
              }
              throw __blockError;
            } finally {
              __bsetup.stateStack.pop();
            }
          }, params: [{ name: "b", hasDefault: false, defaultValue: void 0, variadic: false }], toolDefinition: null }, __toolRegistry)
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "parseBindings");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function parseBindings threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "parseBindings"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "parseBindings",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "parseBindings",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const parseBindings = __AgencyFunction.create({
  name: "parseBindings",
  module: "stdlib/data/wikidata.agency",
  fn: __parseBindings_impl,
  params: [{
    name: "raw",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "parseBindings",
    description: "No description provided.",
    schema: z.object({ "raw": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __wikidataError_impl(err) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["err"] = err;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "wikidataError", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("err" in __overrides) {
      err = __overrides["err"];
      __stack.args["err"] = err;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "wikidataError",
            args: {
              err
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(`Wikidata request failed (the API is rate-limited and expects a descriptive User-Agent): ${__stack.args.err.message ?? __stack.args.err}`);
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "wikidataError");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function wikidataError threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "wikidataError"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "wikidataError",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "wikidataError",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const wikidataError = __AgencyFunction.create({
  name: "wikidataError",
  module: "stdlib/data/wikidata.agency",
  fn: __wikidataError_impl,
  params: [{
    name: "err",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "wikidataError",
    description: "No description provided.",
    schema: z.object({ "err": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __searchFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "searchFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "searchFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_4 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_4),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_4.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_2 = await success(await __call(parseSearch, {
                type: "positional",
                args: [__stack.locals.body]
              }));
              if (hasInterrupts(__stack.locals.__armval_2)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_2);
                return;
              }
              if (isAborted(__stack.locals.__armval_2)) {
                runner3.halt(__stack.locals.__armval_2.carryThrough(__stack, "searchFinalize"));
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_2);
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_4),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_4.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_3 = failure(await __call(wikidataError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "searchFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_3)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_3);
                return;
              }
              if (isAborted(__stack.locals.__armval_3)) {
                runner3.halt(__stack.locals.__armval_3.carryThrough(__stack, "searchFinalize"));
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(1, __stack.locals.__armval_3);
              return;
            });
          }
        }
      ], void 0, { matchId: 1 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_1));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "searchFinalize");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function searchFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "searchFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "searchFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "searchFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const searchFinalize = __AgencyFunction.create({
  name: "searchFinalize",
  module: "stdlib/data/wikidata.agency",
  fn: __searchFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "searchFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __entityFinalize_impl(fetchResult, qid) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __stack.args["qid"] = qid;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "entityFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
    if ("qid" in __overrides) {
      qid = __overrides["qid"];
      __stack.args["qid"] = qid;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "entityFinalize",
            args: {
              fetchResult,
              qid
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_7 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_7),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_7.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.b = __stack.locals.body ?? {};
            });
            await runner2.step(2, async (runner3) => {
              __stack.locals.ents = await __call(values, {
                type: "positional",
                args: [__stack.locals.b.entities ?? {}]
              });
              if (hasInterrupts(__stack.locals.ents)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.ents);
                return;
              }
              if (isAborted(__stack.locals.ents)) {
                runner3.halt(__stack.locals.ents.carryThrough(__stack, "entityFinalize"));
                return;
              }
            });
            await runner2.ifElse(3, [
              {
                condition: async () => __eq(__stack.locals.ents.length, 0),
                body: async (runner3) => {
                  await runner3.step(0, async (runner4) => {
                    runner4.exitMatch(5, failure(`Wikidata returned no entity for ${__stack.args.qid}`, { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "entityFinalize", args: __stack.args }));
                    return;
                  });
                }
              }
            ]);
            await runner2.step(4, async (runner3) => {
              runner3.exitMatch(5, await success(await __call(parseEntity, {
                type: "positional",
                args: [__stack.locals.b, __stack.args.qid]
              })));
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_7),
          body: async (runner2) => {
            await runner2.step(5, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_7.error;
            });
            await runner2.step(6, async (runner3) => {
              __stack.locals.__armval_6 = failure(await __call(wikidataError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "entityFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_6)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_6);
                return;
              }
              if (isAborted(__stack.locals.__armval_6)) {
                runner3.halt(__stack.locals.__armval_6.carryThrough(__stack, "entityFinalize"));
                return;
              }
            });
            await runner2.step(7, async (runner3) => {
              runner3.exitMatch(5, __stack.locals.__armval_6);
              return;
            });
          }
        }
      ], void 0, { matchId: 5 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_5));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "entityFinalize");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function entityFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "entityFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "entityFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "entityFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const entityFinalize = __AgencyFunction.create({
  name: "entityFinalize",
  module: "stdlib/data/wikidata.agency",
  fn: __entityFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }, {
    name: "qid",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "entityFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any(), "qid": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __queryFinalize_impl(fetchResult) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["fetchResult"] = fetchResult;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "queryFinalize", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("fetchResult" in __overrides) {
      fetchResult = __overrides["fetchResult"];
      __stack.args["fetchResult"] = fetchResult;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "queryFinalize",
            args: {
              fetchResult
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        __stack.locals.__scrutinee_11 = __stack.args.fetchResult;
      });
      await runner.ifElse(2, [
        {
          condition: async () => await isSuccess(__stack.locals.__scrutinee_11),
          body: async (runner2) => {
            await runner2.step(0, async (runner3) => {
              __stack.locals.body = __stack.locals.__scrutinee_11.value;
            });
            await runner2.step(1, async (runner3) => {
              __stack.locals.__armval_9 = await success(await __call(parseBindings, {
                type: "positional",
                args: [__stack.locals.body]
              }));
              if (hasInterrupts(__stack.locals.__armval_9)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_9);
                return;
              }
              if (isAborted(__stack.locals.__armval_9)) {
                runner3.halt(__stack.locals.__armval_9.carryThrough(__stack, "queryFinalize"));
                return;
              }
            });
            await runner2.step(2, async (runner3) => {
              runner3.exitMatch(8, __stack.locals.__armval_9);
              return;
            });
          }
        },
        {
          condition: async () => await isFailure(__stack.locals.__scrutinee_11),
          body: async (runner2) => {
            await runner2.step(3, async (runner3) => {
              __stack.locals.err = __stack.locals.__scrutinee_11.error;
            });
            await runner2.step(4, async (runner3) => {
              __stack.locals.__armval_10 = failure(await __call(wikidataError, {
                type: "positional",
                args: [__stack.locals.err]
              }), { checkpoint: getRuntimeContext().ctx.getResultCheckpoint(), functionName: "queryFinalize", args: __stack.args });
              if (hasInterrupts(__stack.locals.__armval_10)) {
                await getRuntimeContext().ctx.pendingPromises.awaitAll();
                runner3.halt(__stack.locals.__armval_10);
                return;
              }
              if (isAborted(__stack.locals.__armval_10)) {
                runner3.halt(__stack.locals.__armval_10.carryThrough(__stack, "queryFinalize"));
                return;
              }
            });
            await runner2.step(5, async (runner3) => {
              runner3.exitMatch(8, __stack.locals.__armval_10);
              return;
            });
          }
        }
      ], void 0, { matchId: 8 });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(__nn(__stack.locals.__matchval_8));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "queryFinalize");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function queryFinalize threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "queryFinalize"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "queryFinalize",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "queryFinalize",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const queryFinalize = __AgencyFunction.create({
  name: "queryFinalize",
  module: "stdlib/data/wikidata.agency",
  fn: __queryFinalize_impl,
  params: [{
    name: "fetchResult",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: true
  }],
  toolDefinition: {
    name: "queryFinalize",
    description: "No description provided.",
    schema: z.object({ "fetchResult": z.any() })
  },
  exported: false
}, __toolRegistry);
async function __wikidataFetch_impl(base, domains, path2) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["base"] = base;
  __stack.args["domains"] = domains;
  __stack.args["path"] = path2;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "wikidataFetch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("base" in __overrides) {
      base = __overrides["base"];
      __stack.args["base"] = base;
    }
    if ("domains" in __overrides) {
      domains = __overrides["domains"];
      __stack.args["domains"] = domains;
    }
    if ("path" in __overrides) {
      path2 = __overrides["path"];
      __stack.args["path"] = path2;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "wikidataFetch",
            args: {
              base,
              domains,
              path: path2
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.handle(1, async (data) => {
        if (__eq(data.effect, `std::http::fetchJSON`)) {
          return await approve();
        }
      }, async (runner2) => {
        await runner2.step(0, async (runner3) => {
          __functionCompleted = true;
          runner3.halt(await __call(fetchJSON, {
            type: "named",
            positionalArgs: [],
            namedArgs: {
              baseUrl: __stack.args.base,
              path: __stack.args.path,
              headers: __globals().get("stdlib/data/wikidata.agency", "WD_HEADERS"),
              allowedDomains: __stack.args.domains
            }
          }));
          return;
        });
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "wikidataFetch");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function wikidataFetch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "wikidataFetch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "wikidataFetch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "wikidataFetch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const wikidataFetch = __AgencyFunction.create({
  name: "wikidataFetch",
  module: "stdlib/data/wikidata.agency",
  fn: __wikidataFetch_impl,
  params: [{
    name: "base",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "domains",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "path",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "wikidataFetch",
    description: "No description provided.",
    schema: z.object({ "base": z.string(), "domains": z.array(z.string()), "path": z.string() })
  },
  exported: false
}, __toolRegistry);
async function __wikidataSearch_impl(name, limit = __UNSET) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["name"] = name;
  __stack.args["limit"] = limit === __UNSET ? 5 : limit;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "wikidataSearch", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("name" in __overrides) {
      name = __overrides["name"];
      __stack.args["name"] = name;
    }
    if ("limit" in __overrides) {
      limit = __overrides["limit"];
      __stack.args["limit"] = limit;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "wikidataSearch",
            args: {
              name,
              limit
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::wikidata", `Search Wikidata for this name?`, {
            "op": `search`,
            "query": __stack.args.name
          }, "std::data/wikidata", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/wikidata.agency", scopeName: "wikidataSearch", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(wikidataFetch, {
          type: "positional",
          args: [__readStatic(WD_BASE, "WD_BASE", "stdlib/data/wikidata.agency"), __readStatic(WD_DOMAINS, "WD_DOMAINS", "stdlib/data/wikidata.agency"), await __call(buildSearchPath, {
            type: "positional",
            args: [__stack.args.name, __stack.args.limit]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "wikidataSearch"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(searchFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "wikidataSearch");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function wikidataSearch threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "wikidataSearch"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "wikidataSearch",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "wikidataSearch",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const wikidataSearch = __AgencyFunction.create({
  name: "wikidataSearch",
  module: "stdlib/data/wikidata.agency",
  fn: __wikidataSearch_impl,
  params: [{
    name: "name",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }, {
    name: "limit",
    hasDefault: true,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "wikidataSearch",
    description: `Search Wikidata for entities by name. Returns matches with QID, label, description, and URL. The
  QID identifies the entity for a follow-up entity fetch or SPARQL query. Empty result set returns an
  empty list.

  @param name - The person, organization, place, or thing to search for
  @param limit - Maximum number of matches to return (default 5)`,
    schema: z.object({ "name": z.string(), "limit": z.number().nullable().describe("Default: 5") })
  },
  exported: true
}, __toolRegistry);
async function __wikidataEntity_impl(qid) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["qid"] = qid;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "wikidataEntity", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("qid" in __overrides) {
      qid = __overrides["qid"];
      __stack.args["qid"] = qid;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "wikidataEntity",
            args: {
              qid
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::wikidata", `Fetch this Wikidata entity?`, {
            "op": `entity`,
            "query": __stack.args.qid
          }, "std::data/wikidata", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/wikidata.agency", scopeName: "wikidataEntity", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(wikidataFetch, {
          type: "positional",
          args: [__readStatic(WD_BASE, "WD_BASE", "stdlib/data/wikidata.agency"), __readStatic(WD_DOMAINS, "WD_DOMAINS", "stdlib/data/wikidata.agency"), await __call(buildEntityPath, {
            type: "positional",
            args: [__stack.args.qid]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "wikidataEntity"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(entityFinalize, {
          type: "positional",
          args: [__stack.locals.result, __stack.args.qid]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "wikidataEntity");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function wikidataEntity threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "wikidataEntity"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "wikidataEntity",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "wikidataEntity",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const wikidataEntity = __AgencyFunction.create({
  name: "wikidataEntity",
  module: "stdlib/data/wikidata.agency",
  fn: __wikidataEntity_impl,
  params: [{
    name: "qid",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "wikidataEntity",
    description: `Fetch one Wikidata entity by its QID. Returns the English label, description, aliases, and claims
  (property id to values; entity-valued claims are QIDs to resolve separately). Unknown QID returns
  a failure.

  @param qid - The Wikidata entity id, e.g. "Q42"`,
    schema: z.object({ "qid": z.string() })
  },
  exported: true
}, __toolRegistry);
async function __wikidataQuery_impl(sparql) {
  const __setupData = setupFunction();
  const __stack = __setupData.stack;
  const __step = __setupData.step;
  const __self = __setupData.self;
  const __ctx = getRuntimeContext().ctx;
  let __forked;
  let __functionCompleted = false;
  if (!__globals().isInitialized("stdlib/data/wikidata.agency")) {
    await __initializeGlobals(__ctx);
  }
  let __funcStartTime = performance.now();
  __stack.args["sparql"] = sparql;
  __self.__destructiveRan = __self.__destructiveRan ?? false;
  const runner = new Runner(__ctx, __stack, { state: __stack, moduleId: "stdlib/data/wikidata.agency", scopeName: "wikidataQuery", threads: __setupData.threads });
  let __resultCheckpointId = -1;
  if (__ctx._pendingArgOverrides) {
    const __overrides = __ctx._pendingArgOverrides;
    __ctx._pendingArgOverrides = void 0;
    if ("sparql" in __overrides) {
      sparql = __overrides["sparql"];
      __stack.args["sparql"] = sparql;
    }
  }
  try {
    await agencyStore.run({
      ...getRuntimeContext(),
      ctx: __ctx,
      stack: __setupData.stateStack,
      threads: __setupData.threads
    }, async () => {
      await runner.hook(0, async () => {
        await callHook({
          name: "onFunctionStart",
          data: {
            functionName: "wikidataQuery",
            args: {
              sparql
            },
            moduleId: "stdlib/data/wikidata.agency"
          }
        });
      });
      await runner.step(1, async (runner2) => {
        const __response = getRuntimeContext().ctx.getInterruptResponse(__self.__interruptId_1);
        if (__response) {
          if (__response.type === "approve") {
          } else if (__response.type === "reject") {
            runner2.halt(failure("interrupt rejected", { checkpoint: getRuntimeContext().ctx.getResultCheckpoint() }));
            return;
          }
        } else {
          const __handlerResult = await interruptWithHandlers("std::wikidata", `Run this SPARQL query against Wikidata?`, {
            "op": `query`,
            "query": __stack.args.sparql
          }, "std::data/wikidata", __ctx, __stateStack());
          if (isRejected(__handlerResult)) {
            runner2.halt(failure(__handlerResult.value ?? "interrupt rejected", { checkpoint: getRuntimeContext().ctx.checkpoints.get(__resultCheckpointId) }));
            return;
          }
          if (!isApproved(__handlerResult)) {
            __self.__interruptId_1 = __handlerResult[0].interruptId;
            const __checkpointId = getRuntimeContext().ctx.checkpoints.create(__stateStack(), __ctx, { moduleId: "stdlib/data/wikidata.agency", scopeName: "wikidataQuery", stepPath: "1" });
            __handlerResult[0].checkpointId = __checkpointId;
            __handlerResult[0].checkpoint = getRuntimeContext().ctx.checkpoints.get(__checkpointId);
            runner2.halt(__handlerResult);
            return;
          }
        }
      });
      await runner.step(2, async (runner2) => {
        __stack.locals.result = await __call(wikidataFetch, {
          type: "positional",
          args: [__readStatic(WDQS_BASE, "WDQS_BASE", "stdlib/data/wikidata.agency"), __readStatic(WDQS_DOMAINS, "WDQS_DOMAINS", "stdlib/data/wikidata.agency"), await __call(buildQueryPath, {
            type: "positional",
            args: [__stack.args.sparql]
          })]
        });
        if (hasInterrupts(__stack.locals.result)) {
          await getRuntimeContext().ctx.pendingPromises.awaitAll();
          runner2.halt(__stack.locals.result);
          return;
        }
        if (isAborted(__stack.locals.result)) {
          runner2.halt(__stack.locals.result.carryThrough(__stack, "wikidataQuery"));
          return;
        }
      });
      await runner.step(3, async (runner2) => {
        __functionCompleted = true;
        runner2.halt(await __call(queryFinalize, {
          type: "positional",
          args: [__stack.locals.result]
        }));
        return;
      });
    });
    if (runner.halted) {
      if (isFailure(runner.haltResult)) {
        stampFailureBoundary(runner.haltResult, __self.__destructiveRan);
      }
      return runner.haltResult;
    }
  } catch (__error) {
    if (__error instanceof RestoreSignal) {
      throw __error;
    }
    if (__error instanceof AgencyAbort) {
      return AbortedResult.fromError(__error, __stack, "wikidataQuery");
    }
    {
      const __errMsg = __error instanceof Error ? __error.message : String(__error);
      const __errStack = __error instanceof Error && __error.stack ? __error.stack : "";
      const __log = __createLogger(__ctx.logLevel);
      __log.error("Function wikidataQuery threw an exception (converted to Failure): " + __errMsg);
      if (__errStack) __log.error(__errStack);
      __ctx.statelogClient?.error?.({
        errorType: "runtimeError",
        message: __errMsg,
        functionName: "wikidataQuery"
      });
    }
    return failure(
      __error instanceof Error ? __error.message : String(__error),
      {
        checkpoint: getRuntimeContext().ctx.getResultCheckpoint(),
        destructiveRan: __self.__destructiveRan,
        functionName: "wikidataQuery",
        args: __stack.args
      }
    );
  } finally {
    __stateStack()?.pop();
    if (__functionCompleted) {
      await callHook({
        name: "onFunctionEnd",
        data: {
          functionName: "wikidataQuery",
          timeTaken: performance.now() - __funcStartTime
        }
      });
    }
  }
}
const wikidataQuery = __AgencyFunction.create({
  name: "wikidataQuery",
  module: "stdlib/data/wikidata.agency",
  fn: __wikidataQuery_impl,
  params: [{
    name: "sparql",
    hasDefault: false,
    defaultValue: void 0,
    variadic: false,
    isFunctionTyped: false,
    acceptsResult: false
  }],
  toolDefinition: {
    name: "wikidataQuery",
    description: `Run a SPARQL query against the Wikidata Query Service and return rows (each a map of the SELECTed
  variable names to string values). Prefixes wd:/wdt:/rdfs: and SERVICE wikibase:label are available.
  Example: SELECT ?item ?itemLabel WHERE { ?item wdt:P31 wd:Q5 . SERVICE wikibase:label { bd:serviceParam wikibase:language "en" } } LIMIT 10

  @param sparql - The SPARQL query text`,
    schema: z.object({ "sparql": z.string() })
  },
  exported: true
}, __toolRegistry);
var stdin_default = graph;
const __sourceMap = { "stdlib/data/wikidata.agency:buildSearchPath": { "1": { "line": 65, "col": 2 }, "2": { "line": 66, "col": 2 } }, "stdlib/data/wikidata.agency:buildEntityPath": { "1": { "line": 71, "col": 2 } }, "stdlib/data/wikidata.agency:buildQueryPath": { "1": { "line": 76, "col": 2 }, "2": { "line": 77, "col": 2 } }, "stdlib/data/wikidata.agency:parseSearch": { "1": { "line": 82, "col": 2 }, "2": { "line": 83, "col": 2 }, "3": { "line": 84, "col": 2 } }, "stdlib/data/wikidata.agency:__block_0": { "3.0": { "line": 85, "col": 4 }, "3.1": { "line": 86, "col": 4 } }, "stdlib/data/wikidata.agency:parseClaimValue": { "1": { "line": 98, "col": 2 }, "2": { "line": 99, "col": 2 }, "3": { "line": 102, "col": 2 }, "4": { "line": 103, "col": 2 }, "5": { "line": 104, "col": 2 }, "6": { "line": 105, "col": 2 }, "7": { "line": 108, "col": 2 }, "8": { "line": 111, "col": 2 }, "9": { "line": 114, "col": 2 }, "10": { "line": 117, "col": 2 }, "11": { "line": 120, "col": 2 }, "12": { "line": 123, "col": 2 }, "2.0": { "line": 100, "col": 4 }, "6.0": { "line": 106, "col": 4 }, "7.0": { "line": 109, "col": 4 }, "8.0": { "line": 112, "col": 4 }, "9.0": { "line": 115, "col": 4 }, "10.0": { "line": 118, "col": 4 }, "11.0": { "line": 121, "col": 4 } }, "stdlib/data/wikidata.agency:parseClaimList": { "1": { "line": 128, "col": 2 }, "2": { "line": 129, "col": 2 } }, "stdlib/data/wikidata.agency:__block_1": { "2.0": { "line": 130, "col": 4 }, "2.1": { "line": 131, "col": 4 } }, "stdlib/data/wikidata.agency:parseClaims": { "1": { "line": 137, "col": 2 }, "2": { "line": 138, "col": 2 } }, "stdlib/data/wikidata.agency:__block_2": { "2.0": { "line": 139, "col": 4 } }, "stdlib/data/wikidata.agency:parseEntity": { "1": { "line": 145, "col": 2 }, "2": { "line": 146, "col": 2 }, "3": { "line": 147, "col": 2 }, "4": { "line": 148, "col": 2 }, "5": { "line": 149, "col": 2 }, "6": { "line": 150, "col": 2 }, "7": { "line": 151, "col": 2 }, "8": { "line": 152, "col": 2 }, "9": { "line": 153, "col": 2 }, "10": { "line": 154, "col": 2 } }, "stdlib/data/wikidata.agency:__block_3": { "10.0": { "line": 159, "col": 6 }, "10.1": { "line": 160, "col": 6 } }, "stdlib/data/wikidata.agency:parseBindings": { "1": { "line": 168, "col": 2 }, "2": { "line": 169, "col": 2 }, "3": { "line": 170, "col": 2 }, "4": { "line": 171, "col": 2 } }, "stdlib/data/wikidata.agency:__block_4": { "4.0": { "line": 172, "col": 4 }, "4.1": { "line": 173, "col": 4 } }, "stdlib/data/wikidata.agency:__block_5": { "4.1.0": { "line": 174, "col": 6 }, "4.1.1": { "line": 175, "col": 6 } }, "stdlib/data/wikidata.agency:wikidataError": { "1": { "line": 182, "col": 2 } }, "stdlib/data/wikidata.agency:searchFinalize": { "1": { "line": 187, "col": 9 }, "2": { "line": 187, "col": 9 }, "3": { "line": 187, "col": 2 }, "2.0": { "line": 187, "col": 9 }, "2.1": { "line": 188, "col": 21 }, "2.2": { "line": 188, "col": 21 }, "2.3": { "line": 187, "col": 9 }, "2.4": { "line": 189, "col": 20 }, "2.5": { "line": 189, "col": 20 } }, "stdlib/data/wikidata.agency:entityFinalize": { "1": { "line": 195, "col": 9 }, "2": { "line": 195, "col": 9 }, "3": { "line": 195, "col": 2 }, "2.0": { "line": 195, "col": 9 }, "2.1": { "line": 197, "col": 6 }, "2.2": { "line": 198, "col": 6 }, "2.3.0": { "line": 200, "col": 8 }, "2.3": { "line": 199, "col": 6 }, "2.4": { "line": 202, "col": 6 }, "2.5": { "line": 195, "col": 9 }, "2.6": { "line": 204, "col": 20 }, "2.7": { "line": 204, "col": 20 } }, "stdlib/data/wikidata.agency:queryFinalize": { "1": { "line": 210, "col": 9 }, "2": { "line": 210, "col": 9 }, "3": { "line": 210, "col": 2 }, "2.0": { "line": 210, "col": 9 }, "2.1": { "line": 211, "col": 21 }, "2.2": { "line": 211, "col": 21 }, "2.3": { "line": 210, "col": 9 }, "2.4": { "line": 212, "col": 20 }, "2.5": { "line": 212, "col": 20 } }, "stdlib/data/wikidata.agency:wikidataFetch": { "1": { "line": 221, "col": 2 }, "1.0": { "line": 222, "col": 4 } }, "stdlib/data/wikidata.agency:wikidataSearch": { "1": { "line": 239, "col": 2 }, "2": { "line": 240, "col": 2 }, "3": { "line": 241, "col": 2 } }, "stdlib/data/wikidata.agency:wikidataEntity": { "1": { "line": 252, "col": 2 }, "2": { "line": 253, "col": 2 }, "3": { "line": 254, "col": 2 } }, "stdlib/data/wikidata.agency:wikidataQuery": { "1": { "line": 265, "col": 2 }, "2": { "line": 266, "col": 2 }, "3": { "line": 267, "col": 2 } } };
export {
  Entity,
  EntityDetail,
  __getCheckpoints,
  __invokeFunction,
  __setDebugger,
  __setLLMClient,
  __setTraceFile,
  __sourceMap,
  __toolRegistry,
  approve,
  buildEntityPath,
  buildQueryPath,
  buildSearchPath,
  stdin_default as default,
  entityFinalize,
  hasInterrupts,
  interrupt,
  isDebugger,
  isInterrupt,
  parseBindings,
  parseClaimList,
  parseClaimValue,
  parseClaims,
  parseEntity,
  parseSearch,
  queryFinalize,
  reject,
  respondToInterrupts,
  rewindFrom,
  searchFinalize,
  wikidataEntity,
  wikidataError,
  wikidataFetch,
  wikidataQuery,
  wikidataSearch
};
